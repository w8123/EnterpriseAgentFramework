const bi = "__reachai.navigate";
function As(e = {}) {
  const t = e.pageInstanceId || Zo(), n = Math.max(1e3, e.actionTimeoutMs || 15e3), s = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Set();
  function a() {
    return Array.from(s.keys()).map((d) => ({
      actionKey: d,
      ...r.get(d) || {}
    }));
  }
  function u(d) {
    i.forEach((g) => g(d));
  }
  function h() {
    const d = a();
    o.forEach((g) => g(d));
  }
  return {
    pageInstanceId: t,
    route: e.route,
    get registeredActions() {
      return Array.from(s.keys());
    },
    get actionDefinitions() {
      return a();
    },
    registerAction(d, g, w = {}) {
      return s.set(d, g), r.set(d, w), h(), () => {
        s.delete(d), r.delete(d), h();
      };
    },
    async handleEvent(d, g) {
      var x;
      if (!Qo(d)) return null;
      const w = (x = d.target) == null ? void 0 : x.pageInstanceId;
      if (w && w !== t) return null;
      if (d.actionKey === bi) {
        const $ = await wr(d, e.confirmAction);
        if (!$.accepted) {
          const y = et(
            d,
            "USER_CANCELLED",
            void 0,
            `Action was cancelled: ${d.actionKey}`
          );
          return u(y), y;
        }
        if (!await _r(d, g)) {
          const y = vr(d);
          return u(y), y;
        }
        const I = await Vo(d, e.onNavigate);
        return $.confirmed && (I.userConfirmed = !0), u(I), I;
      }
      const R = s.get(d.actionKey);
      if (!R) {
        const $ = et(
          d,
          "ACTION_NOT_FOUND",
          void 0,
          void 0,
          `Action is not registered: ${d.actionKey}`
        );
        return u($), $;
      }
      const P = await wr(d, e.confirmAction);
      if (!P.accepted) {
        const $ = et(
          d,
          "USER_CANCELLED",
          void 0,
          `Action was cancelled: ${d.actionKey}`
        );
        return u($), $;
      }
      if (!await _r(d, g)) {
        const $ = vr(d);
        return u($), $;
      }
      try {
        const $ = await Xo(R(d.args || {}, d), n), I = zo(d, $);
        return P.confirmed && (I.userConfirmed = !0), u(I), I;
      } catch ($) {
        const I = $ instanceof Error ? $.message : String($), y = et(
          d,
          I === "Page action timed out" ? "TIMEOUT" : "FAILED",
          void 0,
          void 0,
          I
        );
        return u(y), y;
      }
    },
    onResult(d) {
      return i.add(d), () => i.delete(d);
    },
    onActionDefinitionsChange(d) {
      return o.add(d), () => o.delete(d);
    }
  };
}
async function _r(e, t) {
  return t != null && t.beforeExecute ? await t.beforeExecute(e) : !0;
}
function vr(e) {
  return et(
    e,
    "TIMEOUT",
    void 0,
    void 0,
    "Page action request expired before execution"
  );
}
async function Vo(e, t) {
  var r, i;
  const n = Yt((r = e.metadata) == null ? void 0 : r.pageKey), s = Yt((i = e.metadata) == null ? void 0 : i.route);
  if (!n)
    return et(
      e,
      "FAILED",
      void 0,
      void 0,
      "Cross-route navigation is missing metadata.pageKey"
    );
  if (!t)
    return et(
      e,
      "ACTION_NOT_FOUND",
      void 0,
      void 0,
      "Cross-route navigation is not configured. Set createEafPageBridge({ onNavigate })."
    );
  try {
    return await t({
      requestId: e.requestId,
      targetPageKey: n,
      route: s,
      title: Yt(e.title),
      metadata: e.metadata
    }), et(e, "SUCCESS", {
      pageKey: n,
      route: s,
      ready: !1
    }, "Navigation started");
  } catch (o) {
    return et(
      e,
      "FAILED",
      void 0,
      void 0,
      o instanceof Error ? o.message : String(o)
    );
  }
}
async function wr(e, t) {
  return e.confirm ? t ? { accepted: await t(e), confirmed: !0 } : { accepted: await Wo(e), confirmed: !0 } : { accepted: !0, confirmed: !1 };
}
function Wo(e) {
  if (typeof document > "u" || !document.body) return Promise.resolve(!1);
  const t = document.querySelector("[data-reachai-page-action-confirm]");
  return t == null || t.remove(), new Promise((n) => {
    const s = document.createElement("div");
    s.dataset.reachaiPageActionConfirm = e.requestId, s.setAttribute("role", "presentation"), Object.assign(s.style, {
      position: "fixed",
      inset: "0",
      zIndex: "2147483647",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: "24px",
      background: "rgba(15, 23, 42, 0.48)"
    });
    const r = document.createElement("section");
    r.setAttribute("role", "alertdialog"), r.setAttribute("aria-modal", "true"), r.setAttribute("aria-labelledby", `reachai-confirm-title-${e.requestId}`), r.setAttribute("aria-describedby", `reachai-confirm-message-${e.requestId}`), Object.assign(r.style, {
      width: "min(440px, calc(100vw - 48px))",
      borderRadius: "16px",
      padding: "22px",
      color: "#172033",
      background: "#fff",
      boxShadow: "0 24px 72px rgba(15, 23, 42, 0.28)",
      fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
    });
    const i = document.createElement("div");
    i.textContent = "ReachAI 页面操作确认", Object.assign(i.style, {
      marginBottom: "8px",
      color: "#0b7a59",
      fontSize: "13px",
      fontWeight: "700"
    });
    const o = document.createElement("h2");
    o.id = `reachai-confirm-title-${e.requestId}`, o.textContent = e.title || e.actionKey, Object.assign(o.style, {
      margin: "0 0 10px",
      fontSize: "20px",
      lineHeight: "1.4"
    });
    const a = document.createElement("p");
    a.id = `reachai-confirm-message-${e.requestId}`, a.textContent = "此操作会修改当前业务页面数据。确认后 ReachAI 才会领取请求并调用页面动作。", Object.assign(a.style, {
      margin: "0 0 20px",
      color: "#52605f",
      fontSize: "14px",
      lineHeight: "1.7"
    });
    const u = document.createElement("div");
    Object.assign(u.style, {
      display: "flex",
      justifyContent: "flex-end",
      gap: "10px"
    });
    const h = Sr("取消", !1), d = Sr("确认执行", !0);
    u.append(h, d), r.append(i, o, a, u), s.append(r), document.body.append(s);
    let g = !1;
    const w = (P) => {
      g || (g = !0, document.removeEventListener("keydown", R, !0), s.remove(), n(P));
    }, R = (P) => {
      P.key === "Escape" && (P.preventDefault(), w(!1));
    };
    h.addEventListener("click", () => w(!1), { once: !0 }), d.addEventListener("click", () => w(!0), { once: !0 }), document.addEventListener("keydown", R, !0), d.focus();
  });
}
function Sr(e, t) {
  const n = document.createElement("button");
  return n.type = "button", n.textContent = e, Object.assign(n.style, {
    minWidth: "96px",
    border: t ? "1px solid #0b7a59" : "1px solid #d7dee7",
    borderRadius: "9px",
    padding: "9px 14px",
    color: t ? "#fff" : "#344054",
    background: t ? "#0b7a59" : "#fff",
    cursor: "pointer",
    fontSize: "14px",
    fontWeight: "600"
  }), n;
}
function et(e, t, n, s, r) {
  return {
    protocolVersion: e.protocolVersion || "1.0",
    type: "page.action.result",
    requestId: e.requestId,
    actionKey: e.actionKey,
    status: t,
    data: n,
    message: s,
    error: r
  };
}
function zo(e, t) {
  if (!t || typeof t != "object" || Array.isArray(t))
    return et(e, "SUCCESS", t);
  const n = t, s = Go(n.status);
  if (!s)
    return et(e, "SUCCESS", t);
  const r = Object.prototype.hasOwnProperty.call(n, "data") ? n.data : t;
  return et(
    e,
    s,
    r,
    Yt(n.message),
    Yo(n.error)
  );
}
function Go(e) {
  if (typeof e != "string") return;
  const t = e.trim().toUpperCase();
  return t === "WARN" ? "PRECONDITION_FAILED" : t === "ERROR" ? "FAILED" : Jo(t) ? t : void 0;
}
function Jo(e) {
  return e === "SUCCESS" || e === "NO_DATA" || e === "PRECONDITION_FAILED" || e === "USER_CANCELLED" || e === "FAILED" || e === "CANCELLED" || e === "ACTION_NOT_FOUND" || e === "FORBIDDEN" || e === "TIMEOUT";
}
function Yt(e) {
  return typeof e == "string" && e.trim() ? e.trim() : void 0;
}
function Yo(e) {
  if (typeof e == "string") return Yt(e);
  if (e && typeof e == "object")
    return Yt(e.message);
}
async function Xo(e, t) {
  let n;
  try {
    return await Promise.race([
      Promise.resolve(e),
      new Promise((s, r) => {
        n = setTimeout(() => r(new Error("Page action timed out")), t);
      })
    ]);
  } catch (s) {
    throw s instanceof Error && s.message === "Page action timed out", s;
  } finally {
    n && clearTimeout(n);
  }
}
function Qo(e) {
  if (!e || typeof e != "object") return !1;
  const t = e;
  return t.type === "page.action.requested" && typeof t.requestId == "string" && typeof t.actionKey == "string";
}
function Zo() {
  return typeof crypto < "u" && "randomUUID" in crypto ? `page-${crypto.randomUUID()}` : `page-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}
/**
* @vue/shared v3.5.31
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
// @__NO_SIDE_EFFECTS__
function Ks(e) {
  const t = /* @__PURE__ */ Object.create(null);
  for (const n of e.split(",")) t[n] = 1;
  return (n) => n in t;
}
const he = {}, Xt = [], ht = () => {
}, _i = () => !1, zn = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && // uppercase letter
(e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97), Gn = (e) => e.startsWith("onUpdate:"), ve = Object.assign, Us = (e, t) => {
  const n = e.indexOf(t);
  n > -1 && e.splice(n, 1);
}, ea = Object.prototype.hasOwnProperty, le = (e, t) => ea.call(e, t), J = Array.isArray, Qt = (e) => En(e) === "[object Map]", Jn = (e) => En(e) === "[object Set]", Ir = (e) => En(e) === "[object Date]", ne = (e) => typeof e == "function", be = (e) => typeof e == "string", st = (e) => typeof e == "symbol", ue = (e) => e !== null && typeof e == "object", vi = (e) => (ue(e) || ne(e)) && ne(e.then) && ne(e.catch), wi = Object.prototype.toString, En = (e) => wi.call(e), ta = (e) => En(e).slice(8, -1), Yn = (e) => En(e) === "[object Object]", Bs = (e) => be(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e, dn = /* @__PURE__ */ Ks(
  // the leading comma is intentional so empty string "" is also included
  ",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"
), Xn = (e) => {
  const t = /* @__PURE__ */ Object.create(null);
  return ((n) => t[n] || (t[n] = e(n)));
}, na = /-\w/g, xe = Xn(
  (e) => e.replace(na, (t) => t.slice(1).toUpperCase())
), sa = /\B([A-Z])/g, Ze = Xn(
  (e) => e.replace(sa, "-$1").toLowerCase()
), Qn = Xn((e) => e.charAt(0).toUpperCase() + e.slice(1)), cs = Xn(
  (e) => e ? `on${Qn(e)}` : ""
), ft = (e, t) => !Object.is(e, t), Mn = (e, ...t) => {
  for (let n = 0; n < e.length; n++)
    e[n](...t);
}, Si = (e, t, n, s = !1) => {
  Object.defineProperty(e, t, {
    configurable: !0,
    enumerable: !1,
    writable: s,
    value: n
  });
}, Hs = (e) => {
  const t = parseFloat(e);
  return isNaN(t) ? e : t;
}, Ar = (e) => {
  const t = be(e) ? Number(e) : NaN;
  return isNaN(t) ? e : t;
};
let Er;
const Zn = () => Er || (Er = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {});
function xn(e) {
  if (J(e)) {
    const t = {};
    for (let n = 0; n < e.length; n++) {
      const s = e[n], r = be(s) ? aa(s) : xn(s);
      if (r)
        for (const i in r)
          t[i] = r[i];
    }
    return t;
  } else if (be(e) || ue(e))
    return e;
}
const ra = /;(?![^(]*\))/g, ia = /:([^]+)/, oa = /\/\*[^]*?\*\//g;
function aa(e) {
  const t = {};
  return e.replace(oa, "").split(ra).forEach((n) => {
    if (n) {
      const s = n.split(ia);
      s.length > 1 && (t[s[0].trim()] = s[1].trim());
    }
  }), t;
}
function Oe(e) {
  let t = "";
  if (be(e))
    t = e;
  else if (J(e))
    for (let n = 0; n < e.length; n++) {
      const s = Oe(e[n]);
      s && (t += s + " ");
    }
  else if (ue(e))
    for (const n in e)
      e[n] && (t += n + " ");
  return t.trim();
}
function la(e) {
  if (!e) return null;
  let { class: t, style: n } = e;
  return t && !be(t) && (e.class = Oe(t)), n && (e.style = xn(n)), e;
}
const ca = "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly", ua = /* @__PURE__ */ Ks(ca);
function Ii(e) {
  return !!e || e === "";
}
function da(e, t) {
  if (e.length !== t.length) return !1;
  let n = !0;
  for (let s = 0; n && s < e.length; s++)
    n = Bt(e[s], t[s]);
  return n;
}
function Bt(e, t) {
  if (e === t) return !0;
  let n = Ir(e), s = Ir(t);
  if (n || s)
    return n && s ? e.getTime() === t.getTime() : !1;
  if (n = st(e), s = st(t), n || s)
    return e === t;
  if (n = J(e), s = J(t), n || s)
    return n && s ? da(e, t) : !1;
  if (n = ue(e), s = ue(t), n || s) {
    if (!n || !s)
      return !1;
    const r = Object.keys(e).length, i = Object.keys(t).length;
    if (r !== i)
      return !1;
    for (const o in e) {
      const a = e.hasOwnProperty(o), u = t.hasOwnProperty(o);
      if (a && !u || !a && u || !Bt(e[o], t[o]))
        return !1;
    }
  }
  return String(e) === String(t);
}
function Ai(e, t) {
  return e.findIndex((n) => Bt(n, t));
}
const Ei = (e) => !!(e && e.__v_isRef === !0), Z = (e) => be(e) ? e : e == null ? "" : J(e) || ue(e) && (e.toString === wi || !ne(e.toString)) ? Ei(e) ? Z(e.value) : JSON.stringify(e, xi, 2) : String(e), xi = (e, t) => Ei(t) ? xi(e, t.value) : Qt(t) ? {
  [`Map(${t.size})`]: [...t.entries()].reduce(
    (n, [s, r], i) => (n[us(s, i) + " =>"] = r, n),
    {}
  )
} : Jn(t) ? {
  [`Set(${t.size})`]: [...t.values()].map((n) => us(n))
} : st(t) ? us(t) : ue(t) && !J(t) && !Yn(t) ? String(t) : t, us = (e, t = "") => {
  var n;
  return (
    // Symbol.description in es2019+ so we need to cast here to pass
    // the lib: es2016 check
    st(e) ? `Symbol(${(n = e.description) != null ? n : t})` : e
  );
};
/**
* @vue/reactivity v3.5.31
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
let Ue;
class fa {
  // TODO isolatedDeclarations "__v_skip"
  constructor(t = !1) {
    this.detached = t, this._active = !0, this._on = 0, this.effects = [], this.cleanups = [], this._isPaused = !1, this.__v_skip = !0, this.parent = Ue, !t && Ue && (this.index = (Ue.scopes || (Ue.scopes = [])).push(
      this
    ) - 1);
  }
  get active() {
    return this._active;
  }
  pause() {
    if (this._active) {
      this._isPaused = !0;
      let t, n;
      if (this.scopes)
        for (t = 0, n = this.scopes.length; t < n; t++)
          this.scopes[t].pause();
      for (t = 0, n = this.effects.length; t < n; t++)
        this.effects[t].pause();
    }
  }
  /**
   * Resumes the effect scope, including all child scopes and effects.
   */
  resume() {
    if (this._active && this._isPaused) {
      this._isPaused = !1;
      let t, n;
      if (this.scopes)
        for (t = 0, n = this.scopes.length; t < n; t++)
          this.scopes[t].resume();
      for (t = 0, n = this.effects.length; t < n; t++)
        this.effects[t].resume();
    }
  }
  run(t) {
    if (this._active) {
      const n = Ue;
      try {
        return Ue = this, t();
      } finally {
        Ue = n;
      }
    }
  }
  /**
   * This should only be called on non-detached scopes
   * @internal
   */
  on() {
    ++this._on === 1 && (this.prevScope = Ue, Ue = this);
  }
  /**
   * This should only be called on non-detached scopes
   * @internal
   */
  off() {
    this._on > 0 && --this._on === 0 && (Ue = this.prevScope, this.prevScope = void 0);
  }
  stop(t) {
    if (this._active) {
      this._active = !1;
      let n, s;
      for (n = 0, s = this.effects.length; n < s; n++)
        this.effects[n].stop();
      for (this.effects.length = 0, n = 0, s = this.cleanups.length; n < s; n++)
        this.cleanups[n]();
      if (this.cleanups.length = 0, this.scopes) {
        for (n = 0, s = this.scopes.length; n < s; n++)
          this.scopes[n].stop(!0);
        this.scopes.length = 0;
      }
      if (!this.detached && this.parent && !t) {
        const r = this.parent.scopes.pop();
        r && r !== this && (this.parent.scopes[this.index] = r, r.index = this.index);
      }
      this.parent = void 0;
    }
  }
}
function ha() {
  return Ue;
}
let ge;
const ds = /* @__PURE__ */ new WeakSet();
class Ci {
  constructor(t) {
    this.fn = t, this.deps = void 0, this.depsTail = void 0, this.flags = 5, this.next = void 0, this.cleanup = void 0, this.scheduler = void 0, Ue && Ue.active && Ue.effects.push(this);
  }
  pause() {
    this.flags |= 64;
  }
  resume() {
    this.flags & 64 && (this.flags &= -65, ds.has(this) && (ds.delete(this), this.trigger()));
  }
  /**
   * @internal
   */
  notify() {
    this.flags & 2 && !(this.flags & 32) || this.flags & 8 || Pi(this);
  }
  run() {
    if (!(this.flags & 1))
      return this.fn();
    this.flags |= 2, xr(this), Ti(this);
    const t = ge, n = nt;
    ge = this, nt = !0;
    try {
      return this.fn();
    } finally {
      Ri(this), ge = t, nt = n, this.flags &= -3;
    }
  }
  stop() {
    if (this.flags & 1) {
      for (let t = this.deps; t; t = t.nextDep)
        zs(t);
      this.deps = this.depsTail = void 0, xr(this), this.onStop && this.onStop(), this.flags &= -2;
    }
  }
  trigger() {
    this.flags & 64 ? ds.add(this) : this.scheduler ? this.scheduler() : this.runIfDirty();
  }
  /**
   * @internal
   */
  runIfDirty() {
    Es(this) && this.run();
  }
  get dirty() {
    return Es(this);
  }
}
let ki = 0, fn, hn;
function Pi(e, t = !1) {
  if (e.flags |= 8, t) {
    e.next = hn, hn = e;
    return;
  }
  e.next = fn, fn = e;
}
function Vs() {
  ki++;
}
function Ws() {
  if (--ki > 0)
    return;
  if (hn) {
    let t = hn;
    for (hn = void 0; t; ) {
      const n = t.next;
      t.next = void 0, t.flags &= -9, t = n;
    }
  }
  let e;
  for (; fn; ) {
    let t = fn;
    for (fn = void 0; t; ) {
      const n = t.next;
      if (t.next = void 0, t.flags &= -9, t.flags & 1)
        try {
          t.trigger();
        } catch (s) {
          e || (e = s);
        }
      t = n;
    }
  }
  if (e) throw e;
}
function Ti(e) {
  for (let t = e.deps; t; t = t.nextDep)
    t.version = -1, t.prevActiveLink = t.dep.activeLink, t.dep.activeLink = t;
}
function Ri(e) {
  let t, n = e.depsTail, s = n;
  for (; s; ) {
    const r = s.prevDep;
    s.version === -1 ? (s === n && (n = r), zs(s), pa(s)) : t = s, s.dep.activeLink = s.prevActiveLink, s.prevActiveLink = void 0, s = r;
  }
  e.deps = t, e.depsTail = n;
}
function Es(e) {
  for (let t = e.deps; t; t = t.nextDep)
    if (t.dep.version !== t.version || t.dep.computed && ($i(t.dep.computed) || t.dep.version !== t.version))
      return !0;
  return !!e._dirty;
}
function $i(e) {
  if (e.flags & 4 && !(e.flags & 16) || (e.flags &= -17, e.globalVersion === bn) || (e.globalVersion = bn, !e.isSSR && e.flags & 128 && (!e.deps && !e._dirty || !Es(e))))
    return;
  e.flags |= 2;
  const t = e.dep, n = ge, s = nt;
  ge = e, nt = !0;
  try {
    Ti(e);
    const r = e.fn(e._value);
    (t.version === 0 || ft(r, e._value)) && (e.flags |= 128, e._value = r, t.version++);
  } catch (r) {
    throw t.version++, r;
  } finally {
    ge = n, nt = s, Ri(e), e.flags &= -3;
  }
}
function zs(e, t = !1) {
  const { dep: n, prevSub: s, nextSub: r } = e;
  if (s && (s.nextSub = r, e.prevSub = void 0), r && (r.prevSub = s, e.nextSub = void 0), n.subs === e && (n.subs = s, !s && n.computed)) {
    n.computed.flags &= -5;
    for (let i = n.computed.deps; i; i = i.nextDep)
      zs(i, !0);
  }
  !t && !--n.sc && n.map && n.map.delete(n.key);
}
function pa(e) {
  const { prevDep: t, nextDep: n } = e;
  t && (t.nextDep = n, e.prevDep = void 0), n && (n.prevDep = t, e.nextDep = void 0);
}
let nt = !0;
const Mi = [];
function Ct() {
  Mi.push(nt), nt = !1;
}
function kt() {
  const e = Mi.pop();
  nt = e === void 0 ? !0 : e;
}
function xr(e) {
  const { cleanup: t } = e;
  if (e.cleanup = void 0, t) {
    const n = ge;
    ge = void 0;
    try {
      t();
    } finally {
      ge = n;
    }
  }
}
let bn = 0;
class ga {
  constructor(t, n) {
    this.sub = t, this.dep = n, this.version = n.version, this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0;
  }
}
class Gs {
  // TODO isolatedDeclarations "__v_skip"
  constructor(t) {
    this.computed = t, this.version = 0, this.activeLink = void 0, this.subs = void 0, this.map = void 0, this.key = void 0, this.sc = 0, this.__v_skip = !0;
  }
  track(t) {
    if (!ge || !nt || ge === this.computed)
      return;
    let n = this.activeLink;
    if (n === void 0 || n.sub !== ge)
      n = this.activeLink = new ga(ge, this), ge.deps ? (n.prevDep = ge.depsTail, ge.depsTail.nextDep = n, ge.depsTail = n) : ge.deps = ge.depsTail = n, Oi(n);
    else if (n.version === -1 && (n.version = this.version, n.nextDep)) {
      const s = n.nextDep;
      s.prevDep = n.prevDep, n.prevDep && (n.prevDep.nextDep = s), n.prevDep = ge.depsTail, n.nextDep = void 0, ge.depsTail.nextDep = n, ge.depsTail = n, ge.deps === n && (ge.deps = s);
    }
    return n;
  }
  trigger(t) {
    this.version++, bn++, this.notify(t);
  }
  notify(t) {
    Vs();
    try {
      for (let n = this.subs; n; n = n.prevSub)
        n.sub.notify() && n.sub.dep.notify();
    } finally {
      Ws();
    }
  }
}
function Oi(e) {
  if (e.dep.sc++, e.sub.flags & 4) {
    const t = e.dep.computed;
    if (t && !e.dep.subs) {
      t.flags |= 20;
      for (let s = t.deps; s; s = s.nextDep)
        Oi(s);
    }
    const n = e.dep.subs;
    n !== e && (e.prevSub = n, n && (n.nextSub = e)), e.dep.subs = e;
  }
}
const xs = /* @__PURE__ */ new WeakMap(), jt = /* @__PURE__ */ Symbol(
  ""
), Cs = /* @__PURE__ */ Symbol(
  ""
), _n = /* @__PURE__ */ Symbol(
  ""
);
function $e(e, t, n) {
  if (nt && ge) {
    let s = xs.get(e);
    s || xs.set(e, s = /* @__PURE__ */ new Map());
    let r = s.get(n);
    r || (s.set(n, r = new Gs()), r.map = s, r.key = n), r.track();
  }
}
function It(e, t, n, s, r, i) {
  const o = xs.get(e);
  if (!o) {
    bn++;
    return;
  }
  const a = (u) => {
    u && u.trigger();
  };
  if (Vs(), t === "clear")
    o.forEach(a);
  else {
    const u = J(e), h = u && Bs(n);
    if (u && n === "length") {
      const d = Number(s);
      o.forEach((g, w) => {
        (w === "length" || w === _n || !st(w) && w >= d) && a(g);
      });
    } else
      switch ((n !== void 0 || o.has(void 0)) && a(o.get(n)), h && a(o.get(_n)), t) {
        case "add":
          u ? h && a(o.get("length")) : (a(o.get(jt)), Qt(e) && a(o.get(Cs)));
          break;
        case "delete":
          u || (a(o.get(jt)), Qt(e) && a(o.get(Cs)));
          break;
        case "set":
          Qt(e) && a(o.get(jt));
          break;
      }
  }
  Ws();
}
function Vt(e) {
  const t = /* @__PURE__ */ ce(e);
  return t === e ? t : ($e(t, "iterate", _n), /* @__PURE__ */ tt(e) ? t : t.map(rt));
}
function es(e) {
  return $e(e = /* @__PURE__ */ ce(e), "iterate", _n), e;
}
function ut(e, t) {
  return /* @__PURE__ */ Pt(e) ? nn(/* @__PURE__ */ Kt(e) ? rt(t) : t) : rt(t);
}
const ma = {
  __proto__: null,
  [Symbol.iterator]() {
    return fs(this, Symbol.iterator, (e) => ut(this, e));
  },
  concat(...e) {
    return Vt(this).concat(
      ...e.map((t) => J(t) ? Vt(t) : t)
    );
  },
  entries() {
    return fs(this, "entries", (e) => (e[1] = ut(this, e[1]), e));
  },
  every(e, t) {
    return bt(this, "every", e, t, void 0, arguments);
  },
  filter(e, t) {
    return bt(
      this,
      "filter",
      e,
      t,
      (n) => n.map((s) => ut(this, s)),
      arguments
    );
  },
  find(e, t) {
    return bt(
      this,
      "find",
      e,
      t,
      (n) => ut(this, n),
      arguments
    );
  },
  findIndex(e, t) {
    return bt(this, "findIndex", e, t, void 0, arguments);
  },
  findLast(e, t) {
    return bt(
      this,
      "findLast",
      e,
      t,
      (n) => ut(this, n),
      arguments
    );
  },
  findLastIndex(e, t) {
    return bt(this, "findLastIndex", e, t, void 0, arguments);
  },
  // flat, flatMap could benefit from ARRAY_ITERATE but are not straight-forward to implement
  forEach(e, t) {
    return bt(this, "forEach", e, t, void 0, arguments);
  },
  includes(...e) {
    return hs(this, "includes", e);
  },
  indexOf(...e) {
    return hs(this, "indexOf", e);
  },
  join(e) {
    return Vt(this).join(e);
  },
  // keys() iterator only reads `length`, no optimization required
  lastIndexOf(...e) {
    return hs(this, "lastIndexOf", e);
  },
  map(e, t) {
    return bt(this, "map", e, t, void 0, arguments);
  },
  pop() {
    return an(this, "pop");
  },
  push(...e) {
    return an(this, "push", e);
  },
  reduce(e, ...t) {
    return Cr(this, "reduce", e, t);
  },
  reduceRight(e, ...t) {
    return Cr(this, "reduceRight", e, t);
  },
  shift() {
    return an(this, "shift");
  },
  // slice could use ARRAY_ITERATE but also seems to beg for range tracking
  some(e, t) {
    return bt(this, "some", e, t, void 0, arguments);
  },
  splice(...e) {
    return an(this, "splice", e);
  },
  toReversed() {
    return Vt(this).toReversed();
  },
  toSorted(e) {
    return Vt(this).toSorted(e);
  },
  toSpliced(...e) {
    return Vt(this).toSpliced(...e);
  },
  unshift(...e) {
    return an(this, "unshift", e);
  },
  values() {
    return fs(this, "values", (e) => ut(this, e));
  }
};
function fs(e, t, n) {
  const s = es(e), r = s[t]();
  return s !== e && !/* @__PURE__ */ tt(e) && (r._next = r.next, r.next = () => {
    const i = r._next();
    return i.done || (i.value = n(i.value)), i;
  }), r;
}
const ya = Array.prototype;
function bt(e, t, n, s, r, i) {
  const o = es(e), a = o !== e && !/* @__PURE__ */ tt(e), u = o[t];
  if (u !== ya[t]) {
    const g = u.apply(e, i);
    return a ? rt(g) : g;
  }
  let h = n;
  o !== e && (a ? h = function(g, w) {
    return n.call(this, ut(e, g), w, e);
  } : n.length > 2 && (h = function(g, w) {
    return n.call(this, g, w, e);
  }));
  const d = u.call(o, h, s);
  return a && r ? r(d) : d;
}
function Cr(e, t, n, s) {
  const r = es(e), i = r !== e && !/* @__PURE__ */ tt(e);
  let o = n, a = !1;
  r !== e && (i ? (a = s.length === 0, o = function(h, d, g) {
    return a && (a = !1, h = ut(e, h)), n.call(this, h, ut(e, d), g, e);
  }) : n.length > 3 && (o = function(h, d, g) {
    return n.call(this, h, d, g, e);
  }));
  const u = r[t](o, ...s);
  return a ? ut(e, u) : u;
}
function hs(e, t, n) {
  const s = /* @__PURE__ */ ce(e);
  $e(s, "iterate", _n);
  const r = s[t](...n);
  return (r === -1 || r === !1) && /* @__PURE__ */ Xs(n[0]) ? (n[0] = /* @__PURE__ */ ce(n[0]), s[t](...n)) : r;
}
function an(e, t, n = []) {
  Ct(), Vs();
  const s = (/* @__PURE__ */ ce(e))[t].apply(e, n);
  return Ws(), kt(), s;
}
const ba = /* @__PURE__ */ Ks("__proto__,__v_isRef,__isVue"), Ni = new Set(
  /* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((e) => e !== "arguments" && e !== "caller").map((e) => Symbol[e]).filter(st)
);
function _a(e) {
  st(e) || (e = String(e));
  const t = /* @__PURE__ */ ce(this);
  return $e(t, "has", e), t.hasOwnProperty(e);
}
class Di {
  constructor(t = !1, n = !1) {
    this._isReadonly = t, this._isShallow = n;
  }
  get(t, n, s) {
    if (n === "__v_skip") return t.__v_skip;
    const r = this._isReadonly, i = this._isShallow;
    if (n === "__v_isReactive")
      return !r;
    if (n === "__v_isReadonly")
      return r;
    if (n === "__v_isShallow")
      return i;
    if (n === "__v_raw")
      return s === (r ? i ? Pa : ji : i ? qi : Fi).get(t) || // receiver is not the reactive proxy, but has the same prototype
      // this means the receiver is a user proxy of the reactive proxy
      Object.getPrototypeOf(t) === Object.getPrototypeOf(s) ? t : void 0;
    const o = J(t);
    if (!r) {
      let u;
      if (o && (u = ma[n]))
        return u;
      if (n === "hasOwnProperty")
        return _a;
    }
    const a = Reflect.get(
      t,
      n,
      // if this is a proxy wrapping a ref, return methods using the raw ref
      // as receiver so that we don't have to call `toRaw` on the ref in all
      // its class methods
      /* @__PURE__ */ Ne(t) ? t : s
    );
    if ((st(n) ? Ni.has(n) : ba(n)) || (r || $e(t, "get", n), i))
      return a;
    if (/* @__PURE__ */ Ne(a)) {
      const u = o && Bs(n) ? a : a.value;
      return r && ue(u) ? /* @__PURE__ */ Ps(u) : u;
    }
    return ue(a) ? r ? /* @__PURE__ */ Ps(a) : /* @__PURE__ */ ts(a) : a;
  }
}
class Li extends Di {
  constructor(t = !1) {
    super(!1, t);
  }
  set(t, n, s, r) {
    let i = t[n];
    const o = J(t) && Bs(n);
    if (!this._isShallow) {
      const h = /* @__PURE__ */ Pt(i);
      if (!/* @__PURE__ */ tt(s) && !/* @__PURE__ */ Pt(s) && (i = /* @__PURE__ */ ce(i), s = /* @__PURE__ */ ce(s)), !o && /* @__PURE__ */ Ne(i) && !/* @__PURE__ */ Ne(s))
        return h || (i.value = s), !0;
    }
    const a = o ? Number(n) < t.length : le(t, n), u = Reflect.set(
      t,
      n,
      s,
      /* @__PURE__ */ Ne(t) ? t : r
    );
    return t === /* @__PURE__ */ ce(r) && (a ? ft(s, i) && It(t, "set", n, s) : It(t, "add", n, s)), u;
  }
  deleteProperty(t, n) {
    const s = le(t, n);
    t[n];
    const r = Reflect.deleteProperty(t, n);
    return r && s && It(t, "delete", n, void 0), r;
  }
  has(t, n) {
    const s = Reflect.has(t, n);
    return (!st(n) || !Ni.has(n)) && $e(t, "has", n), s;
  }
  ownKeys(t) {
    return $e(
      t,
      "iterate",
      J(t) ? "length" : jt
    ), Reflect.ownKeys(t);
  }
}
class va extends Di {
  constructor(t = !1) {
    super(!0, t);
  }
  set(t, n) {
    return !0;
  }
  deleteProperty(t, n) {
    return !0;
  }
}
const wa = /* @__PURE__ */ new Li(), Sa = /* @__PURE__ */ new va(), Ia = /* @__PURE__ */ new Li(!0);
const ks = (e) => e, Tn = (e) => Reflect.getPrototypeOf(e);
function Aa(e, t, n) {
  return function(...s) {
    const r = this.__v_raw, i = /* @__PURE__ */ ce(r), o = Qt(i), a = e === "entries" || e === Symbol.iterator && o, u = e === "keys" && o, h = r[e](...s), d = n ? ks : t ? nn : rt;
    return !t && $e(
      i,
      "iterate",
      u ? Cs : jt
    ), ve(
      // inheriting all iterator properties
      Object.create(h),
      {
        // iterator protocol
        next() {
          const { value: g, done: w } = h.next();
          return w ? { value: g, done: w } : {
            value: a ? [d(g[0]), d(g[1])] : d(g),
            done: w
          };
        }
      }
    );
  };
}
function Rn(e) {
  return function(...t) {
    return e === "delete" ? !1 : e === "clear" ? void 0 : this;
  };
}
function Ea(e, t) {
  const n = {
    get(r) {
      const i = this.__v_raw, o = /* @__PURE__ */ ce(i), a = /* @__PURE__ */ ce(r);
      e || (ft(r, a) && $e(o, "get", r), $e(o, "get", a));
      const { has: u } = Tn(o), h = t ? ks : e ? nn : rt;
      if (u.call(o, r))
        return h(i.get(r));
      if (u.call(o, a))
        return h(i.get(a));
      i !== o && i.get(r);
    },
    get size() {
      const r = this.__v_raw;
      return !e && $e(/* @__PURE__ */ ce(r), "iterate", jt), r.size;
    },
    has(r) {
      const i = this.__v_raw, o = /* @__PURE__ */ ce(i), a = /* @__PURE__ */ ce(r);
      return e || (ft(r, a) && $e(o, "has", r), $e(o, "has", a)), r === a ? i.has(r) : i.has(r) || i.has(a);
    },
    forEach(r, i) {
      const o = this, a = o.__v_raw, u = /* @__PURE__ */ ce(a), h = t ? ks : e ? nn : rt;
      return !e && $e(u, "iterate", jt), a.forEach((d, g) => r.call(i, h(d), h(g), o));
    }
  };
  return ve(
    n,
    e ? {
      add: Rn("add"),
      set: Rn("set"),
      delete: Rn("delete"),
      clear: Rn("clear")
    } : {
      add(r) {
        const i = /* @__PURE__ */ ce(this), o = Tn(i), a = /* @__PURE__ */ ce(r), u = !t && !/* @__PURE__ */ tt(r) && !/* @__PURE__ */ Pt(r) ? a : r;
        return o.has.call(i, u) || ft(r, u) && o.has.call(i, r) || ft(a, u) && o.has.call(i, a) || (i.add(u), It(i, "add", u, u)), this;
      },
      set(r, i) {
        !t && !/* @__PURE__ */ tt(i) && !/* @__PURE__ */ Pt(i) && (i = /* @__PURE__ */ ce(i));
        const o = /* @__PURE__ */ ce(this), { has: a, get: u } = Tn(o);
        let h = a.call(o, r);
        h || (r = /* @__PURE__ */ ce(r), h = a.call(o, r));
        const d = u.call(o, r);
        return o.set(r, i), h ? ft(i, d) && It(o, "set", r, i) : It(o, "add", r, i), this;
      },
      delete(r) {
        const i = /* @__PURE__ */ ce(this), { has: o, get: a } = Tn(i);
        let u = o.call(i, r);
        u || (r = /* @__PURE__ */ ce(r), u = o.call(i, r)), a && a.call(i, r);
        const h = i.delete(r);
        return u && It(i, "delete", r, void 0), h;
      },
      clear() {
        const r = /* @__PURE__ */ ce(this), i = r.size !== 0, o = r.clear();
        return i && It(
          r,
          "clear",
          void 0,
          void 0
        ), o;
      }
    }
  ), [
    "keys",
    "values",
    "entries",
    Symbol.iterator
  ].forEach((r) => {
    n[r] = Aa(r, e, t);
  }), n;
}
function Js(e, t) {
  const n = Ea(e, t);
  return (s, r, i) => r === "__v_isReactive" ? !e : r === "__v_isReadonly" ? e : r === "__v_raw" ? s : Reflect.get(
    le(n, r) && r in s ? n : s,
    r,
    i
  );
}
const xa = {
  get: /* @__PURE__ */ Js(!1, !1)
}, Ca = {
  get: /* @__PURE__ */ Js(!1, !0)
}, ka = {
  get: /* @__PURE__ */ Js(!0, !1)
};
const Fi = /* @__PURE__ */ new WeakMap(), qi = /* @__PURE__ */ new WeakMap(), ji = /* @__PURE__ */ new WeakMap(), Pa = /* @__PURE__ */ new WeakMap();
function Ta(e) {
  switch (e) {
    case "Object":
    case "Array":
      return 1;
    case "Map":
    case "Set":
    case "WeakMap":
    case "WeakSet":
      return 2;
    default:
      return 0;
  }
}
function Ra(e) {
  return e.__v_skip || !Object.isExtensible(e) ? 0 : Ta(ta(e));
}
// @__NO_SIDE_EFFECTS__
function ts(e) {
  return /* @__PURE__ */ Pt(e) ? e : Ys(
    e,
    !1,
    wa,
    xa,
    Fi
  );
}
// @__NO_SIDE_EFFECTS__
function $a(e) {
  return Ys(
    e,
    !1,
    Ia,
    Ca,
    qi
  );
}
// @__NO_SIDE_EFFECTS__
function Ps(e) {
  return Ys(
    e,
    !0,
    Sa,
    ka,
    ji
  );
}
function Ys(e, t, n, s, r) {
  if (!ue(e) || e.__v_raw && !(t && e.__v_isReactive))
    return e;
  const i = Ra(e);
  if (i === 0)
    return e;
  const o = r.get(e);
  if (o)
    return o;
  const a = new Proxy(
    e,
    i === 2 ? s : n
  );
  return r.set(e, a), a;
}
// @__NO_SIDE_EFFECTS__
function Kt(e) {
  return /* @__PURE__ */ Pt(e) ? /* @__PURE__ */ Kt(e.__v_raw) : !!(e && e.__v_isReactive);
}
// @__NO_SIDE_EFFECTS__
function Pt(e) {
  return !!(e && e.__v_isReadonly);
}
// @__NO_SIDE_EFFECTS__
function tt(e) {
  return !!(e && e.__v_isShallow);
}
// @__NO_SIDE_EFFECTS__
function Xs(e) {
  return e ? !!e.__v_raw : !1;
}
// @__NO_SIDE_EFFECTS__
function ce(e) {
  const t = e && e.__v_raw;
  return t ? /* @__PURE__ */ ce(t) : e;
}
function Ma(e) {
  return !le(e, "__v_skip") && Object.isExtensible(e) && Si(e, "__v_skip", !0), e;
}
const rt = (e) => ue(e) ? /* @__PURE__ */ ts(e) : e, nn = (e) => ue(e) ? /* @__PURE__ */ Ps(e) : e;
// @__NO_SIDE_EFFECTS__
function Ne(e) {
  return e ? e.__v_isRef === !0 : !1;
}
// @__NO_SIDE_EFFECTS__
function Ee(e) {
  return Oa(e, !1);
}
function Oa(e, t) {
  return /* @__PURE__ */ Ne(e) ? e : new Na(e, t);
}
class Na {
  constructor(t, n) {
    this.dep = new Gs(), this.__v_isRef = !0, this.__v_isShallow = !1, this._rawValue = n ? t : /* @__PURE__ */ ce(t), this._value = n ? t : rt(t), this.__v_isShallow = n;
  }
  get value() {
    return this.dep.track(), this._value;
  }
  set value(t) {
    const n = this._rawValue, s = this.__v_isShallow || /* @__PURE__ */ tt(t) || /* @__PURE__ */ Pt(t);
    t = s ? t : /* @__PURE__ */ ce(t), ft(t, n) && (this._rawValue = t, this._value = s ? t : rt(t), this.dep.trigger());
  }
}
function Qs(e) {
  return /* @__PURE__ */ Ne(e) ? e.value : e;
}
const Da = {
  get: (e, t, n) => t === "__v_raw" ? e : Qs(Reflect.get(e, t, n)),
  set: (e, t, n, s) => {
    const r = e[t];
    return /* @__PURE__ */ Ne(r) && !/* @__PURE__ */ Ne(n) ? (r.value = n, !0) : Reflect.set(e, t, n, s);
  }
};
function Ki(e) {
  return /* @__PURE__ */ Kt(e) ? e : new Proxy(e, Da);
}
class La {
  constructor(t, n, s) {
    this.fn = t, this.setter = n, this._value = void 0, this.dep = new Gs(this), this.__v_isRef = !0, this.deps = void 0, this.depsTail = void 0, this.flags = 16, this.globalVersion = bn - 1, this.next = void 0, this.effect = this, this.__v_isReadonly = !n, this.isSSR = s;
  }
  /**
   * @internal
   */
  notify() {
    if (this.flags |= 16, !(this.flags & 8) && // avoid infinite self recursion
    ge !== this)
      return Pi(this, !0), !0;
  }
  get value() {
    const t = this.dep.track();
    return $i(this), t && (t.version = this.dep.version), this._value;
  }
  set value(t) {
    this.setter && this.setter(t);
  }
}
// @__NO_SIDE_EFFECTS__
function Fa(e, t, n = !1) {
  let s, r;
  return ne(e) ? s = e : (s = e.get, r = e.set), new La(s, r, n);
}
const $n = {}, Ln = /* @__PURE__ */ new WeakMap();
let qt;
function qa(e, t = !1, n = qt) {
  if (n) {
    let s = Ln.get(n);
    s || Ln.set(n, s = []), s.push(e);
  }
}
function ja(e, t, n = he) {
  const { immediate: s, deep: r, once: i, scheduler: o, augmentJob: a, call: u } = n, h = (E) => r ? E : /* @__PURE__ */ tt(E) || r === !1 || r === 0 ? At(E, 1) : At(E);
  let d, g, w, R, P = !1, x = !1;
  if (/* @__PURE__ */ Ne(e) ? (g = () => e.value, P = /* @__PURE__ */ tt(e)) : /* @__PURE__ */ Kt(e) ? (g = () => h(e), P = !0) : J(e) ? (x = !0, P = e.some((E) => /* @__PURE__ */ Kt(E) || /* @__PURE__ */ tt(E)), g = () => e.map((E) => {
    if (/* @__PURE__ */ Ne(E))
      return E.value;
    if (/* @__PURE__ */ Kt(E))
      return h(E);
    if (ne(E))
      return u ? u(E, 2) : E();
  })) : ne(e) ? t ? g = u ? () => u(e, 2) : e : g = () => {
    if (w) {
      Ct();
      try {
        w();
      } finally {
        kt();
      }
    }
    const E = qt;
    qt = d;
    try {
      return u ? u(e, 3, [R]) : e(R);
    } finally {
      qt = E;
    }
  } : g = ht, t && r) {
    const E = g, q = r === !0 ? 1 / 0 : r;
    g = () => At(E(), q);
  }
  const $ = ha(), I = () => {
    d.stop(), $ && $.active && Us($.effects, d);
  };
  if (i && t) {
    const E = t;
    t = (...q) => {
      E(...q), I();
    };
  }
  let y = x ? new Array(e.length).fill($n) : $n;
  const O = (E) => {
    if (!(!(d.flags & 1) || !d.dirty && !E))
      if (t) {
        const q = d.run();
        if (r || P || (x ? q.some((S, M) => ft(S, y[M])) : ft(q, y))) {
          w && w();
          const S = qt;
          qt = d;
          try {
            const M = [
              q,
              // pass undefined as the old value when it's changed for the first time
              y === $n ? void 0 : x && y[0] === $n ? [] : y,
              R
            ];
            y = q, u ? u(t, 3, M) : (
              // @ts-expect-error
              t(...M)
            );
          } finally {
            qt = S;
          }
        }
      } else
        d.run();
  };
  return a && a(O), d = new Ci(g), d.scheduler = o ? () => o(O, !1) : O, R = (E) => qa(E, !1, d), w = d.onStop = () => {
    const E = Ln.get(d);
    if (E) {
      if (u)
        u(E, 4);
      else
        for (const q of E) q();
      Ln.delete(d);
    }
  }, t ? s ? O(!0) : y = d.run() : o ? o(O.bind(null, !0), !0) : d.run(), I.pause = d.pause.bind(d), I.resume = d.resume.bind(d), I.stop = I, I;
}
function At(e, t = 1 / 0, n) {
  if (t <= 0 || !ue(e) || e.__v_skip || (n = n || /* @__PURE__ */ new Map(), (n.get(e) || 0) >= t))
    return e;
  if (n.set(e, t), t--, /* @__PURE__ */ Ne(e))
    At(e.value, t, n);
  else if (J(e))
    for (let s = 0; s < e.length; s++)
      At(e[s], t, n);
  else if (Jn(e) || Qt(e))
    e.forEach((s) => {
      At(s, t, n);
    });
  else if (Yn(e)) {
    for (const s in e)
      At(e[s], t, n);
    for (const s of Object.getOwnPropertySymbols(e))
      Object.prototype.propertyIsEnumerable.call(e, s) && At(e[s], t, n);
  }
  return e;
}
/**
* @vue/runtime-core v3.5.31
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
function Cn(e, t, n, s) {
  try {
    return s ? e(...s) : e();
  } catch (r) {
    ns(r, t, n);
  }
}
function pt(e, t, n, s) {
  if (ne(e)) {
    const r = Cn(e, t, n, s);
    return r && vi(r) && r.catch((i) => {
      ns(i, t, n);
    }), r;
  }
  if (J(e)) {
    const r = [];
    for (let i = 0; i < e.length; i++)
      r.push(pt(e[i], t, n, s));
    return r;
  }
}
function ns(e, t, n, s = !0) {
  const r = t ? t.vnode : null, { errorHandler: i, throwUnhandledErrorInProduction: o } = t && t.appContext.config || he;
  if (t) {
    let a = t.parent;
    const u = t.proxy, h = `https://vuejs.org/error-reference/#runtime-${n}`;
    for (; a; ) {
      const d = a.ec;
      if (d) {
        for (let g = 0; g < d.length; g++)
          if (d[g](e, u, h) === !1)
            return;
      }
      a = a.parent;
    }
    if (i) {
      Ct(), Cn(i, null, 10, [
        e,
        u,
        h
      ]), kt();
      return;
    }
  }
  Ka(e, n, r, s, o);
}
function Ka(e, t, n, s = !0, r = !1) {
  if (r)
    throw e;
  console.error(e);
}
const qe = [];
let ct = -1;
const Zt = [];
let Mt = null, Gt = 0;
const Ui = /* @__PURE__ */ Promise.resolve();
let Fn = null;
function Zs(e) {
  const t = Fn || Ui;
  return e ? t.then(this ? e.bind(this) : e) : t;
}
function Ua(e) {
  let t = ct + 1, n = qe.length;
  for (; t < n; ) {
    const s = t + n >>> 1, r = qe[s], i = vn(r);
    i < e || i === e && r.flags & 2 ? t = s + 1 : n = s;
  }
  return t;
}
function er(e) {
  if (!(e.flags & 1)) {
    const t = vn(e), n = qe[qe.length - 1];
    !n || // fast path when the job id is larger than the tail
    !(e.flags & 2) && t >= vn(n) ? qe.push(e) : qe.splice(Ua(t), 0, e), e.flags |= 1, Bi();
  }
}
function Bi() {
  Fn || (Fn = Ui.then(Vi));
}
function Ba(e) {
  J(e) ? Zt.push(...e) : Mt && e.id === -1 ? Mt.splice(Gt + 1, 0, e) : e.flags & 1 || (Zt.push(e), e.flags |= 1), Bi();
}
function kr(e, t, n = ct + 1) {
  for (; n < qe.length; n++) {
    const s = qe[n];
    if (s && s.flags & 2) {
      if (e && s.id !== e.uid)
        continue;
      qe.splice(n, 1), n--, s.flags & 4 && (s.flags &= -2), s(), s.flags & 4 || (s.flags &= -2);
    }
  }
}
function Hi(e) {
  if (Zt.length) {
    const t = [...new Set(Zt)].sort(
      (n, s) => vn(n) - vn(s)
    );
    if (Zt.length = 0, Mt) {
      Mt.push(...t);
      return;
    }
    for (Mt = t, Gt = 0; Gt < Mt.length; Gt++) {
      const n = Mt[Gt];
      n.flags & 4 && (n.flags &= -2), n.flags & 8 || n(), n.flags &= -2;
    }
    Mt = null, Gt = 0;
  }
}
const vn = (e) => e.id == null ? e.flags & 2 ? -1 : 1 / 0 : e.id;
function Vi(e) {
  try {
    for (ct = 0; ct < qe.length; ct++) {
      const t = qe[ct];
      t && !(t.flags & 8) && (t.flags & 4 && (t.flags &= -2), Cn(
        t,
        t.i,
        t.i ? 15 : 14
      ), t.flags & 4 || (t.flags &= -2));
    }
  } finally {
    for (; ct < qe.length; ct++) {
      const t = qe[ct];
      t && (t.flags &= -2);
    }
    ct = -1, qe.length = 0, Hi(), Fn = null, (qe.length || Zt.length) && Vi();
  }
}
let Pe = null, Wi = null;
function qn(e) {
  const t = Pe;
  return Pe = e, Wi = e && e.type.__scopeId || null, t;
}
function jn(e, t = Pe, n) {
  if (!t || e._n)
    return e;
  const s = (...r) => {
    s._d && Bn(-1);
    const i = qn(t);
    let o;
    try {
      o = e(...r);
    } finally {
      qn(i), s._d && Bn(1);
    }
    return o;
  };
  return s._n = !0, s._c = !0, s._d = !0, s;
}
function Jt(e, t) {
  if (Pe === null)
    return e;
  const n = as(Pe), s = e.dirs || (e.dirs = []);
  for (let r = 0; r < t.length; r++) {
    let [i, o, a, u = he] = t[r];
    i && (ne(i) && (i = {
      mounted: i,
      updated: i
    }), i.deep && At(o), s.push({
      dir: i,
      instance: n,
      value: o,
      oldValue: void 0,
      arg: a,
      modifiers: u
    }));
  }
  return e;
}
function Lt(e, t, n, s) {
  const r = e.dirs, i = t && t.dirs;
  for (let o = 0; o < r.length; o++) {
    const a = r[o];
    i && (a.oldValue = i[o].value);
    let u = a.dir[s];
    u && (Ct(), pt(u, n, 8, [
      e.el,
      a,
      e,
      t
    ]), kt());
  }
}
function Ha(e, t) {
  if (Me) {
    let n = Me.provides;
    const s = Me.parent && Me.parent.provides;
    s === n && (n = Me.provides = Object.create(s)), n[e] = t;
  }
}
function On(e, t, n = !1) {
  const s = Kl();
  if (s || tn) {
    let r = tn ? tn._context.provides : s ? s.parent == null || s.ce ? s.vnode.appContext && s.vnode.appContext.provides : s.parent.provides : void 0;
    if (r && e in r)
      return r[e];
    if (arguments.length > 1)
      return n && ne(t) ? t.call(s && s.proxy) : t;
  }
}
const Va = /* @__PURE__ */ Symbol.for("v-scx"), Wa = () => On(Va);
function Ut(e, t, n) {
  return zi(e, t, n);
}
function zi(e, t, n = he) {
  const { immediate: s, deep: r, flush: i, once: o } = n, a = ve({}, n), u = t && s || !t && i !== "post";
  let h;
  if (An) {
    if (i === "sync") {
      const R = Wa();
      h = R.__watcherHandles || (R.__watcherHandles = []);
    } else if (!u) {
      const R = () => {
      };
      return R.stop = ht, R.resume = ht, R.pause = ht, R;
    }
  }
  const d = Me;
  a.call = (R, P, x) => pt(R, d, P, x);
  let g = !1;
  i === "post" ? a.scheduler = (R) => {
    Ke(R, d && d.suspense);
  } : i !== "sync" && (g = !0, a.scheduler = (R, P) => {
    P ? R() : er(R);
  }), a.augmentJob = (R) => {
    t && (R.flags |= 4), g && (R.flags |= 2, d && (R.id = d.uid, R.i = d));
  };
  const w = ja(e, t, a);
  return An && (h ? h.push(w) : u && w()), w;
}
function za(e, t, n) {
  const s = this.proxy, r = be(e) ? e.includes(".") ? Gi(s, e) : () => s[e] : e.bind(s, s);
  let i;
  ne(t) ? i = t : (i = t.handler, n = t);
  const o = kn(this), a = zi(r, i.bind(s), n);
  return o(), a;
}
function Gi(e, t) {
  const n = t.split(".");
  return () => {
    let s = e;
    for (let r = 0; r < n.length && s; r++)
      s = s[n[r]];
    return s;
  };
}
const Ga = /* @__PURE__ */ Symbol("_vte"), Ja = (e) => e.__isTeleport, Ya = /* @__PURE__ */ Symbol("_leaveCb");
function tr(e, t) {
  e.shapeFlag & 6 && e.component ? (e.transition = t, tr(e.component.subTree, t)) : e.shapeFlag & 128 ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t;
}
// @__NO_SIDE_EFFECTS__
function gt(e, t) {
  return ne(e) ? (
    // #8236: extend call and options.name access are considered side-effects
    // by Rollup, so we have to wrap it in a pure-annotated IIFE.
    ve({ name: e.name }, t, { setup: e })
  ) : e;
}
function Ji(e) {
  e.ids = [e.ids[0] + e.ids[2]++ + "-", 0, 0];
}
function Pr(e, t) {
  let n;
  return !!((n = Object.getOwnPropertyDescriptor(e, t)) && !n.configurable);
}
const Kn = /* @__PURE__ */ new WeakMap();
function pn(e, t, n, s, r = !1) {
  if (J(e)) {
    e.forEach(
      (x, $) => pn(
        x,
        t && (J(t) ? t[$] : t),
        n,
        s,
        r
      )
    );
    return;
  }
  if (en(s) && !r) {
    s.shapeFlag & 512 && s.type.__asyncResolved && s.component.subTree.component && pn(e, t, n, s.component.subTree);
    return;
  }
  const i = s.shapeFlag & 4 ? as(s.component) : s.el, o = r ? null : i, { i: a, r: u } = e, h = t && t.r, d = a.refs === he ? a.refs = {} : a.refs, g = a.setupState, w = /* @__PURE__ */ ce(g), R = g === he ? _i : (x) => Pr(d, x) ? !1 : le(w, x), P = (x, $) => !($ && Pr(d, $));
  if (h != null && h !== u) {
    if (Tr(t), be(h))
      d[h] = null, R(h) && (g[h] = null);
    else if (/* @__PURE__ */ Ne(h)) {
      const x = t;
      P(h, x.k) && (h.value = null), x.k && (d[x.k] = null);
    }
  }
  if (ne(u))
    Cn(u, a, 12, [o, d]);
  else {
    const x = be(u), $ = /* @__PURE__ */ Ne(u);
    if (x || $) {
      const I = () => {
        if (e.f) {
          const y = x ? R(u) ? g[u] : d[u] : P() || !e.k ? u.value : d[e.k];
          if (r)
            J(y) && Us(y, i);
          else if (J(y))
            y.includes(i) || y.push(i);
          else if (x)
            d[u] = [i], R(u) && (g[u] = d[u]);
          else {
            const O = [i];
            P(u, e.k) && (u.value = O), e.k && (d[e.k] = O);
          }
        } else x ? (d[u] = o, R(u) && (g[u] = o)) : $ && (P(u, e.k) && (u.value = o), e.k && (d[e.k] = o));
      };
      if (o) {
        const y = () => {
          I(), Kn.delete(e);
        };
        y.id = -1, Kn.set(e, y), Ke(y, n);
      } else
        Tr(e), I();
    }
  }
}
function Tr(e) {
  const t = Kn.get(e);
  t && (t.flags |= 8, Kn.delete(e));
}
Zn().requestIdleCallback;
Zn().cancelIdleCallback;
const en = (e) => !!e.type.__asyncLoader, Yi = (e) => e.type.__isKeepAlive;
function Xa(e, t) {
  Xi(e, "a", t);
}
function Qa(e, t) {
  Xi(e, "da", t);
}
function Xi(e, t, n = Me) {
  const s = e.__wdc || (e.__wdc = () => {
    let r = n;
    for (; r; ) {
      if (r.isDeactivated)
        return;
      r = r.parent;
    }
    return e();
  });
  if (ss(t, s, n), n) {
    let r = n.parent;
    for (; r && r.parent; )
      Yi(r.parent.vnode) && Za(s, t, n, r), r = r.parent;
  }
}
function Za(e, t, n, s) {
  const r = ss(
    t,
    e,
    s,
    !0
    /* prepend */
  );
  nr(() => {
    Us(s[t], r);
  }, n);
}
function ss(e, t, n = Me, s = !1) {
  if (n) {
    const r = n[e] || (n[e] = []), i = t.__weh || (t.__weh = (...o) => {
      Ct();
      const a = kn(n), u = pt(t, n, e, o);
      return a(), kt(), u;
    });
    return s ? r.unshift(i) : r.push(i), i;
  }
}
const Rt = (e) => (t, n = Me) => {
  (!An || e === "sp") && ss(e, (...s) => t(...s), n);
}, el = Rt("bm"), rs = Rt("m"), tl = Rt(
  "bu"
), nl = Rt("u"), Qi = Rt(
  "bum"
), nr = Rt("um"), sl = Rt(
  "sp"
), rl = Rt("rtg"), il = Rt("rtc");
function ol(e, t = Me) {
  ss("ec", e, t);
}
const al = "components", Zi = /* @__PURE__ */ Symbol.for("v-ndc");
function ll(e) {
  return be(e) ? cl(al, e, !1) || e : e || Zi;
}
function cl(e, t, n = !0, s = !1) {
  const r = Pe || Me;
  if (r) {
    const i = r.type;
    {
      const a = Wl(
        i,
        !1
      );
      if (a && (a === t || a === xe(t) || a === Qn(xe(t))))
        return i;
    }
    const o = (
      // local registration
      // check instance[type] first which is resolved for options API
      Rr(r[e] || i[e], t) || // global registration
      Rr(r.appContext[e], t)
    );
    return !o && s ? i : o;
  }
}
function Rr(e, t) {
  return e && (e[t] || e[xe(t)] || e[Qn(xe(t))]);
}
function Be(e, t, n, s) {
  let r;
  const i = n, o = J(e);
  if (o || be(e)) {
    const a = o && /* @__PURE__ */ Kt(e);
    let u = !1, h = !1;
    a && (u = !/* @__PURE__ */ tt(e), h = /* @__PURE__ */ Pt(e), e = es(e)), r = new Array(e.length);
    for (let d = 0, g = e.length; d < g; d++)
      r[d] = t(
        u ? h ? nn(rt(e[d])) : rt(e[d]) : e[d],
        d,
        void 0,
        i
      );
  } else if (typeof e == "number") {
    r = new Array(e);
    for (let a = 0; a < e; a++)
      r[a] = t(a + 1, a, void 0, i);
  } else if (ue(e))
    if (e[Symbol.iterator])
      r = Array.from(
        e,
        (a, u) => t(a, u, void 0, i)
      );
    else {
      const a = Object.keys(e);
      r = new Array(a.length);
      for (let u = 0, h = a.length; u < h; u++) {
        const d = a[u];
        r[u] = t(e[d], d, u, i);
      }
    }
  else
    r = [];
  return r;
}
function eo(e, t) {
  for (let n = 0; n < t.length; n++) {
    const s = t[n];
    if (J(s))
      for (let r = 0; r < s.length; r++)
        e[s[r].name] = s[r].fn;
    else s && (e[s.name] = s.key ? (...r) => {
      const i = s.fn(...r);
      return i && (i.key = s.key), i;
    } : s.fn);
  }
  return e;
}
function Ot(e, t, n = {}, s, r) {
  if (Pe.ce || Pe.parent && en(Pe.parent) && Pe.parent.ce) {
    const h = Object.keys(n).length > 0;
    return t !== "default" && (n.name = t), T(), mt(
      me,
      null,
      [Te("slot", n, s && s())],
      h ? -2 : 64
    );
  }
  let i = e[t];
  i && i._c && (i._d = !1), T();
  const o = i && to(i(n)), a = n.key || // slot content array of a dynamic conditional slot may have a branch
  // key attached in the `createSlots` helper, respect that
  o && o.key, u = mt(
    me,
    {
      key: (a && !st(a) ? a : `_${t}`) + // #7256 force differentiate fallback content from actual content
      (!o && s ? "_fb" : "")
    },
    o || (s ? s() : []),
    o && e._ === 1 ? 64 : -2
  );
  return i && i._c && (i._d = !0), u;
}
function to(e) {
  return e.some((t) => Sn(t) ? !(t.type === Tt || t.type === me && !to(t.children)) : !0) ? e : null;
}
const Ts = (e) => e ? Ao(e) ? as(e) : Ts(e.parent) : null, gn = (
  // Move PURE marker to new line to workaround compiler discarding it
  // due to type annotation
  /* @__PURE__ */ ve(/* @__PURE__ */ Object.create(null), {
    $: (e) => e,
    $el: (e) => e.vnode.el,
    $data: (e) => e.data,
    $props: (e) => e.props,
    $attrs: (e) => e.attrs,
    $slots: (e) => e.slots,
    $refs: (e) => e.refs,
    $parent: (e) => Ts(e.parent),
    $root: (e) => Ts(e.root),
    $host: (e) => e.ce,
    $emit: (e) => e.emit,
    $options: (e) => so(e),
    $forceUpdate: (e) => e.f || (e.f = () => {
      er(e.update);
    }),
    $nextTick: (e) => e.n || (e.n = Zs.bind(e.proxy)),
    $watch: (e) => za.bind(e)
  })
), ps = (e, t) => e !== he && !e.__isScriptSetup && le(e, t), ul = {
  get({ _: e }, t) {
    if (t === "__v_skip")
      return !0;
    const { ctx: n, setupState: s, data: r, props: i, accessCache: o, type: a, appContext: u } = e;
    if (t[0] !== "$") {
      const w = o[t];
      if (w !== void 0)
        switch (w) {
          case 1:
            return s[t];
          case 2:
            return r[t];
          case 4:
            return n[t];
          case 3:
            return i[t];
        }
      else {
        if (ps(s, t))
          return o[t] = 1, s[t];
        if (r !== he && le(r, t))
          return o[t] = 2, r[t];
        if (le(i, t))
          return o[t] = 3, i[t];
        if (n !== he && le(n, t))
          return o[t] = 4, n[t];
        Rs && (o[t] = 0);
      }
    }
    const h = gn[t];
    let d, g;
    if (h)
      return t === "$attrs" && $e(e.attrs, "get", ""), h(e);
    if (
      // css module (injected by vue-loader)
      (d = a.__cssModules) && (d = d[t])
    )
      return d;
    if (n !== he && le(n, t))
      return o[t] = 4, n[t];
    if (
      // global properties
      g = u.config.globalProperties, le(g, t)
    )
      return g[t];
  },
  set({ _: e }, t, n) {
    const { data: s, setupState: r, ctx: i } = e;
    return ps(r, t) ? (r[t] = n, !0) : s !== he && le(s, t) ? (s[t] = n, !0) : le(e.props, t) || t[0] === "$" && t.slice(1) in e ? !1 : (i[t] = n, !0);
  },
  has({
    _: { data: e, setupState: t, accessCache: n, ctx: s, appContext: r, props: i, type: o }
  }, a) {
    let u;
    return !!(n[a] || e !== he && a[0] !== "$" && le(e, a) || ps(t, a) || le(i, a) || le(s, a) || le(gn, a) || le(r.config.globalProperties, a) || (u = o.__cssModules) && u[a]);
  },
  defineProperty(e, t, n) {
    return n.get != null ? e._.accessCache[t] = 0 : le(n, "value") && this.set(e, t, n.value, null), Reflect.defineProperty(e, t, n);
  }
};
function $r(e) {
  return J(e) ? e.reduce(
    (t, n) => (t[n] = null, t),
    {}
  ) : e;
}
let Rs = !0;
function dl(e) {
  const t = so(e), n = e.proxy, s = e.ctx;
  Rs = !1, t.beforeCreate && Mr(t.beforeCreate, e, "bc");
  const {
    // state
    data: r,
    computed: i,
    methods: o,
    watch: a,
    provide: u,
    inject: h,
    // lifecycle
    created: d,
    beforeMount: g,
    mounted: w,
    beforeUpdate: R,
    updated: P,
    activated: x,
    deactivated: $,
    beforeDestroy: I,
    beforeUnmount: y,
    destroyed: O,
    unmounted: E,
    render: q,
    renderTracked: S,
    renderTriggered: M,
    errorCaptured: j,
    serverPrefetch: K,
    // public API
    expose: H,
    inheritAttrs: se,
    // assets
    components: re,
    directives: ee,
    filters: we
  } = t;
  if (h && fl(h, s, null), o)
    for (const V in o) {
      const Q = o[V];
      ne(Q) && (s[V] = Q.bind(n));
    }
  if (r) {
    const V = r.call(n, n);
    ue(V) && (e.data = /* @__PURE__ */ ts(V));
  }
  if (Rs = !0, i)
    for (const V in i) {
      const Q = i[V], Ie = ne(Q) ? Q.bind(n, n) : ne(Q.get) ? Q.get.bind(n, n) : ht, Xe = !ne(Q) && ne(Q.set) ? Q.set.bind(n) : ht, Ae = ae({
        get: Ie,
        set: Xe
      });
      Object.defineProperty(s, V, {
        enumerable: !0,
        configurable: !0,
        get: () => Ae.value,
        set: (fe) => Ae.value = fe
      });
    }
  if (a)
    for (const V in a)
      no(a[V], s, n, V);
  if (u) {
    const V = ne(u) ? u.call(n) : u;
    Reflect.ownKeys(V).forEach((Q) => {
      Ha(Q, V[Q]);
    });
  }
  d && Mr(d, e, "c");
  function G(V, Q) {
    J(Q) ? Q.forEach((Ie) => V(Ie.bind(n))) : Q && V(Q.bind(n));
  }
  if (G(el, g), G(rs, w), G(tl, R), G(nl, P), G(Xa, x), G(Qa, $), G(ol, j), G(il, S), G(rl, M), G(Qi, y), G(nr, E), G(sl, K), J(H))
    if (H.length) {
      const V = e.exposed || (e.exposed = {});
      H.forEach((Q) => {
        Object.defineProperty(V, Q, {
          get: () => n[Q],
          set: (Ie) => n[Q] = Ie,
          enumerable: !0
        });
      });
    } else e.exposed || (e.exposed = {});
  q && e.render === ht && (e.render = q), se != null && (e.inheritAttrs = se), re && (e.components = re), ee && (e.directives = ee), K && Ji(e);
}
function fl(e, t, n = ht) {
  J(e) && (e = $s(e));
  for (const s in e) {
    const r = e[s];
    let i;
    ue(r) ? "default" in r ? i = On(
      r.from || s,
      r.default,
      !0
    ) : i = On(r.from || s) : i = On(r), /* @__PURE__ */ Ne(i) ? Object.defineProperty(t, s, {
      enumerable: !0,
      configurable: !0,
      get: () => i.value,
      set: (o) => i.value = o
    }) : t[s] = i;
  }
}
function Mr(e, t, n) {
  pt(
    J(e) ? e.map((s) => s.bind(t.proxy)) : e.bind(t.proxy),
    t,
    n
  );
}
function no(e, t, n, s) {
  let r = s.includes(".") ? Gi(n, s) : () => n[s];
  if (be(e)) {
    const i = t[e];
    ne(i) && Ut(r, i);
  } else if (ne(e))
    Ut(r, e.bind(n));
  else if (ue(e))
    if (J(e))
      e.forEach((i) => no(i, t, n, s));
    else {
      const i = ne(e.handler) ? e.handler.bind(n) : t[e.handler];
      ne(i) && Ut(r, i, e);
    }
}
function so(e) {
  const t = e.type, { mixins: n, extends: s } = t, {
    mixins: r,
    optionsCache: i,
    config: { optionMergeStrategies: o }
  } = e.appContext, a = i.get(t);
  let u;
  return a ? u = a : !r.length && !n && !s ? u = t : (u = {}, r.length && r.forEach(
    (h) => Un(u, h, o, !0)
  ), Un(u, t, o)), ue(t) && i.set(t, u), u;
}
function Un(e, t, n, s = !1) {
  const { mixins: r, extends: i } = t;
  i && Un(e, i, n, !0), r && r.forEach(
    (o) => Un(e, o, n, !0)
  );
  for (const o in t)
    if (!(s && o === "expose")) {
      const a = hl[o] || n && n[o];
      e[o] = a ? a(e[o], t[o]) : t[o];
    }
  return e;
}
const hl = {
  data: Or,
  props: Nr,
  emits: Nr,
  // objects
  methods: cn,
  computed: cn,
  // lifecycle
  beforeCreate: Fe,
  created: Fe,
  beforeMount: Fe,
  mounted: Fe,
  beforeUpdate: Fe,
  updated: Fe,
  beforeDestroy: Fe,
  beforeUnmount: Fe,
  destroyed: Fe,
  unmounted: Fe,
  activated: Fe,
  deactivated: Fe,
  errorCaptured: Fe,
  serverPrefetch: Fe,
  // assets
  components: cn,
  directives: cn,
  // watch
  watch: gl,
  // provide / inject
  provide: Or,
  inject: pl
};
function Or(e, t) {
  return t ? e ? function() {
    return ve(
      ne(e) ? e.call(this, this) : e,
      ne(t) ? t.call(this, this) : t
    );
  } : t : e;
}
function pl(e, t) {
  return cn($s(e), $s(t));
}
function $s(e) {
  if (J(e)) {
    const t = {};
    for (let n = 0; n < e.length; n++)
      t[e[n]] = e[n];
    return t;
  }
  return e;
}
function Fe(e, t) {
  return e ? [...new Set([].concat(e, t))] : t;
}
function cn(e, t) {
  return e ? ve(/* @__PURE__ */ Object.create(null), e, t) : t;
}
function Nr(e, t) {
  return e ? J(e) && J(t) ? [.../* @__PURE__ */ new Set([...e, ...t])] : ve(
    /* @__PURE__ */ Object.create(null),
    $r(e),
    $r(t ?? {})
  ) : t;
}
function gl(e, t) {
  if (!e) return t;
  if (!t) return e;
  const n = ve(/* @__PURE__ */ Object.create(null), e);
  for (const s in t)
    n[s] = Fe(e[s], t[s]);
  return n;
}
function ro() {
  return {
    app: null,
    config: {
      isNativeTag: _i,
      performance: !1,
      globalProperties: {},
      optionMergeStrategies: {},
      errorHandler: void 0,
      warnHandler: void 0,
      compilerOptions: {}
    },
    mixins: [],
    components: {},
    directives: {},
    provides: /* @__PURE__ */ Object.create(null),
    optionsCache: /* @__PURE__ */ new WeakMap(),
    propsCache: /* @__PURE__ */ new WeakMap(),
    emitsCache: /* @__PURE__ */ new WeakMap()
  };
}
let ml = 0;
function yl(e, t) {
  return function(s, r = null) {
    ne(s) || (s = ve({}, s)), r != null && !ue(r) && (r = null);
    const i = ro(), o = /* @__PURE__ */ new WeakSet(), a = [];
    let u = !1;
    const h = i.app = {
      _uid: ml++,
      _component: s,
      _props: r,
      _container: null,
      _context: i,
      _instance: null,
      version: Jl,
      get config() {
        return i.config;
      },
      set config(d) {
      },
      use(d, ...g) {
        return o.has(d) || (d && ne(d.install) ? (o.add(d), d.install(h, ...g)) : ne(d) && (o.add(d), d(h, ...g))), h;
      },
      mixin(d) {
        return i.mixins.includes(d) || i.mixins.push(d), h;
      },
      component(d, g) {
        return g ? (i.components[d] = g, h) : i.components[d];
      },
      directive(d, g) {
        return g ? (i.directives[d] = g, h) : i.directives[d];
      },
      mount(d, g, w) {
        if (!u) {
          const R = h._ceVNode || Te(s, r);
          return R.appContext = i, w === !0 ? w = "svg" : w === !1 && (w = void 0), e(R, d, w), u = !0, h._container = d, d.__vue_app__ = h, as(R.component);
        }
      },
      onUnmount(d) {
        a.push(d);
      },
      unmount() {
        u && (pt(
          a,
          h._instance,
          16
        ), e(null, h._container), delete h._container.__vue_app__);
      },
      provide(d, g) {
        return i.provides[d] = g, h;
      },
      runWithContext(d) {
        const g = tn;
        tn = h;
        try {
          return d();
        } finally {
          tn = g;
        }
      }
    };
    return h;
  };
}
let tn = null;
const bl = (e, t) => t === "modelValue" || t === "model-value" ? e.modelModifiers : e[`${t}Modifiers`] || e[`${xe(t)}Modifiers`] || e[`${Ze(t)}Modifiers`];
function _l(e, t, ...n) {
  if (e.isUnmounted) return;
  const s = e.vnode.props || he;
  let r = n;
  const i = t.startsWith("update:"), o = i && bl(s, t.slice(7));
  o && (o.trim && (r = n.map((d) => be(d) ? d.trim() : d)), o.number && (r = n.map(Hs)));
  let a, u = s[a = cs(t)] || // also try camelCase event handler (#2249)
  s[a = cs(xe(t))];
  !u && i && (u = s[a = cs(Ze(t))]), u && pt(
    u,
    e,
    6,
    r
  );
  const h = s[a + "Once"];
  if (h) {
    if (!e.emitted)
      e.emitted = {};
    else if (e.emitted[a])
      return;
    e.emitted[a] = !0, pt(
      h,
      e,
      6,
      r
    );
  }
}
const vl = /* @__PURE__ */ new WeakMap();
function io(e, t, n = !1) {
  const s = n ? vl : t.emitsCache, r = s.get(e);
  if (r !== void 0)
    return r;
  const i = e.emits;
  let o = {}, a = !1;
  if (!ne(e)) {
    const u = (h) => {
      const d = io(h, t, !0);
      d && (a = !0, ve(o, d));
    };
    !n && t.mixins.length && t.mixins.forEach(u), e.extends && u(e.extends), e.mixins && e.mixins.forEach(u);
  }
  return !i && !a ? (ue(e) && s.set(e, null), null) : (J(i) ? i.forEach((u) => o[u] = null) : ve(o, i), ue(e) && s.set(e, o), o);
}
function is(e, t) {
  return !e || !zn(t) ? !1 : (t = t.slice(2).replace(/Once$/, ""), le(e, t[0].toLowerCase() + t.slice(1)) || le(e, Ze(t)) || le(e, t));
}
function Dr(e) {
  const {
    type: t,
    vnode: n,
    proxy: s,
    withProxy: r,
    propsOptions: [i],
    slots: o,
    attrs: a,
    emit: u,
    render: h,
    renderCache: d,
    props: g,
    data: w,
    setupState: R,
    ctx: P,
    inheritAttrs: x
  } = e, $ = qn(e);
  let I, y;
  try {
    if (n.shapeFlag & 4) {
      const E = r || s, q = E;
      I = dt(
        h.call(
          q,
          E,
          d,
          g,
          R,
          w,
          P
        )
      ), y = a;
    } else {
      const E = t;
      I = dt(
        E.length > 1 ? E(
          g,
          { attrs: a, slots: o, emit: u }
        ) : E(
          g,
          null
        )
      ), y = t.props ? a : wl(a);
    }
  } catch (E) {
    mn.length = 0, ns(E, e, 1), I = Te(Tt);
  }
  let O = I;
  if (y && x !== !1) {
    const E = Object.keys(y), { shapeFlag: q } = O;
    E.length && q & 7 && (i && E.some(Gn) && (y = Sl(
      y,
      i
    )), O = sn(O, y, !1, !0));
  }
  return n.dirs && (O = sn(O, null, !1, !0), O.dirs = O.dirs ? O.dirs.concat(n.dirs) : n.dirs), n.transition && tr(O, n.transition), I = O, qn($), I;
}
const wl = (e) => {
  let t;
  for (const n in e)
    (n === "class" || n === "style" || zn(n)) && ((t || (t = {}))[n] = e[n]);
  return t;
}, Sl = (e, t) => {
  const n = {};
  for (const s in e)
    (!Gn(s) || !(s.slice(9) in t)) && (n[s] = e[s]);
  return n;
};
function Il(e, t, n) {
  const { props: s, children: r, component: i } = e, { props: o, children: a, patchFlag: u } = t, h = i.emitsOptions;
  if (t.dirs || t.transition)
    return !0;
  if (n && u >= 0) {
    if (u & 1024)
      return !0;
    if (u & 16)
      return s ? Lr(s, o, h) : !!o;
    if (u & 8) {
      const d = t.dynamicProps;
      for (let g = 0; g < d.length; g++) {
        const w = d[g];
        if (oo(o, s, w) && !is(h, w))
          return !0;
      }
    }
  } else
    return (r || a) && (!a || !a.$stable) ? !0 : s === o ? !1 : s ? o ? Lr(s, o, h) : !0 : !!o;
  return !1;
}
function Lr(e, t, n) {
  const s = Object.keys(t);
  if (s.length !== Object.keys(e).length)
    return !0;
  for (let r = 0; r < s.length; r++) {
    const i = s[r];
    if (oo(t, e, i) && !is(n, i))
      return !0;
  }
  return !1;
}
function oo(e, t, n) {
  const s = e[n], r = t[n];
  return n === "style" && ue(s) && ue(r) ? !Bt(s, r) : s !== r;
}
function Al({ vnode: e, parent: t, suspense: n }, s) {
  for (; t; ) {
    const r = t.subTree;
    if (r.suspense && r.suspense.activeBranch === e && (r.suspense.vnode.el = r.el = s, e = r), r === e)
      (e = t.vnode).el = s, t = t.parent;
    else
      break;
  }
  n && n.activeBranch === e && (n.vnode.el = s);
}
const ao = {}, lo = () => Object.create(ao), co = (e) => Object.getPrototypeOf(e) === ao;
function El(e, t, n, s = !1) {
  const r = {}, i = lo();
  e.propsDefaults = /* @__PURE__ */ Object.create(null), uo(e, t, r, i);
  for (const o in e.propsOptions[0])
    o in r || (r[o] = void 0);
  n ? e.props = s ? r : /* @__PURE__ */ $a(r) : e.type.props ? e.props = r : e.props = i, e.attrs = i;
}
function xl(e, t, n, s) {
  const {
    props: r,
    attrs: i,
    vnode: { patchFlag: o }
  } = e, a = /* @__PURE__ */ ce(r), [u] = e.propsOptions;
  let h = !1;
  if (
    // always force full diff in dev
    // - #1942 if hmr is enabled with sfc component
    // - vite#872 non-sfc component used by sfc component
    (s || o > 0) && !(o & 16)
  ) {
    if (o & 8) {
      const d = e.vnode.dynamicProps;
      for (let g = 0; g < d.length; g++) {
        let w = d[g];
        if (is(e.emitsOptions, w))
          continue;
        const R = t[w];
        if (u)
          if (le(i, w))
            R !== i[w] && (i[w] = R, h = !0);
          else {
            const P = xe(w);
            r[P] = Ms(
              u,
              a,
              P,
              R,
              e,
              !1
            );
          }
        else
          R !== i[w] && (i[w] = R, h = !0);
      }
    }
  } else {
    uo(e, t, r, i) && (h = !0);
    let d;
    for (const g in a)
      (!t || // for camelCase
      !le(t, g) && // it's possible the original props was passed in as kebab-case
      // and converted to camelCase (#955)
      ((d = Ze(g)) === g || !le(t, d))) && (u ? n && // for camelCase
      (n[g] !== void 0 || // for kebab-case
      n[d] !== void 0) && (r[g] = Ms(
        u,
        a,
        g,
        void 0,
        e,
        !0
      )) : delete r[g]);
    if (i !== a)
      for (const g in i)
        (!t || !le(t, g)) && (delete i[g], h = !0);
  }
  h && It(e.attrs, "set", "");
}
function uo(e, t, n, s) {
  const [r, i] = e.propsOptions;
  let o = !1, a;
  if (t)
    for (let u in t) {
      if (dn(u))
        continue;
      const h = t[u];
      let d;
      r && le(r, d = xe(u)) ? !i || !i.includes(d) ? n[d] = h : (a || (a = {}))[d] = h : is(e.emitsOptions, u) || (!(u in s) || h !== s[u]) && (s[u] = h, o = !0);
    }
  if (i) {
    const u = /* @__PURE__ */ ce(n), h = a || he;
    for (let d = 0; d < i.length; d++) {
      const g = i[d];
      n[g] = Ms(
        r,
        u,
        g,
        h[g],
        e,
        !le(h, g)
      );
    }
  }
  return o;
}
function Ms(e, t, n, s, r, i) {
  const o = e[n];
  if (o != null) {
    const a = le(o, "default");
    if (a && s === void 0) {
      const u = o.default;
      if (o.type !== Function && !o.skipFactory && ne(u)) {
        const { propsDefaults: h } = r;
        if (n in h)
          s = h[n];
        else {
          const d = kn(r);
          s = h[n] = u.call(
            null,
            t
          ), d();
        }
      } else
        s = u;
      r.ce && r.ce._setProp(n, s);
    }
    o[
      0
      /* shouldCast */
    ] && (i && !a ? s = !1 : o[
      1
      /* shouldCastTrue */
    ] && (s === "" || s === Ze(n)) && (s = !0));
  }
  return s;
}
const Cl = /* @__PURE__ */ new WeakMap();
function fo(e, t, n = !1) {
  const s = n ? Cl : t.propsCache, r = s.get(e);
  if (r)
    return r;
  const i = e.props, o = {}, a = [];
  let u = !1;
  if (!ne(e)) {
    const d = (g) => {
      u = !0;
      const [w, R] = fo(g, t, !0);
      ve(o, w), R && a.push(...R);
    };
    !n && t.mixins.length && t.mixins.forEach(d), e.extends && d(e.extends), e.mixins && e.mixins.forEach(d);
  }
  if (!i && !u)
    return ue(e) && s.set(e, Xt), Xt;
  if (J(i))
    for (let d = 0; d < i.length; d++) {
      const g = xe(i[d]);
      Fr(g) && (o[g] = he);
    }
  else if (i)
    for (const d in i) {
      const g = xe(d);
      if (Fr(g)) {
        const w = i[d], R = o[g] = J(w) || ne(w) ? { type: w } : ve({}, w), P = R.type;
        let x = !1, $ = !0;
        if (J(P))
          for (let I = 0; I < P.length; ++I) {
            const y = P[I], O = ne(y) && y.name;
            if (O === "Boolean") {
              x = !0;
              break;
            } else O === "String" && ($ = !1);
          }
        else
          x = ne(P) && P.name === "Boolean";
        R[
          0
          /* shouldCast */
        ] = x, R[
          1
          /* shouldCastTrue */
        ] = $, (x || le(R, "default")) && a.push(g);
      }
    }
  const h = [o, a];
  return ue(e) && s.set(e, h), h;
}
function Fr(e) {
  return e[0] !== "$" && !dn(e);
}
const sr = (e) => e === "_" || e === "_ctx" || e === "$stable", rr = (e) => J(e) ? e.map(dt) : [dt(e)], kl = (e, t, n) => {
  if (t._n)
    return t;
  const s = jn((...r) => rr(t(...r)), n);
  return s._c = !1, s;
}, ho = (e, t, n) => {
  const s = e._ctx;
  for (const r in e) {
    if (sr(r)) continue;
    const i = e[r];
    if (ne(i))
      t[r] = kl(r, i, s);
    else if (i != null) {
      const o = rr(i);
      t[r] = () => o;
    }
  }
}, po = (e, t) => {
  const n = rr(t);
  e.slots.default = () => n;
}, go = (e, t, n) => {
  for (const s in t)
    (n || !sr(s)) && (e[s] = t[s]);
}, Pl = (e, t, n) => {
  const s = e.slots = lo();
  if (e.vnode.shapeFlag & 32) {
    const r = t._;
    r ? (go(s, t, n), n && Si(s, "_", r, !0)) : ho(t, s);
  } else t && po(e, t);
}, Tl = (e, t, n) => {
  const { vnode: s, slots: r } = e;
  let i = !0, o = he;
  if (s.shapeFlag & 32) {
    const a = t._;
    a ? n && a === 1 ? i = !1 : go(r, t, n) : (i = !t.$stable, ho(t, r)), o = t;
  } else t && (po(e, t), o = { default: 1 });
  if (i)
    for (const a in r)
      !sr(a) && o[a] == null && delete r[a];
}, Ke = Nl;
function Rl(e) {
  return $l(e);
}
function $l(e, t) {
  const n = Zn();
  n.__VUE__ = !0;
  const {
    insert: s,
    remove: r,
    patchProp: i,
    createElement: o,
    createText: a,
    createComment: u,
    setText: h,
    setElementText: d,
    parentNode: g,
    nextSibling: w,
    setScopeId: R = ht,
    insertStaticContent: P
  } = e, x = (l, c, f, m = null, b = null, p = null, v = void 0, _ = null, C = !!c.dynamicChildren) => {
    if (l === c)
      return;
    l && !ln(l, c) && (m = k(l), fe(l, b, p, !0), l = null), c.patchFlag === -2 && (C = !1, c.dynamicChildren = null);
    const { type: A, ref: B, shapeFlag: F } = c;
    switch (A) {
      case os:
        $(l, c, f, m);
        break;
      case Tt:
        I(l, c, f, m);
        break;
      case ms:
        l == null && y(c, f, m, v);
        break;
      case me:
        re(
          l,
          c,
          f,
          m,
          b,
          p,
          v,
          _,
          C
        );
        break;
      default:
        F & 1 ? q(
          l,
          c,
          f,
          m,
          b,
          p,
          v,
          _,
          C
        ) : F & 6 ? ee(
          l,
          c,
          f,
          m,
          b,
          p,
          v,
          _,
          C
        ) : (F & 64 || F & 128) && A.process(
          l,
          c,
          f,
          m,
          b,
          p,
          v,
          _,
          C,
          ie
        );
    }
    B != null && b ? pn(B, l && l.ref, p, c || l, !c) : B == null && l && l.ref != null && pn(l.ref, null, p, l, !0);
  }, $ = (l, c, f, m) => {
    if (l == null)
      s(
        c.el = a(c.children),
        f,
        m
      );
    else {
      const b = c.el = l.el;
      c.children !== l.children && h(b, c.children);
    }
  }, I = (l, c, f, m) => {
    l == null ? s(
      c.el = u(c.children || ""),
      f,
      m
    ) : c.el = l.el;
  }, y = (l, c, f, m) => {
    [l.el, l.anchor] = P(
      l.children,
      c,
      f,
      m,
      l.el,
      l.anchor
    );
  }, O = ({ el: l, anchor: c }, f, m) => {
    let b;
    for (; l && l !== c; )
      b = w(l), s(l, f, m), l = b;
    s(c, f, m);
  }, E = ({ el: l, anchor: c }) => {
    let f;
    for (; l && l !== c; )
      f = w(l), r(l), l = f;
    r(c);
  }, q = (l, c, f, m, b, p, v, _, C) => {
    if (c.type === "svg" ? v = "svg" : c.type === "math" && (v = "mathml"), l == null)
      S(
        c,
        f,
        m,
        b,
        p,
        v,
        _,
        C
      );
    else {
      const A = l.el && l.el._isVueCE ? l.el : null;
      try {
        A && A._beginPatch(), K(
          l,
          c,
          b,
          p,
          v,
          _,
          C
        );
      } finally {
        A && A._endPatch();
      }
    }
  }, S = (l, c, f, m, b, p, v, _) => {
    let C, A;
    const { props: B, shapeFlag: F, transition: W, dirs: z } = l;
    if (C = l.el = o(
      l.type,
      p,
      B && B.is,
      B
    ), F & 8 ? d(C, l.children) : F & 16 && j(
      l.children,
      C,
      null,
      m,
      b,
      gs(l, p),
      v,
      _
    ), z && Lt(l, null, m, "created"), M(C, l, l.scopeId, v, m), B) {
      for (const oe in B)
        oe !== "value" && !dn(oe) && i(C, oe, null, B[oe], p, m);
      "value" in B && i(C, "value", null, B.value, p), (A = B.onVnodeBeforeMount) && lt(A, m, l);
    }
    z && Lt(l, null, m, "beforeMount");
    const X = Ml(b, W);
    X && W.beforeEnter(C), s(C, c, f), ((A = B && B.onVnodeMounted) || X || z) && Ke(() => {
      try {
        A && lt(A, m, l), X && W.enter(C), z && Lt(l, null, m, "mounted");
      } finally {
      }
    }, b);
  }, M = (l, c, f, m, b) => {
    if (f && R(l, f), m)
      for (let p = 0; p < m.length; p++)
        R(l, m[p]);
    if (b) {
      let p = b.subTree;
      if (c === p || _o(p.type) && (p.ssContent === c || p.ssFallback === c)) {
        const v = b.vnode;
        M(
          l,
          v,
          v.scopeId,
          v.slotScopeIds,
          b.parent
        );
      }
    }
  }, j = (l, c, f, m, b, p, v, _, C = 0) => {
    for (let A = C; A < l.length; A++) {
      const B = l[A] = _ ? St(l[A]) : dt(l[A]);
      x(
        null,
        B,
        c,
        f,
        m,
        b,
        p,
        v,
        _
      );
    }
  }, K = (l, c, f, m, b, p, v) => {
    const _ = c.el = l.el;
    let { patchFlag: C, dynamicChildren: A, dirs: B } = c;
    C |= l.patchFlag & 16;
    const F = l.props || he, W = c.props || he;
    let z;
    if (f && Ft(f, !1), (z = W.onVnodeBeforeUpdate) && lt(z, f, c, l), B && Lt(c, l, f, "beforeUpdate"), f && Ft(f, !0), (F.innerHTML && W.innerHTML == null || F.textContent && W.textContent == null) && d(_, ""), A ? H(
      l.dynamicChildren,
      A,
      _,
      f,
      m,
      gs(c, b),
      p
    ) : v || Q(
      l,
      c,
      _,
      null,
      f,
      m,
      gs(c, b),
      p,
      !1
    ), C > 0) {
      if (C & 16)
        se(_, F, W, f, b);
      else if (C & 2 && F.class !== W.class && i(_, "class", null, W.class, b), C & 4 && i(_, "style", F.style, W.style, b), C & 8) {
        const X = c.dynamicProps;
        for (let oe = 0; oe < X.length; oe++) {
          const pe = X[oe], Se = F[pe], Ce = W[pe];
          (Ce !== Se || pe === "value") && i(_, pe, Se, Ce, b, f);
        }
      }
      C & 1 && l.children !== c.children && d(_, c.children);
    } else !v && A == null && se(_, F, W, f, b);
    ((z = W.onVnodeUpdated) || B) && Ke(() => {
      z && lt(z, f, c, l), B && Lt(c, l, f, "updated");
    }, m);
  }, H = (l, c, f, m, b, p, v) => {
    for (let _ = 0; _ < c.length; _++) {
      const C = l[_], A = c[_], B = (
        // oldVNode may be an errored async setup() component inside Suspense
        // which will not have a mounted element
        C.el && // - In the case of a Fragment, we need to provide the actual parent
        // of the Fragment itself so it can move its children.
        (C.type === me || // - In the case of different nodes, there is going to be a replacement
        // which also requires the correct parent container
        !ln(C, A) || // - In the case of a component, it could contain anything.
        C.shapeFlag & 198) ? g(C.el) : (
          // In other cases, the parent container is not actually used so we
          // just pass the block element here to avoid a DOM parentNode call.
          f
        )
      );
      x(
        C,
        A,
        B,
        null,
        m,
        b,
        p,
        v,
        !0
      );
    }
  }, se = (l, c, f, m, b) => {
    if (c !== f) {
      if (c !== he)
        for (const p in c)
          !dn(p) && !(p in f) && i(
            l,
            p,
            c[p],
            null,
            b,
            m
          );
      for (const p in f) {
        if (dn(p)) continue;
        const v = f[p], _ = c[p];
        v !== _ && p !== "value" && i(l, p, _, v, b, m);
      }
      "value" in f && i(l, "value", c.value, f.value, b);
    }
  }, re = (l, c, f, m, b, p, v, _, C) => {
    const A = c.el = l ? l.el : a(""), B = c.anchor = l ? l.anchor : a("");
    let { patchFlag: F, dynamicChildren: W, slotScopeIds: z } = c;
    z && (_ = _ ? _.concat(z) : z), l == null ? (s(A, f, m), s(B, f, m), j(
      // #10007
      // such fragment like `<></>` will be compiled into
      // a fragment which doesn't have a children.
      // In this case fallback to an empty array
      c.children || [],
      f,
      B,
      b,
      p,
      v,
      _,
      C
    )) : F > 0 && F & 64 && W && // #2715 the previous fragment could've been a BAILed one as a result
    // of renderSlot() with no valid children
    l.dynamicChildren && l.dynamicChildren.length === W.length ? (H(
      l.dynamicChildren,
      W,
      f,
      b,
      p,
      v,
      _
    ), // #2080 if the stable fragment has a key, it's a <template v-for> that may
    //  get moved around. Make sure all root level vnodes inherit el.
    // #2134 or if it's a component root, it may also get moved around
    // as the component is being moved.
    (c.key != null || b && c === b.subTree) && mo(
      l,
      c,
      !0
      /* shallow */
    )) : Q(
      l,
      c,
      f,
      B,
      b,
      p,
      v,
      _,
      C
    );
  }, ee = (l, c, f, m, b, p, v, _, C) => {
    c.slotScopeIds = _, l == null ? c.shapeFlag & 512 ? b.ctx.activate(
      c,
      f,
      m,
      v,
      C
    ) : we(
      c,
      f,
      m,
      b,
      p,
      v,
      C
    ) : de(l, c, C);
  }, we = (l, c, f, m, b, p, v) => {
    const _ = l.component = jl(
      l,
      m,
      b
    );
    if (Yi(l) && (_.ctx.renderer = ie), Ul(_, !1, v), _.asyncDep) {
      if (b && b.registerDep(_, G, v), !l.el) {
        const C = _.subTree = Te(Tt);
        I(null, C, c, f), l.placeholder = C.el;
      }
    } else
      G(
        _,
        l,
        c,
        f,
        b,
        p,
        v
      );
  }, de = (l, c, f) => {
    const m = c.component = l.component;
    if (Il(l, c, f))
      if (m.asyncDep && !m.asyncResolved) {
        V(m, c, f);
        return;
      } else
        m.next = c, m.update();
    else
      c.el = l.el, m.vnode = c;
  }, G = (l, c, f, m, b, p, v) => {
    const _ = () => {
      if (l.isMounted) {
        let { next: F, bu: W, u: z, parent: X, vnode: oe } = l;
        {
          const ot = yo(l);
          if (ot) {
            F && (F.el = oe.el, V(l, F, v)), ot.asyncDep.then(() => {
              Ke(() => {
                l.isUnmounted || A();
              }, b);
            });
            return;
          }
        }
        let pe = F, Se;
        Ft(l, !1), F ? (F.el = oe.el, V(l, F, v)) : F = oe, W && Mn(W), (Se = F.props && F.props.onVnodeBeforeUpdate) && lt(Se, X, F, oe), Ft(l, !0);
        const Ce = Dr(l), it = l.subTree;
        l.subTree = Ce, x(
          it,
          Ce,
          // parent may have changed if it's in a teleport
          g(it.el),
          // anchor may have changed if it's in a fragment
          k(it),
          l,
          b,
          p
        ), F.el = Ce.el, pe === null && Al(l, Ce.el), z && Ke(z, b), (Se = F.props && F.props.onVnodeUpdated) && Ke(
          () => lt(Se, X, F, oe),
          b
        );
      } else {
        let F;
        const { el: W, props: z } = c, { bm: X, m: oe, parent: pe, root: Se, type: Ce } = l, it = en(c);
        Ft(l, !1), X && Mn(X), !it && (F = z && z.onVnodeBeforeMount) && lt(F, pe, c), Ft(l, !0);
        {
          Se.ce && Se.ce._hasShadowRoot() && Se.ce._injectChildStyle(
            Ce,
            l.parent ? l.parent.type : void 0
          );
          const ot = l.subTree = Dr(l);
          x(
            null,
            ot,
            f,
            m,
            l,
            b,
            p
          ), c.el = ot.el;
        }
        if (oe && Ke(oe, b), !it && (F = z && z.onVnodeMounted)) {
          const ot = c;
          Ke(
            () => lt(F, pe, ot),
            b
          );
        }
        (c.shapeFlag & 256 || pe && en(pe.vnode) && pe.vnode.shapeFlag & 256) && l.a && Ke(l.a, b), l.isMounted = !0, c = f = m = null;
      }
    };
    l.scope.on();
    const C = l.effect = new Ci(_);
    l.scope.off();
    const A = l.update = C.run.bind(C), B = l.job = C.runIfDirty.bind(C);
    B.i = l, B.id = l.uid, C.scheduler = () => er(B), Ft(l, !0), A();
  }, V = (l, c, f) => {
    c.component = l;
    const m = l.vnode.props;
    l.vnode = c, l.next = null, xl(l, c.props, m, f), Tl(l, c.children, f), Ct(), kr(l), kt();
  }, Q = (l, c, f, m, b, p, v, _, C = !1) => {
    const A = l && l.children, B = l ? l.shapeFlag : 0, F = c.children, { patchFlag: W, shapeFlag: z } = c;
    if (W > 0) {
      if (W & 128) {
        Xe(
          A,
          F,
          f,
          m,
          b,
          p,
          v,
          _,
          C
        );
        return;
      } else if (W & 256) {
        Ie(
          A,
          F,
          f,
          m,
          b,
          p,
          v,
          _,
          C
        );
        return;
      }
    }
    z & 8 ? (B & 16 && Le(A, b, p), F !== A && d(f, F)) : B & 16 ? z & 16 ? Xe(
      A,
      F,
      f,
      m,
      b,
      p,
      v,
      _,
      C
    ) : Le(A, b, p, !0) : (B & 8 && d(f, ""), z & 16 && j(
      F,
      f,
      m,
      b,
      p,
      v,
      _,
      C
    ));
  }, Ie = (l, c, f, m, b, p, v, _, C) => {
    l = l || Xt, c = c || Xt;
    const A = l.length, B = c.length, F = Math.min(A, B);
    let W;
    for (W = 0; W < F; W++) {
      const z = c[W] = C ? St(c[W]) : dt(c[W]);
      x(
        l[W],
        z,
        f,
        null,
        b,
        p,
        v,
        _,
        C
      );
    }
    A > B ? Le(
      l,
      b,
      p,
      !0,
      !1,
      F
    ) : j(
      c,
      f,
      m,
      b,
      p,
      v,
      _,
      C,
      F
    );
  }, Xe = (l, c, f, m, b, p, v, _, C) => {
    let A = 0;
    const B = c.length;
    let F = l.length - 1, W = B - 1;
    for (; A <= F && A <= W; ) {
      const z = l[A], X = c[A] = C ? St(c[A]) : dt(c[A]);
      if (ln(z, X))
        x(
          z,
          X,
          f,
          null,
          b,
          p,
          v,
          _,
          C
        );
      else
        break;
      A++;
    }
    for (; A <= F && A <= W; ) {
      const z = l[F], X = c[W] = C ? St(c[W]) : dt(c[W]);
      if (ln(z, X))
        x(
          z,
          X,
          f,
          null,
          b,
          p,
          v,
          _,
          C
        );
      else
        break;
      F--, W--;
    }
    if (A > F) {
      if (A <= W) {
        const z = W + 1, X = z < B ? c[z].el : m;
        for (; A <= W; )
          x(
            null,
            c[A] = C ? St(c[A]) : dt(c[A]),
            f,
            X,
            b,
            p,
            v,
            _,
            C
          ), A++;
      }
    } else if (A > W)
      for (; A <= F; )
        fe(l[A], b, p, !0), A++;
    else {
      const z = A, X = A, oe = /* @__PURE__ */ new Map();
      for (A = X; A <= W; A++) {
        const ze = c[A] = C ? St(c[A]) : dt(c[A]);
        ze.key != null && oe.set(ze.key, A);
      }
      let pe, Se = 0;
      const Ce = W - X + 1;
      let it = !1, ot = 0;
      const on = new Array(Ce);
      for (A = 0; A < Ce; A++) on[A] = 0;
      for (A = z; A <= F; A++) {
        const ze = l[A];
        if (Se >= Ce) {
          fe(ze, b, p, !0);
          continue;
        }
        let at;
        if (ze.key != null)
          at = oe.get(ze.key);
        else
          for (pe = X; pe <= W; pe++)
            if (on[pe - X] === 0 && ln(ze, c[pe])) {
              at = pe;
              break;
            }
        at === void 0 ? fe(ze, b, p, !0) : (on[at - X] = A + 1, at >= ot ? ot = at : it = !0, x(
          ze,
          c[at],
          f,
          null,
          b,
          p,
          v,
          _,
          C
        ), Se++);
      }
      const mr = it ? Ol(on) : Xt;
      for (pe = mr.length - 1, A = Ce - 1; A >= 0; A--) {
        const ze = X + A, at = c[ze], yr = c[ze + 1], br = ze + 1 < B ? (
          // #13559, #14173 fallback to el placeholder for unresolved async component
          yr.el || bo(yr)
        ) : m;
        on[A] === 0 ? x(
          null,
          at,
          f,
          br,
          b,
          p,
          v,
          _,
          C
        ) : it && (pe < 0 || A !== mr[pe] ? Ae(at, f, br, 2) : pe--);
      }
    }
  }, Ae = (l, c, f, m, b = null) => {
    const { el: p, type: v, transition: _, children: C, shapeFlag: A } = l;
    if (A & 6) {
      Ae(l.component.subTree, c, f, m);
      return;
    }
    if (A & 128) {
      l.suspense.move(c, f, m);
      return;
    }
    if (A & 64) {
      v.move(l, c, f, ie);
      return;
    }
    if (v === me) {
      s(p, c, f);
      for (let F = 0; F < C.length; F++)
        Ae(C[F], c, f, m);
      s(l.anchor, c, f);
      return;
    }
    if (v === ms) {
      O(l, c, f);
      return;
    }
    if (m !== 2 && A & 1 && _)
      if (m === 0)
        _.beforeEnter(p), s(p, c, f), Ke(() => _.enter(p), b);
      else {
        const { leave: F, delayLeave: W, afterLeave: z } = _, X = () => {
          l.ctx.isUnmounted ? r(p) : s(p, c, f);
        }, oe = () => {
          p._isLeaving && p[Ya](
            !0
            /* cancelled */
          ), F(p, () => {
            X(), z && z();
          });
        };
        W ? W(p, X, oe) : oe();
      }
    else
      s(p, c, f);
  }, fe = (l, c, f, m = !1, b = !1) => {
    const {
      type: p,
      props: v,
      ref: _,
      children: C,
      dynamicChildren: A,
      shapeFlag: B,
      patchFlag: F,
      dirs: W,
      cacheIndex: z,
      memo: X
    } = l;
    if (F === -2 && (b = !1), _ != null && (Ct(), pn(_, null, f, l, !0), kt()), z != null && (c.renderCache[z] = void 0), B & 256) {
      c.ctx.deactivate(l);
      return;
    }
    const oe = B & 1 && W, pe = !en(l);
    let Se;
    if (pe && (Se = v && v.onVnodeBeforeUnmount) && lt(Se, c, l), B & 6)
      Re(l.component, f, m);
    else {
      if (B & 128) {
        l.suspense.unmount(f, m);
        return;
      }
      oe && Lt(l, null, c, "beforeUnmount"), B & 64 ? l.type.remove(
        l,
        c,
        f,
        ie,
        m
      ) : A && // #5154
      // when v-once is used inside a block, setBlockTracking(-1) marks the
      // parent block with hasOnce: true
      // so that it doesn't take the fast path during unmount - otherwise
      // components nested in v-once are never unmounted.
      !A.hasOnce && // #1153: fast path should not be taken for non-stable (v-for) fragments
      (p !== me || F > 0 && F & 64) ? Le(
        A,
        c,
        f,
        !1,
        !0
      ) : (p === me && F & 384 || !b && B & 16) && Le(C, c, f), m && De(l);
    }
    const Ce = X != null && z == null;
    (pe && (Se = v && v.onVnodeUnmounted) || oe || Ce) && Ke(() => {
      Se && lt(Se, c, l), oe && Lt(l, null, c, "unmounted"), Ce && (l.el = null);
    }, f);
  }, De = (l) => {
    const { type: c, el: f, anchor: m, transition: b } = l;
    if (c === me) {
      yt(f, m);
      return;
    }
    if (c === ms) {
      E(l);
      return;
    }
    const p = () => {
      r(f), b && !b.persisted && b.afterLeave && b.afterLeave();
    };
    if (l.shapeFlag & 1 && b && !b.persisted) {
      const { leave: v, delayLeave: _ } = b, C = () => v(f, p);
      _ ? _(l.el, p, C) : C();
    } else
      p();
  }, yt = (l, c) => {
    let f;
    for (; l !== c; )
      f = w(l), r(l), l = f;
    r(c);
  }, Re = (l, c, f) => {
    const { bum: m, scope: b, job: p, subTree: v, um: _, m: C, a: A } = l;
    qr(C), qr(A), m && Mn(m), b.stop(), p && (p.flags |= 8, fe(v, l, c, f)), _ && Ke(_, c), Ke(() => {
      l.isUnmounted = !0;
    }, c);
  }, Le = (l, c, f, m = !1, b = !1, p = 0) => {
    for (let v = p; v < l.length; v++)
      fe(l[v], c, f, m, b);
  }, k = (l) => {
    if (l.shapeFlag & 6)
      return k(l.component.subTree);
    if (l.shapeFlag & 128)
      return l.suspense.next();
    const c = w(l.anchor || l.el), f = c && c[Ga];
    return f ? w(f) : c;
  };
  let D = !1;
  const Y = (l, c, f) => {
    let m;
    l == null ? c._vnode && (fe(c._vnode, null, null, !0), m = c._vnode.component) : x(
      c._vnode || null,
      l,
      c,
      null,
      null,
      null,
      f
    ), c._vnode = l, D || (D = !0, kr(m), Hi(), D = !1);
  }, ie = {
    p: x,
    um: fe,
    m: Ae,
    r: De,
    mt: we,
    mc: j,
    pc: Q,
    pbc: H,
    n: k,
    o: e
  };
  return {
    render: Y,
    hydrate: void 0,
    createApp: yl(Y)
  };
}
function gs({ type: e, props: t }, n) {
  return n === "svg" && e === "foreignObject" || n === "mathml" && e === "annotation-xml" && t && t.encoding && t.encoding.includes("html") ? void 0 : n;
}
function Ft({ effect: e, job: t }, n) {
  n ? (e.flags |= 32, t.flags |= 4) : (e.flags &= -33, t.flags &= -5);
}
function Ml(e, t) {
  return (!e || e && !e.pendingBranch) && t && !t.persisted;
}
function mo(e, t, n = !1) {
  const s = e.children, r = t.children;
  if (J(s) && J(r))
    for (let i = 0; i < s.length; i++) {
      const o = s[i];
      let a = r[i];
      a.shapeFlag & 1 && !a.dynamicChildren && ((a.patchFlag <= 0 || a.patchFlag === 32) && (a = r[i] = St(r[i]), a.el = o.el), !n && a.patchFlag !== -2 && mo(o, a)), a.type === os && (a.patchFlag === -1 && (a = r[i] = St(a)), a.el = o.el), a.type === Tt && !a.el && (a.el = o.el);
    }
}
function Ol(e) {
  const t = e.slice(), n = [0];
  let s, r, i, o, a;
  const u = e.length;
  for (s = 0; s < u; s++) {
    const h = e[s];
    if (h !== 0) {
      if (r = n[n.length - 1], e[r] < h) {
        t[s] = r, n.push(s);
        continue;
      }
      for (i = 0, o = n.length - 1; i < o; )
        a = i + o >> 1, e[n[a]] < h ? i = a + 1 : o = a;
      h < e[n[i]] && (i > 0 && (t[s] = n[i - 1]), n[i] = s);
    }
  }
  for (i = n.length, o = n[i - 1]; i-- > 0; )
    n[i] = o, o = t[o];
  return n;
}
function yo(e) {
  const t = e.subTree.component;
  if (t)
    return t.asyncDep && !t.asyncResolved ? t : yo(t);
}
function qr(e) {
  if (e)
    for (let t = 0; t < e.length; t++)
      e[t].flags |= 8;
}
function bo(e) {
  if (e.placeholder)
    return e.placeholder;
  const t = e.component;
  return t ? bo(t.subTree) : null;
}
const _o = (e) => e.__isSuspense;
function Nl(e, t) {
  t && t.pendingBranch ? J(e) ? t.effects.push(...e) : t.effects.push(e) : Ba(e);
}
const me = /* @__PURE__ */ Symbol.for("v-fgt"), os = /* @__PURE__ */ Symbol.for("v-txt"), Tt = /* @__PURE__ */ Symbol.for("v-cmt"), ms = /* @__PURE__ */ Symbol.for("v-stc"), mn = [];
let Je = null;
function T(e = !1) {
  mn.push(Je = e ? null : []);
}
function Dl() {
  mn.pop(), Je = mn[mn.length - 1] || null;
}
let wn = 1;
function Bn(e, t = !1) {
  wn += e, e < 0 && Je && t && (Je.hasOnce = !0);
}
function vo(e) {
  return e.dynamicChildren = wn > 0 ? Je || Xt : null, Dl(), wn > 0 && Je && Je.push(e), e;
}
function N(e, t, n, s, r, i) {
  return vo(
    U(
      e,
      t,
      n,
      s,
      r,
      i,
      !0
    )
  );
}
function mt(e, t, n, s, r) {
  return vo(
    Te(
      e,
      t,
      n,
      s,
      r,
      !0
    )
  );
}
function Sn(e) {
  return e ? e.__v_isVNode === !0 : !1;
}
function ln(e, t) {
  return e.type === t.type && e.key === t.key;
}
const wo = ({ key: e }) => e ?? null, Nn = ({
  ref: e,
  ref_key: t,
  ref_for: n
}) => (typeof e == "number" && (e = "" + e), e != null ? be(e) || /* @__PURE__ */ Ne(e) || ne(e) ? { i: Pe, r: e, k: t, f: !!n } : e : null);
function U(e, t = null, n = null, s = 0, r = null, i = e === me ? 0 : 1, o = !1, a = !1) {
  const u = {
    __v_isVNode: !0,
    __v_skip: !0,
    type: e,
    props: t,
    key: t && wo(t),
    ref: t && Nn(t),
    scopeId: Wi,
    slotScopeIds: null,
    children: n,
    component: null,
    suspense: null,
    ssContent: null,
    ssFallback: null,
    dirs: null,
    transition: null,
    el: null,
    anchor: null,
    target: null,
    targetStart: null,
    targetAnchor: null,
    staticCount: 0,
    shapeFlag: i,
    patchFlag: s,
    dynamicProps: r,
    dynamicChildren: null,
    appContext: null,
    ctx: Pe
  };
  return a ? (ir(u, n), i & 128 && e.normalize(u)) : n && (u.shapeFlag |= be(n) ? 8 : 16), wn > 0 && // avoid a block node from tracking itself
  !o && // has current parent block
  Je && // presence of a patch flag indicates this node needs patching on updates.
  // component nodes also should always be patched, because even if the
  // component doesn't need to update, it needs to persist the instance on to
  // the next vnode so that it can be properly unmounted later.
  (u.patchFlag > 0 || i & 6) && // the EVENTS flag is only for hydration and if it is the only flag, the
  // vnode should not be considered dynamic due to handler caching.
  u.patchFlag !== 32 && Je.push(u), u;
}
const Te = Ll;
function Ll(e, t = null, n = null, s = 0, r = null, i = !1) {
  if ((!e || e === Zi) && (e = Tt), Sn(e)) {
    const a = sn(
      e,
      t,
      !0
      /* mergeRef: true */
    );
    return n && ir(a, n), wn > 0 && !i && Je && (a.shapeFlag & 6 ? Je[Je.indexOf(e)] = a : Je.push(a)), a.patchFlag = -2, a;
  }
  if (zl(e) && (e = e.__vccOpts), t) {
    t = So(t);
    let { class: a, style: u } = t;
    a && !be(a) && (t.class = Oe(a)), ue(u) && (/* @__PURE__ */ Xs(u) && !J(u) && (u = ve({}, u)), t.style = xn(u));
  }
  const o = be(e) ? 1 : _o(e) ? 128 : Ja(e) ? 64 : ue(e) ? 4 : ne(e) ? 2 : 0;
  return U(
    e,
    t,
    n,
    s,
    r,
    o,
    i,
    !0
  );
}
function So(e) {
  return e ? /* @__PURE__ */ Xs(e) || co(e) ? ve({}, e) : e : null;
}
function sn(e, t, n = !1, s = !1) {
  const { props: r, ref: i, patchFlag: o, children: a, transition: u } = e, h = t ? Io(r || {}, t) : r, d = {
    __v_isVNode: !0,
    __v_skip: !0,
    type: e.type,
    props: h,
    key: h && wo(h),
    ref: t && t.ref ? (
      // #2078 in the case of <component :is="vnode" ref="extra"/>
      // if the vnode itself already has a ref, cloneVNode will need to merge
      // the refs so the single vnode can be set on multiple refs
      n && i ? J(i) ? i.concat(Nn(t)) : [i, Nn(t)] : Nn(t)
    ) : i,
    scopeId: e.scopeId,
    slotScopeIds: e.slotScopeIds,
    children: a,
    target: e.target,
    targetStart: e.targetStart,
    targetAnchor: e.targetAnchor,
    staticCount: e.staticCount,
    shapeFlag: e.shapeFlag,
    // if the vnode is cloned with extra props, we can no longer assume its
    // existing patch flag to be reliable and need to add the FULL_PROPS flag.
    // note: preserve flag for fragments since they use the flag for children
    // fast paths only.
    patchFlag: t && e.type !== me ? o === -1 ? 16 : o | 16 : o,
    dynamicProps: e.dynamicProps,
    dynamicChildren: e.dynamicChildren,
    appContext: e.appContext,
    dirs: e.dirs,
    transition: u,
    // These should technically only be non-null on mounted VNodes. However,
    // they *should* be copied for kept-alive vnodes. So we just always copy
    // them since them being non-null during a mount doesn't affect the logic as
    // they will simply be overwritten.
    component: e.component,
    suspense: e.suspense,
    ssContent: e.ssContent && sn(e.ssContent),
    ssFallback: e.ssFallback && sn(e.ssFallback),
    placeholder: e.placeholder,
    el: e.el,
    anchor: e.anchor,
    ctx: e.ctx,
    ce: e.ce
  };
  return u && s && tr(
    d,
    u.clone(d)
  ), d;
}
function In(e = " ", t = 0) {
  return Te(os, null, e, t);
}
function te(e = "", t = !1) {
  return t ? (T(), mt(Tt, null, e)) : Te(Tt, null, e);
}
function dt(e) {
  return e == null || typeof e == "boolean" ? Te(Tt) : J(e) ? Te(
    me,
    null,
    // #3666, avoid reference pollution when reusing vnode
    e.slice()
  ) : Sn(e) ? St(e) : Te(os, null, String(e));
}
function St(e) {
  return e.el === null && e.patchFlag !== -1 || e.memo ? e : sn(e);
}
function ir(e, t) {
  let n = 0;
  const { shapeFlag: s } = e;
  if (t == null)
    t = null;
  else if (J(t))
    n = 16;
  else if (typeof t == "object")
    if (s & 65) {
      const r = t.default;
      r && (r._c && (r._d = !1), ir(e, r()), r._c && (r._d = !0));
      return;
    } else {
      n = 32;
      const r = t._;
      !r && !co(t) ? t._ctx = Pe : r === 3 && Pe && (Pe.slots._ === 1 ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024));
    }
  else ne(t) ? (t = { default: t, _ctx: Pe }, n = 32) : (t = String(t), s & 64 ? (n = 16, t = [In(t)]) : n = 8);
  e.children = t, e.shapeFlag |= n;
}
function Io(...e) {
  const t = {};
  for (let n = 0; n < e.length; n++) {
    const s = e[n];
    for (const r in s)
      if (r === "class")
        t.class !== s.class && (t.class = Oe([t.class, s.class]));
      else if (r === "style")
        t.style = xn([t.style, s.style]);
      else if (zn(r)) {
        const i = t[r], o = s[r];
        o && i !== o && !(J(i) && i.includes(o)) ? t[r] = i ? [].concat(i, o) : o : o == null && i == null && // mergeProps({ 'onUpdate:modelValue': undefined }) should not retain
        // the model listener.
        !Gn(r) && (t[r] = o);
      } else r !== "" && (t[r] = s[r]);
  }
  return t;
}
function lt(e, t, n, s = null) {
  pt(e, t, 7, [
    n,
    s
  ]);
}
const Fl = ro();
let ql = 0;
function jl(e, t, n) {
  const s = e.type, r = (t ? t.appContext : e.appContext) || Fl, i = {
    uid: ql++,
    vnode: e,
    type: s,
    parent: t,
    appContext: r,
    root: null,
    // to be immediately set
    next: null,
    subTree: null,
    // will be set synchronously right after creation
    effect: null,
    update: null,
    // will be set synchronously right after creation
    job: null,
    scope: new fa(
      !0
      /* detached */
    ),
    render: null,
    proxy: null,
    exposed: null,
    exposeProxy: null,
    withProxy: null,
    provides: t ? t.provides : Object.create(r.provides),
    ids: t ? t.ids : ["", 0, 0],
    accessCache: null,
    renderCache: [],
    // local resolved assets
    components: null,
    directives: null,
    // resolved props and emits options
    propsOptions: fo(s, r),
    emitsOptions: io(s, r),
    // emit
    emit: null,
    // to be set immediately
    emitted: null,
    // props default value
    propsDefaults: he,
    // inheritAttrs
    inheritAttrs: s.inheritAttrs,
    // state
    ctx: he,
    data: he,
    props: he,
    attrs: he,
    slots: he,
    refs: he,
    setupState: he,
    setupContext: null,
    // suspense related
    suspense: n,
    suspenseId: n ? n.pendingId : 0,
    asyncDep: null,
    asyncResolved: !1,
    // lifecycle hooks
    // not using enums here because it results in computed properties
    isMounted: !1,
    isUnmounted: !1,
    isDeactivated: !1,
    bc: null,
    c: null,
    bm: null,
    m: null,
    bu: null,
    u: null,
    um: null,
    bum: null,
    da: null,
    a: null,
    rtg: null,
    rtc: null,
    ec: null,
    sp: null
  };
  return i.ctx = { _: i }, i.root = t ? t.root : i, i.emit = _l.bind(null, i), e.ce && e.ce(i), i;
}
let Me = null;
const Kl = () => Me || Pe;
let Hn, Os;
{
  const e = Zn(), t = (n, s) => {
    let r;
    return (r = e[n]) || (r = e[n] = []), r.push(s), (i) => {
      r.length > 1 ? r.forEach((o) => o(i)) : r[0](i);
    };
  };
  Hn = t(
    "__VUE_INSTANCE_SETTERS__",
    (n) => Me = n
  ), Os = t(
    "__VUE_SSR_SETTERS__",
    (n) => An = n
  );
}
const kn = (e) => {
  const t = Me;
  return Hn(e), e.scope.on(), () => {
    e.scope.off(), Hn(t);
  };
}, jr = () => {
  Me && Me.scope.off(), Hn(null);
};
function Ao(e) {
  return e.vnode.shapeFlag & 4;
}
let An = !1;
function Ul(e, t = !1, n = !1) {
  t && Os(t);
  const { props: s, children: r } = e.vnode, i = Ao(e);
  El(e, s, i, t), Pl(e, r, n || t);
  const o = i ? Bl(e, t) : void 0;
  return t && Os(!1), o;
}
function Bl(e, t) {
  const n = e.type;
  e.accessCache = /* @__PURE__ */ Object.create(null), e.proxy = new Proxy(e.ctx, ul);
  const { setup: s } = n;
  if (s) {
    Ct();
    const r = e.setupContext = s.length > 1 ? Vl(e) : null, i = kn(e), o = Cn(
      s,
      e,
      0,
      [
        e.props,
        r
      ]
    ), a = vi(o);
    if (kt(), i(), (a || e.sp) && !en(e) && Ji(e), a) {
      if (o.then(jr, jr), t)
        return o.then((u) => {
          Kr(e, u);
        }).catch((u) => {
          ns(u, e, 0);
        });
      e.asyncDep = o;
    } else
      Kr(e, o);
  } else
    Eo(e);
}
function Kr(e, t, n) {
  ne(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : ue(t) && (e.setupState = Ki(t)), Eo(e);
}
function Eo(e, t, n) {
  const s = e.type;
  e.render || (e.render = s.render || ht);
  {
    const r = kn(e);
    Ct();
    try {
      dl(e);
    } finally {
      kt(), r();
    }
  }
}
const Hl = {
  get(e, t) {
    return $e(e, "get", ""), e[t];
  }
};
function Vl(e) {
  const t = (n) => {
    e.exposed = n || {};
  };
  return {
    attrs: new Proxy(e.attrs, Hl),
    slots: e.slots,
    emit: e.emit,
    expose: t
  };
}
function as(e) {
  return e.exposed ? e.exposeProxy || (e.exposeProxy = new Proxy(Ki(Ma(e.exposed)), {
    get(t, n) {
      if (n in t)
        return t[n];
      if (n in gn)
        return gn[n](e);
    },
    has(t, n) {
      return n in t || n in gn;
    }
  })) : e.proxy;
}
function Wl(e, t = !0) {
  return ne(e) ? e.displayName || e.name : e.name || t && e.__name;
}
function zl(e) {
  return ne(e) && "__vccOpts" in e;
}
const ae = (e, t) => /* @__PURE__ */ Fa(e, t, An);
function Gl(e, t, n) {
  try {
    Bn(-1);
    const s = arguments.length;
    return s === 2 ? ue(t) && !J(t) ? Sn(t) ? Te(e, null, [t]) : Te(e, t) : Te(e, null, t) : (s > 3 ? n = Array.prototype.slice.call(arguments, 2) : s === 3 && Sn(n) && (n = [n]), Te(e, t, n));
  } finally {
    Bn(1);
  }
}
const Jl = "3.5.31";
/**
* @vue/runtime-dom v3.5.31
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
let Ns;
const Ur = typeof window < "u" && window.trustedTypes;
if (Ur)
  try {
    Ns = /* @__PURE__ */ Ur.createPolicy("vue", {
      createHTML: (e) => e
    });
  } catch {
  }
const xo = Ns ? (e) => Ns.createHTML(e) : (e) => e, Yl = "http://www.w3.org/2000/svg", Xl = "http://www.w3.org/1998/Math/MathML", wt = typeof document < "u" ? document : null, Br = wt && /* @__PURE__ */ wt.createElement("template"), Ql = {
  insert: (e, t, n) => {
    t.insertBefore(e, n || null);
  },
  remove: (e) => {
    const t = e.parentNode;
    t && t.removeChild(e);
  },
  createElement: (e, t, n, s) => {
    const r = t === "svg" ? wt.createElementNS(Yl, e) : t === "mathml" ? wt.createElementNS(Xl, e) : n ? wt.createElement(e, { is: n }) : wt.createElement(e);
    return e === "select" && s && s.multiple != null && r.setAttribute("multiple", s.multiple), r;
  },
  createText: (e) => wt.createTextNode(e),
  createComment: (e) => wt.createComment(e),
  setText: (e, t) => {
    e.nodeValue = t;
  },
  setElementText: (e, t) => {
    e.textContent = t;
  },
  parentNode: (e) => e.parentNode,
  nextSibling: (e) => e.nextSibling,
  querySelector: (e) => wt.querySelector(e),
  setScopeId(e, t) {
    e.setAttribute(t, "");
  },
  // __UNSAFE__
  // Reason: innerHTML.
  // Static content here can only come from compiled templates.
  // As long as the user only uses trusted templates, this is safe.
  insertStaticContent(e, t, n, s, r, i) {
    const o = n ? n.previousSibling : t.lastChild;
    if (r && (r === i || r.nextSibling))
      for (; t.insertBefore(r.cloneNode(!0), n), !(r === i || !(r = r.nextSibling)); )
        ;
    else {
      Br.innerHTML = xo(
        s === "svg" ? `<svg>${e}</svg>` : s === "mathml" ? `<math>${e}</math>` : e
      );
      const a = Br.content;
      if (s === "svg" || s === "mathml") {
        const u = a.firstChild;
        for (; u.firstChild; )
          a.appendChild(u.firstChild);
        a.removeChild(u);
      }
      t.insertBefore(a, n);
    }
    return [
      // first
      o ? o.nextSibling : t.firstChild,
      // last
      n ? n.previousSibling : t.lastChild
    ];
  }
}, Zl = /* @__PURE__ */ Symbol("_vtc");
function ec(e, t, n) {
  const s = e[Zl];
  s && (t = (t ? [t, ...s] : [...s]).join(" ")), t == null ? e.removeAttribute("class") : n ? e.setAttribute("class", t) : e.className = t;
}
const Hr = /* @__PURE__ */ Symbol("_vod"), tc = /* @__PURE__ */ Symbol("_vsh"), nc = /* @__PURE__ */ Symbol(""), sc = /(?:^|;)\s*display\s*:/;
function rc(e, t, n) {
  const s = e.style, r = be(n);
  let i = !1;
  if (n && !r) {
    if (t)
      if (be(t))
        for (const o of t.split(";")) {
          const a = o.slice(0, o.indexOf(":")).trim();
          n[a] == null && Dn(s, a, "");
        }
      else
        for (const o in t)
          n[o] == null && Dn(s, o, "");
    for (const o in n)
      o === "display" && (i = !0), Dn(s, o, n[o]);
  } else if (r) {
    if (t !== n) {
      const o = s[nc];
      o && (n += ";" + o), s.cssText = n, i = sc.test(n);
    }
  } else t && e.removeAttribute("style");
  Hr in e && (e[Hr] = i ? s.display : "", e[tc] && (s.display = "none"));
}
const Vr = /\s*!important$/;
function Dn(e, t, n) {
  if (J(n))
    n.forEach((s) => Dn(e, t, s));
  else if (n == null && (n = ""), t.startsWith("--"))
    e.setProperty(t, n);
  else {
    const s = ic(e, t);
    Vr.test(n) ? e.setProperty(
      Ze(s),
      n.replace(Vr, ""),
      "important"
    ) : e[s] = n;
  }
}
const Wr = ["Webkit", "Moz", "ms"], ys = {};
function ic(e, t) {
  const n = ys[t];
  if (n)
    return n;
  let s = xe(t);
  if (s !== "filter" && s in e)
    return ys[t] = s;
  s = Qn(s);
  for (let r = 0; r < Wr.length; r++) {
    const i = Wr[r] + s;
    if (i in e)
      return ys[t] = i;
  }
  return t;
}
const zr = "http://www.w3.org/1999/xlink";
function Gr(e, t, n, s, r, i = ua(t)) {
  s && t.startsWith("xlink:") ? n == null ? e.removeAttributeNS(zr, t.slice(6, t.length)) : e.setAttributeNS(zr, t, n) : n == null || i && !Ii(n) ? e.removeAttribute(t) : e.setAttribute(
    t,
    i ? "" : st(n) ? String(n) : n
  );
}
function Jr(e, t, n, s, r) {
  if (t === "innerHTML" || t === "textContent") {
    n != null && (e[t] = t === "innerHTML" ? xo(n) : n);
    return;
  }
  const i = e.tagName;
  if (t === "value" && i !== "PROGRESS" && // custom elements may use _value internally
  !i.includes("-")) {
    const a = i === "OPTION" ? e.getAttribute("value") || "" : e.value, u = n == null ? (
      // #11647: value should be set as empty string for null and undefined,
      // but <input type="checkbox"> should be set as 'on'.
      e.type === "checkbox" ? "on" : ""
    ) : String(n);
    (a !== u || !("_value" in e)) && (e.value = u), n == null && e.removeAttribute(t), e._value = n;
    return;
  }
  let o = !1;
  if (n === "" || n == null) {
    const a = typeof e[t];
    a === "boolean" ? n = Ii(n) : n == null && a === "string" ? (n = "", o = !0) : a === "number" && (n = 0, o = !0);
  }
  try {
    e[t] = n;
  } catch {
  }
  o && e.removeAttribute(r || t);
}
function Nt(e, t, n, s) {
  e.addEventListener(t, n, s);
}
function oc(e, t, n, s) {
  e.removeEventListener(t, n, s);
}
const Yr = /* @__PURE__ */ Symbol("_vei");
function ac(e, t, n, s, r = null) {
  const i = e[Yr] || (e[Yr] = {}), o = i[t];
  if (s && o)
    o.value = s;
  else {
    const [a, u] = lc(t);
    if (s) {
      const h = i[t] = dc(
        s,
        r
      );
      Nt(e, a, h, u);
    } else o && (oc(e, a, o, u), i[t] = void 0);
  }
}
const Xr = /(?:Once|Passive|Capture)$/;
function lc(e) {
  let t;
  if (Xr.test(e)) {
    t = {};
    let s;
    for (; s = e.match(Xr); )
      e = e.slice(0, e.length - s[0].length), t[s[0].toLowerCase()] = !0;
  }
  return [e[2] === ":" ? e.slice(3) : Ze(e.slice(2)), t];
}
let bs = 0;
const cc = /* @__PURE__ */ Promise.resolve(), uc = () => bs || (cc.then(() => bs = 0), bs = Date.now());
function dc(e, t) {
  const n = (s) => {
    if (!s._vts)
      s._vts = Date.now();
    else if (s._vts <= n.attached)
      return;
    pt(
      fc(s, n.value),
      t,
      5,
      [s]
    );
  };
  return n.value = e, n.attached = uc(), n;
}
function fc(e, t) {
  if (J(t)) {
    const n = e.stopImmediatePropagation;
    return e.stopImmediatePropagation = () => {
      n.call(e), e._stopped = !0;
    }, t.map(
      (s) => (r) => !r._stopped && s && s(r)
    );
  } else
    return t;
}
const Qr = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && // lowercase letter
e.charCodeAt(2) > 96 && e.charCodeAt(2) < 123, hc = (e, t, n, s, r, i) => {
  const o = r === "svg";
  t === "class" ? ec(e, s, o) : t === "style" ? rc(e, n, s) : zn(t) ? Gn(t) || ac(e, t, n, s, i) : (t[0] === "." ? (t = t.slice(1), !0) : t[0] === "^" ? (t = t.slice(1), !1) : pc(e, t, s, o)) ? (Jr(e, t, s), !e.tagName.includes("-") && (t === "value" || t === "checked" || t === "selected") && Gr(e, t, s, o, i, t !== "value")) : /* #11081 force set props for possible async custom element */ e._isVueCE && // #12408 check if it's declared prop or it's async custom element
  (gc(e, t) || // @ts-expect-error _def is private
  e._def.__asyncLoader && (/[A-Z]/.test(t) || !be(s))) ? Jr(e, xe(t), s, i, t) : (t === "true-value" ? e._trueValue = s : t === "false-value" && (e._falseValue = s), Gr(e, t, s, o));
};
function pc(e, t, n, s) {
  if (s)
    return !!(t === "innerHTML" || t === "textContent" || t in e && Qr(t) && ne(n));
  if (t === "spellcheck" || t === "draggable" || t === "translate" || t === "autocorrect" || t === "sandbox" && e.tagName === "IFRAME" || t === "form" || t === "list" && e.tagName === "INPUT" || t === "type" && e.tagName === "TEXTAREA")
    return !1;
  if (t === "width" || t === "height") {
    const r = e.tagName;
    if (r === "IMG" || r === "VIDEO" || r === "CANVAS" || r === "SOURCE")
      return !1;
  }
  return Qr(t) && be(n) ? !1 : t in e;
}
function gc(e, t) {
  const n = (
    // @ts-expect-error _def is private
    e._def.props
  );
  if (!n)
    return !1;
  const s = xe(t);
  return Array.isArray(n) ? n.some((r) => xe(r) === s) : Object.keys(n).some((r) => xe(r) === s);
}
const Zr = {};
// @__NO_SIDE_EFFECTS__
function mc(e, t, n) {
  let s = /* @__PURE__ */ gt(e, t);
  Yn(s) && (s = ve({}, s, t));
  class r extends or {
    constructor(o) {
      super(s, o, n);
    }
  }
  return r.def = s, r;
}
const yc = typeof HTMLElement < "u" ? HTMLElement : class {
};
class or extends yc {
  constructor(t, n = {}, s = Ls) {
    super(), this._def = t, this._props = n, this._createApp = s, this._isVueCE = !0, this._instance = null, this._app = null, this._nonce = this._def.nonce, this._connected = !1, this._resolved = !1, this._patching = !1, this._dirty = !1, this._numberProps = null, this._styleChildren = /* @__PURE__ */ new WeakSet(), this._styleAnchors = /* @__PURE__ */ new WeakMap(), this._ob = null, this.shadowRoot && s !== Ls ? this._root = this.shadowRoot : t.shadowRoot !== !1 ? (this.attachShadow(
      ve({}, t.shadowRootOptions, {
        mode: "open"
      })
    ), this._root = this.shadowRoot) : this._root = this;
  }
  connectedCallback() {
    if (!this.isConnected) return;
    !this.shadowRoot && !this._resolved && this._parseSlots(), this._connected = !0;
    let t = this;
    for (; t = t && // #12479 should check assignedSlot first to get correct parent
    (t.assignedSlot || t.parentNode || t.host); )
      if (t instanceof or) {
        this._parent = t;
        break;
      }
    this._instance || (this._resolved ? this._mount(this._def) : t && t._pendingResolve ? this._pendingResolve = t._pendingResolve.then(() => {
      this._pendingResolve = void 0, this._resolveDef();
    }) : this._resolveDef());
  }
  _setParent(t = this._parent) {
    t && (this._instance.parent = t._instance, this._inheritParentContext(t));
  }
  _inheritParentContext(t = this._parent) {
    t && this._app && Object.setPrototypeOf(
      this._app._context.provides,
      t._instance.provides
    );
  }
  disconnectedCallback() {
    this._connected = !1, Zs(() => {
      this._connected || (this._ob && (this._ob.disconnect(), this._ob = null), this._app && this._app.unmount(), this._instance && (this._instance.ce = void 0), this._app = this._instance = null, this._teleportTargets && (this._teleportTargets.clear(), this._teleportTargets = void 0));
    });
  }
  _processMutations(t) {
    for (const n of t)
      this._setAttr(n.attributeName);
  }
  /**
   * resolve inner component definition (handle possible async component)
   */
  _resolveDef() {
    if (this._pendingResolve)
      return;
    for (let s = 0; s < this.attributes.length; s++)
      this._setAttr(this.attributes[s].name);
    this._ob = new MutationObserver(this._processMutations.bind(this)), this._ob.observe(this, { attributes: !0 });
    const t = (s, r = !1) => {
      this._resolved = !0, this._pendingResolve = void 0;
      const { props: i, styles: o } = s;
      let a;
      if (i && !J(i))
        for (const u in i) {
          const h = i[u];
          (h === Number || h && h.type === Number) && (u in this._props && (this._props[u] = Ar(this._props[u])), (a || (a = /* @__PURE__ */ Object.create(null)))[xe(u)] = !0);
        }
      this._numberProps = a, this._resolveProps(s), this.shadowRoot && this._applyStyles(o), this._mount(s);
    }, n = this._def.__asyncLoader;
    n ? this._pendingResolve = n().then((s) => {
      s.configureApp = this._def.configureApp, t(this._def = s, !0);
    }) : t(this._def);
  }
  _mount(t) {
    this._app = this._createApp(t), this._inheritParentContext(), t.configureApp && t.configureApp(this._app), this._app._ceVNode = this._createVNode(), this._app.mount(this._root);
    const n = this._instance && this._instance.exposed;
    if (n)
      for (const s in n)
        le(this, s) || Object.defineProperty(this, s, {
          // unwrap ref to be consistent with public instance behavior
          get: () => Qs(n[s])
        });
  }
  _resolveProps(t) {
    const { props: n } = t, s = J(n) ? n : Object.keys(n || {});
    for (const r of Object.keys(this))
      r[0] !== "_" && s.includes(r) && this._setProp(r, this[r]);
    for (const r of s.map(xe))
      Object.defineProperty(this, r, {
        get() {
          return this._getProp(r);
        },
        set(i) {
          this._setProp(r, i, !0, !this._patching);
        }
      });
  }
  _setAttr(t) {
    if (t.startsWith("data-v-")) return;
    const n = this.hasAttribute(t);
    let s = n ? this.getAttribute(t) : Zr;
    const r = xe(t);
    n && this._numberProps && this._numberProps[r] && (s = Ar(s)), this._setProp(r, s, !1, !0);
  }
  /**
   * @internal
   */
  _getProp(t) {
    return this._props[t];
  }
  /**
   * @internal
   */
  _setProp(t, n, s = !0, r = !1) {
    if (n !== this._props[t] && (this._dirty = !0, n === Zr ? delete this._props[t] : (this._props[t] = n, t === "key" && this._app && (this._app._ceVNode.key = n)), r && this._instance && this._update(), s)) {
      const i = this._ob;
      i && (this._processMutations(i.takeRecords()), i.disconnect()), n === !0 ? this.setAttribute(Ze(t), "") : typeof n == "string" || typeof n == "number" ? this.setAttribute(Ze(t), n + "") : n || this.removeAttribute(Ze(t)), i && i.observe(this, { attributes: !0 });
    }
  }
  _update() {
    const t = this._createVNode();
    this._app && (t.appContext = this._app._context), Ic(t, this._root);
  }
  _createVNode() {
    const t = {};
    this.shadowRoot || (t.onVnodeMounted = t.onVnodeUpdated = this._renderSlots.bind(this));
    const n = Te(this._def, ve(t, this._props));
    return this._instance || (n.ce = (s) => {
      this._instance = s, s.ce = this, s.isCE = !0;
      const r = (i, o) => {
        this.dispatchEvent(
          new CustomEvent(
            i,
            Yn(o[0]) ? ve({ detail: o }, o[0]) : { detail: o }
          )
        );
      };
      s.emit = (i, ...o) => {
        r(i, o), Ze(i) !== i && r(Ze(i), o);
      }, this._setParent();
    }), n;
  }
  _applyStyles(t, n, s) {
    if (!t) return;
    if (n) {
      if (n === this._def || this._styleChildren.has(n))
        return;
      this._styleChildren.add(n);
    }
    const r = this._nonce, i = this.shadowRoot, o = s ? this._getStyleAnchor(s) || this._getStyleAnchor(this._def) : this._getRootStyleInsertionAnchor(i);
    let a = null;
    for (let u = t.length - 1; u >= 0; u--) {
      const h = document.createElement("style");
      r && h.setAttribute("nonce", r), h.textContent = t[u], i.insertBefore(h, a || o), a = h, u === 0 && (s || this._styleAnchors.set(this._def, h), n && this._styleAnchors.set(n, h));
    }
  }
  _getStyleAnchor(t) {
    if (!t)
      return null;
    const n = this._styleAnchors.get(t);
    return n && n.parentNode === this.shadowRoot ? n : (n && this._styleAnchors.delete(t), null);
  }
  _getRootStyleInsertionAnchor(t) {
    for (let n = 0; n < t.childNodes.length; n++) {
      const s = t.childNodes[n];
      if (!(s instanceof HTMLStyleElement))
        return s;
    }
    return null;
  }
  /**
   * Only called when shadowRoot is false
   */
  _parseSlots() {
    const t = this._slots = {};
    let n;
    for (; n = this.firstChild; ) {
      const s = n.nodeType === 1 && n.getAttribute("slot") || "default";
      (t[s] || (t[s] = [])).push(n), this.removeChild(n);
    }
  }
  /**
   * Only called when shadowRoot is false
   */
  _renderSlots() {
    const t = this._getSlots(), n = this._instance.type.__scopeId;
    for (let s = 0; s < t.length; s++) {
      const r = t[s], i = r.getAttribute("name") || "default", o = this._slots[i], a = r.parentNode;
      if (o)
        for (const u of o) {
          if (n && u.nodeType === 1) {
            const h = n + "-s", d = document.createTreeWalker(u, 1);
            u.setAttribute(h, "");
            let g;
            for (; g = d.nextNode(); )
              g.setAttribute(h, "");
          }
          a.insertBefore(u, r);
        }
      else
        for (; r.firstChild; ) a.insertBefore(r.firstChild, r);
      a.removeChild(r);
    }
  }
  /**
   * @internal
   */
  _getSlots() {
    const t = [this];
    this._teleportTargets && t.push(...this._teleportTargets);
    const n = /* @__PURE__ */ new Set();
    for (const s of t) {
      const r = s.querySelectorAll("slot");
      for (let i = 0; i < r.length; i++)
        n.add(r[i]);
    }
    return Array.from(n);
  }
  /**
   * @internal
   */
  _injectChildStyle(t, n) {
    this._applyStyles(t.styles, t, n);
  }
  /**
   * @internal
   */
  _beginPatch() {
    this._patching = !0, this._dirty = !1;
  }
  /**
   * @internal
   */
  _endPatch() {
    this._patching = !1, this._dirty && this._instance && this._update();
  }
  /**
   * @internal
   */
  _hasShadowRoot() {
    return this._def.shadowRoot !== !1;
  }
  /**
   * @internal
   */
  _removeChildStyle(t) {
  }
}
const rn = (e) => {
  const t = e.props["onUpdate:modelValue"] || !1;
  return J(t) ? (n) => Mn(t, n) : t;
};
function bc(e) {
  e.target.composing = !0;
}
function ei(e) {
  const t = e.target;
  t.composing && (t.composing = !1, t.dispatchEvent(new Event("input")));
}
const Et = /* @__PURE__ */ Symbol("_assign");
function ti(e, t, n) {
  return t && (e = e.trim()), n && (e = Hs(e)), e;
}
const Ds = {
  created(e, { modifiers: { lazy: t, trim: n, number: s } }, r) {
    e[Et] = rn(r);
    const i = s || r.props && r.props.type === "number";
    Nt(e, t ? "change" : "input", (o) => {
      o.target.composing || e[Et](ti(e.value, n, i));
    }), (n || i) && Nt(e, "change", () => {
      e.value = ti(e.value, n, i);
    }), t || (Nt(e, "compositionstart", bc), Nt(e, "compositionend", ei), Nt(e, "change", ei));
  },
  // set value on mounted so it's after min/max for type="range"
  mounted(e, { value: t }) {
    e.value = t ?? "";
  },
  beforeUpdate(e, { value: t, oldValue: n, modifiers: { lazy: s, trim: r, number: i } }, o) {
    if (e[Et] = rn(o), e.composing) return;
    const a = (i || e.type === "number") && !/^0\d/.test(e.value) ? Hs(e.value) : e.value, u = t ?? "";
    if (a === u)
      return;
    const h = e.getRootNode();
    (h instanceof Document || h instanceof ShadowRoot) && h.activeElement === e && e.type !== "range" && (s && t === n || r && e.value.trim() === u) || (e.value = u);
  }
}, ni = {
  // #4096 array checkboxes need to be deep traversed
  deep: !0,
  created(e, t, n) {
    e[Et] = rn(n), Nt(e, "change", () => {
      const s = e._modelValue, r = Co(e), i = e.checked, o = e[Et];
      if (J(s)) {
        const a = Ai(s, r), u = a !== -1;
        if (i && !u)
          o(s.concat(r));
        else if (!i && u) {
          const h = [...s];
          h.splice(a, 1), o(h);
        }
      } else if (Jn(s)) {
        const a = new Set(s);
        i ? a.add(r) : a.delete(r), o(a);
      } else
        o(ko(e, i));
    });
  },
  // set initial checked on mount to wait for true-value/false-value
  mounted: si,
  beforeUpdate(e, t, n) {
    e[Et] = rn(n), si(e, t, n);
  }
};
function si(e, { value: t, oldValue: n }, s) {
  e._modelValue = t;
  let r;
  if (J(t))
    r = Ai(t, s.props.value) > -1;
  else if (Jn(t))
    r = t.has(s.props.value);
  else {
    if (t === n) return;
    r = Bt(t, ko(e, !0));
  }
  e.checked !== r && (e.checked = r);
}
const _c = {
  created(e, { value: t }, n) {
    e.checked = Bt(t, n.props.value), e[Et] = rn(n), Nt(e, "change", () => {
      e[Et](Co(e));
    });
  },
  beforeUpdate(e, { value: t, oldValue: n }, s) {
    e[Et] = rn(s), t !== n && (e.checked = Bt(t, s.props.value));
  }
};
function Co(e) {
  return "_value" in e ? e._value : e.value;
}
function ko(e, t) {
  const n = t ? "_trueValue" : "_falseValue";
  return n in e ? e[n] : t;
}
const vc = ["ctrl", "shift", "alt", "meta"], wc = {
  stop: (e) => e.stopPropagation(),
  prevent: (e) => e.preventDefault(),
  self: (e) => e.target !== e.currentTarget,
  ctrl: (e) => !e.ctrlKey,
  shift: (e) => !e.shiftKey,
  alt: (e) => !e.altKey,
  meta: (e) => !e.metaKey,
  left: (e) => "button" in e && e.button !== 0,
  middle: (e) => "button" in e && e.button !== 1,
  right: (e) => "button" in e && e.button !== 2,
  exact: (e, t) => vc.some((n) => e[`${n}Key`] && !t.includes(n))
}, Po = (e, t) => {
  if (!e) return e;
  const n = e._withMods || (e._withMods = {}), s = t.join(".");
  return n[s] || (n[s] = ((r, ...i) => {
    for (let o = 0; o < t.length; o++) {
      const a = wc[t[o]];
      if (a && a(r, t)) return;
    }
    return e(r, ...i);
  }));
}, Sc = /* @__PURE__ */ ve({ patchProp: hc }, Ql);
let ri;
function To() {
  return ri || (ri = Rl(Sc));
}
const Ic = ((...e) => {
  To().render(...e);
}), Ls = ((...e) => {
  const t = To().createApp(...e), { mount: n } = t;
  return t.mount = (s) => {
    const r = Ec(s);
    if (!r) return;
    const i = t._component;
    !ne(i) && !i.render && !i.template && (i.template = r.innerHTML), r.nodeType === 1 && (r.textContent = "");
    const o = n(r, !1, Ac(r));
    return r instanceof Element && (r.removeAttribute("v-cloak"), r.setAttribute("data-v-app", "")), o;
  }, t;
});
function Ac(e) {
  if (e instanceof SVGElement)
    return "svg";
  if (typeof MathMLElement == "function" && e instanceof MathMLElement)
    return "mathml";
}
function Ec(e) {
  return be(e) ? document.querySelector(e) : e;
}
let ii = 0;
function Ge(e = "c") {
  ii += 1;
  const t = Math.random().toString(36).slice(2, 8);
  return `${e}_${Date.now().toString(36)}_${ii}_${t}`;
}
function Ve() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
function ar(e) {
  return {
    sessionId: e,
    turnStatus: "idle",
    messages: [],
    error: null
  };
}
function xc(e) {
  return e.blocks.filter((t) => t.type === "text").map((t) => t.text).join("");
}
function Cc(e) {
  return e.startsWith("debug.");
}
function ye(e, t, n = {}) {
  return {
    protocolVersion: "1.0",
    type: e,
    timestamp: Ve(),
    data: t,
    ...n
  };
}
const kc = {
  form: "form",
  text_question: "text_question",
  textquestion: "text_question",
  select: "select",
  choice: "choice",
  multi_select: "multi_select",
  multiselect: "multi_select",
  confirm: "confirm",
  table: "table",
  detail: "detail",
  card: "card",
  report: "report",
  summary_card: "summary_card",
  summarycard: "summary_card",
  list_card: "list_card",
  listcard: "list_card",
  output_card: "output_card",
  outputcard: "output_card",
  page_action: "page_action",
  pageaction: "page_action",
  custom: "custom"
}, Ro = /* @__PURE__ */ new Set([
  "table",
  "detail",
  "card",
  "report",
  "summary_card",
  "list_card",
  "output_card"
]), Pc = /* @__PURE__ */ new Set([
  "card_only",
  "text_and_card",
  "text_only"
]);
function He(e) {
  return !e || typeof e != "object" || Array.isArray(e) ? null : e;
}
function We(e) {
  if (e == null) return;
  const t = String(e).trim();
  return t || void 0;
}
function $o(e) {
  var n;
  const t = ((n = We(e)) == null ? void 0 : n.toLowerCase().replace(/[\s-]+/g, "_")) || "custom";
  return kc[t] || t;
}
function Tc(e) {
  if (!Array.isArray(e)) return;
  const t = [];
  for (const n of e) {
    const s = He(n);
    if (!s) continue;
    const r = We(s.key) || We(s.name) || We(s.id);
    if (!r) continue;
    const i = Array.isArray(s.options) ? s.options.map((o) => {
      const a = He(o);
      return a ? {
        value: a.value ?? a.id ?? "",
        label: String(a.label ?? a.name ?? a.value ?? "")
      } : null;
    }).filter((o) => !!o) : void 0;
    t.push({
      key: r,
      name: We(s.name),
      label: String(s.label ?? s.name ?? r),
      type: String(s.type ?? "string"),
      required: s.required === !0,
      targetPath: We(s.targetPath),
      options: i,
      placeholder: We(s.placeholder),
      source: He(s.source) || void 0
    });
  }
  return t.length ? t : void 0;
}
function Rc(e) {
  if (!Array.isArray(e)) return;
  const t = [];
  for (const n of e) {
    const s = He(n);
    s && t.push({ ...s });
  }
  return t.length ? t : void 0;
}
function $c(e) {
  var s;
  const t = He(e);
  if (!t) return;
  const n = (s = We(t.mode)) == null ? void 0 : s.toLowerCase().replace(/[\s-]+/g, "_");
  if (!(!n || !Pc.has(n)))
    return { ...t, mode: n };
}
function Mc(e, t, n) {
  const s = `${e}|${t || ""}|${n || ""}`.slice(0, 80);
  let r = 0;
  for (let i = 0; i < s.length; i += 1)
    r = (r << 5) - r + s.charCodeAt(i) | 0;
  return `local:readonly:${e}:${Math.abs(r).toString(36)}`;
}
function lr(e) {
  const t = He(e);
  if (!t) return null;
  const n = $o(t.component ?? t.type), s = We(t.title), r = We(t.message);
  let i = We(t.interactionId);
  i || (Ro.has(n) ? i = Mc(n, s, r) : i = Ge("interaction"));
  const o = He(t.extension) || void 0, a = He(t.schema) || He(t.renderSchema) || He(o == null ? void 0 : o.renderSchema) || void 0;
  return {
    schemaVersion: "1.0",
    interactionId: i,
    traceId: We(t.traceId),
    type: We(t.type),
    component: n,
    title: s,
    message: r,
    ttlSeconds: typeof t.ttlSeconds == "number" ? t.ttlSeconds : void 0,
    expiresAt: We(t.expiresAt),
    fields: Tc(t.fields),
    prefilled: He(t.prefilled) || void 0,
    missing: Array.isArray(t.missing) ? t.missing.map(String) : void 0,
    summary: He(t.summary) || void 0,
    data: t.data,
    schema: a,
    actions: Rc(t.actions),
    presentation: $c(t.presentation ?? (o == null ? void 0 : o.presentation)),
    datasources: He(t.datasources) || void 0,
    behavior: He(t.behavior) || void 0,
    extension: o
  };
}
function Oc(e) {
  return Ro.has($o(e));
}
function Mo(e) {
  var t, n;
  return ((n = (t = lr(e)) == null ? void 0 : t.presentation) == null ? void 0 : n.mode) || "text_and_card";
}
function cr(e) {
  return Mo(e) === "card_only";
}
function Nc(e) {
  return Mo(e) === "text_only";
}
function ls(e) {
  var s;
  const t = lr(e);
  if (!t) return !1;
  const n = (s = t.behavior) == null ? void 0 : s.blocking;
  return typeof n == "boolean" ? n : !Oc(t.component);
}
function ke(e) {
  return {
    ...e,
    messages: e.messages.map((t) => ({
      ...t,
      blocks: t.blocks.map((n) => ({ ...n })),
      metadata: t.metadata ? { ...t.metadata } : void 0,
      completion: t.completion ? { ...t.completion } : void 0
    })),
    metadata: e.metadata ? { ...e.metadata } : void 0
  };
}
function Dc(e, t) {
  return e.id === t || e.transportMessageId === t;
}
function ur(e) {
  for (let t = e.messages.length - 1; t >= 0; t -= 1) {
    const n = e.messages[t];
    if (n.role === "assistant" && (n.status === "streaming" || n.status === "pending"))
      return n;
  }
}
function oi(e, t) {
  return ur(e);
}
function Lc(e) {
  for (let t = e.messages.length - 1; t >= 0; t -= 1)
    if (e.messages[t].role === "assistant") return e.messages[t];
}
function vt(e, t, n, s = {}) {
  if (t) {
    const o = e.messages.find((a) => Dc(a, t));
    if (o && (o.status === "pending" || o.status === "streaming" || s.reuseCompleted))
      return n && (o.metadata = { ...o.metadata || {}, ...n }), o;
  }
  const r = ur(e);
  if (r)
    return t && r.transportMessageId !== t && (r.transportMessageId = t), n && (r.metadata = { ...r.metadata || {}, ...n }), r;
  if (s.reuseCompleted) {
    const o = Lc(e);
    if (o)
      return n && (o.metadata = { ...o.metadata || {}, ...n }), o;
  }
  const i = {
    id: Ge("msg"),
    role: "assistant",
    status: "streaming",
    blocks: [],
    createdAt: Ve(),
    metadata: n,
    transportMessageId: t
  };
  return e.messages.push(i), i;
}
function Oo(e, t) {
  return e.blocks.find(
    (n) => n.type === "interaction" && n.request.interactionId === t
  );
}
function ai(e, t) {
  if (!t || e.blocks.some((s) => s.type === "interaction" && cr(s.request))) return;
  const n = e.blocks[e.blocks.length - 1];
  if (n && n.type === "text" && n.status !== "completed")
    n.text += t, n.status = "streaming";
  else {
    const s = {
      id: Ge("blk"),
      type: "text",
      text: t,
      status: "streaming"
    };
    e.blocks.push(s);
  }
  e.status = "streaming", e.updatedAt = Ve();
}
function li(e, t, n = "waiting") {
  const s = lr(t);
  if (!s) return;
  if (Nc(s)) {
    e.blocks = e.blocks.filter(
      (i) => i.type !== "interaction" || i.request.interactionId !== s.interactionId
    ), e.updatedAt = Ve();
    return;
  }
  cr(s) && (e.blocks = e.blocks.filter((i) => i.type !== "text"));
  const r = Oo(e, s.interactionId);
  if (r) {
    r.request = s, (r.state === "waiting" || r.state === "failed") && (r.state = n), e.updatedAt = Ve();
    return;
  }
  e.blocks.push({
    id: Ge("blk"),
    type: "interaction",
    request: s,
    state: n
  }), e.updatedAt = Ve();
}
function _s(e) {
  for (const t of e.blocks)
    t.type === "text" && t.status === "streaming" && (t.status = "completed");
}
function Qe(e, t) {
  switch (t.type) {
    case "reset":
      return ar(t.sessionId);
    case "restore":
      return ke(t.snapshot);
    case "set_session": {
      const n = ke(e);
      return n.sessionId = t.sessionId, n;
    }
    case "set_error": {
      const n = ke(e);
      return n.error = t.error, n;
    }
    case "append_user_message": {
      const n = ke(e);
      return n.messages.push({
        id: t.id || Ge("msg"),
        role: "user",
        status: "completed",
        blocks: [{ id: Ge("blk"), type: "text", text: t.text, status: "completed" }],
        createdAt: Ve(),
        metadata: t.metadata
      }), n.error = null, n;
    }
    case "begin_assistant_placeholder": {
      const n = ke(e), s = ur(n);
      return s && (!t.turnId || !s.turnId || s.turnId === t.turnId) ? (t.turnId && (s.turnId = t.turnId, n.turnId = t.turnId), n) : (n.messages.push({
        id: Ge("msg"),
        role: "assistant",
        status: "pending",
        blocks: [],
        createdAt: Ve(),
        turnId: t.turnId,
        localPlaceholder: !0
      }), t.turnId && (n.turnId = t.turnId), n.error = null, n);
    }
    case "start_assistant_message": {
      const n = ke(e), s = vt(n, t.id, t.metadata);
      return s.status === "pending" && (s.status = "streaming"), s.updatedAt = Ve(), n.turnStatus = n.turnStatus === "waiting" ? "waiting" : "streaming", n.error = null, n;
    }
    case "append_text_delta": {
      const n = ke(e), s = vt(n, t.messageId);
      return ai(s, t.text), (n.turnStatus === "idle" || n.turnStatus === "sending") && (n.turnStatus = "streaming"), n;
    }
    case "add_interaction": {
      const n = ke(e), s = vt(n, t.messageId);
      return li(s, t.request, t.state || "waiting"), (n.turnStatus === "idle" || n.turnStatus === "sending") && (n.turnStatus = "streaming"), n;
    }
    case "update_interaction_state": {
      const n = ke(e);
      for (const s of n.messages) {
        const r = Oo(s, t.interactionId);
        if (r) {
          r.state = t.state, t.result && (r.result = t.result), t.errorMessage !== void 0 && (r.errorMessage = t.errorMessage), s.updatedAt = Ve();
          break;
        }
      }
      return n;
    }
    case "add_notice": {
      const n = ke(e);
      return vt(n, t.messageId).blocks.push({
        id: Ge("blk"),
        type: "notice",
        level: t.level || "info",
        text: t.text
      }), n;
    }
    case "add_error_block": {
      const n = ke(e), s = vt(n, t.messageId);
      return s.blocks.push({
        id: Ge("blk"),
        type: "error",
        text: t.text,
        retryable: t.retryable
      }), s.status = "failed", n;
    }
    case "add_page_action": {
      const n = ke(e), s = vt(n, t.messageId);
      return s.blocks.some(
        (i) => i.type === "page_action" && i.requestId === t.requestId
      ) || !t.requestId || s.blocks.push({
        id: Ge("blk"),
        type: "page_action",
        requestId: t.requestId,
        actionKey: t.actionKey,
        title: t.title,
        args: t.args,
        status: "pending"
      }), n;
    }
    case "set_turn_status": {
      const n = ke(e);
      return n.turnStatus = t.status, n;
    }
    case "complete_turn": {
      const n = ke(e);
      t.sessionId && (n.sessionId = t.sessionId);
      const s = vt(n, void 0, void 0, { reuseCompleted: !0 });
      t.answer && (s.blocks.some((o) => o.type === "text" && o.text) || ai(s, t.answer)), t.uiRequest && li(s, t.uiRequest, ls(t.uiRequest) ? "waiting" : "resolved"), _s(s);
      const r = s.blocks.some(
        (i) => i.type === "interaction" && i.state === "waiting"
      );
      return s.status = "completed", s.updatedAt = Ve(), t.metadata && (s.metadata = { ...s.metadata || {}, ...t.metadata }, n.metadata = { ...n.metadata || {}, ...t.metadata }), t.completion && (s.completion = {
        ...s.completion || {},
        ...t.completion
      }), n.turnStatus = r ? "waiting" : "completed", n.error = null, n;
    }
    case "fail_turn": {
      const n = ke(e), s = oi(n) || vt(n);
      return _s(s), s.status = "failed", s.blocks.push({
        id: Ge("blk"),
        type: "error",
        text: t.message,
        retryable: !0
      }), t.metadata && (s.metadata = { ...s.metadata || {}, ...t.metadata }, n.metadata = { ...n.metadata || {}, ...t.metadata }), s.updatedAt = Ve(), n.turnStatus = "failed", n.error = t.message, n;
    }
    case "cancel_turn": {
      const n = ke(e), s = oi(n);
      return s && (_s(s), s.status = "cancelled", s.updatedAt = Ve()), n.turnStatus = "cancelled", n.error = null, n;
    }
    case "apply_event":
      return Fc(e, t.event);
    default:
      return e;
  }
}
function Fc(e, t) {
  const n = t.type, s = t.data && typeof t.data == "object" ? t.data : {}, r = t.turnId && e.turnId !== t.turnId ? { ...e, turnId: t.turnId } : e;
  switch (n) {
    case "session.created":
    case "session.restored":
      return n === "session.restored" && t.data && typeof t.data == "object" && "messages" in t.data ? Qe(r, { type: "restore", snapshot: t.data }) : Qe(r, { type: "set_session", sessionId: t.sessionId || _e(s.sessionId) });
    case "turn.started":
      return Qe(r, { type: "set_turn_status", status: "sending" });
    case "turn.progress": {
      const i = ke(r), o = vt(i, _e(s.messageId)), a = typeof s.message == "string" ? s.message.trim() : "";
      return o.metadata = {
        ...o.metadata || {},
        publicProgress: {
          phase: _e(s.phase),
          state: _e(s.state),
          ...a ? { message: a } : {}
        }
      }, o.status === "pending" && (o.status = "streaming"), o.updatedAt = Ve(), (i.turnStatus === "idle" || i.turnStatus === "sending") && (i.turnStatus = "streaming"), i;
    }
    case "message.started":
      return Qe(r, {
        type: "start_assistant_message",
        id: _e(s.messageId)
      });
    case "message.delta": {
      const i = typeof s.text == "string" ? s.text : typeof t.data == "string" ? t.data : "";
      return Qe(r, {
        type: "append_text_delta",
        text: i,
        messageId: _e(s.messageId)
      });
    }
    case "ui.requested":
      return Qe(r, {
        type: "add_interaction",
        request: s.uiRequest ?? t.data,
        state: ls(s.uiRequest ?? t.data) ? "waiting" : "resolved",
        messageId: _e(s.messageId)
      });
    case "page.action.requested":
      return Qe(r, {
        type: "add_page_action",
        requestId: String(s.requestId || ""),
        actionKey: String(s.actionKey || ""),
        title: _e(s.title),
        args: s.args || void 0,
        messageId: _e(s.messageId)
      });
    case "turn.waiting":
      return Qe(r, {
        type: "complete_turn",
        answer: _e(s.answer),
        uiRequest: s.uiRequest,
        sessionId: t.sessionId || _e(s.sessionId),
        metadata: vs(s.metadata, s.result),
        completion: {
          intentType: s.intentType,
          toolCalls: s.toolCalls,
          result: s.result
        }
      });
    case "turn.completed":
      return Qe(r, {
        type: "complete_turn",
        answer: _e(s.answer),
        uiRequest: s.uiRequest,
        sessionId: t.sessionId || _e(s.sessionId),
        metadata: {
          ...vs(s.metadata, s.result),
          ...t.traceId ? { traceId: t.traceId } : {},
          ...s.traceId ? { traceId: s.traceId } : {}
        },
        completion: {
          intentType: s.intentType,
          toolCalls: s.toolCalls,
          result: s.result
        }
      });
    case "turn.cancelled":
      return Qe(r, { type: "cancel_turn" });
    case "turn.failed": {
      const i = vs(s.metadata, s.result), o = t.traceId || _e(s.traceId) || _e(i.traceId), a = _e(s.code) || _e(i.code);
      return Qe(r, {
        type: "fail_turn",
        message: _e(s.message) || _e(s.error) || "对话失败",
        metadata: {
          ...i,
          success: !1,
          ...a ? { code: a } : {},
          ...o ? { traceId: o } : {},
          ...t.sessionId || _e(s.sessionId) ? { sessionId: t.sessionId || _e(s.sessionId) } : {}
        }
      });
    }
    default:
      return r;
  }
}
function _e(e) {
  if (e == null) return;
  const t = String(e);
  return t || void 0;
}
function vs(e, t) {
  if (e && typeof e == "object" && !Array.isArray(e)) {
    const n = e;
    if (n.metadata && typeof n.metadata == "object" && !Array.isArray(n.metadata) && ("answer" in n || "uiRequest" in n || "sessionId" in n)) {
      const r = { ...n.metadata };
      return "success" in n && (r.success = n.success), n.code != null && (r.code = n.code), n.traceId != null && (r.traceId = n.traceId), r;
    }
    if (!("answer" in n) && !("uiRequest" in n))
      return { ...n };
    const s = {};
    if ("success" in n && (s.success = n.success), n.code != null && (s.code = n.code), n.traceId != null && (s.traceId = n.traceId), t && typeof t == "object" && !Array.isArray(t)) {
      const r = t.metadata;
      if (r && typeof r == "object" && !Array.isArray(r))
        return { ...r, ...s };
    }
    return s;
  }
  if (t && typeof t == "object" && !Array.isArray(t)) {
    const n = t, s = n.metadata, r = {};
    return "success" in n && (r.success = n.success), s && typeof s == "object" && !Array.isArray(s) ? { ...s, ...r } : r;
  }
  return {};
}
function qc(e) {
  return ar(e);
}
function jc(e) {
  const t = e.trim();
  if (!t) return "";
  try {
    return JSON.parse(t);
  } catch {
    return e;
  }
}
function No(e) {
  const n = e.replace(/\r\n/g, `
`).replace(/\r/g, `
`).split(`
`);
  let s = "message", r;
  const i = [];
  for (const a of n)
    if (!(!a || a.startsWith(":"))) {
      if (a.startsWith("event:")) {
        s = a.slice(6).trim();
        continue;
      }
      if (a.startsWith("id:")) {
        r = a.slice(3).trim();
        continue;
      }
      a.startsWith("data:") && i.push(a.slice(5).replace(/^ /, ""));
    }
  if (!i.length && s === "message") return null;
  const o = i.join(`
`);
  return {
    event: s,
    rawData: o,
    data: jc(o),
    id: r
  };
}
function Kc(e) {
  const t = [];
  let n = e.replace(/\r\n/g, `
`).replace(/\r/g, `
`), s = n.indexOf(`

`);
  for (; s >= 0; ) {
    const r = n.slice(0, s);
    n = n.slice(s + 2);
    const i = No(r);
    i && t.push(i), s = n.indexOf(`

`);
  }
  return { frames: t, rest: n };
}
async function* Uc(e, t = {}) {
  const n = e.getReader(), s = new TextDecoder();
  let r = "";
  const i = t.signal, o = () => {
    if (i != null && i.aborted)
      throw new DOMException("The operation was aborted.", "AbortError");
  };
  try {
    for (; ; ) {
      o();
      const { done: a, value: u } = await n.read();
      if (a) break;
      o(), r += s.decode(u, { stream: !0 });
      const h = Kc(r);
      r = h.rest;
      for (const d of h.frames)
        yield d;
    }
    if (r += s.decode(), r.trim()) {
      const a = No(r.trim());
      a && (yield a);
    }
  } finally {
    try {
      n.releaseLock();
    } catch {
    }
  }
}
function Vn(e) {
  return !e || typeof e != "object" ? !1 : e.name === "AbortError";
}
const Bc = /* @__PURE__ */ new Set([
  "message.delta",
  "ui.requested",
  "page.action.requested",
  "turn.started",
  "turn.progress",
  "turn.waiting",
  "turn.completed",
  "turn.failed",
  "turn.cancelled",
  "interaction.submitted",
  "interaction.cancelled"
]);
function Hc(e) {
  const { transport: t, onDebugEvent: n, onPublicEvent: s } = e;
  let r = qc(e.initialSessionId);
  const i = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Set();
  let a = !1, u = null, h = 0, d;
  const g = /* @__PURE__ */ new Set(), w = /* @__PURE__ */ new Set(), R = /* @__PURE__ */ new Set();
  function P() {
    var S;
    (S = e.onChange) == null || S.call(e, r);
    for (const M of i) M(r);
  }
  function x(S) {
    r = Qe(r, S), P();
  }
  function $(S) {
    return S.turnId || !d ? S : { ...S, turnId: d };
  }
  function I(S) {
    if (!Bc.has(S.type)) return !1;
    const M = S.data && typeof S.data == "object" ? S.data : {}, j = S.turnId || d || "";
    if (S.type === "message.delta")
      return !0;
    if (S.type === "page.action.requested") {
      const K = String(M.requestId || "");
      if (!K) return !0;
      const H = `page.action.requested:${K}`;
      return R.has(H) ? !1 : (R.add(H), !0);
    }
    if (S.type === "ui.requested") {
      const K = M.uiRequest, H = `ui.requested:${j}:${(K == null ? void 0 : K.interactionId) || JSON.stringify(M.uiRequest || "")}`;
      return w.has(H) ? !1 : (w.add(H), !0);
    }
    if (S.type === "turn.completed" || S.type === "turn.waiting" || S.type === "turn.failed" || S.type === "turn.cancelled") {
      const K = S.sessionId || (M.sessionId != null ? String(M.sessionId) : "") || r.sessionId || "", H = `${S.type}:${K}:${j}`;
      return g.has(H) ? !1 : (g.add(H), !0);
    }
    if (S.type === "interaction.submitted" || S.type === "interaction.cancelled") {
      const K = `${S.type}:${j}:${String(M.interactionId || "")}:${String(M.action || "")}`;
      return g.has(K) ? !1 : (g.add(K), !0);
    }
    return !0;
  }
  function y(S) {
    const M = $(S);
    I(M) && (s == null || s(M));
  }
  function O(S) {
    const M = $(S);
    if (Cc(M.type)) {
      n == null || n(M);
      return;
    }
    if (M.type === "page.action.requested") {
      const j = M.data && typeof M.data == "object" ? M.data : {}, K = String(j.requestId || "");
      if (K) {
        const H = `page.action.requested:${K}`;
        if (R.has(H))
          return;
      }
    }
    y(M), x({ type: "apply_event", event: M });
  }
  async function E(S, M) {
    for await (const j of S) {
      if (a || M !== h) break;
      O(j);
    }
  }
  async function q(S, M) {
    var se, re, ee, we;
    if (a) return;
    const j = ++h;
    d = Ge("turn"), M === "start" || ((se = S.uiSubmit) == null ? void 0 : se.action) !== "cancel" ? (u == null || u.abort(), u = new AbortController()) : (!u || u.signal.aborted) && (u = new AbortController());
    const K = u.signal;
    x({ type: "set_turn_status", status: "sending" }), x({ type: "set_error", error: null }), M === "start" && S.message && x({ type: "append_user_message", text: S.message }), (M === "start" || ((re = S.uiSubmit) == null ? void 0 : re.action) !== "cancel") && x({ type: "begin_assistant_placeholder", turnId: d });
    try {
      const de = M === "resume" && t.resumeInteraction && S.interactionId ? t.resumeInteraction(
        S.interactionId,
        ((ee = S.uiSubmit) == null ? void 0 : ee.action) || "submit",
        ((we = S.uiSubmit) == null ? void 0 : we.values) || S.values || {},
        K
      ) : t.startTurn(S, K);
      if (await E(de, j), j !== h) return;
      (r.turnStatus === "sending" || r.turnStatus === "streaming") && x({ type: "set_turn_status", status: "completed" });
    } catch (de) {
      if (j !== h) return;
      if (Vn(de) || K.aborted) {
        x({ type: "cancel_turn" }), y(ye("turn.cancelled", {}, { sessionId: r.sessionId, turnId: d }));
        return;
      }
      const G = de instanceof Error ? de.message : String(de);
      x({ type: "fail_turn", message: G }), y(ye("turn.failed", { message: G, error: G }, {
        sessionId: r.sessionId,
        turnId: d
      }));
    }
  }
  return {
    getState() {
      return r;
    },
    subscribe(S) {
      return i.add(S), S(r), () => i.delete(S);
    },
    async send(S) {
      const M = typeof S == "string" ? { message: S } : S;
      !M.message && !M.values && !M.uiSubmit || await q(M, "start");
    },
    async submitInteraction(S, M, j = {}) {
      if (!S || o.has(S)) return;
      o.add(S);
      const K = M === "cancel";
      x({
        type: "update_interaction_state",
        interactionId: S,
        state: "submitting",
        result: { action: M, values: j }
      });
      try {
        await q(
          {
            interactionId: S,
            uiSubmit: { action: M, values: j },
            values: j,
            message: void 0
          },
          "resume"
        ), K && r.turnStatus === "cancelled" ? (x({
          type: "update_interaction_state",
          interactionId: S,
          state: "cancelled",
          result: { action: M, values: j }
        }), y(ye(
          "interaction.cancelled",
          { interactionId: S, action: M, values: j },
          { sessionId: r.sessionId, turnId: d }
        ))) : r.turnStatus === "failed" ? x({
          type: "update_interaction_state",
          interactionId: S,
          state: "failed",
          errorMessage: r.error || "提交失败"
        }) : K ? (x({
          type: "update_interaction_state",
          interactionId: S,
          state: "cancelled",
          result: { action: M, values: j }
        }), y(ye(
          "interaction.cancelled",
          { interactionId: S, action: M, values: j },
          { sessionId: r.sessionId, turnId: d }
        ))) : r.turnStatus === "cancelled" ? x({
          type: "update_interaction_state",
          interactionId: S,
          state: "cancelled",
          result: { action: M, values: j }
        }) : (x({
          type: "update_interaction_state",
          interactionId: S,
          state: "resolved",
          result: { action: M, values: j }
        }), y(ye(
          "interaction.submitted",
          { interactionId: S, action: M, values: j },
          { sessionId: r.sessionId, turnId: d }
        )));
      } catch (H) {
        Vn(H) || r.turnStatus === "cancelled" ? x({
          type: "update_interaction_state",
          interactionId: S,
          state: "failed",
          errorMessage: "交互提交被中断"
        }) : x({
          type: "update_interaction_state",
          interactionId: S,
          state: "failed",
          errorMessage: H instanceof Error ? H.message : String(H)
        });
      } finally {
        o.delete(S);
      }
    },
    async cancel() {
      var S;
      h += 1, d = Ge("turn"), u == null || u.abort(), u = null;
      try {
        await ((S = t.cancelTurn) == null ? void 0 : S.call(t));
      } catch {
      }
      x({ type: "cancel_turn" }), y(ye("turn.cancelled", {}, { sessionId: r.sessionId, turnId: d }));
    },
    async clearSession() {
      var S;
      h += 1, d = void 0, u == null || u.abort(), u = null, await ((S = t.clearSession) == null ? void 0 : S.call(t)), g.clear(), w.clear(), R.clear(), x({ type: "reset", sessionId: void 0 });
    },
    async restore() {
      var M;
      const S = await ((M = t.restoreSession) == null ? void 0 : M.call(t));
      return S ? (x({ type: "restore", snapshot: S }), S) : null;
    },
    dispose() {
      a = !0, h += 1, d = void 0, u == null || u.abort(), u = null, i.clear(), g.clear(), w.clear(), R.clear(), t.dispose();
    }
  };
}
function dr(e) {
  return !e || typeof e != "object" || Array.isArray(e) ? null : e;
}
function Vc(e) {
  const t = dr(e);
  return t && "text" in t ? String(t.text ?? "") : typeof e == "string" ? e : "";
}
function Do(e) {
  if (!e) return;
  const t = dr(e.metadata);
  if (t) return { ...t };
  if (!("answer" in e) && !("uiRequest" in e) && !("sessionId" in e) && !("toolCalls" in e))
    return { ...e };
}
function Wc(e, t, n, s) {
  const r = Do(e || void 0);
  return {
    answer: s,
    sessionId: n,
    result: t,
    metadata: r,
    intentType: e == null ? void 0 : e.intentType,
    toolCalls: e == null ? void 0 : e.toolCalls,
    uiRequest: e == null ? void 0 : e.uiRequest
  };
}
function Lo(e, t, n = {}) {
  const s = dr(t), r = n.sessionId || (s != null && s.sessionId ? String(s.sessionId) : void 0);
  switch (e) {
    case "message.delta": {
      const i = Vc(t);
      return i ? ye("message.delta", { text: i }, { sessionId: r }) : null;
    }
    case "ui.requested":
      return ye("ui.requested", {
        uiRequest: (s == null ? void 0 : s.uiRequest) ?? t
      }, { sessionId: r });
    case "page.action.requested":
      return ye("page.action.requested", t, { sessionId: r });
    case "message.completed": {
      const i = (s == null ? void 0 : s.answer) != null ? String(s.answer) : void 0, o = s == null ? void 0 : s.uiRequest, a = Wc(s, t, r, i);
      return o ? [
        ye("ui.requested", { uiRequest: o }, { sessionId: r }),
        ye(ls(o) ? "turn.waiting" : "turn.completed", a, { sessionId: r })
      ] : ye("turn.completed", a, { sessionId: r });
    }
    case "error":
    case "execution.error": {
      const i = (s == null ? void 0 : s.message) != null ? String(s.message) : typeof t == "string" ? t : "Embed 对话失败";
      return ye("turn.failed", { message: i, error: i }, { sessionId: r });
    }
    case "execution.started":
      return ye("turn.started", s || {}, { sessionId: r });
    case "turn.progress":
      return ye("turn.progress", s || {}, { sessionId: r });
    case "execution.completed":
      return Lo("message.completed", t, n);
    case "supervisor.step":
    case "reasoning.delta":
      return null;
    default:
      return null;
  }
}
function* zc(e) {
  if (e) {
    if (Array.isArray(e)) {
      for (const t of e) yield t;
      return;
    }
    yield e;
  }
}
function Gc(e, t) {
  const n = typeof crypto < "u" && typeof crypto.randomUUID == "function" ? crypto.randomUUID().replace(/-/g, "") : `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`;
  return `${e}-${t}-${n}`;
}
function Jc(e) {
  return e === 404 || e === 405 || e === 415 || e === 501;
}
function Yc(e) {
  return !e || typeof e != "object" ? !1 : e.name === "AbortError";
}
function ws(e) {
  return e.aborted || Yc(e.error) || e.bytesOrEventsConsumed || e.status == null ? !1 : Jc(e.status);
}
function Xc(e) {
  const t = e.fetchImpl || fetch, n = e.preferStream !== !1;
  let s = !1;
  const r = /* @__PURE__ */ new Set();
  let i = null;
  function o(y) {
    const O = e.apiBase.replace(/\/$/, "");
    return y.startsWith("http") ? y : `${O}${y.startsWith("/") ? y : `/${y}`}`;
  }
  async function a(y, O, E) {
    const q = {
      "Content-Type": "application/json",
      ...O.headers
    }, S = e.tokenProvider();
    S && (q.Authorization = `Bearer ${S}`);
    let M = await t(y, { ...O, headers: q, signal: E });
    if (M.status === 401 && e.onUnauthorized) {
      const j = await e.onUnauthorized();
      if (typeof j == "string" && j)
        q.Authorization = `Bearer ${j}`;
      else {
        const K = e.tokenProvider();
        K && (q.Authorization = `Bearer ${K}`);
      }
      M = await t(y, { ...O, headers: q, signal: E });
    }
    return M;
  }
  function u(y, O) {
    const E = new Error(`${y}: HTTP ${O}`);
    return E.status = O, E;
  }
  async function h(y) {
    if (s) throw new Error("Embed transport disposed");
    const O = e.getSessionId();
    return O || (i || (i = (async () => {
      var K, H;
      const E = e.sessionsPath || "/chat/sessions", q = await a(o(E), {
        method: "POST",
        body: JSON.stringify(((K = e.createSessionPayload) == null ? void 0 : K.call(e)) || { context: (H = e.getContext) == null ? void 0 : H.call(e) })
      }, y);
      if (!q.ok)
        throw u("Embed session create failed", q.status);
      const S = await q.json().catch(() => ({})), M = S.data && typeof S.data == "object" ? S.data : S, j = M.sessionId ? String(M.sessionId) : M.id ? String(M.id) : void 0;
      if (!j) throw new Error("Embed session create returned no sessionId");
      return e.setSessionId(j), j;
    })().finally(() => {
      i = null;
    })), i);
  }
  async function d(y) {
    return e.setSessionId(void 0), h(y);
  }
  async function* g(y, O, E) {
    if (!y.body) throw new Error("Embed stream has no body");
    for await (const q of Uc(y.body, { signal: E })) {
      const S = Lo(q.event, q.data, { sessionId: O });
      for (const M of zc(S))
        yield M;
    }
  }
  function* w(y, O) {
    yield ye("turn.started", {}, { sessionId: O }), y.answer && !cr(y.uiRequest) && (yield ye("message.delta", { text: String(y.answer) }, { sessionId: O }));
    const E = y.metadata && typeof y.metadata == "object" && !Array.isArray(y.metadata) ? { ...y.metadata } : void 0;
    y.uiRequest ? (yield ye("ui.requested", { uiRequest: y.uiRequest }, { sessionId: O }), yield ye(ls(y.uiRequest) ? "turn.waiting" : "turn.completed", {
      answer: y.answer,
      uiRequest: y.uiRequest,
      sessionId: O,
      result: y,
      metadata: E,
      intentType: y.intentType,
      toolCalls: y.toolCalls
    }, { sessionId: O })) : yield ye("turn.completed", {
      answer: y.answer,
      sessionId: O,
      result: y,
      metadata: E,
      intentType: y.intentType,
      toolCalls: y.toolCalls
    }, { sessionId: O });
  }
  async function* R(y, O, E, q = !0) {
    var H, se;
    const S = ((H = e.messagesJsonPath) == null ? void 0 : H.call(e, y)) || `/chat/sessions/${encodeURIComponent(y)}/messages`, M = await a(o(S), {
      method: "POST",
      body: JSON.stringify({
        message: O.message,
        context: (se = e.getContext) == null ? void 0 : se.call(e),
        interactionId: O.interactionId,
        uiSubmit: O.uiSubmit
      })
    }, E);
    if (M.status === 401 && q) {
      const re = await d(E);
      yield* R(re, O, E, !1);
      return;
    }
    if (!M.ok)
      throw u("Embed message failed", M.status);
    const j = await M.json().catch(() => ({})), K = j.data && typeof j.data == "object" ? j.data : j;
    yield* w(K, y);
  }
  async function* P(y, O, E, q = !0) {
    var K, H;
    const S = ((K = e.messagesPath) == null ? void 0 : K.call(e, y)) || `/chat/sessions/${encodeURIComponent(y)}/messages/stream`, M = await a(o(S), {
      method: "POST",
      headers: { Accept: "text/event-stream" },
      body: JSON.stringify({
        message: O.message,
        context: (H = e.getContext) == null ? void 0 : H.call(e),
        interactionId: O.interactionId,
        uiSubmit: O.uiSubmit
      })
    }, E);
    if (M.status === 401 && q) {
      const se = await d(E);
      yield* P(se, O, E, !1);
      return;
    }
    const j = M.headers.get("content-type") || "";
    if (!M.ok || !M.body || !j.includes("text/event-stream")) {
      if (ws({
        status: M.status,
        bytesOrEventsConsumed: !1,
        aborted: E == null ? void 0 : E.aborted
      })) {
        yield* R(y, O, E, q);
        return;
      }
      throw u("Embed stream failed", M.status);
    }
    yield ye("turn.started", {}, { sessionId: y }), yield* g(M, y, E);
  }
  async function* x(y, O) {
    if (s) return;
    const E = new AbortController();
    r.add(E);
    const q = () => E.abort();
    O == null || O.addEventListener("abort", q);
    try {
      const S = await h(E.signal);
      if (!n) {
        yield* R(S, y, E.signal);
        return;
      }
      yield* P(S, y, E.signal);
    } catch (S) {
      if (Vn(S) || E.signal.aborted) {
        yield ye("turn.cancelled", {}, { sessionId: e.getSessionId() });
        return;
      }
      throw S;
    } finally {
      O == null || O.removeEventListener("abort", q), r.delete(E);
    }
  }
  async function* $(y, O, E, q, S, M) {
    var re, ee;
    const j = ((re = e.interactionSubmitPath) == null ? void 0 : re.call(e, y, O)) || `/chat/sessions/${encodeURIComponent(y)}/interactions/${encodeURIComponent(O)}/submit`, K = await a(o(j), {
      method: "POST",
      body: JSON.stringify({
        action: E,
        values: q,
        idempotencyKey: S,
        context: (ee = e.getContext) == null ? void 0 : ee.call(e)
      })
    }, M);
    if (!K.ok)
      throw u("Embed interaction submit failed", K.status);
    const H = await K.json().catch(() => ({})), se = H.data && typeof H.data == "object" ? H.data : H;
    yield* w(se, y);
  }
  async function* I(y, O, E, q) {
    var H, se;
    if (s) return;
    const S = e.getSessionId();
    if (!S) throw new Error("No embed session");
    const M = Gc("embed", y);
    if (!n) {
      yield* $(S, y, O, E, M, q);
      return;
    }
    const j = ((H = e.interactionSubmitStreamPath) == null ? void 0 : H.call(e, S, y)) || `/chat/sessions/${encodeURIComponent(S)}/interactions/${encodeURIComponent(y)}/submit/stream`;
    let K = !1;
    try {
      const re = await a(o(j), {
        method: "POST",
        headers: { Accept: "text/event-stream" },
        body: JSON.stringify({
          action: O,
          values: E,
          idempotencyKey: M,
          context: (se = e.getContext) == null ? void 0 : se.call(e)
        })
      }, q), ee = re.headers.get("content-type") || "";
      if (re.ok && re.body && ee.includes("text/event-stream")) {
        yield ye("turn.started", {}, { sessionId: S }), K = !0, yield* g(re, S, q);
        return;
      }
      if (ws({
        status: re.status,
        bytesOrEventsConsumed: !1,
        aborted: q == null ? void 0 : q.aborted
      })) {
        yield* $(S, y, O, E, M, q);
        return;
      }
      throw u("Embed interaction stream failed", re.status);
    } catch (re) {
      if (Vn(re) || q != null && q.aborted) {
        yield ye("turn.cancelled", {}, { sessionId: S });
        return;
      }
      if (ws({
        status: re == null ? void 0 : re.status,
        bytesOrEventsConsumed: K,
        aborted: q == null ? void 0 : q.aborted,
        error: re
      })) {
        yield* $(S, y, O, E, M, q);
        return;
      }
      throw re;
    }
  }
  return {
    kind: "embed",
    capabilities: {
      eventStreaming: n,
      tokenStreaming: !0,
      abort: !0,
      restore: !1,
      structuredInitialInput: !1,
      pageActions: !0
    },
    startTurn: x,
    resumeInteraction: I,
    /** 供 facade / 测试显式预热会话（带去重） */
    ensureSession: h,
    async cancelTurn() {
      for (const y of r) y.abort();
      r.clear();
    },
    dispose() {
      s = !0, i = null;
      for (const y of r) y.abort();
      r.clear();
    }
  };
}
const Qc = /* @__PURE__ */ new Map(), Zc = {
  form: "form",
  text_question: "form",
  select: "select",
  choice: "select",
  multi_select: "select",
  confirm: "confirm",
  table: "table",
  detail: "detail",
  card: "output_card",
  report: "output_card",
  summary_card: "summary_card",
  list_card: "list_card",
  output_card: "output_card",
  page_action: "page_action",
  custom: "custom"
};
function eu(e) {
  const t = String(e || "custom").toLowerCase();
  return Zc[t] || "custom";
}
function tu(e) {
  if (e)
    return Qc.get(e);
}
const nu = /* @__PURE__ */ new Set(["__proto__", "prototype", "constructor"]), su = /* @__PURE__ */ new Set(["neutral", "success", "warning", "danger", "info"]);
function Dt(e) {
  return !e || typeof e != "object" || Array.isArray(e) ? null : e;
}
function Ye(e) {
  return e == null ? void 0 : String(e).trim() || void 0;
}
function Fo(e, t, n, s) {
  const r = typeof e == "number" ? e : Number(e);
  return Number.isFinite(r) ? Math.min(s, Math.max(n, Math.floor(r))) : t;
}
function ru(e) {
  const t = e.trim().replace(/^\$\.?/, "").replace(/\[\s*["']?([^\]"']+)["']?\s*\]/g, ".$1").replace(/^\./, "");
  if (!t) return [];
  const n = t.split(".").filter(Boolean);
  return n.some((s) => nu.has(s)) ? [] : n;
}
function xt(e, t) {
  if (!(t != null && t.trim())) return e;
  const n = ru(t);
  if (!n.length) return;
  let s = e;
  for (const r of n) {
    if (Array.isArray(s)) {
      const o = Number(r);
      if (!Number.isInteger(o) || o < 0 || o >= s.length) return;
      s = s[o];
      continue;
    }
    const i = Dt(s);
    if (!i || !Object.prototype.hasOwnProperty.call(i, r)) return;
    s = i[r];
  }
  return s;
}
function iu(e) {
  var n;
  const t = Dt(e.schema);
  return t || Dt((n = e.extension) == null ? void 0 : n.renderSchema) || {};
}
function ou(e, t) {
  const n = Ye(t.itemsPath ?? t.dataPath), s = n ? xt(e, n) : void 0, r = Array.isArray(s) ? s : Array.isArray(e) ? e : [
    "records",
    "items",
    "rows",
    "list",
    "data.records",
    "data.items",
    "data.rows",
    "data.list",
    "data"
  ].map((o) => xt(e, o)).find(Array.isArray);
  if (Array.isArray(r))
    return r.map((o) => Dt(o) || { value: o });
  const i = Dt(e);
  return i ? [i] : [];
}
function au(e, t, n) {
  const s = Ye(t.totalPath ?? t.totalField), r = s ? [xt(e, s)] : ["total", "totalCount", "data.total", "data.totalCount", "pagination.total"].map((i) => xt(e, i));
  for (const i of r) {
    const o = Number(i);
    if (Number.isFinite(o) && o >= 0) return Math.floor(o);
  }
  return n;
}
function fr(e) {
  const t = Dt(e);
  return t ? Object.fromEntries(
    Object.entries(t).filter(([, n]) => n != null).map(([n, s]) => [n, String(s)])
  ) : {};
}
function lu(e) {
  const t = fr(e);
  return Object.fromEntries(
    Object.entries(t).map(([n, s]) => [n, s.toLowerCase()]).filter((n) => su.has(n[1]))
  );
}
function cu(e) {
  return Array.isArray(e.fields) ? e.fields.flatMap((t) => {
    if (typeof t == "string" && t.trim())
      return [{
        key: t.trim(),
        label: t.trim(),
        valueMap: {},
        separator: "、",
        hideWhenEmpty: !1
      }];
    const n = Dt(t), s = Ye((n == null ? void 0 : n.key) ?? (n == null ? void 0 : n.field) ?? (n == null ? void 0 : n.name));
    return !n || !s || n.hidden === !0 ? [] : [{
      key: s,
      label: Ye(n.label ?? n.title) || s,
      valueMap: fr(n.valueMap ?? n.labels),
      maxItems: n.maxItems == null ? void 0 : Fo(n.maxItems, 3, 1, 20),
      separator: Ye(n.separator) || "、",
      hideWhenEmpty: n.hideWhenEmpty === !0
    }];
  }) : [];
}
function uu(e) {
  const t = Dt(e.status) || {}, n = Ye(t.field ?? e.statusField ?? e.badgeField);
  return n ? {
    field: n,
    valueMap: fr(t.valueMap ?? t.labels ?? e.statusMap),
    toneMap: lu(t.toneMap ?? t.tones ?? e.statusToneMap)
  } : null;
}
function du(e) {
  const t = String(e), n = t.trim().toLowerCase(), s = n === "1" ? ["true"] : n === "0" ? ["false"] : n === "true" ? ["1"] : n === "false" ? ["0"] : [];
  return [.../* @__PURE__ */ new Set([t, n, ...s])];
}
function Fs(e, t) {
  for (const n of du(e)) {
    const s = t[n];
    if (s != null) return s;
  }
}
function yn(e, t) {
  if (e == null || e === "") return "-";
  const n = Fs(e, (t == null ? void 0 : t.valueMap) || {});
  if (n != null) return n;
  if (Array.isArray(e)) {
    const s = (t == null ? void 0 : t.maxItems) ?? e.length, r = e.slice(0, s).map((o) => yn(o)), i = e.length - r.length;
    return `${r.join((t == null ? void 0 : t.separator) || "、")}${i > 0 ? `… +${i}` : ""}`;
  }
  if (typeof e == "object")
    try {
      return JSON.stringify(e);
    } catch {
      return String(e);
    }
  return String(e);
}
function fu(e) {
  for (const n of ["title", "name", "displayName", "label"])
    if (Ye(e[n])) return n;
  const t = Object.keys(e).find((n) => /(?:name|title|label)$/i.test(n) && Ye(e[n]));
  return t || Object.keys(e).find((n) => typeof e[n] == "string" && Ye(e[n]));
}
function hu(e, t) {
  return Object.keys(e).filter((n) => !t.has(n)).slice(0, 4).map((n) => ({
    key: n,
    label: n,
    valueMap: {},
    separator: "、",
    hideWhenEmpty: !1
  }));
}
function pu(e, t, n) {
  const s = t ? xt(e, t) : e.id ?? e.key ?? e.code;
  return s == null || s === "" ? `list-item-${n}` : String(s);
}
function gu(e, t) {
  if (!t) return;
  const n = xt(e, t.field);
  if (!(n == null || n === ""))
    return {
      label: Fs(n, t.valueMap) || yn(n),
      tone: Fs(n, t.toneMap) ?? "neutral"
    };
}
function mu(e) {
  const t = iu(e), n = ou(e.data, t), s = cu(t), r = uu(t), i = Ye(t.titleField), o = Ye(t.subtitleField), a = Ye(t.itemKey ?? t.rowKey), u = n.map((h, d) => {
    const g = i || fu(h), w = new Set(
      [g, o, r == null ? void 0 : r.field, a].filter((P) => !!P)
    ), R = s.length ? s : hu(h, w);
    return {
      key: pu(h, a, d),
      title: g ? yn(xt(h, g)) : `#${d + 1}`,
      subtitle: o ? yn(xt(h, o)) : void 0,
      status: gu(h, r),
      fields: R.flatMap((P) => {
        const x = xt(h, P.key);
        return P.hideWhenEmpty && (x == null || x === "") ? [] : [{ key: P.key, label: P.label, value: yn(x, P) }];
      })
    };
  });
  return {
    items: u,
    total: au(e.data, t, u.length),
    initialVisibleCount: Fo(t.initialVisibleCount, 5, 1, 50),
    showCount: t.showCount !== !1,
    emptyText: Ye(t.emptyText) || "暂无数据"
  };
}
const yu = ["aria-label"], bu = {
  key: 0,
  class: "reachai-interaction__header"
}, _u = { key: 0 }, vu = {
  key: 1,
  class: "reachai-interaction__badge"
}, wu = {
  key: 1,
  class: "reachai-interaction__message"
}, Su = {
  key: 2,
  class: "reachai-interaction__state",
  "aria-live": "polite"
}, Iu = { key: 0 }, Au = ["onUpdate:modelValue", "disabled"], Eu = ["onUpdate:modelValue", "disabled", "placeholder"], xu = ["value", "multiple", "disabled", "onChange"], Cu = ["value"], ku = ["onUpdate:modelValue", "disabled"], Pu = ["value", "disabled", "placeholder", "onInput"], Tu = ["value", "disabled", "placeholder", "onInput"], Ru = {
  key: 0,
  class: "reachai-interaction__actions"
}, $u = ["disabled"], Mu = ["disabled"], Ou = {
  key: 5,
  class: "reachai-interaction__confirm"
}, Nu = {
  key: 0,
  class: "reachai-interaction__actions"
}, Du = ["disabled"], Lu = ["disabled"], Fu = ["disabled"], qu = {
  key: 6,
  class: "reachai-interaction__choice"
}, ju = ["value", "disabled"], Ku = ["name", "value", "disabled"], Uu = {
  key: 0,
  class: "reachai-interaction__actions"
}, Bu = ["disabled"], Hu = ["disabled"], Vu = {
  key: 7,
  class: "reachai-interaction__table-wrap"
}, Wu = { class: "reachai-interaction__table" }, zu = {
  key: 8,
  class: "reachai-interaction__detail"
}, Gu = {
  key: 0,
  class: "reachai-interaction__actions"
}, Ju = ["disabled", "onClick"], Yu = {
  key: 9,
  class: "reachai-interaction__list"
}, Xu = {
  key: 0,
  class: "reachai-interaction__list-summary"
}, Qu = {
  key: 1,
  class: "reachai-interaction__empty"
}, Zu = { class: "reachai-interaction__list-item-header" }, ed = { class: "reachai-interaction__list-title" }, td = { key: 0 }, nd = {
  key: 0,
  class: "reachai-interaction__list-fields"
}, sd = ["aria-expanded"], rd = {
  key: 10,
  class: "reachai-interaction__page-action"
}, id = { class: "reachai-interaction__actions" }, od = ["disabled"], ad = ["disabled"], ld = {
  key: 11,
  class: "reachai-interaction__custom"
}, cd = { class: "reachai-interaction__warn" }, ud = { class: "reachai-interaction__actions" }, dd = ["disabled"], fd = ["disabled"], hd = {
  key: 12,
  class: "reachai-interaction__error",
  role: "alert"
}, pd = {
  key: 13,
  class: "reachai-interaction__actions"
}, gd = /* @__PURE__ */ gt({
  __name: "UnifiedInteractionRenderer",
  props: {
    request: {},
    state: {},
    errorMessage: {},
    disabled: { type: Boolean }
  },
  emits: ["submit", "cancel", "action"],
  setup(e, { emit: t }) {
    const n = e, s = t, r = ae(() => eu(n.request.component)), i = ae(() => n.state || "waiting"), o = ae(
      () => n.disabled || i.value === "submitting" || i.value === "resolved" || i.value === "expired" || i.value === "cancelled"
    ), a = ae(() => `reachai-choice-${n.request.interactionId || "default"}`), u = /* @__PURE__ */ Ee(""), h = /* @__PURE__ */ Ee(!1), d = ae(() => n.request.actions || []), g = ae(() => {
      var D;
      return ((D = n.request.behavior) == null ? void 0 : D.readonly) === !0 ? !0 : (/* @__PURE__ */ new Set(["table", "detail", "summary_card", "list_card", "output_card", "card", "report"])).has(r.value) && !d.value.length;
    }), w = ae(() => !g.value), R = ae(() => {
      switch (i.value) {
        case "submitting":
          return "提交中…";
        case "resolved":
          return "已提交";
        case "failed":
          return "提交失败";
        case "expired":
          return "已过期";
        case "cancelled":
          return "已取消";
        default:
          return "";
      }
    }), P = /* @__PURE__ */ ts({}), x = /* @__PURE__ */ Ee(null), $ = /* @__PURE__ */ Ee([]), I = /* @__PURE__ */ Ee(null);
    function y(k, D) {
      return k == null ? D.type === "boolean" ? !1 : D.type === "multi_select" ? [] : "" : typeof k == "string" || typeof k == "number" || typeof k == "boolean" ? k : Array.isArray(k) ? k.map(String) : String(k);
    }
    Ut(
      () => n.request,
      (k) => {
        var L, l, c, f;
        u.value = "", h.value = !1, Object.keys(P).forEach((m) => delete P[m]);
        for (const m of k.fields || []) {
          const b = (L = k.prefilled) == null ? void 0 : L[m.key];
          P[m.key] = y(b, m);
        }
        const D = (l = k.fields) == null ? void 0 : l[0], Y = D == null ? void 0 : D.key, ie = Y && ((c = k.prefilled) == null ? void 0 : c[Y]) !== void 0 ? k.prefilled[Y] : (f = k.prefilled) == null ? void 0 : f.value;
        if (k.component === "multi_select") {
          Array.isArray(ie) ? $.value = [...ie] : ie == null ? $.value = [] : $.value = [ie], x.value = null;
          return;
        }
        ie !== void 0 && (typeof ie == "string" || typeof ie == "number" || typeof ie == "boolean" ? x.value = ie : ie == null ? x.value = null : x.value = String(ie));
      },
      { immediate: !0, deep: !0 }
    );
    function O(k) {
      var D;
      return k.type === "select" || k.type === "multi_select" || !!((D = k.options) != null && D.length);
    }
    function E(k) {
      const D = P[k.key];
      return k.type === "multi_select" ? Array.isArray(D) ? D.map(String) : [] : typeof D == "string" || typeof D == "number" ? D : D == null ? void 0 : String(D);
    }
    function q(k, D) {
      const Y = D.target;
      k.type === "multi_select" ? P[k.key] = Array.from(Y.selectedOptions).map((ie) => ie.value) : P[k.key] = Y.value;
    }
    const S = ae(() => {
      var Y, ie;
      const k = (Y = n.request.fields) == null ? void 0 : Y[0];
      if ((ie = k == null ? void 0 : k.options) != null && ie.length) return k.options;
      const D = n.request.data;
      return Array.isArray(D) ? D.map((L, l) => {
        if (L && typeof L == "object") {
          const c = L;
          return { value: c.value ?? c.id ?? l, label: String(c.label ?? c.name ?? c.value ?? l) };
        }
        return { value: L, label: String(L) };
      }) : [];
    }), M = ae(() => {
      const k = n.request.data;
      return Array.isArray(k) ? k.map((D) => D && typeof D == "object" ? D : { value: D }) : k && typeof k == "object" ? [k] : n.request.summary ? [n.request.summary] : [];
    }), j = ae(() => {
      const k = se(n.request);
      if (k.length) return k;
      const D = M.value[0];
      return D ? Object.keys(D).map((Y) => ({ key: Y, label: Y })) : [];
    }), K = ae(() => mu(n.request)), H = ae(() => h.value ? K.value.items : K.value.items.slice(0, K.value.initialVisibleCount));
    function se(k) {
      var Y, ie;
      const D = [
        (Y = k.schema) == null ? void 0 : Y.columns,
        (ie = k.extension) == null ? void 0 : ie.columns,
        k.data && typeof k.data == "object" && !Array.isArray(k.data) ? k.data.columns : void 0
      ];
      for (const L of D)
        if (!(!Array.isArray(L) || !L.length))
          return L.map((l, c) => {
            if (typeof l == "string") return { key: l, label: l };
            if (l && typeof l == "object") {
              const f = l, m = String(f.key ?? f.field ?? f.name ?? c);
              return { key: m, label: String(f.label ?? f.title ?? m) };
            }
            return { key: String(c), label: String(l) };
          });
      return [];
    }
    const re = ae(() => {
      const k = n.request.summary || n.request.data || {};
      return Array.isArray(k) ? k.map((D, Y) => ({
        key: String(Y),
        label: `#${Y + 1}`,
        value: D
      })) : Object.entries(k || {}).map(([D, Y]) => ({ key: D, label: D, value: Y }));
    }), ee = ae(() => {
      var D;
      const k = (D = n.request.extension) == null ? void 0 : D.pageActionRequest;
      return k && typeof k == "object" ? k : n.request.data && typeof n.request.data == "object" ? n.request.data : {};
    }), we = ae(
      () => String(ee.value.title || n.request.title || "页面动作")
    ), de = ae(
      () => {
        var k;
        return (k = n.request.extension) != null && k.rendererKey ? String(n.request.extension.rendererKey) : "";
      }
    ), G = ae(() => {
      const k = de.value;
      if (!k) return null;
      const D = tu(k);
      if (!D) return null;
      const Y = D({
        request: n.request,
        state: i.value,
        disabled: o.value,
        onSubmit: (ie, L) => fe(ie, L),
        onCancel: () => Re()
      });
      return Y ? /* @__PURE__ */ gt({
        name: `ReachAiCustomInteraction_${k}`,
        setup() {
          return () => Gl(Y);
        }
      }) : null;
    });
    function V(k) {
      if (k == null) return "-";
      if (typeof k == "string") return k;
      try {
        return JSON.stringify(k);
      } catch {
        return String(k);
      }
    }
    function Q(k) {
      return String(k.key || k.action || "submit");
    }
    function Ie(k) {
      return String(k.label || k.key || k.action || "提交");
    }
    function Xe(k) {
      return k.values && typeof k.values == "object" ? k.values : { ...k };
    }
    function Ae(k) {
      return k.type === "primary" || Q(k) === "confirm" || Q(k) === "submit";
    }
    function fe(k, D) {
      o.value && i.value !== "failed" || (I.value = { action: k, values: D }, s("submit", k, D), s("action", k, D));
    }
    function De(k) {
      for (const D of n.request.fields || [])
        if (D.required) {
          const Y = P[D.key];
          if (Y === "" || Y == null || Array.isArray(Y) && !Y.length) {
            u.value = `请填写必填项：${D.label || D.key}`;
            return;
          }
        }
      u.value = "", fe(k, { ...P });
    }
    function yt() {
      var k, D;
      if (n.request.component === "multi_select") {
        if (!$.value.length && ((k = n.request.fields) != null && k.some((Y) => Y.required))) {
          u.value = "请至少选择一项";
          return;
        }
        u.value = "", fe("choose", { value: [...$.value] });
      } else {
        if ((x.value === null || x.value === "") && ((D = n.request.fields) != null && D.some((Y) => Y.required))) {
          u.value = "请选择一项";
          return;
        }
        u.value = "", fe("choose", { value: x.value });
      }
    }
    function Re() {
      o.value || (s("cancel"), s("action", "cancel", {}));
    }
    function Le() {
      I.value && (s("submit", I.value.action, I.value.values), s("action", I.value.action, I.value.values));
    }
    return (k, D) => {
      var Y, ie;
      return T(), N("div", {
        class: Oe(["reachai-interaction", [
          `reachai-interaction--${r.value}`,
          `reachai-interaction--${i.value}`,
          { "is-disabled": o.value }
        ]]),
        role: "region",
        "aria-label": e.request.title || e.request.component || "interaction"
      }, [
        e.request.title || (Y = e.request.missing) != null && Y.length ? (T(), N("header", bu, [
          e.request.title ? (T(), N("strong", _u, Z(e.request.title), 1)) : te("", !0),
          (ie = e.request.missing) != null && ie.length ? (T(), N("span", vu, "待补充 " + Z(e.request.missing.length) + " 项", 1)) : te("", !0)
        ])) : te("", !0),
        e.request.message && r.value !== "form" ? (T(), N("p", wu, Z(e.request.message), 1)) : te("", !0),
        R.value ? (T(), N("div", Su, Z(R.value), 1)) : te("", !0),
        G.value ? (T(), mt(ll(G.value), {
          key: 3,
          class: "reachai-interaction__custom-host"
        })) : r.value === "form" ? (T(), N("form", {
          key: 4,
          class: "reachai-interaction__form",
          onSubmit: D[0] || (D[0] = Po((L) => De("submit"), ["prevent"]))
        }, [
          (T(!0), N(me, null, Be(e.request.fields || [], (L) => (T(), N("label", {
            key: L.key,
            class: "reachai-interaction__field"
          }, [
            U("span", null, [
              In(Z(L.label), 1),
              L.required ? (T(), N("em", Iu, "*")) : te("", !0)
            ]),
            L.type === "boolean" ? Jt((T(), N("input", {
              key: 0,
              "onUpdate:modelValue": (l) => P[L.key] = l,
              type: "checkbox",
              disabled: o.value
            }, null, 8, Au)), [
              [ni, P[L.key]]
            ]) : L.type === "number" || L.type === "integer" ? Jt((T(), N("input", {
              key: 1,
              "onUpdate:modelValue": (l) => P[L.key] = l,
              type: "number",
              disabled: o.value,
              placeholder: L.placeholder
            }, null, 8, Eu)), [
              [
                Ds,
                P[L.key],
                void 0,
                { number: !0 }
              ]
            ]) : O(L) ? (T(), N("select", {
              key: 2,
              value: E(L),
              multiple: L.type === "multi_select",
              disabled: o.value,
              onChange: (l) => q(L, l)
            }, [
              (T(!0), N(me, null, Be(L.options || [], (l) => (T(), N("option", {
                key: String(l.value),
                value: l.value
              }, Z(l.label), 9, Cu))), 128))
            ], 40, xu)) : L.type === "date" ? Jt((T(), N("input", {
              key: 3,
              "onUpdate:modelValue": (l) => P[L.key] = l,
              type: "date",
              disabled: o.value
            }, null, 8, ku)), [
              [Ds, P[L.key]]
            ]) : L.type === "textarea" || L.type === "object" || L.type === "array" ? (T(), N("textarea", {
              key: 4,
              value: String(P[L.key] ?? ""),
              rows: "3",
              disabled: o.value,
              placeholder: L.placeholder,
              onInput: (l) => P[L.key] = l.target.value
            }, null, 40, Pu)) : (T(), N("input", {
              key: 5,
              value: String(P[L.key] ?? ""),
              type: "text",
              disabled: o.value,
              placeholder: L.placeholder,
              onInput: (l) => P[L.key] = l.target.value
            }, null, 40, Tu))
          ]))), 128)),
          w.value ? (T(), N("div", Ru, [
            U("button", {
              type: "button",
              disabled: o.value,
              onClick: Re
            }, "取消", 8, $u),
            U("button", {
              type: "submit",
              class: "is-primary",
              disabled: o.value
            }, "提交", 8, Mu)
          ])) : te("", !0)
        ], 32)) : r.value === "confirm" ? (T(), N("div", Ou, [
          U("p", null, Z(e.request.message || "请确认是否继续。"), 1),
          w.value ? (T(), N("div", Nu, [
            U("button", {
              type: "button",
              disabled: o.value,
              onClick: Re
            }, "取消", 8, Du),
            U("button", {
              type: "button",
              disabled: o.value,
              onClick: D[1] || (D[1] = (L) => fe("reject", { confirm: !1 }))
            }, "拒绝", 8, Lu),
            U("button", {
              type: "button",
              class: "is-primary",
              disabled: o.value,
              onClick: D[2] || (D[2] = (L) => fe("confirm", { confirm: !0 }))
            }, "确认", 8, Fu)
          ])) : te("", !0)
        ])) : r.value === "select" ? (T(), N("div", qu, [
          (T(!0), N(me, null, Be(S.value, (L) => (T(), N("label", {
            key: String(L.value),
            class: "reachai-interaction__option"
          }, [
            e.request.component === "multi_select" ? Jt((T(), N("input", {
              key: 0,
              "onUpdate:modelValue": D[3] || (D[3] = (l) => $.value = l),
              type: "checkbox",
              value: L.value,
              disabled: o.value
            }, null, 8, ju)), [
              [ni, $.value]
            ]) : Jt((T(), N("input", {
              key: 1,
              "onUpdate:modelValue": D[4] || (D[4] = (l) => x.value = l),
              type: "radio",
              name: a.value,
              value: L.value,
              disabled: o.value
            }, null, 8, Ku)), [
              [_c, x.value]
            ]),
            U("span", null, Z(L.label), 1)
          ]))), 128)),
          w.value ? (T(), N("div", Uu, [
            U("button", {
              type: "button",
              disabled: o.value,
              onClick: Re
            }, "取消", 8, Bu),
            U("button", {
              type: "button",
              class: "is-primary",
              disabled: o.value,
              onClick: yt
            }, "选择", 8, Hu)
          ])) : te("", !0)
        ])) : r.value === "table" ? (T(), N("div", Vu, [
          U("table", Wu, [
            U("thead", null, [
              U("tr", null, [
                (T(!0), N(me, null, Be(j.value, (L) => (T(), N("th", {
                  key: L.key
                }, Z(L.label), 1))), 128))
              ])
            ]),
            U("tbody", null, [
              (T(!0), N(me, null, Be(M.value, (L, l) => (T(), N("tr", { key: l }, [
                (T(!0), N(me, null, Be(j.value, (c) => (T(), N("td", {
                  key: c.key
                }, Z(V(L[c.key])), 1))), 128))
              ]))), 128))
            ])
          ])
        ])) : r.value === "detail" || r.value === "summary_card" || r.value === "output_card" ? (T(), N("div", zu, [
          U("dl", null, [
            (T(!0), N(me, null, Be(re.value, (L) => (T(), N("div", {
              key: L.key
            }, [
              U("dt", null, Z(L.label), 1),
              U("dd", null, Z(V(L.value)), 1)
            ]))), 128))
          ]),
          w.value && d.value.length ? (T(), N("div", Gu, [
            (T(!0), N(me, null, Be(d.value, (L) => (T(), N("button", {
              key: Q(L),
              type: "button",
              class: Oe({ "is-primary": Ae(L) }),
              disabled: o.value,
              onClick: (l) => fe(Q(L), Xe(L))
            }, Z(Ie(L)), 11, Ju))), 128))
          ])) : te("", !0)
        ])) : r.value === "list_card" ? (T(), N("div", Yu, [
          K.value.showCount ? (T(), N("div", Xu, " 共 " + Z(K.value.total) + " 条 ", 1)) : te("", !0),
          K.value.items.length ? te("", !0) : (T(), N("p", Qu, Z(K.value.emptyText), 1)),
          (T(!0), N(me, null, Be(H.value, (L) => (T(), N("article", {
            key: L.key,
            class: "reachai-interaction__list-item"
          }, [
            U("header", Zu, [
              U("div", ed, [
                U("strong", null, Z(L.title), 1),
                L.subtitle ? (T(), N("span", td, Z(L.subtitle), 1)) : te("", !0)
              ]),
              L.status ? (T(), N("span", {
                key: 0,
                class: Oe(["reachai-interaction__status-chip", `is-${L.status.tone}`])
              }, Z(L.status.label), 3)) : te("", !0)
            ]),
            L.fields.length ? (T(), N("dl", nd, [
              (T(!0), N(me, null, Be(L.fields, (l) => (T(), N("div", {
                key: l.key
              }, [
                U("dt", null, Z(l.label), 1),
                U("dd", null, Z(l.value), 1)
              ]))), 128))
            ])) : te("", !0)
          ]))), 128)),
          K.value.items.length > K.value.initialVisibleCount ? (T(), N("button", {
            key: 2,
            type: "button",
            class: "reachai-interaction__list-toggle",
            "aria-expanded": h.value,
            onClick: D[5] || (D[5] = (L) => h.value = !h.value)
          }, Z(h.value ? "收起" : `展开剩余 ${K.value.items.length - K.value.initialVisibleCount} 条`), 9, sd)) : te("", !0)
        ])) : r.value === "page_action" ? (T(), N("div", rd, [
          U("p", null, Z(we.value), 1),
          U("dl", null, [
            U("div", null, [
              D[8] || (D[8] = U("dt", null, "actionKey", -1)),
              U("dd", null, Z(ee.value.actionKey || "-"), 1)
            ]),
            U("div", null, [
              D[9] || (D[9] = U("dt", null, "requestId", -1)),
              U("dd", null, Z(ee.value.requestId || e.request.interactionId || "-"), 1)
            ]),
            U("div", null, [
              D[10] || (D[10] = U("dt", null, "args", -1)),
              U("dd", null, Z(V(ee.value.args || {})), 1)
            ])
          ]),
          U("div", id, [
            ee.value.confirm ? (T(), N("button", {
              key: 0,
              type: "button",
              disabled: o.value,
              onClick: Re
            }, "取消", 8, od)) : te("", !0),
            U("button", {
              type: "button",
              class: "is-primary",
              disabled: o.value,
              onClick: D[6] || (D[6] = (L) => fe("page_action_ack", { requestId: ee.value.requestId, actionKey: ee.value.actionKey }))
            }, " 已收到 ", 8, ad)
          ])
        ])) : (T(), N("div", ld, [
          U("p", cd, Z(de.value ? `自定义渲染器未在宿主注册：${de.value}` : `未注册的交互组件：${e.request.component || "unknown"}`), 1),
          U("pre", null, Z(V(e.request.data ?? e.request.summary ?? {})), 1),
          U("div", ud, [
            U("button", {
              type: "button",
              disabled: o.value,
              onClick: Re
            }, "取消", 8, dd),
            U("button", {
              type: "button",
              class: "is-primary",
              disabled: o.value,
              onClick: D[7] || (D[7] = (L) => fe("submit", {}))
            }, "按原始值提交", 8, fd)
          ])
        ])),
        u.value || e.errorMessage ? (T(), N("p", hd, Z(u.value || e.errorMessage), 1)) : te("", !0),
        i.value === "failed" ? (T(), N("div", pd, [
          U("button", {
            type: "button",
            class: "is-primary",
            onClick: Le
          }, "重试")
        ])) : te("", !0)
      ], 10, yu);
    };
  }
}), Ht = (e, t) => {
  const n = e.__vccOpts || e;
  for (const [s, r] of t)
    n[s] = r;
  return n;
}, md = /* @__PURE__ */ Ht(gd, [["__scopeId", "data-v-2a5d0f29"]]), yd = ["data-type"], bd = {
  key: 0,
  class: "reachai-block__caret",
  "aria-hidden": "true"
}, _d = {
  key: 2,
  class: "reachai-block__page-action"
}, vd = { key: 0 }, wd = ["data-level"], Sd = {
  key: 4,
  class: "reachai-block__error",
  role: "alert"
}, Id = /* @__PURE__ */ gt({
  __name: "ConversationBlockRenderer",
  props: {
    block: {}
  },
  emits: ["interaction-submit", "interaction-cancel", "retry"],
  setup(e, { emit: t }) {
    const n = t;
    function s(i, o, a) {
      i.type === "interaction" && n("interaction-submit", i.request.interactionId, o, a);
    }
    function r(i) {
      i.type === "interaction" && n("interaction-cancel", i.request.interactionId);
    }
    return (i, o) => (T(), N("div", {
      class: "reachai-block",
      "data-type": e.block.type
    }, [
      e.block.type === "text" ? (T(), N("div", {
        key: 0,
        class: Oe(["reachai-block__text", { "is-streaming": e.block.status === "streaming" }])
      }, [
        In(Z(e.block.text) + " ", 1),
        e.block.status === "streaming" ? (T(), N("span", bd)) : te("", !0)
      ], 2)) : e.block.type === "interaction" ? (T(), mt(md, {
        key: 1,
        request: e.block.request,
        state: e.block.state,
        "error-message": e.block.errorMessage,
        onSubmit: o[0] || (o[0] = (a, u) => s(e.block, a, u)),
        onCancel: o[1] || (o[1] = (a) => r(e.block))
      }, null, 8, ["request", "state", "error-message"])) : e.block.type === "page_action" ? (T(), N("div", _d, [
        U("strong", null, Z(e.block.title || e.block.actionKey), 1),
        U("span", null, Z(e.block.status), 1),
        e.block.message ? (T(), N("p", vd, Z(e.block.message), 1)) : te("", !0)
      ])) : e.block.type === "notice" ? (T(), N("div", {
        key: 3,
        class: "reachai-block__notice",
        "data-level": e.block.level || "info"
      }, Z(e.block.text), 9, wd)) : e.block.type === "error" ? (T(), N("div", Sd, [
        In(Z(e.block.text) + " ", 1),
        e.block.retryable ? (T(), N("button", {
          key: 0,
          type: "button",
          onClick: o[2] || (o[2] = (a) => i.$emit("retry"))
        }, "重试")) : te("", !0)
      ])) : te("", !0)
    ], 8, yd));
  }
}), ci = /* @__PURE__ */ Ht(Id, [["__scopeId", "data-v-775b19fc"]]), Ad = ["data-message-id", "data-role", "data-status"], Ed = {
  key: 0,
  class: "reachai-message__user-row"
}, xd = { class: "reachai-message__user-bubble" }, Cd = {
  key: 0,
  class: "reachai-message__user-avatar",
  "aria-hidden": "true"
}, kd = {
  key: 0,
  class: "reachai-message__prism-avatar",
  "aria-hidden": "true"
}, Pd = {
  key: 0,
  class: "reachai-message__card-heading"
}, Td = {
  key: 0,
  class: "reachai-message__thinking-title"
}, Rd = {
  key: 1,
  class: "reachai-message__weak-label"
}, $d = {
  key: 2,
  class: "reachai-message__heading-spacer",
  "aria-hidden": "true"
}, Md = ["data-tone"], Od = {
  key: 1,
  class: "reachai-message__status-hint"
}, Nd = {
  key: 2,
  class: "reachai-message__thinking-details"
}, Dd = ["aria-expanded"], Ld = {
  class: "reachai-message__thinking-chevron",
  "aria-hidden": "true"
}, Fd = {
  key: 0,
  class: "reachai-message__thinking-steps"
}, qd = ["data-state"], jd = { class: "reachai-message__thinking-step-body" }, Kd = { key: 0 }, Ud = { class: "reachai-message__body" }, Bd = {
  key: 0,
  class: "reachai-message__loading"
}, Hd = {
  key: 3,
  class: "reachai-message__meta"
}, Vd = /* @__PURE__ */ gt({
  __name: "ConversationMessageItem",
  props: {
    message: {},
    assistantLabel: { default: "" },
    statusHint: { default: "" },
    thinkingPresentation: { default: null },
    showAvatars: { type: Boolean, default: !0 },
    surface: { default: "admin" }
  },
  emits: ["interaction-submit", "interaction-cancel", "retry"],
  setup(e) {
    const t = e, n = /* @__PURE__ */ Ee(!1), s = ae(
      () => t.message.role !== "user" && (t.message.status === "pending" || t.message.status === "streaming")
    ), r = ae(() => s.value), i = ae(() => {
      var g;
      return ((g = t.thinkingPresentation) == null ? void 0 : g.steps) || [];
    });
    Ut(
      () => t.message.id,
      () => {
        n.value = !1;
      }
    ), Ut(s, (g) => {
      g || (n.value = !1);
    });
    const o = ae(
      () => !s.value && !!t.assistantLabel && t.message.role === "assistant" && t.surface === "admin"
    ), a = ae(() => [
      `reachai-message--${t.message.role}`,
      `reachai-message--${t.message.status}`,
      {
        "reachai-message--thinking": s.value,
        "reachai-message--prism": t.message.role !== "user"
      }
    ]), u = ae(() => ({
      "reachai-message__card-shell--thinking": s.value,
      "reachai-message__card-shell--response": !s.value,
      "reachai-message__card-shell--failed": t.message.status === "failed",
      "reachai-message__card-shell--cancelled": t.message.status === "cancelled"
    })), h = ae(() => ({
      "reachai-message__card--thinking": s.value,
      "reachai-message__card--response": !s.value,
      [`reachai-message__card--${t.message.status}`]: !0
    })), d = ae(() => s.value ? null : t.message.status === "failed" ? { label: "失败", tone: "danger" } : t.message.status === "cancelled" ? { label: "已取消", tone: "warning" } : null);
    return (g, w) => {
      var R;
      return T(), N("article", {
        class: Oe(["reachai-message", a.value]),
        "data-message-id": e.message.id,
        "data-role": e.message.role,
        "data-status": e.message.status
      }, [
        e.message.role === "user" ? (T(), N("div", Ed, [
          U("div", xd, [
            (T(!0), N(me, null, Be(e.message.blocks, (P) => (T(), mt(ci, {
              key: P.id,
              block: P,
              onInteractionSubmit: w[0] || (w[0] = (...x) => g.$emit("interaction-submit", ...x)),
              onInteractionCancel: w[1] || (w[1] = (x) => g.$emit("interaction-cancel", x)),
              onRetry: w[2] || (w[2] = (x) => g.$emit("retry"))
            }, null, 8, ["block"]))), 128))
          ]),
          e.showAvatars ? (T(), N("div", Cd, [...w[7] || (w[7] = [
            U("svg", {
              viewBox: "0 0 24 24",
              width: "18",
              height: "18",
              fill: "none",
              stroke: "currentColor",
              "stroke-width": "1.8"
            }, [
              U("circle", {
                cx: "12",
                cy: "8",
                r: "3.5"
              }),
              U("path", {
                d: "M5 19.5c1.2-3.2 3.6-4.8 7-4.8s5.8 1.6 7 4.8",
                "stroke-linecap": "round"
              })
            ], -1)
          ])])) : te("", !0)
        ])) : (T(), N("div", {
          key: 1,
          class: Oe(["reachai-message__assistant-row", { "reachai-message__assistant-row--without-avatar": !e.showAvatars }])
        }, [
          e.showAvatars ? (T(), N("div", kd, [...w[8] || (w[8] = [
            U("span", { class: "reachai-message__prism-avatar-img" }, null, -1)
          ])])) : te("", !0),
          U("div", {
            class: Oe(["reachai-message__card-shell", u.value])
          }, [
            U("div", {
              class: Oe(["reachai-message__card", h.value])
            }, [
              r.value || o.value || d.value ? (T(), N("header", Pd, [
                r.value ? (T(), N("div", Td, [...w[9] || (w[9] = [
                  U("span", {
                    class: "reachai-message__spark",
                    "aria-hidden": "true"
                  }, "✦", -1),
                  U("strong", null, "思考中…", -1),
                  U("span", {
                    class: "reachai-message__thinking-dots",
                    "aria-hidden": "true"
                  }, [
                    U("i"),
                    U("i"),
                    U("i")
                  ], -1)
                ])])) : o.value ? (T(), N("div", Rd, Z(e.assistantLabel), 1)) : (T(), N("span", $d)),
                d.value ? (T(), N("span", {
                  key: 3,
                  class: "reachai-message__status-capsule",
                  "data-tone": d.value.tone
                }, Z(d.value.label), 9, Md)) : te("", !0)
              ])) : te("", !0),
              r.value && e.statusHint ? (T(), N("p", Od, Z(e.statusHint), 1)) : te("", !0),
              r.value && ((R = e.thinkingPresentation) != null && R.label) ? (T(), N("div", Nd, [
                U("button", {
                  type: "button",
                  class: "reachai-message__thinking-toggle",
                  "aria-expanded": n.value,
                  onClick: w[3] || (w[3] = (P) => n.value = !n.value)
                }, [
                  U("span", null, Z(e.thinkingPresentation.label), 1),
                  U("span", Ld, Z(n.value ? "▴" : "▾"), 1)
                ], 8, Dd),
                n.value && i.value.length ? (T(), N("ul", Fd, [
                  (T(!0), N(me, null, Be(i.value, (P) => (T(), N("li", {
                    key: P.id,
                    class: "reachai-message__thinking-step",
                    "data-state": P.state
                  }, [
                    w[10] || (w[10] = U("span", {
                      class: "reachai-message__thinking-step-mark",
                      "aria-hidden": "true"
                    }, null, -1)),
                    U("div", jd, [
                      U("strong", null, Z(P.title), 1),
                      P.detail ? (T(), N("p", Kd, Z(P.detail), 1)) : te("", !0)
                    ])
                  ], 8, qd))), 128))
                ])) : te("", !0)
              ])) : te("", !0),
              U("div", Ud, [
                (T(!0), N(me, null, Be(e.message.blocks, (P) => (T(), mt(ci, {
                  key: P.id,
                  block: P,
                  onInteractionSubmit: w[4] || (w[4] = (...x) => g.$emit("interaction-submit", ...x)),
                  onInteractionCancel: w[5] || (w[5] = (x) => g.$emit("interaction-cancel", x)),
                  onRetry: w[6] || (w[6] = (x) => g.$emit("retry"))
                }, null, 8, ["block"]))), 128)),
                !e.message.blocks.length && s.value && !e.statusHint ? (T(), N("div", Bd, " 正在处理 ")) : te("", !0)
              ]),
              g.$slots.meta ? (T(), N("footer", Hd, [
                Ot(g.$slots, "meta", { message: e.message }, void 0)
              ])) : te("", !0)
            ], 2)
          ], 2)
        ], 2))
      ], 10, Ad);
    };
  }
}), Wd = /* @__PURE__ */ Ht(Vd, [["__scopeId", "data-v-302c24f4"]]), zd = {
  key: 0,
  class: "reachai-message-list__empty"
}, Gd = /* @__PURE__ */ gt({
  __name: "ConversationMessageList",
  props: {
    messages: {},
    autoFollow: { type: Boolean, default: !0 },
    assistantLabel: { default: "" },
    resolveStatusHint: {},
    resolveThinkingPresentation: {},
    showAvatars: { type: Boolean, default: !0 },
    surface: { default: "admin" }
  },
  emits: ["interaction-submit", "interaction-cancel", "retry"],
  setup(e, { expose: t }) {
    const n = e, s = /* @__PURE__ */ Ee(null), r = /* @__PURE__ */ Ee(!0), i = /* @__PURE__ */ Ee(!1);
    function o(d) {
      var g;
      return ((g = n.resolveStatusHint) == null ? void 0 : g.call(n, d)) || "";
    }
    function a(d) {
      var g;
      return ((g = n.resolveThinkingPresentation) == null ? void 0 : g.call(n, d)) || null;
    }
    function u() {
      const d = s.value;
      if (!d) return;
      const g = d.scrollHeight - d.scrollTop - d.clientHeight;
      r.value = g < 48, i.value = !r.value;
    }
    function h(d = !1) {
      const g = s.value;
      g && (!d && !r.value || (g.scrollTop = g.scrollHeight, i.value = !1, r.value = !0));
    }
    return Ut(
      () => n.messages,
      async () => {
        n.autoFollow !== !1 && (await Zs(), h());
      },
      { deep: !0 }
    ), rs(() => h(!0)), t({ scrollToBottom: h }), (d, g) => (T(), N("div", {
      ref_key: "listEl",
      ref: s,
      class: "reachai-message-list",
      role: "log",
      "aria-live": "polite",
      onScroll: u
    }, [
      e.messages.length ? te("", !0) : (T(), N("div", zd, [
        Ot(d.$slots, "empty", {}, () => [
          g[4] || (g[4] = In("开始对话吧", -1))
        ])
      ])),
      (T(!0), N(me, null, Be(e.messages, (w) => (T(), mt(Wd, {
        key: w.id,
        message: w,
        "assistant-label": e.assistantLabel,
        "status-hint": o(w),
        "thinking-presentation": a(w),
        "show-avatars": e.showAvatars,
        surface: e.surface,
        onInteractionSubmit: g[0] || (g[0] = (...R) => d.$emit("interaction-submit", ...R)),
        onInteractionCancel: g[1] || (g[1] = (R) => d.$emit("interaction-cancel", R)),
        onRetry: g[2] || (g[2] = (R) => d.$emit("retry"))
      }, eo({ _: 2 }, [
        d.$slots["message-meta"] ? {
          name: "meta",
          fn: jn((R) => [
            Ot(d.$slots, "message-meta", Io({ ref_for: !0 }, R), void 0, !0)
          ]),
          key: "0"
        } : void 0
      ]), 1032, ["message", "assistant-label", "status-hint", "thinking-presentation", "show-avatars", "surface"]))), 128)),
      i.value ? (T(), N("button", {
        key: 1,
        type: "button",
        class: "reachai-message-list__jump",
        onClick: g[3] || (g[3] = (w) => h(!0))
      }, " 回到底部 ")) : te("", !0)
    ], 544));
  }
}), Jd = /* @__PURE__ */ Ht(Gd, [["__scopeId", "data-v-3cddb8bb"]]), Yd = ["placeholder", "disabled", "aria-label"], Xd = { class: "reachai-composer__actions" }, Qd = { class: "reachai-composer__buttons" }, Zd = ["disabled"], ef = /* @__PURE__ */ gt({
  __name: "ConversationComposer",
  props: {
    placeholder: { default: "输入消息" },
    disabled: { type: Boolean, default: !1 },
    showStop: { type: Boolean, default: !1 }
  },
  emits: ["send", "stop"],
  setup(e, { expose: t, emit: n }) {
    const s = n, r = /* @__PURE__ */ Ee(""), i = /* @__PURE__ */ Ee(null);
    function o() {
      const u = r.value.trim();
      u && (s("send", u), r.value = "");
    }
    function a(u) {
      (u.ctrlKey || u.metaKey) && u.key === "Enter" && (u.preventDefault(), o());
    }
    return t({
      focus() {
        var u;
        (u = i.value) == null || u.focus();
      },
      setValue(u) {
        r.value = u;
      }
    }), (u, h) => (T(), N("form", {
      class: Oe(["reachai-composer", { "is-disabled": e.disabled }]),
      onSubmit: Po(o, ["prevent"])
    }, [
      Jt(U("textarea", {
        ref_key: "inputEl",
        ref: i,
        "onUpdate:modelValue": h[0] || (h[0] = (d) => r.value = d),
        class: "reachai-composer__input",
        rows: "2",
        placeholder: e.placeholder,
        disabled: e.disabled,
        "aria-label": e.placeholder,
        onKeydown: a
      }, null, 40, Yd), [
        [Ds, r.value]
      ]),
      U("div", Xd, [
        h[2] || (h[2] = U("span", { class: "reachai-composer__hint" }, [
          U("kbd", null, "Ctrl"),
          U("b", null, "+"),
          U("kbd", null, "Enter"),
          U("em", null, "发送")
        ], -1)),
        U("div", Qd, [
          e.showStop ? (T(), N("button", {
            key: 0,
            type: "button",
            class: "reachai-composer__stop",
            onClick: h[1] || (h[1] = (d) => u.$emit("stop"))
          }, " 停止 ")) : te("", !0),
          U("button", {
            type: "submit",
            class: Oe(["reachai-composer__send", { "is-busy": e.showStop }]),
            disabled: e.disabled || !r.value.trim()
          }, Z(e.showStop ? "思考中" : "发送"), 11, Zd)
        ])
      ])
    ], 34));
  }
}), tf = /* @__PURE__ */ Ht(ef, [["__scopeId", "data-v-2a661fcc"]]), nf = ["data-surface"], sf = {
  key: 0,
  class: "reachai-conversation__header"
}, rf = {
  key: 1,
  class: "reachai-conversation__error",
  role: "alert"
}, of = {
  key: 2,
  class: "reachai-conversation__footer"
}, af = 480, lf = /* @__PURE__ */ gt({
  __name: "ConversationView",
  props: {
    snapshot: {},
    density: { default: "comfortable" },
    chrome: { default: "panel" },
    placeholder: {},
    hideComposer: { type: Boolean, default: !1 },
    autoFollow: { type: Boolean, default: !0 },
    disableSendWhileBusy: { type: Boolean, default: !0 },
    forceComposerDisabled: { type: Boolean, default: !1 },
    atmosphere: { type: Boolean, default: !0 },
    assistantLabel: { default: "" },
    showAvatars: { type: Boolean, default: !0 },
    surface: { default: "admin" },
    resolveStatusHint: {},
    resolveThinkingPresentation: {}
  },
  emits: ["send", "stop", "retry", "interaction-submit", "interaction-cancel"],
  setup(e, { emit: t }) {
    const n = e, s = t, r = /* @__PURE__ */ Ee(null), i = /* @__PURE__ */ Ee(!1);
    let o = null;
    const a = ae(() => ({})), u = ae(
      () => n.snapshot.turnStatus === "sending" || n.snapshot.turnStatus === "streaming"
    ), h = ae(() => u.value), d = ae(() => n.showAvatars && !i.value), g = ae(
      () => n.forceComposerDisabled || n.disableSendWhileBusy && (u.value || n.snapshot.turnStatus === "waiting")
    );
    function w(I) {
      s("send", I);
    }
    function R(I, y, O) {
      s("interaction-submit", I, y, O);
    }
    function P(I) {
      s("interaction-cancel", I);
    }
    function x(I) {
      I > 0 && (i.value = I <= af);
    }
    function $() {
      var y;
      const I = ((y = r.value) == null ? void 0 : y.getBoundingClientRect().width) || 0;
      x(I);
    }
    return rs(() => {
      if ($(), typeof ResizeObserver > "u") {
        window.addEventListener("resize", $);
        return;
      }
      o = new ResizeObserver((I) => {
        const y = I[0];
        y && x(y.contentRect.width);
      }), r.value && o.observe(r.value);
    }), Qi(() => {
      o == null || o.disconnect(), o = null, window.removeEventListener("resize", $);
    }), (I, y) => (T(), N("div", {
      ref_key: "conversationEl",
      ref: r,
      class: Oe(["reachai-conversation", [
        `reachai-conversation--${e.density}`,
        `reachai-conversation--${e.chrome}`,
        {
          "reachai-conversation--atmosphere": e.atmosphere,
          "reachai-conversation--narrow": i.value,
          "is-busy": u.value
        }
      ]]),
      "data-surface": e.surface,
      style: xn(a.value)
    }, [
      I.$slots.header ? (T(), N("header", sf, [
        Ot(I.$slots, "header", {}, void 0)
      ])) : te("", !0),
      Te(Jd, {
        messages: e.snapshot.messages,
        "auto-follow": e.autoFollow,
        "assistant-label": e.assistantLabel,
        "resolve-status-hint": e.resolveStatusHint,
        "resolve-thinking-presentation": e.resolveThinkingPresentation,
        "show-avatars": d.value,
        surface: e.surface,
        onInteractionSubmit: R,
        onInteractionCancel: P,
        onRetry: y[0] || (y[0] = (O) => I.$emit("retry"))
      }, eo({ _: 2 }, [
        I.$slots.empty ? {
          name: "empty",
          fn: jn(() => [
            Ot(I.$slots, "empty", {}, void 0, !0)
          ]),
          key: "0"
        } : void 0,
        I.$slots["message-meta"] ? {
          name: "message-meta",
          fn: jn((O) => [
            Ot(I.$slots, "message-meta", la(So(O)), void 0, !0)
          ]),
          key: "1"
        } : void 0
      ]), 1032, ["messages", "auto-follow", "assistant-label", "resolve-status-hint", "resolve-thinking-presentation", "show-avatars", "surface"]),
      e.snapshot.error ? (T(), N("div", rf, [
        U("span", null, Z(e.snapshot.error), 1),
        U("button", {
          type: "button",
          onClick: y[1] || (y[1] = (O) => I.$emit("retry"))
        }, "重试")
      ])) : te("", !0),
      Ot(I.$slots, "composer", {}, () => [
        e.hideComposer ? te("", !0) : (T(), mt(tf, {
          key: 0,
          disabled: g.value,
          "show-stop": h.value,
          placeholder: e.placeholder,
          onSend: w,
          onStop: y[2] || (y[2] = (O) => I.$emit("stop"))
        }, null, 8, ["disabled", "show-stop", "placeholder"]))
      ]),
      I.$slots.footer ? (T(), N("footer", of, [
        Ot(I.$slots, "footer", {}, void 0)
      ])) : te("", !0)
    ], 14, nf));
  }
}), cf = /* @__PURE__ */ Ht(lf, [["__scopeId", "data-v-9f74d6d6"]]), uf = "1.0.0-SNAPSHOT";
function Ss(e, t) {
  return {
    pageKey: t == null ? void 0 : t.pageKey,
    pageInstanceId: e.pageInstanceId,
    route: e.route || (typeof location < "u" ? location.pathname : "/"),
    bridgeActions: e.registeredActions,
    sdkVersion: uf
  };
}
const df = { class: "eaf-chat-host" }, ff = ["role"], hf = /* @__PURE__ */ gt({
  __name: "EmbedChatHost",
  props: {
    apiBase: {},
    tokenProvider: {},
    tokenTimeoutMs: { default: 1e4 },
    bridge: {},
    page: {},
    context: { default: () => ({}) },
    placeholder: { default: "输入消息" },
    locale: { default: "zh-CN" },
    preferStream: { type: Boolean, default: !0 },
    onEvent: {},
    onError: {},
    onAuthStateChange: {},
    onTokenChanged: {},
    onSessionChanged: {},
    onUnauthorized: {}
  },
  setup(e, { expose: t }) {
    const n = e, s = /* @__PURE__ */ Ee(ar()), r = /* @__PURE__ */ Ee({
      phase: "token",
      status: "loading",
      reason: "initial",
      attempt: 0,
      message: n.locale === "en-US" ? "Connecting to ReachAI…" : "正在连接 ReachAI…"
    });
    let i = "", o = { ...n.context }, a = n.bridge, u = n.page, h = "", d = 0, g = !1, w = 0, R = null, P = null, x = "", $ = null;
    function I(c) {
      var f;
      r.value = c, (f = n.onAuthStateChange) == null || f.call(n, c);
    }
    function y(c) {
      const f = typeof c == "string" ? c : c == null ? void 0 : c.token, m = typeof c == "object" && c ? Number(c.expiresAt || 0) : 0, b = typeof c == "object" && c ? Number(c.expiresIn || 0) : 0;
      return {
        token: String(f || "").trim(),
        expiresAt: m > 0 ? m : b > 0 ? Date.now() + b * 1e3 : 0
      };
    }
    function O(c) {
      if (!c || typeof c != "object") return;
      const f = c.httpStatus ?? c.status, m = Number(f);
      return Number.isFinite(m) && m > 0 ? m : void 0;
    }
    function E(c, f, m, b) {
      const p = new Error(f);
      return p.name = "EafChatTokenError", p.code = c, p.phase = "token", p.retryable = b !== 403, p.httpStatus = b, p.cause = m, p;
    }
    function q(c) {
      if (c && typeof c == "object" && c.code)
        return c;
      const f = O(c);
      return f === 401 ? E(
        "TOKEN_PROVIDER_UNAUTHORIZED",
        n.locale === "en-US" ? "Authentication expired. Sign in again and retry." : "身份认证已失效，请重新登录后重试",
        c,
        f
      ) : f != null && f >= 500 ? E(
        "TOKEN_PROVIDER_UNAVAILABLE",
        n.locale === "en-US" ? "ReachAI is temporarily unavailable. Retry later." : "ReachAI 暂时不可用，请稍后重试",
        c,
        f
      ) : c instanceof TypeError ? E(
        "TOKEN_PROVIDER_NETWORK_ERROR",
        n.locale === "en-US" ? "Network connection failed. Check your network and retry." : "网络连接失败，请检查网络后重试",
        c,
        f
      ) : E(
        "TOKEN_PROVIDER_FAILED",
        n.locale === "en-US" ? "Unable to connect to ReachAI. Retry later." : "暂时无法连接 ReachAI，请稍后重试",
        c,
        f
      );
    }
    function S(c) {
      return {
        message: c.message,
        code: c.code,
        phase: c.phase,
        httpStatus: c.httpStatus,
        retryable: c.retryable
      };
    }
    async function M(c, f = !1) {
      if (g) throw new DOMException("The operation was aborted.", "AbortError");
      const m = d > 0 && Date.now() + 3e4 >= d;
      if (h && !f && !m) return h;
      if (R) return R;
      const b = m && c === "send" ? "expiring" : c, p = ++w, v = new AbortController();
      P = v, I({
        phase: "token",
        status: "loading",
        reason: b,
        attempt: p,
        message: n.locale === "en-US" ? "Connecting to ReachAI…" : "正在连接 ReachAI…"
      });
      let _;
      const C = Number.isFinite(n.tokenTimeoutMs) && n.tokenTimeoutMs > 0 ? n.tokenTimeoutMs : 1e4, A = Ss(a, u), B = {
        reason: b,
        signal: v.signal,
        attempt: p,
        sessionId: i || void 0,
        pageKey: A.pageKey,
        pageInstanceId: A.pageInstanceId,
        route: A.route,
        origin: (u == null ? void 0 : u.origin) || (typeof location < "u" ? location.origin : "")
      }, F = Promise.resolve().then(async () => {
        if (c === "unauthorized" && n.onUnauthorized) {
          const z = await n.onUnauthorized();
          if (z) return z;
        }
        return n.tokenProvider(B);
      }), W = new Promise((z, X) => {
        _ = setTimeout(() => {
          v.abort(), X(E(
            "TOKEN_PROVIDER_TIMEOUT",
            n.locale === "en-US" ? "Connection timed out. Retry." : "连接超时，请重试"
          ));
        }, C);
      });
      return R = Promise.race([F, W]).then((z) => {
        var oe;
        if (g) throw new DOMException("The operation was aborted.", "AbortError");
        const X = y(z);
        if (!X.token)
          throw E(
            "TOKEN_PROVIDER_EMPTY",
            n.locale === "en-US" ? "Authentication token is unavailable. Retry." : "登录凭证不可用，请重试"
          );
        return h = X.token, d = X.expiresAt, (oe = n.onTokenChanged) == null || oe.call(n, X.token), I({
          phase: "token",
          status: "ready",
          reason: b,
          attempt: p
        }), X.token;
      }).catch((z) => {
        var oe;
        if (z instanceof DOMException && z.name === "AbortError" && g) throw z;
        const X = q(z);
        throw h = "", d = 0, (oe = n.onTokenChanged) == null || oe.call(n, ""), I({
          phase: "token",
          status: "error",
          reason: b,
          attempt: p,
          message: X.message,
          error: S(X)
        }), X;
      }).finally(() => {
        _ !== void 0 && clearTimeout(_), P === v && (P = null), R = null;
      }), R;
    }
    async function j(c = "unauthorized") {
      var f;
      return h = "", d = 0, (f = n.onTokenChanged) == null || f.call(n, ""), M(c, !0);
    }
    function K() {
      return j("retry");
    }
    function H(c) {
      var b;
      const f = String(c || ""), m = f !== i;
      i = f, m && f && ((b = n.onSessionChanged) == null || b.call(n, f));
    }
    const se = Xc({
      apiBase: n.apiBase,
      tokenProvider: () => h,
      getSessionId: () => i || void 0,
      setSessionId: H,
      getContext: () => o,
      createSessionPayload: () => ({
        ...Ss(a, u)
      }),
      preferStream: n.preferStream,
      onUnauthorized: () => j("unauthorized")
    }), re = se, ee = Hc({
      transport: se,
      onPublicEvent: we,
      onChange(c) {
        s.value = c, c.sessionId && H(c.sessionId), G(c);
      }
    });
    M("initial").catch((c) => {
      g || L(c);
    });
    function we(c) {
      var b, p, v, _, C, A, B, F;
      const f = c.data, m = {
        sessionId: c.sessionId || i || void 0,
        turnId: c.turnId
      };
      switch (c.type) {
        case "message.delta":
          (b = n.onEvent) == null || b.call(n, { type: "message.delta", data: f, ...m });
          return;
        case "ui.requested":
          (p = n.onEvent) == null || p.call(n, { type: "ui.requested", data: f, ...m });
          return;
        case "page.action.requested":
          (v = n.onEvent) == null || v.call(n, { type: "page.action.requested", data: f, ...m });
          return;
        case "turn.progress":
          (_ = n.onEvent) == null || _.call(n, { type: "turn.progress", data: f, ...m });
          return;
        case "turn.completed":
        case "turn.waiting":
          (C = n.onEvent) == null || C.call(n, {
            type: "message.completed",
            data: de(c),
            ...m
          });
          return;
        case "turn.failed":
          (A = n.onEvent) == null || A.call(n, { type: "error", data: f, ...m });
          return;
        case "interaction.submitted":
          (B = n.onEvent) == null || B.call(n, { type: "interaction.submitted", data: f, ...m });
          return;
        case "interaction.cancelled":
          (F = n.onEvent) == null || F.call(n, { type: "interaction.cancelled", data: f, ...m });
          return;
        default:
          return;
      }
    }
    function de(c) {
      const f = c.data && typeof c.data == "object" ? c.data : {}, m = Do(f) || (f.metadata && typeof f.metadata == "object" && !Array.isArray(f.metadata) ? { ...f.metadata } : void 0);
      return {
        answer: f.answer != null ? String(f.answer) : void 0,
        sessionId: c.sessionId || (f.sessionId != null ? String(f.sessionId) : i) || void 0,
        uiRequest: f.uiRequest,
        metadata: m,
        intentType: f.intentType,
        toolCalls: f.toolCalls,
        turnId: c.turnId
      };
    }
    function G(c) {
      if (!$) return;
      const f = c.turnStatus;
      if (f === "sending" || f === "streaming") {
        $.armed = !0;
        return;
      }
      if (!$.armed || f !== "completed" && f !== "waiting" && f !== "failed" && f !== "cancelled")
        return;
      const m = $;
      if ($ = null, f === "failed") {
        m.reject(new Error(c.error || "Message failed"));
        return;
      }
      if (f === "cancelled") {
        m.reject(new DOMException("The operation was aborted.", "AbortError"));
        return;
      }
      m.resolve(V(c));
    }
    function V(c) {
      var _, C;
      let f = "", m, b, p, v;
      for (let A = c.messages.length - 1; A >= 0; A -= 1) {
        const B = c.messages[A];
        if (B.role === "assistant") {
          f = xc(B);
          for (const F of B.blocks)
            F.type === "interaction" && (F.state === "waiting" || F.state === "submitting") && (m = F.request);
          b = B.metadata ? { ...B.metadata } : void 0, b && "metadata" in b && typeof b.metadata == "object" && (b = { ...b.metadata }), p = (_ = B.completion) == null ? void 0 : _.intentType, v = (C = B.completion) == null ? void 0 : C.toolCalls;
          break;
        }
      }
      return b && (delete b.result, delete b.answer, delete b.uiRequest, delete b.sessionId, delete b.intentType, delete b.toolCalls), {
        answer: f,
        sessionId: c.sessionId || i || void 0,
        uiRequest: m,
        metadata: b && Object.keys(b).length ? b : void 0,
        intentType: p,
        toolCalls: v,
        turnId: c.turnId
      };
    }
    async function Q(c) {
      if (g)
        throw new DOMException("The operation was aborted.", "AbortError");
      const f = c.trim();
      if (!f) return {};
      if ($)
        throw new Error("Another message is still in flight");
      return x = f, await M("send"), new Promise((m, b) => {
        $ = { resolve: m, reject: b, armed: !1 }, ee.send(f).catch((p) => {
          $ && ($ = null, b(p));
        });
      });
    }
    function Ie(c) {
      o = { ...o, ...c };
    }
    function Xe() {
      return i || null;
    }
    function Ae() {
      return i || null;
    }
    async function fe() {
      if (g) throw new DOMException("The operation was aborted.", "AbortError");
      if (await M("send"), i) return i;
      if (typeof re.ensureSession == "function")
        return re.ensureSession();
      throw new Error("Embed transport cannot ensure session");
    }
    async function De(c, f, m) {
      if (g) throw new DOMException("The operation was aborted.", "AbortError");
      if (!i) throw new Error("An active Embed chat session is required before page rebinding");
      if (!m) throw new Error("A platform navigation request id is required before page rebinding");
      const b = a, p = u;
      a = c, u = f;
      try {
        const v = await j("page-navigation"), _ = await fetch(
          `${n.apiBase}/chat/sessions/${encodeURIComponent(i)}/page-bridge/rebind`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${v}`
            },
            body: JSON.stringify({
              ...Ss(a, u),
              navigationRequestId: m
            })
          }
        ), C = await _.json().catch(() => ({}));
        if (!_.ok || C.code && C.code !== 200 && C.code !== 0) {
          const A = E(
            "PAGE_NAVIGATION_REBIND_FAILED",
            C.message || `Page navigation rebind failed: ${_.status}`,
            void 0,
            _.status
          );
          throw A.phase = "page-action", A;
        }
      } catch (v) {
        throw a = b, u = p, v;
      }
    }
    function yt(c) {
      var b;
      if (c.role !== "assistant" || c.status !== "pending" && c.status !== "streaming") return;
      const f = (b = c.metadata) == null ? void 0 : b.publicProgress;
      if (f && typeof f == "object" && !Array.isArray(f)) {
        const p = f.message;
        if (typeof p == "string" && p.trim())
          return p.trim().slice(0, 120);
      }
      return c.blocks.some((p) => p.type === "text" && p.text) ? "正在生成回答" : "正在处理";
    }
    function Re(c) {
      Q(c).catch(L);
    }
    function Le() {
      K().catch(L);
    }
    function k() {
      if (r.value.status === "error") {
        Le();
        return;
      }
      !x || $ || Q(x).catch(L);
    }
    function D() {
      ee.cancel().then(() => {
        if ($) {
          const c = $;
          $ = null, c.reject(new DOMException("The operation was aborted.", "AbortError"));
        }
      });
    }
    function Y(c, f, m) {
      ee.submitInteraction(c, f, m).catch(L);
    }
    function ie(c) {
      ee.submitInteraction(c, "cancel", {}).catch(L);
    }
    function L(c) {
      var b;
      const f = c && typeof c == "object" ? c : void 0, m = {
        message: (f == null ? void 0 : f.message) || (c instanceof Error ? c.message : String(c)),
        cause: (f == null ? void 0 : f.cause) ?? c,
        code: f == null ? void 0 : f.code,
        phase: f == null ? void 0 : f.phase,
        httpStatus: (f == null ? void 0 : f.httpStatus) ?? O(c),
        retryable: f == null ? void 0 : f.retryable
      };
      try {
        (b = n.onError) == null || b.call(n, m);
      } catch {
      }
    }
    function l() {
      if (g = !0, P == null || P.abort(), P = null, $) {
        const c = $;
        $ = null, c.reject(new DOMException("The operation was aborted.", "AbortError"));
      }
      ee.dispose();
    }
    return nr(() => {
      l();
    }), t({
      sendMessage: Q,
      retryAuthentication: K,
      refreshToken: j,
      setContext: Ie,
      getSessionId: Xe,
      getExistingSessionId: Ae,
      ensureHostSession: fe,
      rebindPage: De,
      disposeHost: l
    }), (c, f) => (T(), N("div", df, [
      r.value.status !== "ready" ? (T(), N("div", {
        key: 0,
        class: Oe(["eaf-chat-auth", `is-${r.value.status}`]),
        role: r.value.status === "error" ? "alert" : "status",
        "aria-live": "polite"
      }, [
        U("span", null, Z(r.value.message), 1),
        r.value.status === "error" ? (T(), N("button", {
          key: 0,
          type: "button",
          onClick: Le
        }, Z(e.locale === "en-US" ? "Retry" : "重试"), 1)) : te("", !0)
      ], 10, ff)) : te("", !0),
      Te(Qs(cf), {
        class: "eaf-chat__conversation",
        chrome: "inline",
        density: "compact",
        surface: "embed",
        atmosphere: "",
        snapshot: s.value,
        placeholder: e.placeholder,
        "force-composer-disabled": r.value.status !== "ready",
        "resolve-status-hint": yt,
        onSend: Re,
        onStop: D,
        onRetry: k,
        onInteractionSubmit: Y,
        onInteractionCancel: ie
      }, null, 8, ["snapshot", "placeholder", "force-composer-disabled"])
    ]));
  }
}), qo = /* @__PURE__ */ Ht(hf, [["__scopeId", "data-v-919beec7"]]);
function qs(e) {
  var s;
  const t = (s = e.metadata) == null ? void 0 : s.pageActionQueue;
  if (!Array.isArray(t)) return [];
  const n = hr(e.metadata);
  return t.map((r) => jo(r, n)).filter((r) => !!r);
}
function jo(e, t) {
  if (!e || typeof e != "object") return null;
  const n = e;
  if (n.type !== "page.action.requested" || typeof n.requestId != "string" || typeof n.actionKey != "string") return null;
  const s = n.metadata && typeof n.metadata == "object" ? { ...n.metadata } : {}, r = typeof n.pageKey == "string" ? n.pageKey : t;
  return r && !s.pageKey && (s.pageKey = r), {
    type: "page.action.requested",
    protocolVersion: typeof n.protocolVersion == "string" ? n.protocolVersion : void 0,
    requestId: n.requestId,
    actionKey: n.actionKey,
    title: typeof n.title == "string" ? n.title : void 0,
    args: n.args && typeof n.args == "object" ? n.args : void 0,
    target: n.target && typeof n.target == "object" ? n.target : void 0,
    confirm: n.confirm === !0,
    metadata: s
  };
}
async function Wn(e) {
  var i;
  const t = jo(e.request, hr(e.responseMetadata));
  if (!(t != null && t.requestId)) return;
  const n = t.requestId;
  if (e.handledPageActions.has(n) && !((i = e.pendingPageActionResults) != null && i.has(n))) return;
  const s = e.inFlightPageActions.get(n);
  if (s) {
    await s;
    return;
  }
  const r = (async () => {
    var a, u, h, d, g, w, R, P, x;
    const o = (a = e.pendingPageActionResults) == null ? void 0 : a.get(n);
    if (e.handledPageActions.has(n)) {
      if (!o) return;
      await ui(e, o), (u = e.pendingPageActionResults) == null || u.delete(n);
      return;
    }
    e.handledPageActions.add(n), (h = e.onRequested) == null || h.call(e, t);
    try {
      let $ = !1, I = !1, y = !1;
      const O = async () => (I || (I = !0, y = await pf(e, t), $ = !y), y), E = await gf(
        t,
        e.bridge,
        e.responseMetadata,
        /* @__PURE__ */ new Set(),
        // 已认领，内部不再二次 gated
        O
      );
      if (!E) return;
      if ($) {
        (d = e.onError) == null || d.call(e, new Error(`Page action request expired before execution: ${t.actionKey}`));
        return;
      }
      Ko(E.status) && ((g = e.onError) == null || g.call(e, new Error(E.error || `Page action ${E.status}: ${t.actionKey}`))), (w = e.pendingPageActionResults) == null || w.set(n, E);
      try {
        await ui(e, E);
      } catch (q) {
        throw js(q, 409) && ((R = e.pendingPageActionResults) == null || R.delete(n)), q;
      }
      (P = e.pendingPageActionResults) == null || P.delete(n);
    } catch ($) {
      (x = e.onError) == null || x.call(e, $);
    }
  })();
  e.inFlightPageActions.set(n, r);
  try {
    await r;
  } finally {
    e.inFlightPageActions.delete(n);
  }
}
async function pf(e, t) {
  let n = e.token;
  try {
    return await fi(
      e.apiBase,
      e.sessionId,
      n,
      t,
      e.fetchImpl
    );
  } catch (s) {
    if (js(s, 409)) return !1;
    if (!pr(s) || !e.refreshToken) throw s;
    n = await e.refreshToken();
    try {
      return await fi(
        e.apiBase,
        e.sessionId,
        n,
        t,
        e.fetchImpl
      );
    } catch (r) {
      if (js(r, 409)) return !1;
      throw r;
    }
  }
}
async function ui(e, t) {
  let n = e.token;
  try {
    await di(
      e.apiBase,
      e.sessionId,
      n,
      t,
      e.fetchImpl
    );
  } catch (s) {
    if (!pr(s) || !e.refreshToken) throw s;
    n = await e.refreshToken(), await di(
      e.apiBase,
      e.sessionId,
      n,
      t,
      e.fetchImpl
    );
  }
}
async function gf(e, t, n, s, r) {
  const i = await t.handleEvent(e, { beforeExecute: r });
  if (i && i.status !== "ACTION_NOT_FOUND")
    return s.add(e.requestId), i;
  if (r && !await r(e))
    return {
      protocolVersion: e.protocolVersion || "1.0",
      type: "page.action.result",
      requestId: e.requestId,
      actionKey: e.actionKey,
      status: "TIMEOUT",
      error: "Page action request expired before execution"
    };
  const o = await yf(e, n);
  return o ? (o.status !== "ACTION_NOT_FOUND" && s.add(e.requestId), o) : (i && s.add(e.requestId), i);
}
async function mf(e) {
  const t = qs(e.response);
  for (const n of t)
    await Wn({
      request: n,
      bridge: e.bridge,
      sessionId: e.sessionId,
      apiBase: e.apiBase,
      token: e.token,
      handledPageActions: e.handledPageActions,
      inFlightPageActions: e.inFlightPageActions,
      pendingPageActionResults: e.pendingPageActionResults,
      responseMetadata: e.response.metadata,
      onRequested: e.onRequested,
      onError: e.onError,
      refreshToken: e.refreshToken,
      fetchImpl: e.fetchImpl
    });
}
async function yf(e, t) {
  const n = typeof window < "u" ? window.__REACHAI_PAGE_BRIDGE__ : void 0;
  if (!n || typeof n.execute != "function") return null;
  const s = _f(e) || hr(t);
  if (!s)
    return {
      protocolVersion: e.protocolVersion || "1.0",
      type: "page.action.result",
      requestId: e.requestId,
      actionKey: e.actionKey,
      status: "ACTION_NOT_FOUND",
      error: "Page action pageKey is missing for window.__REACHAI_PAGE_BRIDGE__ fallback"
    };
  try {
    const r = await n.execute(s, e.actionKey, e.args || {}, {
      confirmed: !0,
      requestId: e.requestId
    }), i = r && typeof r == "object" ? r : { data: r }, o = String(i.status || "SUCCESS").trim().toUpperCase(), a = bf(o), u = i.error && typeof i.error == "object" ? String(i.error.message || i.message || "") : String(i.message || "");
    return {
      protocolVersion: e.protocolVersion || "1.0",
      type: "page.action.result",
      requestId: e.requestId,
      actionKey: e.actionKey,
      status: a,
      data: i.data ?? r,
      message: typeof i.message == "string" && i.message.trim() ? i.message.trim() : void 0,
      error: Ko(a) ? u || `Page action returned ${o}` : void 0
    };
  } catch (r) {
    return {
      protocolVersion: e.protocolVersion || "1.0",
      type: "page.action.result",
      requestId: e.requestId,
      actionKey: e.actionKey,
      status: "FAILED",
      error: r instanceof Error ? r.message : String(r)
    };
  }
}
function Ko(e) {
  return e === "FAILED" || e === "TIMEOUT" || e === "ACTION_NOT_FOUND" || e === "FORBIDDEN";
}
function bf(e) {
  switch (e) {
    case "SUCCESS":
    case "NO_DATA":
    case "PRECONDITION_FAILED":
    case "USER_CANCELLED":
    case "FAILED":
    case "CANCELLED":
    case "ACTION_NOT_FOUND":
    case "FORBIDDEN":
    case "TIMEOUT":
      return e;
    // Legacy page bridge templates expose WARN / ERROR. Preserve their business
    // meaning on the public Embed boundary instead of treating a warning as a
    // transport failure.
    case "WARN":
      return "PRECONDITION_FAILED";
    case "ERROR":
      return "FAILED";
    default:
      return "FAILED";
  }
}
function _f(e) {
  var n;
  const t = (n = e.metadata) == null ? void 0 : n.pageKey;
  return typeof t == "string" && t.trim() ? t.trim() : void 0;
}
function hr(e) {
  const t = e == null ? void 0 : e.pageKey;
  return typeof t == "string" && t.trim() ? t.trim() : void 0;
}
async function di(e, t, n, s, r = fetch) {
  await Uo(
    `${e}/chat/sessions/${encodeURIComponent(t)}/page-actions/${encodeURIComponent(s.requestId)}/result`,
    s,
    n,
    r
  );
}
async function fi(e, t, n, s, r = fetch) {
  return (await Uo(
    `${e}/chat/sessions/${encodeURIComponent(t)}/page-actions/${encodeURIComponent(s.requestId)}/claim`,
    { requestId: s.requestId, actionKey: s.actionKey },
    n,
    r
  )).claimed === !0;
}
async function vf(e) {
  var u;
  const t = e.fetchImpl || fetch, n = e.inFlightPageActions || /* @__PURE__ */ new Map(), s = `${e.apiBase}/chat/sessions/${encodeURIComponent(e.sessionId)}/page-actions/pending?limit=10`;
  let r = e.token;
  const i = e.refreshToken ? async () => (r = await e.refreshToken(), r) : void 0;
  let o;
  try {
    o = await hi(s, r, t);
  } catch (h) {
    if (!pr(h) || !i) throw h;
    await i(), o = await hi(s, r, t);
  }
  const a = /* @__PURE__ */ new Set();
  for (const h of o)
    h != null && h.requestId && (a.add(h.requestId), await Wn({
      request: h,
      bridge: e.bridge,
      sessionId: e.sessionId,
      apiBase: e.apiBase,
      token: r,
      handledPageActions: e.handledPageActions,
      inFlightPageActions: n,
      pendingPageActionResults: e.pendingPageActionResults,
      responseMetadata: e.context,
      onRequested: (d) => {
        var g;
        return (g = e.onEvent) == null ? void 0 : g.call(e, { type: "page.action.requested", data: d });
      },
      onError: e.onError,
      refreshToken: i,
      fetchImpl: t
    }));
  for (const [h, d] of [
    ...((u = e.pendingPageActionResults) == null ? void 0 : u.entries()) || []
  ])
    a.has(h) || (e.handledPageActions.add(h), await Wn({
      request: {
        type: "page.action.requested",
        requestId: h,
        actionKey: d.actionKey
      },
      bridge: e.bridge,
      sessionId: e.sessionId,
      apiBase: e.apiBase,
      token: r,
      handledPageActions: e.handledPageActions,
      inFlightPageActions: n,
      pendingPageActionResults: e.pendingPageActionResults,
      responseMetadata: e.context,
      onError: e.onError,
      refreshToken: i,
      fetchImpl: t
    }));
}
async function Uo(e, t, n, s) {
  const r = await s(e, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${n}`
    },
    body: JSON.stringify(t)
  }), i = await r.json().catch(() => ({}));
  if (!r.ok || i.code && i.code !== 200 && i.code !== 0)
    throw Bo(i.message || `Request failed: ${r.status}`, r.status);
  return i.data ?? i;
}
async function hi(e, t, n) {
  const s = await n(e, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${t}`
    }
  }), r = await s.json().catch(() => ({}));
  if (!s.ok || r.code && r.code !== 200 && r.code !== 0)
    throw Bo(r.message || `Request failed: ${s.status}`, s.status);
  return r.data ?? r;
}
function Bo(e, t) {
  const n = new Error(e);
  return n.status = t, n;
}
function pr(e) {
  return !!(e && typeof e == "object" && e.status === 401);
}
function js(e, t) {
  return !!(e && typeof e == "object" && e.status === t);
}
const Wt = {
  activeWindowMs: 5e3,
  activeIntervalMs: 1e3,
  idleIntervalMs: 1e4,
  /** Kept for timing compatibility; visible active sessions continue low-frequency polling. */
  recoveryWindowMs: 2e4,
  /** 第 1..n 次连续失败后的等待间隔（ms），封顶取最后一项 */
  backoffMs: [5e3, 1e4, 2e4, 4e4, 6e4]
};
function wf(e) {
  var H, se, re, ee, we, de;
  const t = {
    activeWindowMs: ((H = e.timings) == null ? void 0 : H.activeWindowMs) ?? Wt.activeWindowMs,
    activeIntervalMs: ((se = e.timings) == null ? void 0 : se.activeIntervalMs) ?? Wt.activeIntervalMs,
    idleIntervalMs: ((re = e.timings) == null ? void 0 : re.idleIntervalMs) ?? Wt.idleIntervalMs,
    recoveryWindowMs: Math.max(
      ((ee = e.timings) == null ? void 0 : ee.recoveryWindowMs) ?? Wt.recoveryWindowMs,
      ((we = e.timings) == null ? void 0 : we.activeWindowMs) ?? Wt.activeWindowMs
    ),
    backoffMs: ((de = e.timings) == null ? void 0 : de.backoffMs) ?? Wt.backoffMs
  }, n = e.now || (() => Date.now()), s = e.setTimeoutFn || ((G, V) => window.setTimeout(G, V)), r = e.clearTimeoutFn || ((G) => window.clearTimeout(G)), i = e.isDocumentHidden || (() => typeof document > "u" ? !1 : document.visibilityState === "hidden");
  let o = !1, a, u = !1, h = !1, d = !1, g = 0, w = 0, R = 0, P = 0, x;
  function $() {
    return !(o || e.isDestroyed() || !e.getSessionId() || !e.hasRegisteredActions() || i());
  }
  function I() {
    a !== void 0 && (r(a), a = void 0);
  }
  function y() {
    if (R <= 0) return 0;
    const G = Math.min(R - 1, t.backoffMs.length - 1);
    return t.backoffMs[G];
  }
  function O(G) {
    if (P > G)
      return P - G;
    if (d) {
      if (w > 0) {
        const V = G - w;
        if (V < t.activeIntervalMs)
          return t.activeIntervalMs - V;
      }
      return 0;
    }
    if (G < g) {
      if (w > 0) {
        const V = G - w;
        if (V < t.activeIntervalMs)
          return t.activeIntervalMs - V;
      }
      return 0;
    }
    if (w > 0) {
      const V = G - w;
      if (V < t.idleIntervalMs)
        return t.idleIntervalMs - V;
    }
    return t.idleIntervalMs;
  }
  function E() {
    if (I(), o || e.isDestroyed() || !$()) return;
    if (u) {
      h = !0;
      return;
    }
    const G = n(), V = O(G);
    V !== null && (a = s(() => {
      a = void 0, q();
    }, Math.max(0, V)));
  }
  async function q() {
    var G;
    if (!(o || e.isDestroyed()) && $()) {
      if (u) {
        h = !0;
        return;
      }
      u = !0, d = !1, w = n();
      try {
        await e.poll(), R = 0, P = 0;
      } catch (V) {
        R += 1;
        const Q = y();
        P = n() + Q, (G = e.onError) == null || G.call(e, V);
      } finally {
        u = !1, h && (h = !1, d = !0), E();
      }
    }
  }
  function S() {
    if (o || e.isDestroyed()) return;
    const G = n();
    if (g = Math.max(g, G + t.activeWindowMs), d = !0, u) {
      h = !0;
      return;
    }
    E();
  }
  function M(G, V) {
    if (!(o || e.isDestroyed())) {
      if (G <= 0 && V > 0) {
        e.getSessionId() && S();
        return;
      }
      G > 0 && V <= 0 && (I(), d = !1, h = !1);
    }
  }
  function j() {
    if (!(o || e.isDestroyed())) {
      if (i()) {
        I();
        return;
      }
      S();
    }
  }
  return x = (e.addVisibilityListener || ((G) => typeof document > "u" ? () => {
  } : (document.addEventListener("visibilitychange", G), () => document.removeEventListener("visibilitychange", G))))(j), {
    notifyActivity: S,
    notifyActionsChanged: M,
    destroy() {
      o = !0, I(), d = !1, h = !1, x == null || x(), x = void 0;
    },
    isInFlight() {
      return u;
    }
  };
}
const Sf = 380, If = 560, Af = 320, Ef = 360, je = 12, pi = 18;
let xf = 0;
function Cf(e) {
  const t = e.position || "inline", n = t !== "inline", s = e.resizable !== !1, r = n && e.launcherDraggable !== !1, i = e.locale === "en-US", o = `reachai-chat-panel-${++xf}`, a = document.createElement("div");
  a.className = "eaf-chat", a.dataset.launcherState = "thinking", a.dataset.position = t, n && a.classList.add(`eaf-chat--${t}`), s || a.classList.add("eaf-chat--resize-disabled");
  const u = i ? `Open ${e.brandName}` : `打开${e.brandName}`, h = i ? `Minimize ${e.brandName}` : `最小化${e.brandName}`, d = i ? "Resize conversation" : "调整对话框大小";
  a.innerHTML = `
    <section id="${o}" class="eaf-chat__panel" aria-label="${$t(e.brandName)}">
      <div class="eaf-chat__header">
        <div class="eaf-chat__brand">${$t(e.brandName)}</div>
        <div class="eaf-chat__header-actions">
          <span class="eaf-chat__connection-status" role="status" aria-live="polite">${i ? "Connecting" : "正在连接"}</span>
          <button
            class="eaf-chat__toggle eaf-chat__minimize"
            type="button"
            aria-label="${$t(h)}"
            title="${$t(h)}"
            aria-controls="${o}"
            aria-expanded="true"
          ><span aria-hidden="true"></span></button>
        </div>
      </div>
      <div class="eaf-chat__body"></div>
      <button
        class="eaf-chat__resize-handle"
        type="button"
        aria-label="${$t(d)}"
        title="${$t(d)}"
      ><span aria-hidden="true"></span></button>
    </section>
    <div class="eaf-chat__launcher-wrap">
      <span class="eaf-chat__launcher-label">${$t(e.brandName)}</span>
      <button
        class="eaf-chat__launcher"
        type="button"
        aria-label="${$t(u)}"
        aria-controls="${o}"
        aria-expanded="false"
      >
        <span class="eaf-chat__launcher-orbit eaf-chat__launcher-orbit--back" aria-hidden="true"></span>
        <span class="eaf-chat__launcher-prism" aria-hidden="true"></span>
        <span class="eaf-chat__launcher-glass" aria-hidden="true"></span>
        <span class="eaf-chat__launcher-orbit" aria-hidden="true"></span>
        <span class="eaf-chat__launcher-particle" aria-hidden="true"></span>
        <span class="eaf-chat__launcher-badge" aria-hidden="true">1</span>
        <span class="eaf-chat__launcher-error" aria-hidden="true">!</span>
      </button>
    </div>
  `, e.mount.appendChild(a);
  const g = _t(a, ".eaf-chat__panel"), w = _t(a, ".eaf-chat__header"), R = _t(a, ".eaf-chat__body"), P = _t(a, ".eaf-chat__connection-status"), x = _t(a, ".eaf-chat__minimize"), $ = _t(a, ".eaf-chat__resize-handle"), I = _t(a, ".eaf-chat__launcher-wrap"), y = _t(a, ".eaf-chat__launcher"), O = _t(a, ".eaf-chat__launcher-label");
  let E = t === "bottom-left" ? "north-east" : t === "bottom-right" ? "north-west" : "south-east";
  $.dataset.resizeAnchor = E, $.hidden = !s, y.classList.toggle("eaf-chat__launcher--draggable", r), a.classList.toggle("eaf-chat--panel-draggable", n);
  let q = e.initialOpen !== !1, S = !1, M = "thinking", j = null, K = null, H = null, se = !1, re = "", ee = "";
  function we() {
    a.classList.toggle("eaf-chat--closed", !q), a.dataset.open = q ? "true" : "false", g.hidden = !q, g.setAttribute("aria-hidden", q ? "false" : "true"), I.hidden = q, y.setAttribute("aria-expanded", q ? "true" : "false"), x.setAttribute("aria-expanded", q ? "true" : "false");
  }
  function de(p, v = !0) {
    var _;
    S || q === p || (q = p, we(), q && v && ((_ = e.onOpen) == null || _.call(e)));
  }
  function G(p) {
    M = p, a.dataset.launcherState = p;
    const v = p === "thinking" ? i ? "connecting" : "正在连接" : p === "unread" ? i ? "new message" : "有新消息" : p === "error" ? i ? "connection error" : "连接异常" : "", _ = v ? i ? `${u} (${v})` : `${u}（${v}）` : u;
    y.setAttribute("aria-label", _), y.title = _, O.textContent = p === "error" ? i ? `${e.brandName} · Connection error` : `${e.brandName} · 连接异常` : p === "unread" ? i ? `${e.brandName} · New message` : `${e.brandName} · 有新消息` : e.brandName;
  }
  function V() {
    const p = g.getBoundingClientRect(), v = p.width || gi(a, "--reachai-chat-user-width") || Sf, _ = p.height || gi(a, "--reachai-chat-user-height") || If;
    return { width: v, height: _ };
  }
  function Q() {
    return n && Number.isFinite(Number.parseFloat(g.style.left)) && Number.isFinite(Number.parseFloat(g.style.top));
  }
  function Ie(p, v) {
    if (!n) return;
    const _ = g.getBoundingClientRect(), C = V(), A = _.width || C.width, B = _.height || C.height, F = Math.max(je, window.innerWidth - A - je), W = Math.max(je, window.innerHeight - B - je), z = zt(p, je, F), X = zt(v, je, W);
    g.style.right = "auto", g.style.bottom = "auto", g.style.left = `${Math.round(z)}px`, g.style.top = `${Math.round(X)}px`, a.classList.add("eaf-chat--user-positioned");
  }
  function Xe() {
    const p = e.mount.getBoundingClientRect(), v = n ? window.innerWidth - je * 2 : p.width || window.innerWidth, _ = n ? window.innerHeight - je * 2 : p.height || window.innerHeight, C = Math.max(240, v), A = Math.max(260, _);
    return {
      minWidth: Math.min(Af, C),
      minHeight: Math.min(Ef, A),
      maxWidth: C,
      maxHeight: A
    };
  }
  function Ae(p, v) {
    const _ = Xe(), C = Math.round(zt(p, _.minWidth, _.maxWidth)), A = Math.round(zt(v, _.minHeight, _.maxHeight));
    return a.style.setProperty("--reachai-chat-user-width", `${C}px`), a.style.setProperty("--reachai-chat-user-height", `${A}px`), a.classList.add("eaf-chat--user-sized"), $.setAttribute(
      "aria-label",
      i ? `${d}, current ${C} by ${A}` : `${d}，当前 ${C} × ${A}`
    ), { width: C, height: A };
  }
  function fe(p) {
    if (!j || p.pointerId !== j.pointerId) return;
    const v = p.clientX - j.startX, _ = p.clientY - j.startY, C = j.width + (E.includes("west") ? -v : v), A = j.height + (E.includes("north") ? -_ : _), B = Ae(C, A);
    if (j.customPosition) {
      const F = j.left + (E.includes("west") ? j.width - B.width : 0), W = j.top + (E.includes("north") ? j.height - B.height : 0);
      Ie(F, W);
    }
    p.preventDefault();
  }
  function De(p) {
    var _;
    if (!j || p && p.pointerId !== j.pointerId) return;
    const v = j.pointerId;
    j = null, a.classList.remove("eaf-chat--resizing"), document.body.style.userSelect = re;
    try {
      (_ = $.hasPointerCapture) != null && _.call($, v) && $.releasePointerCapture(v);
    } catch {
    }
  }
  function yt(p) {
    var C;
    if (!s || p.button !== 0 || H) return;
    const v = V(), _ = g.getBoundingClientRect();
    j = {
      pointerId: p.pointerId,
      startX: p.clientX,
      startY: p.clientY,
      width: v.width,
      height: v.height,
      left: _.left,
      top: _.top,
      customPosition: Q()
    }, re = document.body.style.userSelect, document.body.style.userSelect = "none", a.classList.add("eaf-chat--resizing"), $.focus({ preventScroll: !0 }), (C = $.setPointerCapture) == null || C.call($, p.pointerId), p.preventDefault(), p.stopPropagation();
  }
  function Re(p) {
    if (!s || !["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(p.key)) return;
    const v = p.shiftKey ? 40 : 16, _ = V();
    let C = _.width, A = _.height;
    const B = g.getBoundingClientRect(), F = Q();
    p.key === "ArrowLeft" && (C += E.includes("west") ? v : -v), p.key === "ArrowRight" && (C += E.includes("west") ? -v : v), p.key === "ArrowUp" && (A += E.includes("north") ? v : -v), p.key === "ArrowDown" && (A += E.includes("north") ? -v : v);
    const W = Ae(C, A);
    if (F) {
      const z = B.left + (E.includes("west") ? _.width - W.width : 0), X = B.top + (E.includes("north") ? _.height - W.height : 0);
      Ie(z, X);
    }
    p.preventDefault();
  }
  function Le(p) {
    return p instanceof Element && !!p.closest('button, a, input, textarea, select, [role="button"], [contenteditable="true"]');
  }
  function k(p) {
    var _;
    if (!n || !q || p.button !== 0 || p.isPrimary === !1 || j || Le(p.target)) return;
    const v = g.getBoundingClientRect();
    H = {
      pointerId: p.pointerId,
      startX: p.clientX,
      startY: p.clientY,
      left: v.left,
      top: v.top,
      moved: !1
    }, ee = document.body.style.userSelect, document.body.style.userSelect = "none", a.classList.add("eaf-chat--panel-dragging"), (_ = w.setPointerCapture) == null || _.call(w, p.pointerId), p.preventDefault();
  }
  function D(p) {
    if (!H || p.pointerId !== H.pointerId) return;
    const v = p.clientX - H.startX, _ = p.clientY - H.startY;
    !H.moved && Math.hypot(v, _) > 3 && (H.moved = !0), H.moved && (Ie(H.left + v, H.top + _), p.preventDefault());
  }
  function Y(p) {
    var _;
    if (!H || p && p.pointerId !== H.pointerId) return;
    const v = H.pointerId;
    H = null, a.classList.remove("eaf-chat--panel-dragging"), document.body.style.userSelect = ee;
    try {
      (_ = w.hasPointerCapture) != null && _.call(w, v) && w.releasePointerCapture(v);
    } catch {
    }
  }
  function ie(p, v) {
    const _ = I.offsetWidth || 64, C = I.offsetHeight || 64, A = Math.max(je, window.innerWidth - _ - je), B = Math.max(je, window.innerHeight - C - je), F = zt(p, je, A), W = zt(v, je, B);
    I.style.right = "auto", I.style.bottom = "auto", I.style.left = `${Math.round(F)}px`, I.style.top = `${Math.round(W)}px`;
    const z = F + _ / 2 < window.innerWidth / 2;
    a.dataset.launcherDock = z ? "left" : "right", n && !Q() && (E = z ? "north-east" : "north-west", $.dataset.resizeAnchor = E);
  }
  function L() {
    const p = I.getBoundingClientRect(), v = p.left + p.width / 2 < window.innerWidth / 2;
    ie(
      v ? pi : window.innerWidth - p.width - pi,
      p.top
    );
  }
  function l(p) {
    var _;
    if (!r || p.button !== 0) return;
    const v = I.getBoundingClientRect();
    K = {
      pointerId: p.pointerId,
      startX: p.clientX,
      startY: p.clientY,
      left: v.left,
      top: v.top,
      moved: !1
    }, (_ = y.setPointerCapture) == null || _.call(y, p.pointerId), a.classList.add("eaf-chat--launcher-dragging");
  }
  function c(p) {
    if (!K || p.pointerId !== K.pointerId) return;
    const v = p.clientX - K.startX, _ = p.clientY - K.startY;
    !K.moved && Math.hypot(v, _) > 4 && (K.moved = !0), K.moved && (ie(K.left + v, K.top + _), p.preventDefault());
  }
  function f(p) {
    var _;
    if (!K || p.pointerId !== K.pointerId) return;
    const v = K.moved;
    K = null, a.classList.remove("eaf-chat--launcher-dragging");
    try {
      (_ = y.hasPointerCapture) != null && _.call(y, p.pointerId) && y.releasePointerCapture(p.pointerId);
    } catch {
    }
    v && (L(), se = !0, window.setTimeout(() => {
      se = !1;
    }, 0));
  }
  function m() {
    if (se) {
      se = !1;
      return;
    }
    de(!0);
  }
  function b() {
    const p = Number.parseFloat(I.style.left), v = Number.parseFloat(I.style.top);
    if (Number.isFinite(p) && Number.isFinite(v) && ie(p, v), a.classList.contains("eaf-chat--user-sized")) {
      const A = V();
      Ae(A.width, A.height);
    }
    const _ = Number.parseFloat(g.style.left), C = Number.parseFloat(g.style.top);
    Number.isFinite(_) && Number.isFinite(C) && Ie(_, C);
  }
  return x.addEventListener("click", () => de(!1)), w.addEventListener("pointerdown", k), y.addEventListener("click", m), y.addEventListener("pointerdown", l), y.addEventListener("pointermove", c), y.addEventListener("pointerup", f), y.addEventListener("pointercancel", f), $.addEventListener("pointerdown", yt), $.addEventListener("keydown", Re), window.addEventListener("pointermove", fe), window.addEventListener("pointermove", D), window.addEventListener("pointerup", De), window.addEventListener("pointerup", Y), window.addEventListener("pointercancel", De), window.addEventListener("pointercancel", Y), window.addEventListener("resize", b), we(), G(M), {
    root: a,
    panel: g,
    body: R,
    connectionStatus: P,
    minimizeButton: x,
    launcher: y,
    isOpen: () => q,
    open: () => de(!0),
    close: () => de(!1),
    toggle: () => de(!q),
    setLauncherState: G,
    destroy() {
      S || (S = !0, De(), Y(), window.removeEventListener("pointermove", fe), window.removeEventListener("pointermove", D), window.removeEventListener("pointerup", De), window.removeEventListener("pointerup", Y), window.removeEventListener("pointercancel", De), window.removeEventListener("pointercancel", Y), window.removeEventListener("resize", b), a.remove());
    }
  };
}
function _t(e, t) {
  const n = e.querySelector(t);
  if (!n) throw new Error(`ReachAI embed shell element missing: ${t}`);
  return n;
}
function gi(e, t) {
  const n = Number.parseFloat(e.style.getPropertyValue(t));
  return Number.isFinite(n) ? n : 0;
}
function zt(e, t, n) {
  return Math.min(Math.max(e, t), n);
}
function $t(e) {
  return e.replace(/[<>&"']/g, (t) => ({
    "<": "&lt;",
    ">": "&gt;",
    "&": "&amp;",
    '"': "&quot;",
    "'": "&#39;"
  })[t] || t);
}
const un = {
  "tech-purple": { primary: "#6366f1", rgb: "99 102 241" },
  "metro-green": { primary: "#0b7a59", rgb: "11 122 89" },
  "aurora-cyan": { primary: "#0891b2", rgb: "8 145 178" },
  "nebula-violet": { primary: "#7c3aed", rgb: "124 58 237" },
  "coral-rose": { primary: "#db2777", rgb: "219 39 119" },
  "solar-gold": { primary: "#b45309", rgb: "180 83 9" },
  "deep-ocean": { primary: "#1d4ed8", rgb: "29 78 216" }
}, mi = "tech-purple";
function kf(e) {
  const t = String((e == null ? void 0 : e.primaryColor) || "").trim();
  if (t)
    return {
      primary: t,
      rgb: Pf(t) || un[mi].rgb,
      source: "primaryColor"
    };
  const n = String((e == null ? void 0 : e.preset) || "").trim();
  if (n && n in un) {
    const r = un[n];
    return { primary: r.primary, rgb: r.rgb, source: "preset" };
  }
  const s = un[mi];
  return { primary: s.primary, rgb: s.rgb, source: "default" };
}
function Pf(e) {
  const t = e.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);
  if (t) {
    const s = t[1];
    return s.length === 3 ? [
      parseInt(s[0] + s[0], 16),
      parseInt(s[1] + s[1], 16),
      parseInt(s[2] + s[2], 16)
    ].join(" ") : [
      parseInt(s.slice(0, 2), 16),
      parseInt(s.slice(2, 4), 16),
      parseInt(s.slice(4, 6), 16)
    ].join(" ");
  }
  const n = e.match(/^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
  return n ? `${Number(n[1])} ${Number(n[2])} ${Number(n[3])}` : null;
}
function Tf(e, t) {
  const n = kf({
    preset: t == null ? void 0 : t.preset,
    primaryColor: t == null ? void 0 : t.primaryColor
  });
  e.style.setProperty("--reachai-chat-primary", n.primary), e.style.setProperty("--reachai-chat-spectrum-anchor", n.primary), e.style.setProperty("--reachai-chat-primary-rgb", n.rgb), t != null && t.preset && t.preset in un ? e.dataset.chatPreset = t.preset : n.source === "default" ? e.dataset.chatPreset = "tech-purple" : delete e.dataset.chatPreset;
}
async function Kf(e) {
  var ie, L;
  if (!e.agentId) throw new Error("agentId is required");
  const t = typeof e.mount == "string" ? document.querySelector(e.mount) : e.mount;
  if (!t) throw new Error("mount element not found");
  let n = e.bridge || As({ route: location.pathname }), s = e.page;
  const r = Lf(e.apiBase, e.embedPathPrefix), i = Ff(e.apiBase), o = e.locale || "zh-CN";
  let a = "", u = { ...e.context || {} };
  const h = /* @__PURE__ */ new Set(), d = /* @__PURE__ */ new Set(), g = /* @__PURE__ */ new Map(), w = /* @__PURE__ */ new Map(), R = /* @__PURE__ */ new Set();
  let P, x = !1, $ = null, I = null, y = !1, O = n.registeredActions.length, E = null, q = () => {
  };
  function S(l, c = {}) {
    var b;
    const f = l && typeof l == "object" ? l : {}, m = String(f.requestId || "");
    if (m) {
      if (R.has(m)) return !1;
      R.add(m);
    }
    if (String(f.actionKey || "") === bi && m) {
      const p = f.metadata && typeof f.metadata == "object" ? f.metadata : {};
      E = {
        requestId: m,
        targetPageKey: typeof p.pageKey == "string" ? p.pageKey : void 0,
        route: typeof p.route == "string" ? p.route : void 0
      };
    }
    return (b = e.onEvent) == null || b.call(e, {
      type: "page.action.requested",
      data: l,
      sessionId: c.sessionId,
      turnId: c.turnId
    }), !0;
  }
  function M(l, c, f) {
    if (!x) {
      if (!c) {
        se(new Error("Page action requires an active embed session; no sessionId available"));
        return;
      }
      Wn({
        request: l,
        bridge: n,
        sessionId: c,
        apiBase: r,
        token: a,
        handledPageActions: d,
        inFlightPageActions: g,
        pendingPageActionResults: w,
        responseMetadata: f,
        onRequested: (m) => S(m, { sessionId: c }),
        onError: se,
        refreshToken: async () => (await k(), a)
      }).catch(se);
    }
  }
  function j(l) {
    if (l.sessionId) return l.sessionId;
    const c = l.data && typeof l.data == "object" ? l.data : {};
    return c.sessionId != null && String(c.sessionId) ? String(c.sessionId) : (I == null ? void 0 : I.getExistingSessionId()) || (I == null ? void 0 : I.getSessionId()) || void 0;
  }
  function K(l) {
    var c, f;
    if (l.type === "page.action.requested") {
      const m = S(l.data, {
        sessionId: l.sessionId,
        turnId: l.turnId
      });
      M(
        l.data,
        j(l),
        l.data && typeof l.data == "object" ? l.data.metadata : void 0
      ), m && ee.notifyActivity();
      return;
    }
    if (l.type === "message.completed") {
      const m = l.data;
      V && !V.isOpen() && (G = !0, Q());
      for (const b of qs(m))
        S(b, { sessionId: m.sessionId, turnId: m.turnId });
      (c = e.onEvent) == null || c.call(e, l), H(m).catch(se), ee.notifyActivity();
      return;
    }
    (f = e.onEvent) == null || f.call(e, l);
  }
  async function H(l) {
    if (!l || x) return;
    const c = l.sessionId || (I == null ? void 0 : I.getExistingSessionId()) || (I == null ? void 0 : I.getSessionId()), f = qs(l);
    if (!c) {
      f.length > 0 && se(new Error("Page action requires an active embed session; no sessionId available"));
      return;
    }
    await mf({
      response: l,
      bridge: n,
      sessionId: c,
      apiBase: r,
      token: a,
      handledPageActions: d,
      inFlightPageActions: g,
      pendingPageActionResults: w,
      onRequested: (m) => S(m, { sessionId: c }),
      onError: se,
      refreshToken: async () => (await k(), a)
    });
  }
  function se(l) {
    var f;
    const c = { message: l instanceof Error ? l.message : String(l), cause: l };
    (f = e.onError) == null || f.call(e, c);
  }
  async function re() {
    if (x) return;
    const l = I == null ? void 0 : I.getExistingSessionId();
    l && await vf({
      apiBase: r,
      token: a,
      sessionId: l,
      bridge: n,
      handledPageActions: d,
      pendingPageActions: h,
      inFlightPageActions: g,
      pendingPageActionResults: w,
      context: u,
      // poll 自己已 dispatch；此处只 publish，禁止再走 emitPublicEvent→dispatch 递归
      onEvent: (c) => {
        c.type === "page.action.requested" && S(c.data, { sessionId: l });
      },
      onError: se,
      refreshToken: async () => (await k(), a)
    });
  }
  const ee = wf({
    getSessionId: () => (I == null ? void 0 : I.getExistingSessionId()) || null,
    hasRegisteredActions: () => n.registeredActions.length > 0,
    isDestroyed: () => x,
    poll: re,
    onError: se
  });
  let we = "loading", de = !1, G = !1, V;
  function Q() {
    V && V.setLauncherState(
      we === "error" ? "error" : we === "loading" || de ? "thinking" : G ? "unread" : "idle"
    );
  }
  V = Cf({
    mount: t,
    position: e.position,
    initialOpen: e.initialOpen,
    brandName: ((ie = e.theme) == null ? void 0 : ie.brandName) || "ReachAI",
    locale: o,
    resizable: e.resizable,
    launcherDraggable: e.launcherDraggable,
    onOpen: () => {
      G = !1, Q(), ee.notifyActivity();
    }
  });
  const { root: Ie, body: Xe, connectionStatus: Ae } = V;
  Tf(Ie, e.theme);
  function fe(l) {
    var c, f;
    we = l.status, Ie.dataset.authState = l.status, Ae.hidden = l.status === "ready", Ae.classList.toggle("is-error", l.status === "error"), Ae.textContent = l.status === "loading" ? o === "en-US" ? "Connecting" : "正在连接" : l.status === "error" ? o === "en-US" ? "Connection failed" : "连接失败" : "", Q();
    try {
      (c = e.onStateChange) == null || c.call(e, l);
    } catch (m) {
      try {
        (f = e.onError) == null || f.call(e, {
          message: "ReachAI state callback failed",
          cause: m,
          code: "STATE_CALLBACK_FAILED",
          phase: "token",
          retryable: !1
        });
      } catch {
      }
    }
  }
  $ = Ls(qo, {
    apiBase: r,
    tokenProvider: e.tokenProvider,
    tokenTimeoutMs: e.tokenTimeoutMs,
    bridge: n,
    page: s,
    context: u,
    locale: o,
    placeholder: o === "zh-CN" ? "输入消息" : "Type a message",
    preferStream: e.stream !== !1,
    onEvent: K,
    onError: (l) => {
      var c;
      return (c = e.onError) == null ? void 0 : c.call(e, l);
    },
    onAuthStateChange: fe,
    onTokenChanged: (l) => {
      a = l;
    },
    onSessionChanged: () => {
      ee.notifyActivity();
    }
  }), I = $.mount(Xe);
  function De() {
    q(), q = n.onActionDefinitionsChange(() => {
      Re();
      const l = n.registeredActions.length;
      ee.notifyActionsChanged(O, l), O = l;
    });
  }
  De(), Re(0);
  function yt(l) {
    var f;
    const c = { message: l instanceof Error ? l.message : String(l), cause: l };
    (f = e.onError) == null || f.call(e, c);
  }
  function Re(l = 250) {
    !e.pageRegistry || e.pageRegistry.registerOnStart === !1 || !s || (P && window.clearTimeout(P), P = window.setTimeout(() => {
      P = void 0, Le().catch(yt);
    }, l));
  }
  async function Le() {
    x || await Rf(i, e, n, s);
  }
  async function k() {
    if (!I) throw new Error("Embed chat host is not ready");
    a = await I.refreshToken("page-action");
  }
  async function D(l) {
    const c = l.trim();
    if (!c || !I || x) return {};
    if (y) throw new Error("Another message is still in flight");
    y = !0, de = !0, Q(), ee.notifyActivity();
    try {
      const f = await I.sendMessage(c);
      return await H(f), ee.notifyActivity(), f;
    } catch (f) {
      throw se(f), f;
    } finally {
      y = !1, de = !1, Q();
    }
  }
  const Y = {
    get bridge() {
      return n;
    },
    get sessionId() {
      return (I == null ? void 0 : I.getSessionId()) || null;
    },
    open() {
      V.open();
    },
    close() {
      V.close();
    },
    toggle() {
      V.toggle();
    },
    send: D,
    async retry() {
      !I || x || (a = await I.retryAuthentication());
    },
    async rebindPage(l) {
      var m;
      if (x) throw new Error("Embed chat client has been destroyed");
      if (!(l != null && l.bridge) || !((m = l.page) != null && m.pageKey))
        throw new Error("rebindPage requires the target bridge and page.pageKey");
      if (!I) throw new Error("Embed chat host is not ready");
      const c = E;
      if (!c)
        throw new Error("No platform navigation is pending; rebindPage is only valid after onNavigate");
      if (c.targetPageKey && c.targetPageKey !== l.page.pageKey)
        throw new Error(`Target page does not match pending navigation: ${c.targetPageKey}`);
      const f = O;
      await I.rebindPage(l.bridge, l.page, c.requestId), n = l.bridge, s = l.page, O = n.registeredActions.length, De(), E = null, ee.notifyActionsChanged(f, O), Re(0), ee.notifyActivity();
    },
    registerPageCatalog: Le,
    setContext(l) {
      u = { ...u, ...l || {} }, I == null || I.setContext(l || {});
    },
    destroy() {
      x = !0, ee.destroy(), q(), P && window.clearTimeout(P), I == null || I.disposeHost(), $ == null || $.unmount(), $ = null, I = null, V.destroy();
    }
  };
  return typeof process < "u" && ((L = process.env) != null && L.VITEST) && Object.assign(Y, {
    __emitPublicEventForTests: K
  }), Y;
}
async function Rf(e, t, n, s) {
  const r = t.pageRegistry;
  !r || r.registerOnStart === !1 || !s || !r.projectCode || !r.appKey || !r.appSecret || await Mf(
    `${e}/api/registry/projects/${encodeURIComponent(r.projectCode)}/pages/register`,
    {
      pageKey: s.pageKey,
      name: s.name || s.pageKey,
      routePattern: s.routePattern || n.route || location.pathname,
      origin: s.origin || location.origin,
      pageInstanceId: n.pageInstanceId,
      replaceActions: !0,
      actions: n.actionDefinitions.map($f),
      metadata: s.metadata || {}
    },
    r
  );
}
function $f(e) {
  return {
    actionKey: e.actionKey,
    title: e.title || e.actionKey,
    description: e.description || "",
    confirmRequired: e.confirmRequired === !0,
    inputSchema: e.inputSchema || {},
    outputSchema: e.outputSchema || {},
    sampleArgs: e.sampleArgs || {},
    allowedAgentIds: e.allowedAgentIds || [],
    metadata: e.metadata || {}
  };
}
async function Mf(e, t, n) {
  const s = String(Date.now()), r = Nf(), i = await Of(n.appSecret, `${n.projectCode}
${s}
${r}`), o = await fetch(e, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-ReachAI-App-Key": n.appKey,
      "X-ReachAI-Timestamp": s,
      "X-ReachAI-Nonce": r,
      "X-ReachAI-Signature": i
    },
    body: JSON.stringify(t)
  }), a = await o.json().catch(() => ({}));
  if (!o.ok || a.code && a.code !== 200 && a.code !== 0)
    throw Df(a.message || `Page catalog registration failed: ${o.status}`, o.status);
  return a.data ?? a;
}
async function Of(e, t) {
  if (!(crypto != null && crypto.subtle))
    throw new Error("Web Crypto API is required for ReachAI page catalog registration");
  const n = new TextEncoder(), s = await crypto.subtle.importKey(
    "raw",
    n.encode(e),
    { name: "HMAC", hash: "SHA-256" },
    !1,
    ["sign"]
  ), r = await crypto.subtle.sign("HMAC", s, n.encode(t));
  return Array.from(new Uint8Array(r)).map((i) => i.toString(16).padStart(2, "0")).join("");
}
function Nf() {
  return typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}
function Df(e, t) {
  const n = new Error(e);
  return n.status = t, n;
}
function Lf(e, t) {
  const n = Pn((e || "").trim());
  if (t !== void 0) {
    const s = gr(t || "/api/embed");
    return yi(qf(n, s), s);
  }
  return Ho(n) ? n : yi(n, "/api/embed");
}
function Ff(e) {
  const t = Pn((e || "").trim());
  return t ? Ho(t) ? t.replace(/\/api\/(?:reachai\/)?embed$/i, "") : t : "";
}
function yi(e, t) {
  const n = Pn(e), s = gr(t);
  return n ? s ? `${n}${s}` : n : s || "";
}
function qf(e, t) {
  const n = gr(t);
  return !e || !n ? e : e.toLowerCase().endsWith(n.toLowerCase()) ? Pn(e.slice(0, -n.length)) : e;
}
function gr(e) {
  const t = Pn((e || "").trim());
  return t ? t.startsWith("/") ? t : `/${t}` : "";
}
function Ho(e) {
  return /\/api\/(?:reachai\/)?embed$/i.test(e);
}
function Pn(e) {
  return e.endsWith("/") ? e.slice(0, -1) : e;
}
const jf = /* @__PURE__ */ gt({
  __name: "ReachAiChatElement.ce",
  props: {
    apiBase: { default: "/api/embed", type: String },
    token: { default: "", type: String },
    pageKey: { type: String },
    route: { type: String },
    placeholder: { default: "输入消息", type: String }
  },
  setup(e) {
    const t = e, n = /* @__PURE__ */ Ee(!1), s = /* @__PURE__ */ Ee(As()), r = /* @__PURE__ */ Ee(void 0), i = /* @__PURE__ */ Ee({});
    function o() {
      return t.token;
    }
    async function a() {
      return t.token;
    }
    return rs(() => {
      s.value = As({
        route: t.route || (typeof location < "u" ? location.pathname : "/")
      }), t.pageKey && (r.value = { pageKey: t.pageKey }), n.value = !0;
    }), (u, h) => n.value ? (T(), mt(qo, {
      key: 0,
      "api-base": e.apiBase,
      "token-provider": o,
      bridge: s.value,
      page: r.value,
      context: i.value,
      placeholder: e.placeholder,
      "on-unauthorized": a
    }, null, 8, ["api-base", "bridge", "page", "context", "placeholder"])) : te("", !0);
  }
});
let Is = !1;
function Uf(e = "reachai-chat") {
  if (!(Is || typeof customElements > "u")) {
    if (customElements.get(e)) {
      Is = !0;
      return;
    }
    customElements.define(e, /* @__PURE__ */ mc(jf)), Is = !0;
  }
}
export {
  un as EAF_CHAT_THEME_PRESETS,
  bi as EAF_PAGE_NAVIGATE_ACTION,
  Ss as buildEafChatSessionPayload,
  Kf as createEafChat,
  As as createEafPageBridge,
  Uf as defineReachAiChatElement,
  Lf as resolveEafChatEmbedApiRoot,
  Ff as resolveEafChatPlatformBase,
  kf as resolveEafChatThemePrimary
};
