function cn(e = {}) {
  const t = e.pageInstanceId || po(), s = Math.max(1e3, e.actionTimeoutMs || 15e3), n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Set();
  function a() {
    return Array.from(n.keys()).map((c) => ({
      actionKey: c,
      ...r.get(c) || {}
    }));
  }
  function l(c) {
    i.forEach((d) => d(c));
  }
  function f() {
    const c = a();
    o.forEach((d) => d(c));
  }
  return {
    pageInstanceId: t,
    route: e.route,
    get registeredActions() {
      return Array.from(n.keys());
    },
    get actionDefinitions() {
      return a();
    },
    registerAction(c, d, g = {}) {
      return n.set(c, d), r.set(c, g), f(), () => {
        n.delete(c), r.delete(c), f();
      };
    },
    async handleEvent(c) {
      var _;
      if (!ho(c)) return null;
      const d = (_ = c.target) == null ? void 0 : _.pageInstanceId;
      if (d && d !== t) return null;
      const g = n.get(c.actionKey);
      if (!g) {
        const M = ys(c, "ACTION_NOT_FOUND", void 0, `Action is not registered: ${c.actionKey}`);
        return l(M), M;
      }
      if (!await uo(c, e.confirmAction)) {
        const M = ys(c, "CANCELLED", void 0, `Action was cancelled: ${c.actionKey}`);
        return l(M), M;
      }
      try {
        const M = await fo(g(c.args || {}, c), s), p = ys(c, "SUCCESS", M);
        return l(p), p;
      } catch (M) {
        const p = M instanceof Error ? M.message : String(M), $ = ys(c, p === "Page action timed out" ? "TIMEOUT" : "FAILED", void 0, p);
        return l($), $;
      }
    },
    onResult(c) {
      return i.add(c), () => i.delete(c);
    },
    onActionDefinitionsChange(c) {
      return o.add(c), () => o.delete(c);
    }
  };
}
async function uo(e, t) {
  return e.confirm ? t ? await t(e) : typeof window < "u" && typeof window.confirm == "function" ? window.confirm(e.title || `Run page action: ${e.actionKey}`) : !1 : !0;
}
function ys(e, t, s, n) {
  return {
    protocolVersion: e.protocolVersion || "1.0",
    type: "page.action.result",
    requestId: e.requestId,
    actionKey: e.actionKey,
    status: t,
    data: s,
    error: n
  };
}
async function fo(e, t) {
  let s;
  try {
    return await Promise.race([
      Promise.resolve(e),
      new Promise((n, r) => {
        s = setTimeout(() => r(new Error("Page action timed out")), t);
      })
    ]);
  } catch (n) {
    throw n instanceof Error && n.message === "Page action timed out", n;
  } finally {
    s && clearTimeout(s);
  }
}
function ho(e) {
  if (!e || typeof e != "object") return !1;
  const t = e;
  return t.type === "page.action.requested" && typeof t.requestId == "string" && typeof t.actionKey == "string";
}
function po() {
  return typeof crypto < "u" && "randomUUID" in crypto ? `page-${crypto.randomUUID()}` : `page-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}
/**
* @vue/shared v3.5.31
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
// @__NO_SIDE_EFFECTS__
function xn(e) {
  const t = /* @__PURE__ */ Object.create(null);
  for (const s of e.split(",")) t[s] = 1;
  return (s) => s in t;
}
const pe = {}, Lt = [], ft = () => {
}, Hr = () => !1, Ms = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && // uppercase letter
(e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97), qs = (e) => e.startsWith("onUpdate:"), Se = Object.assign, Cn = (e, t) => {
  const s = e.indexOf(t);
  s > -1 && e.splice(s, 1);
}, go = Object.prototype.hasOwnProperty, ce = (e, t) => go.call(e, t), z = Array.isArray, Ut = (e) => ds(e) === "[object Map]", js = (e) => ds(e) === "[object Set]", er = (e) => ds(e) === "[object Date]", Z = (e) => typeof e == "function", ve = (e) => typeof e == "string", et = (e) => typeof e == "symbol", de = (e) => e !== null && typeof e == "object", Vr = (e) => (de(e) || Z(e)) && Z(e.then) && Z(e.catch), Wr = Object.prototype.toString, ds = (e) => Wr.call(e), mo = (e) => ds(e).slice(8, -1), Ns = (e) => ds(e) === "[object Object]", An = (e) => ve(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e, Zt = /* @__PURE__ */ xn(
  // the leading comma is intentional so empty string "" is also included
  ",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"
), Fs = (e) => {
  const t = /* @__PURE__ */ Object.create(null);
  return ((s) => t[s] || (t[s] = e(s)));
}, yo = /-\w/g, Ae = Fs(
  (e) => e.replace(yo, (t) => t.slice(1).toUpperCase())
), bo = /\B([A-Z])/g, Ge = Fs(
  (e) => e.replace(bo, "-$1").toLowerCase()
), Ds = Fs((e) => e.charAt(0).toUpperCase() + e.slice(1)), Js = Fs(
  (e) => e ? `on${Ds(e)}` : ""
), ut = (e, t) => !Object.is(e, t), Ss = (e, ...t) => {
  for (let s = 0; s < e.length; s++)
    e[s](...t);
}, zr = (e, t, s, n = !1) => {
  Object.defineProperty(e, t, {
    configurable: !0,
    enumerable: !1,
    writable: n,
    value: s
  });
}, kn = (e) => {
  const t = parseFloat(e);
  return isNaN(t) ? e : t;
}, tr = (e) => {
  const t = ve(e) ? Number(e) : NaN;
  return isNaN(t) ? e : t;
};
let sr;
const Ks = () => sr || (sr = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {});
function hs(e) {
  if (z(e)) {
    const t = {};
    for (let s = 0; s < e.length; s++) {
      const n = e[s], r = ve(n) ? wo(n) : hs(n);
      if (r)
        for (const i in r)
          t[i] = r[i];
    }
    return t;
  } else if (ve(e) || de(e))
    return e;
}
const _o = /;(?![^(]*\))/g, vo = /:([^]+)/, So = /\/\*[^]*?\*\//g;
function wo(e) {
  const t = {};
  return e.replace(So, "").split(_o).forEach((s) => {
    if (s) {
      const n = s.split(vo);
      n.length > 1 && (t[n[0].trim()] = n[1].trim());
    }
  }), t;
}
function Ye(e) {
  let t = "";
  if (ve(e))
    t = e;
  else if (z(e))
    for (let s = 0; s < e.length; s++) {
      const n = Ye(e[s]);
      n && (t += n + " ");
    }
  else if (de(e))
    for (const s in e)
      e[s] && (t += s + " ");
  return t.trim();
}
function Io(e) {
  if (!e) return null;
  let { class: t, style: s } = e;
  return t && !ve(t) && (e.class = Ye(t)), s && (e.style = hs(s)), e;
}
const xo = "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly", Co = /* @__PURE__ */ xn(xo);
function Jr(e) {
  return !!e || e === "";
}
function Ao(e, t) {
  if (e.length !== t.length) return !1;
  let s = !0;
  for (let n = 0; s && n < e.length; n++)
    s = jt(e[n], t[n]);
  return s;
}
function jt(e, t) {
  if (e === t) return !0;
  let s = er(e), n = er(t);
  if (s || n)
    return s && n ? e.getTime() === t.getTime() : !1;
  if (s = et(e), n = et(t), s || n)
    return e === t;
  if (s = z(e), n = z(t), s || n)
    return s && n ? Ao(e, t) : !1;
  if (s = de(e), n = de(t), s || n) {
    if (!s || !n)
      return !1;
    const r = Object.keys(e).length, i = Object.keys(t).length;
    if (r !== i)
      return !1;
    for (const o in e) {
      const a = e.hasOwnProperty(o), l = t.hasOwnProperty(o);
      if (a && !l || !a && l || !jt(e[o], t[o]))
        return !1;
    }
  }
  return String(e) === String(t);
}
function Gr(e, t) {
  return e.findIndex((s) => jt(s, t));
}
const Yr = (e) => !!(e && e.__v_isRef === !0), te = (e) => ve(e) ? e : e == null ? "" : z(e) || de(e) && (e.toString === Wr || !Z(e.toString)) ? Yr(e) ? te(e.value) : JSON.stringify(e, Xr, 2) : String(e), Xr = (e, t) => Yr(t) ? Xr(e, t.value) : Ut(t) ? {
  [`Map(${t.size})`]: [...t.entries()].reduce(
    (s, [n, r], i) => (s[Gs(n, i) + " =>"] = r, s),
    {}
  )
} : js(t) ? {
  [`Set(${t.size})`]: [...t.values()].map((s) => Gs(s))
} : et(t) ? Gs(t) : de(t) && !z(t) && !Ns(t) ? String(t) : t, Gs = (e, t = "") => {
  var s;
  return (
    // Symbol.description in es2019+ so we need to cast here to pass
    // the lib: es2016 check
    et(e) ? `Symbol(${(s = e.description) != null ? s : t})` : e
  );
};
/**
* @vue/reactivity v3.5.31
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
let Le;
class ko {
  // TODO isolatedDeclarations "__v_skip"
  constructor(t = !1) {
    this.detached = t, this._active = !0, this._on = 0, this.effects = [], this.cleanups = [], this._isPaused = !1, this.__v_skip = !0, this.parent = Le, !t && Le && (this.index = (Le.scopes || (Le.scopes = [])).push(
      this
    ) - 1);
  }
  get active() {
    return this._active;
  }
  pause() {
    if (this._active) {
      this._isPaused = !0;
      let t, s;
      if (this.scopes)
        for (t = 0, s = this.scopes.length; t < s; t++)
          this.scopes[t].pause();
      for (t = 0, s = this.effects.length; t < s; t++)
        this.effects[t].pause();
    }
  }
  /**
   * Resumes the effect scope, including all child scopes and effects.
   */
  resume() {
    if (this._active && this._isPaused) {
      this._isPaused = !1;
      let t, s;
      if (this.scopes)
        for (t = 0, s = this.scopes.length; t < s; t++)
          this.scopes[t].resume();
      for (t = 0, s = this.effects.length; t < s; t++)
        this.effects[t].resume();
    }
  }
  run(t) {
    if (this._active) {
      const s = Le;
      try {
        return Le = this, t();
      } finally {
        Le = s;
      }
    }
  }
  /**
   * This should only be called on non-detached scopes
   * @internal
   */
  on() {
    ++this._on === 1 && (this.prevScope = Le, Le = this);
  }
  /**
   * This should only be called on non-detached scopes
   * @internal
   */
  off() {
    this._on > 0 && --this._on === 0 && (Le = this.prevScope, this.prevScope = void 0);
  }
  stop(t) {
    if (this._active) {
      this._active = !1;
      let s, n;
      for (s = 0, n = this.effects.length; s < n; s++)
        this.effects[s].stop();
      for (this.effects.length = 0, s = 0, n = this.cleanups.length; s < n; s++)
        this.cleanups[s]();
      if (this.cleanups.length = 0, this.scopes) {
        for (s = 0, n = this.scopes.length; s < n; s++)
          this.scopes[s].stop(!0);
        this.scopes.length = 0;
      }
      if (!this.detached && this.parent && !t) {
        const r = this.parent.scopes.pop();
        r && r !== this && (this.parent.scopes[this.index] = r, r.index = this.index);
      }
      this.parent = void 0;
    }
  }
}
function Eo() {
  return Le;
}
let ye;
const Ys = /* @__PURE__ */ new WeakSet();
class Qr {
  constructor(t) {
    this.fn = t, this.deps = void 0, this.depsTail = void 0, this.flags = 5, this.next = void 0, this.cleanup = void 0, this.scheduler = void 0, Le && Le.active && Le.effects.push(this);
  }
  pause() {
    this.flags |= 64;
  }
  resume() {
    this.flags & 64 && (this.flags &= -65, Ys.has(this) && (Ys.delete(this), this.trigger()));
  }
  /**
   * @internal
   */
  notify() {
    this.flags & 2 && !(this.flags & 32) || this.flags & 8 || ei(this);
  }
  run() {
    if (!(this.flags & 1))
      return this.fn();
    this.flags |= 2, nr(this), ti(this);
    const t = ye, s = Ze;
    ye = this, Ze = !0;
    try {
      return this.fn();
    } finally {
      si(this), ye = t, Ze = s, this.flags &= -3;
    }
  }
  stop() {
    if (this.flags & 1) {
      for (let t = this.deps; t; t = t.nextDep)
        Pn(t);
      this.deps = this.depsTail = void 0, nr(this), this.onStop && this.onStop(), this.flags &= -2;
    }
  }
  trigger() {
    this.flags & 64 ? Ys.add(this) : this.scheduler ? this.scheduler() : this.runIfDirty();
  }
  /**
   * @internal
   */
  runIfDirty() {
    un(this) && this.run();
  }
  get dirty() {
    return un(this);
  }
}
let Zr = 0, es, ts;
function ei(e, t = !1) {
  if (e.flags |= 8, t) {
    e.next = ts, ts = e;
    return;
  }
  e.next = es, es = e;
}
function En() {
  Zr++;
}
function Tn() {
  if (--Zr > 0)
    return;
  if (ts) {
    let t = ts;
    for (ts = void 0; t; ) {
      const s = t.next;
      t.next = void 0, t.flags &= -9, t = s;
    }
  }
  let e;
  for (; es; ) {
    let t = es;
    for (es = void 0; t; ) {
      const s = t.next;
      if (t.next = void 0, t.flags &= -9, t.flags & 1)
        try {
          t.trigger();
        } catch (n) {
          e || (e = n);
        }
      t = s;
    }
  }
  if (e) throw e;
}
function ti(e) {
  for (let t = e.deps; t; t = t.nextDep)
    t.version = -1, t.prevActiveLink = t.dep.activeLink, t.dep.activeLink = t;
}
function si(e) {
  let t, s = e.depsTail, n = s;
  for (; n; ) {
    const r = n.prevDep;
    n.version === -1 ? (n === s && (s = r), Pn(n), To(n)) : t = n, n.dep.activeLink = n.prevActiveLink, n.prevActiveLink = void 0, n = r;
  }
  e.deps = t, e.depsTail = s;
}
function un(e) {
  for (let t = e.deps; t; t = t.nextDep)
    if (t.dep.version !== t.version || t.dep.computed && (ni(t.dep.computed) || t.dep.version !== t.version))
      return !0;
  return !!e._dirty;
}
function ni(e) {
  if (e.flags & 4 && !(e.flags & 16) || (e.flags &= -17, e.globalVersion === is) || (e.globalVersion = is, !e.isSSR && e.flags & 128 && (!e.deps && !e._dirty || !un(e))))
    return;
  e.flags |= 2;
  const t = e.dep, s = ye, n = Ze;
  ye = e, Ze = !0;
  try {
    ti(e);
    const r = e.fn(e._value);
    (t.version === 0 || ut(r, e._value)) && (e.flags |= 128, e._value = r, t.version++);
  } catch (r) {
    throw t.version++, r;
  } finally {
    ye = s, Ze = n, si(e), e.flags &= -3;
  }
}
function Pn(e, t = !1) {
  const { dep: s, prevSub: n, nextSub: r } = e;
  if (n && (n.nextSub = r, e.prevSub = void 0), r && (r.prevSub = n, e.nextSub = void 0), s.subs === e && (s.subs = n, !n && s.computed)) {
    s.computed.flags &= -5;
    for (let i = s.computed.deps; i; i = i.nextDep)
      Pn(i, !0);
  }
  !t && !--s.sc && s.map && s.map.delete(s.key);
}
function To(e) {
  const { prevDep: t, nextDep: s } = e;
  t && (t.nextDep = s, e.prevDep = void 0), s && (s.prevDep = t, e.nextDep = void 0);
}
let Ze = !0;
const ri = [];
function St() {
  ri.push(Ze), Ze = !1;
}
function wt() {
  const e = ri.pop();
  Ze = e === void 0 ? !0 : e;
}
function nr(e) {
  const { cleanup: t } = e;
  if (e.cleanup = void 0, t) {
    const s = ye;
    ye = void 0;
    try {
      t();
    } finally {
      ye = s;
    }
  }
}
let is = 0;
class Po {
  constructor(t, s) {
    this.sub = t, this.dep = s, this.version = s.version, this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0;
  }
}
class $n {
  // TODO isolatedDeclarations "__v_skip"
  constructor(t) {
    this.computed = t, this.version = 0, this.activeLink = void 0, this.subs = void 0, this.map = void 0, this.key = void 0, this.sc = 0, this.__v_skip = !0;
  }
  track(t) {
    if (!ye || !Ze || ye === this.computed)
      return;
    let s = this.activeLink;
    if (s === void 0 || s.sub !== ye)
      s = this.activeLink = new Po(ye, this), ye.deps ? (s.prevDep = ye.depsTail, ye.depsTail.nextDep = s, ye.depsTail = s) : ye.deps = ye.depsTail = s, ii(s);
    else if (s.version === -1 && (s.version = this.version, s.nextDep)) {
      const n = s.nextDep;
      n.prevDep = s.prevDep, s.prevDep && (s.prevDep.nextDep = n), s.prevDep = ye.depsTail, s.nextDep = void 0, ye.depsTail.nextDep = s, ye.depsTail = s, ye.deps === s && (ye.deps = n);
    }
    return s;
  }
  trigger(t) {
    this.version++, is++, this.notify(t);
  }
  notify(t) {
    En();
    try {
      for (let s = this.subs; s; s = s.prevSub)
        s.sub.notify() && s.sub.dep.notify();
    } finally {
      Tn();
    }
  }
}
function ii(e) {
  if (e.dep.sc++, e.sub.flags & 4) {
    const t = e.dep.computed;
    if (t && !e.dep.subs) {
      t.flags |= 20;
      for (let n = t.deps; n; n = n.nextDep)
        ii(n);
    }
    const s = e.dep.subs;
    s !== e && (e.prevSub = s, s && (s.nextSub = e)), e.dep.subs = e;
  }
}
const fn = /* @__PURE__ */ new WeakMap(), Ot = /* @__PURE__ */ Symbol(
  ""
), dn = /* @__PURE__ */ Symbol(
  ""
), os = /* @__PURE__ */ Symbol(
  ""
);
function Re(e, t, s) {
  if (Ze && ye) {
    let n = fn.get(e);
    n || fn.set(e, n = /* @__PURE__ */ new Map());
    let r = n.get(s);
    r || (n.set(s, r = new $n()), r.map = n, r.key = s), r.track();
  }
}
function bt(e, t, s, n, r, i) {
  const o = fn.get(e);
  if (!o) {
    is++;
    return;
  }
  const a = (l) => {
    l && l.trigger();
  };
  if (En(), t === "clear")
    o.forEach(a);
  else {
    const l = z(e), f = l && An(s);
    if (l && s === "length") {
      const c = Number(n);
      o.forEach((d, g) => {
        (g === "length" || g === os || !et(g) && g >= c) && a(d);
      });
    } else
      switch ((s !== void 0 || o.has(void 0)) && a(o.get(s)), f && a(o.get(os)), t) {
        case "add":
          l ? f && a(o.get("length")) : (a(o.get(Ot)), Ut(e) && a(o.get(dn)));
          break;
        case "delete":
          l || (a(o.get(Ot)), Ut(e) && a(o.get(dn)));
          break;
        case "set":
          Ut(e) && a(o.get(Ot));
          break;
      }
  }
  Tn();
}
function Ft(e) {
  const t = /* @__PURE__ */ ue(e);
  return t === e ? t : (Re(t, "iterate", os), /* @__PURE__ */ Xe(e) ? t : t.map(tt));
}
function Ls(e) {
  return Re(e = /* @__PURE__ */ ue(e), "iterate", os), e;
}
function lt(e, t) {
  return /* @__PURE__ */ It(e) ? Wt(/* @__PURE__ */ Mt(e) ? tt(t) : t) : tt(t);
}
const $o = {
  __proto__: null,
  [Symbol.iterator]() {
    return Xs(this, Symbol.iterator, (e) => lt(this, e));
  },
  concat(...e) {
    return Ft(this).concat(
      ...e.map((t) => z(t) ? Ft(t) : t)
    );
  },
  entries() {
    return Xs(this, "entries", (e) => (e[1] = lt(this, e[1]), e));
  },
  every(e, t) {
    return gt(this, "every", e, t, void 0, arguments);
  },
  filter(e, t) {
    return gt(
      this,
      "filter",
      e,
      t,
      (s) => s.map((n) => lt(this, n)),
      arguments
    );
  },
  find(e, t) {
    return gt(
      this,
      "find",
      e,
      t,
      (s) => lt(this, s),
      arguments
    );
  },
  findIndex(e, t) {
    return gt(this, "findIndex", e, t, void 0, arguments);
  },
  findLast(e, t) {
    return gt(
      this,
      "findLast",
      e,
      t,
      (s) => lt(this, s),
      arguments
    );
  },
  findLastIndex(e, t) {
    return gt(this, "findLastIndex", e, t, void 0, arguments);
  },
  // flat, flatMap could benefit from ARRAY_ITERATE but are not straight-forward to implement
  forEach(e, t) {
    return gt(this, "forEach", e, t, void 0, arguments);
  },
  includes(...e) {
    return Qs(this, "includes", e);
  },
  indexOf(...e) {
    return Qs(this, "indexOf", e);
  },
  join(e) {
    return Ft(this).join(e);
  },
  // keys() iterator only reads `length`, no optimization required
  lastIndexOf(...e) {
    return Qs(this, "lastIndexOf", e);
  },
  map(e, t) {
    return gt(this, "map", e, t, void 0, arguments);
  },
  pop() {
    return Yt(this, "pop");
  },
  push(...e) {
    return Yt(this, "push", e);
  },
  reduce(e, ...t) {
    return rr(this, "reduce", e, t);
  },
  reduceRight(e, ...t) {
    return rr(this, "reduceRight", e, t);
  },
  shift() {
    return Yt(this, "shift");
  },
  // slice could use ARRAY_ITERATE but also seems to beg for range tracking
  some(e, t) {
    return gt(this, "some", e, t, void 0, arguments);
  },
  splice(...e) {
    return Yt(this, "splice", e);
  },
  toReversed() {
    return Ft(this).toReversed();
  },
  toSorted(e) {
    return Ft(this).toSorted(e);
  },
  toSpliced(...e) {
    return Ft(this).toSpliced(...e);
  },
  unshift(...e) {
    return Yt(this, "unshift", e);
  },
  values() {
    return Xs(this, "values", (e) => lt(this, e));
  }
};
function Xs(e, t, s) {
  const n = Ls(e), r = n[t]();
  return n !== e && !/* @__PURE__ */ Xe(e) && (r._next = r.next, r.next = () => {
    const i = r._next();
    return i.done || (i.value = s(i.value)), i;
  }), r;
}
const Ro = Array.prototype;
function gt(e, t, s, n, r, i) {
  const o = Ls(e), a = o !== e && !/* @__PURE__ */ Xe(e), l = o[t];
  if (l !== Ro[t]) {
    const d = l.apply(e, i);
    return a ? tt(d) : d;
  }
  let f = s;
  o !== e && (a ? f = function(d, g) {
    return s.call(this, lt(e, d), g, e);
  } : s.length > 2 && (f = function(d, g) {
    return s.call(this, d, g, e);
  }));
  const c = l.call(o, f, n);
  return a && r ? r(c) : c;
}
function rr(e, t, s, n) {
  const r = Ls(e), i = r !== e && !/* @__PURE__ */ Xe(e);
  let o = s, a = !1;
  r !== e && (i ? (a = n.length === 0, o = function(f, c, d) {
    return a && (a = !1, f = lt(e, f)), s.call(this, f, lt(e, c), d, e);
  }) : s.length > 3 && (o = function(f, c, d) {
    return s.call(this, f, c, d, e);
  }));
  const l = r[t](o, ...n);
  return a ? lt(e, l) : l;
}
function Qs(e, t, s) {
  const n = /* @__PURE__ */ ue(e);
  Re(n, "iterate", os);
  const r = n[t](...s);
  return (r === -1 || r === !1) && /* @__PURE__ */ Mn(s[0]) ? (s[0] = /* @__PURE__ */ ue(s[0]), n[t](...s)) : r;
}
function Yt(e, t, s = []) {
  St(), En();
  const n = (/* @__PURE__ */ ue(e))[t].apply(e, s);
  return Tn(), wt(), n;
}
const Oo = /* @__PURE__ */ xn("__proto__,__v_isRef,__isVue"), oi = new Set(
  /* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((e) => e !== "arguments" && e !== "caller").map((e) => Symbol[e]).filter(et)
);
function Mo(e) {
  et(e) || (e = String(e));
  const t = /* @__PURE__ */ ue(this);
  return Re(t, "has", e), t.hasOwnProperty(e);
}
class ai {
  constructor(t = !1, s = !1) {
    this._isReadonly = t, this._isShallow = s;
  }
  get(t, s, n) {
    if (s === "__v_skip") return t.__v_skip;
    const r = this._isReadonly, i = this._isShallow;
    if (s === "__v_isReactive")
      return !r;
    if (s === "__v_isReadonly")
      return r;
    if (s === "__v_isShallow")
      return i;
    if (s === "__v_raw")
      return n === (r ? i ? Ho : fi : i ? ui : ci).get(t) || // receiver is not the reactive proxy, but has the same prototype
      // this means the receiver is a user proxy of the reactive proxy
      Object.getPrototypeOf(t) === Object.getPrototypeOf(n) ? t : void 0;
    const o = z(t);
    if (!r) {
      let l;
      if (o && (l = $o[s]))
        return l;
      if (s === "hasOwnProperty")
        return Mo;
    }
    const a = Reflect.get(
      t,
      s,
      // if this is a proxy wrapping a ref, return methods using the raw ref
      // as receiver so that we don't have to call `toRaw` on the ref in all
      // its class methods
      /* @__PURE__ */ qe(t) ? t : n
    );
    if ((et(s) ? oi.has(s) : Oo(s)) || (r || Re(t, "get", s), i))
      return a;
    if (/* @__PURE__ */ qe(a)) {
      const l = o && An(s) ? a : a.value;
      return r && de(l) ? /* @__PURE__ */ pn(l) : l;
    }
    return de(a) ? r ? /* @__PURE__ */ pn(a) : /* @__PURE__ */ Us(a) : a;
  }
}
class li extends ai {
  constructor(t = !1) {
    super(!1, t);
  }
  set(t, s, n, r) {
    let i = t[s];
    const o = z(t) && An(s);
    if (!this._isShallow) {
      const f = /* @__PURE__ */ It(i);
      if (!/* @__PURE__ */ Xe(n) && !/* @__PURE__ */ It(n) && (i = /* @__PURE__ */ ue(i), n = /* @__PURE__ */ ue(n)), !o && /* @__PURE__ */ qe(i) && !/* @__PURE__ */ qe(n))
        return f || (i.value = n), !0;
    }
    const a = o ? Number(s) < t.length : ce(t, s), l = Reflect.set(
      t,
      s,
      n,
      /* @__PURE__ */ qe(t) ? t : r
    );
    return t === /* @__PURE__ */ ue(r) && (a ? ut(n, i) && bt(t, "set", s, n) : bt(t, "add", s, n)), l;
  }
  deleteProperty(t, s) {
    const n = ce(t, s);
    t[s];
    const r = Reflect.deleteProperty(t, s);
    return r && n && bt(t, "delete", s, void 0), r;
  }
  has(t, s) {
    const n = Reflect.has(t, s);
    return (!et(s) || !oi.has(s)) && Re(t, "has", s), n;
  }
  ownKeys(t) {
    return Re(
      t,
      "iterate",
      z(t) ? "length" : Ot
    ), Reflect.ownKeys(t);
  }
}
class qo extends ai {
  constructor(t = !1) {
    super(!0, t);
  }
  set(t, s) {
    return !0;
  }
  deleteProperty(t, s) {
    return !0;
  }
}
const jo = /* @__PURE__ */ new li(), No = /* @__PURE__ */ new qo(), Fo = /* @__PURE__ */ new li(!0);
const hn = (e) => e, bs = (e) => Reflect.getPrototypeOf(e);
function Do(e, t, s) {
  return function(...n) {
    const r = this.__v_raw, i = /* @__PURE__ */ ue(r), o = Ut(i), a = e === "entries" || e === Symbol.iterator && o, l = e === "keys" && o, f = r[e](...n), c = s ? hn : t ? Wt : tt;
    return !t && Re(
      i,
      "iterate",
      l ? dn : Ot
    ), Se(
      // inheriting all iterator properties
      Object.create(f),
      {
        // iterator protocol
        next() {
          const { value: d, done: g } = f.next();
          return g ? { value: d, done: g } : {
            value: a ? [c(d[0]), c(d[1])] : c(d),
            done: g
          };
        }
      }
    );
  };
}
function _s(e) {
  return function(...t) {
    return e === "delete" ? !1 : e === "clear" ? void 0 : this;
  };
}
function Ko(e, t) {
  const s = {
    get(r) {
      const i = this.__v_raw, o = /* @__PURE__ */ ue(i), a = /* @__PURE__ */ ue(r);
      e || (ut(r, a) && Re(o, "get", r), Re(o, "get", a));
      const { has: l } = bs(o), f = t ? hn : e ? Wt : tt;
      if (l.call(o, r))
        return f(i.get(r));
      if (l.call(o, a))
        return f(i.get(a));
      i !== o && i.get(r);
    },
    get size() {
      const r = this.__v_raw;
      return !e && Re(/* @__PURE__ */ ue(r), "iterate", Ot), r.size;
    },
    has(r) {
      const i = this.__v_raw, o = /* @__PURE__ */ ue(i), a = /* @__PURE__ */ ue(r);
      return e || (ut(r, a) && Re(o, "has", r), Re(o, "has", a)), r === a ? i.has(r) : i.has(r) || i.has(a);
    },
    forEach(r, i) {
      const o = this, a = o.__v_raw, l = /* @__PURE__ */ ue(a), f = t ? hn : e ? Wt : tt;
      return !e && Re(l, "iterate", Ot), a.forEach((c, d) => r.call(i, f(c), f(d), o));
    }
  };
  return Se(
    s,
    e ? {
      add: _s("add"),
      set: _s("set"),
      delete: _s("delete"),
      clear: _s("clear")
    } : {
      add(r) {
        const i = /* @__PURE__ */ ue(this), o = bs(i), a = /* @__PURE__ */ ue(r), l = !t && !/* @__PURE__ */ Xe(r) && !/* @__PURE__ */ It(r) ? a : r;
        return o.has.call(i, l) || ut(r, l) && o.has.call(i, r) || ut(a, l) && o.has.call(i, a) || (i.add(l), bt(i, "add", l, l)), this;
      },
      set(r, i) {
        !t && !/* @__PURE__ */ Xe(i) && !/* @__PURE__ */ It(i) && (i = /* @__PURE__ */ ue(i));
        const o = /* @__PURE__ */ ue(this), { has: a, get: l } = bs(o);
        let f = a.call(o, r);
        f || (r = /* @__PURE__ */ ue(r), f = a.call(o, r));
        const c = l.call(o, r);
        return o.set(r, i), f ? ut(i, c) && bt(o, "set", r, i) : bt(o, "add", r, i), this;
      },
      delete(r) {
        const i = /* @__PURE__ */ ue(this), { has: o, get: a } = bs(i);
        let l = o.call(i, r);
        l || (r = /* @__PURE__ */ ue(r), l = o.call(i, r)), a && a.call(i, r);
        const f = i.delete(r);
        return l && bt(i, "delete", r, void 0), f;
      },
      clear() {
        const r = /* @__PURE__ */ ue(this), i = r.size !== 0, o = r.clear();
        return i && bt(
          r,
          "clear",
          void 0,
          void 0
        ), o;
      }
    }
  ), [
    "keys",
    "values",
    "entries",
    Symbol.iterator
  ].forEach((r) => {
    s[r] = Do(r, e, t);
  }), s;
}
function Rn(e, t) {
  const s = Ko(e, t);
  return (n, r, i) => r === "__v_isReactive" ? !e : r === "__v_isReadonly" ? e : r === "__v_raw" ? n : Reflect.get(
    ce(s, r) && r in n ? s : n,
    r,
    i
  );
}
const Lo = {
  get: /* @__PURE__ */ Rn(!1, !1)
}, Uo = {
  get: /* @__PURE__ */ Rn(!1, !0)
}, Bo = {
  get: /* @__PURE__ */ Rn(!0, !1)
};
const ci = /* @__PURE__ */ new WeakMap(), ui = /* @__PURE__ */ new WeakMap(), fi = /* @__PURE__ */ new WeakMap(), Ho = /* @__PURE__ */ new WeakMap();
function Vo(e) {
  switch (e) {
    case "Object":
    case "Array":
      return 1;
    case "Map":
    case "Set":
    case "WeakMap":
    case "WeakSet":
      return 2;
    default:
      return 0;
  }
}
function Wo(e) {
  return e.__v_skip || !Object.isExtensible(e) ? 0 : Vo(mo(e));
}
// @__NO_SIDE_EFFECTS__
function Us(e) {
  return /* @__PURE__ */ It(e) ? e : On(
    e,
    !1,
    jo,
    Lo,
    ci
  );
}
// @__NO_SIDE_EFFECTS__
function zo(e) {
  return On(
    e,
    !1,
    Fo,
    Uo,
    ui
  );
}
// @__NO_SIDE_EFFECTS__
function pn(e) {
  return On(
    e,
    !0,
    No,
    Bo,
    fi
  );
}
function On(e, t, s, n, r) {
  if (!de(e) || e.__v_raw && !(t && e.__v_isReactive))
    return e;
  const i = Wo(e);
  if (i === 0)
    return e;
  const o = r.get(e);
  if (o)
    return o;
  const a = new Proxy(
    e,
    i === 2 ? n : s
  );
  return r.set(e, a), a;
}
// @__NO_SIDE_EFFECTS__
function Mt(e) {
  return /* @__PURE__ */ It(e) ? /* @__PURE__ */ Mt(e.__v_raw) : !!(e && e.__v_isReactive);
}
// @__NO_SIDE_EFFECTS__
function It(e) {
  return !!(e && e.__v_isReadonly);
}
// @__NO_SIDE_EFFECTS__
function Xe(e) {
  return !!(e && e.__v_isShallow);
}
// @__NO_SIDE_EFFECTS__
function Mn(e) {
  return e ? !!e.__v_raw : !1;
}
// @__NO_SIDE_EFFECTS__
function ue(e) {
  const t = e && e.__v_raw;
  return t ? /* @__PURE__ */ ue(t) : e;
}
function Jo(e) {
  return !ce(e, "__v_skip") && Object.isExtensible(e) && zr(e, "__v_skip", !0), e;
}
const tt = (e) => de(e) ? /* @__PURE__ */ Us(e) : e, Wt = (e) => de(e) ? /* @__PURE__ */ pn(e) : e;
// @__NO_SIDE_EFFECTS__
function qe(e) {
  return e ? e.__v_isRef === !0 : !1;
}
// @__NO_SIDE_EFFECTS__
function De(e) {
  return Go(e, !1);
}
function Go(e, t) {
  return /* @__PURE__ */ qe(e) ? e : new Yo(e, t);
}
class Yo {
  constructor(t, s) {
    this.dep = new $n(), this.__v_isRef = !0, this.__v_isShallow = !1, this._rawValue = s ? t : /* @__PURE__ */ ue(t), this._value = s ? t : tt(t), this.__v_isShallow = s;
  }
  get value() {
    return this.dep.track(), this._value;
  }
  set value(t) {
    const s = this._rawValue, n = this.__v_isShallow || /* @__PURE__ */ Xe(t) || /* @__PURE__ */ It(t);
    t = n ? t : /* @__PURE__ */ ue(t), ut(t, s) && (this._rawValue = t, this._value = n ? t : tt(t), this.dep.trigger());
  }
}
function qn(e) {
  return /* @__PURE__ */ qe(e) ? e.value : e;
}
const Xo = {
  get: (e, t, s) => t === "__v_raw" ? e : qn(Reflect.get(e, t, s)),
  set: (e, t, s, n) => {
    const r = e[t];
    return /* @__PURE__ */ qe(r) && !/* @__PURE__ */ qe(s) ? (r.value = s, !0) : Reflect.set(e, t, s, n);
  }
};
function di(e) {
  return /* @__PURE__ */ Mt(e) ? e : new Proxy(e, Xo);
}
class Qo {
  constructor(t, s, n) {
    this.fn = t, this.setter = s, this._value = void 0, this.dep = new $n(this), this.__v_isRef = !0, this.deps = void 0, this.depsTail = void 0, this.flags = 16, this.globalVersion = is - 1, this.next = void 0, this.effect = this, this.__v_isReadonly = !s, this.isSSR = n;
  }
  /**
   * @internal
   */
  notify() {
    if (this.flags |= 16, !(this.flags & 8) && // avoid infinite self recursion
    ye !== this)
      return ei(this, !0), !0;
  }
  get value() {
    const t = this.dep.track();
    return ni(this), t && (t.version = this.dep.version), this._value;
  }
  set value(t) {
    this.setter && this.setter(t);
  }
}
// @__NO_SIDE_EFFECTS__
function Zo(e, t, s = !1) {
  let n, r;
  return Z(e) ? n = e : (n = e.get, r = e.set), new Qo(n, r, s);
}
const vs = {}, Cs = /* @__PURE__ */ new WeakMap();
let Rt;
function ea(e, t = !1, s = Rt) {
  if (s) {
    let n = Cs.get(s);
    n || Cs.set(s, n = []), n.push(e);
  }
}
function ta(e, t, s = pe) {
  const { immediate: n, deep: r, once: i, scheduler: o, augmentJob: a, call: l } = s, f = (R) => r ? R : /* @__PURE__ */ Xe(R) || r === !1 || r === 0 ? _t(R, 1) : _t(R);
  let c, d, g, _, M = !1, p = !1;
  if (/* @__PURE__ */ qe(e) ? (d = () => e.value, M = /* @__PURE__ */ Xe(e)) : /* @__PURE__ */ Mt(e) ? (d = () => f(e), M = !0) : z(e) ? (p = !0, M = e.some((R) => /* @__PURE__ */ Mt(R) || /* @__PURE__ */ Xe(R)), d = () => e.map((R) => {
    if (/* @__PURE__ */ qe(R))
      return R.value;
    if (/* @__PURE__ */ Mt(R))
      return f(R);
    if (Z(R))
      return l ? l(R, 2) : R();
  })) : Z(e) ? t ? d = l ? () => l(e, 2) : e : d = () => {
    if (g) {
      St();
      try {
        g();
      } finally {
        wt();
      }
    }
    const R = Rt;
    Rt = c;
    try {
      return l ? l(e, 3, [_]) : e(_);
    } finally {
      Rt = R;
    }
  } : d = ft, t && r) {
    const R = d, B = r === !0 ? 1 / 0 : r;
    d = () => _t(R(), B);
  }
  const $ = Eo(), K = () => {
    c.stop(), $ && $.active && Cn($.effects, c);
  };
  if (i && t) {
    const R = t;
    t = (...B) => {
      R(...B), K();
    };
  }
  let E = p ? new Array(e.length).fill(vs) : vs;
  const L = (R) => {
    if (!(!(c.flags & 1) || !c.dirty && !R))
      if (t) {
        const B = c.run();
        if (r || M || (p ? B.some((m, k) => ut(m, E[k])) : ut(B, E))) {
          g && g();
          const m = Rt;
          Rt = c;
          try {
            const k = [
              B,
              // pass undefined as the old value when it's changed for the first time
              E === vs ? void 0 : p && E[0] === vs ? [] : E,
              _
            ];
            E = B, l ? l(t, 3, k) : (
              // @ts-expect-error
              t(...k)
            );
          } finally {
            Rt = m;
          }
        }
      } else
        c.run();
  };
  return a && a(L), c = new Qr(d), c.scheduler = o ? () => o(L, !1) : L, _ = (R) => ea(R, !1, c), g = c.onStop = () => {
    const R = Cs.get(c);
    if (R) {
      if (l)
        l(R, 4);
      else
        for (const B of R) B();
      Cs.delete(c);
    }
  }, t ? n ? L(!0) : E = c.run() : o ? o(L.bind(null, !0), !0) : c.run(), K.pause = c.pause.bind(c), K.resume = c.resume.bind(c), K.stop = K, K;
}
function _t(e, t = 1 / 0, s) {
  if (t <= 0 || !de(e) || e.__v_skip || (s = s || /* @__PURE__ */ new Map(), (s.get(e) || 0) >= t))
    return e;
  if (s.set(e, t), t--, /* @__PURE__ */ qe(e))
    _t(e.value, t, s);
  else if (z(e))
    for (let n = 0; n < e.length; n++)
      _t(e[n], t, s);
  else if (js(e) || Ut(e))
    e.forEach((n) => {
      _t(n, t, s);
    });
  else if (Ns(e)) {
    for (const n in e)
      _t(e[n], t, s);
    for (const n of Object.getOwnPropertySymbols(e))
      Object.prototype.propertyIsEnumerable.call(e, n) && _t(e[n], t, s);
  }
  return e;
}
/**
* @vue/runtime-core v3.5.31
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
function ps(e, t, s, n) {
  try {
    return n ? e(...n) : e();
  } catch (r) {
    Bs(r, t, s);
  }
}
function dt(e, t, s, n) {
  if (Z(e)) {
    const r = ps(e, t, s, n);
    return r && Vr(r) && r.catch((i) => {
      Bs(i, t, s);
    }), r;
  }
  if (z(e)) {
    const r = [];
    for (let i = 0; i < e.length; i++)
      r.push(dt(e[i], t, s, n));
    return r;
  }
}
function Bs(e, t, s, n = !0) {
  const r = t ? t.vnode : null, { errorHandler: i, throwUnhandledErrorInProduction: o } = t && t.appContext.config || pe;
  if (t) {
    let a = t.parent;
    const l = t.proxy, f = `https://vuejs.org/error-reference/#runtime-${s}`;
    for (; a; ) {
      const c = a.ec;
      if (c) {
        for (let d = 0; d < c.length; d++)
          if (c[d](e, l, f) === !1)
            return;
      }
      a = a.parent;
    }
    if (i) {
      St(), ps(i, null, 10, [
        e,
        l,
        f
      ]), wt();
      return;
    }
  }
  sa(e, s, r, n, o);
}
function sa(e, t, s, n = !0, r = !1) {
  if (r)
    throw e;
  console.error(e);
}
const Fe = [];
let at = -1;
const Bt = [];
let kt = null, Dt = 0;
const hi = /* @__PURE__ */ Promise.resolve();
let As = null;
function jn(e) {
  const t = As || hi;
  return e ? t.then(this ? e.bind(this) : e) : t;
}
function na(e) {
  let t = at + 1, s = Fe.length;
  for (; t < s; ) {
    const n = t + s >>> 1, r = Fe[n], i = as(r);
    i < e || i === e && r.flags & 2 ? t = n + 1 : s = n;
  }
  return t;
}
function Nn(e) {
  if (!(e.flags & 1)) {
    const t = as(e), s = Fe[Fe.length - 1];
    !s || // fast path when the job id is larger than the tail
    !(e.flags & 2) && t >= as(s) ? Fe.push(e) : Fe.splice(na(t), 0, e), e.flags |= 1, pi();
  }
}
function pi() {
  As || (As = hi.then(mi));
}
function ra(e) {
  z(e) ? Bt.push(...e) : kt && e.id === -1 ? kt.splice(Dt + 1, 0, e) : e.flags & 1 || (Bt.push(e), e.flags |= 1), pi();
}
function ir(e, t, s = at + 1) {
  for (; s < Fe.length; s++) {
    const n = Fe[s];
    if (n && n.flags & 2) {
      if (e && n.id !== e.uid)
        continue;
      Fe.splice(s, 1), s--, n.flags & 4 && (n.flags &= -2), n(), n.flags & 4 || (n.flags &= -2);
    }
  }
}
function gi(e) {
  if (Bt.length) {
    const t = [...new Set(Bt)].sort(
      (s, n) => as(s) - as(n)
    );
    if (Bt.length = 0, kt) {
      kt.push(...t);
      return;
    }
    for (kt = t, Dt = 0; Dt < kt.length; Dt++) {
      const s = kt[Dt];
      s.flags & 4 && (s.flags &= -2), s.flags & 8 || s(), s.flags &= -2;
    }
    kt = null, Dt = 0;
  }
}
const as = (e) => e.id == null ? e.flags & 2 ? -1 : 1 / 0 : e.id;
function mi(e) {
  try {
    for (at = 0; at < Fe.length; at++) {
      const t = Fe[at];
      t && !(t.flags & 8) && (t.flags & 4 && (t.flags &= -2), ps(
        t,
        t.i,
        t.i ? 15 : 14
      ), t.flags & 4 || (t.flags &= -2));
    }
  } finally {
    for (; at < Fe.length; at++) {
      const t = Fe[at];
      t && (t.flags &= -2);
    }
    at = -1, Fe.length = 0, gi(), As = null, (Fe.length || Bt.length) && mi();
  }
}
let Te = null, yi = null;
function ks(e) {
  const t = Te;
  return Te = e, yi = e && e.type.__scopeId || null, t;
}
function Es(e, t = Te, s) {
  if (!t || e._n)
    return e;
  const n = (...r) => {
    n._d && $s(-1);
    const i = ks(t);
    let o;
    try {
      o = e(...r);
    } finally {
      ks(i), n._d && $s(1);
    }
    return o;
  };
  return n._n = !0, n._c = !0, n._d = !0, n;
}
function Kt(e, t) {
  if (Te === null)
    return e;
  const s = zs(Te), n = e.dirs || (e.dirs = []);
  for (let r = 0; r < t.length; r++) {
    let [i, o, a, l = pe] = t[r];
    i && (Z(i) && (i = {
      mounted: i,
      updated: i
    }), i.deep && _t(o), n.push({
      dir: i,
      instance: s,
      value: o,
      oldValue: void 0,
      arg: a,
      modifiers: l
    }));
  }
  return e;
}
function Pt(e, t, s, n) {
  const r = e.dirs, i = t && t.dirs;
  for (let o = 0; o < r.length; o++) {
    const a = r[o];
    i && (a.oldValue = i[o].value);
    let l = a.dir[n];
    l && (St(), dt(l, s, 8, [
      e.el,
      a,
      e,
      t
    ]), wt());
  }
}
function ia(e, t) {
  if (Oe) {
    let s = Oe.provides;
    const n = Oe.parent && Oe.parent.provides;
    n === s && (s = Oe.provides = Object.create(n)), s[e] = t;
  }
}
function ws(e, t, s = !1) {
  const n = nl();
  if (n || Vt) {
    let r = Vt ? Vt._context.provides : n ? n.parent == null || n.ce ? n.vnode.appContext && n.vnode.appContext.provides : n.parent.provides : void 0;
    if (r && e in r)
      return r[e];
    if (arguments.length > 1)
      return s && Z(t) ? t.call(n && n.proxy) : t;
  }
}
const oa = /* @__PURE__ */ Symbol.for("v-scx"), aa = () => ws(oa);
function qt(e, t, s) {
  return bi(e, t, s);
}
function bi(e, t, s = pe) {
  const { immediate: n, deep: r, flush: i, once: o } = s, a = Se({}, s), l = t && n || !t && i !== "post";
  let f;
  if (fs) {
    if (i === "sync") {
      const _ = aa();
      f = _.__watcherHandles || (_.__watcherHandles = []);
    } else if (!l) {
      const _ = () => {
      };
      return _.stop = ft, _.resume = ft, _.pause = ft, _;
    }
  }
  const c = Oe;
  a.call = (_, M, p) => dt(_, c, M, p);
  let d = !1;
  i === "post" ? a.scheduler = (_) => {
    Ke(_, c && c.suspense);
  } : i !== "sync" && (d = !0, a.scheduler = (_, M) => {
    M ? _() : Nn(_);
  }), a.augmentJob = (_) => {
    t && (_.flags |= 4), d && (_.flags |= 2, c && (_.id = c.uid, _.i = c));
  };
  const g = ta(e, t, a);
  return fs && (f ? f.push(g) : l && g()), g;
}
function la(e, t, s) {
  const n = this.proxy, r = ve(e) ? e.includes(".") ? _i(n, e) : () => n[e] : e.bind(n, n);
  let i;
  Z(t) ? i = t : (i = t.handler, s = t);
  const o = gs(this), a = bi(r, i.bind(n), s);
  return o(), a;
}
function _i(e, t) {
  const s = t.split(".");
  return () => {
    let n = e;
    for (let r = 0; r < s.length && n; r++)
      n = n[s[r]];
    return n;
  };
}
const ca = /* @__PURE__ */ Symbol("_vte"), ua = (e) => e.__isTeleport, fa = /* @__PURE__ */ Symbol("_leaveCb");
function Fn(e, t) {
  e.shapeFlag & 6 && e.component ? (e.transition = t, Fn(e.component.subTree, t)) : e.shapeFlag & 128 ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t;
}
// @__NO_SIDE_EFFECTS__
function ht(e, t) {
  return Z(e) ? (
    // #8236: extend call and options.name access are considered side-effects
    // by Rollup, so we have to wrap it in a pure-annotated IIFE.
    Se({ name: e.name }, t, { setup: e })
  ) : e;
}
function vi(e) {
  e.ids = [e.ids[0] + e.ids[2]++ + "-", 0, 0];
}
function or(e, t) {
  let s;
  return !!((s = Object.getOwnPropertyDescriptor(e, t)) && !s.configurable);
}
const Ts = /* @__PURE__ */ new WeakMap();
function ss(e, t, s, n, r = !1) {
  if (z(e)) {
    e.forEach(
      (p, $) => ss(
        p,
        t && (z(t) ? t[$] : t),
        s,
        n,
        r
      )
    );
    return;
  }
  if (Ht(n) && !r) {
    n.shapeFlag & 512 && n.type.__asyncResolved && n.component.subTree.component && ss(e, t, s, n.component.subTree);
    return;
  }
  const i = n.shapeFlag & 4 ? zs(n.component) : n.el, o = r ? null : i, { i: a, r: l } = e, f = t && t.r, c = a.refs === pe ? a.refs = {} : a.refs, d = a.setupState, g = /* @__PURE__ */ ue(d), _ = d === pe ? Hr : (p) => or(c, p) ? !1 : ce(g, p), M = (p, $) => !($ && or(c, $));
  if (f != null && f !== l) {
    if (ar(t), ve(f))
      c[f] = null, _(f) && (d[f] = null);
    else if (/* @__PURE__ */ qe(f)) {
      const p = t;
      M(f, p.k) && (f.value = null), p.k && (c[p.k] = null);
    }
  }
  if (Z(l))
    ps(l, a, 12, [o, c]);
  else {
    const p = ve(l), $ = /* @__PURE__ */ qe(l);
    if (p || $) {
      const K = () => {
        if (e.f) {
          const E = p ? _(l) ? d[l] : c[l] : M() || !e.k ? l.value : c[e.k];
          if (r)
            z(E) && Cn(E, i);
          else if (z(E))
            E.includes(i) || E.push(i);
          else if (p)
            c[l] = [i], _(l) && (d[l] = c[l]);
          else {
            const L = [i];
            M(l, e.k) && (l.value = L), e.k && (c[e.k] = L);
          }
        } else p ? (c[l] = o, _(l) && (d[l] = o)) : $ && (M(l, e.k) && (l.value = o), e.k && (c[e.k] = o));
      };
      if (o) {
        const E = () => {
          K(), Ts.delete(e);
        };
        E.id = -1, Ts.set(e, E), Ke(E, s);
      } else
        ar(e), K();
    }
  }
}
function ar(e) {
  const t = Ts.get(e);
  t && (t.flags |= 8, Ts.delete(e));
}
Ks().requestIdleCallback;
Ks().cancelIdleCallback;
const Ht = (e) => !!e.type.__asyncLoader, Si = (e) => e.type.__isKeepAlive;
function da(e, t) {
  wi(e, "a", t);
}
function ha(e, t) {
  wi(e, "da", t);
}
function wi(e, t, s = Oe) {
  const n = e.__wdc || (e.__wdc = () => {
    let r = s;
    for (; r; ) {
      if (r.isDeactivated)
        return;
      r = r.parent;
    }
    return e();
  });
  if (Hs(t, n, s), s) {
    let r = s.parent;
    for (; r && r.parent; )
      Si(r.parent.vnode) && pa(n, t, s, r), r = r.parent;
  }
}
function pa(e, t, s, n) {
  const r = Hs(
    t,
    e,
    n,
    !0
    /* prepend */
  );
  Kn(() => {
    Cn(n[t], r);
  }, s);
}
function Hs(e, t, s = Oe, n = !1) {
  if (s) {
    const r = s[e] || (s[e] = []), i = t.__weh || (t.__weh = (...o) => {
      St();
      const a = gs(s), l = dt(t, s, e, o);
      return a(), wt(), l;
    });
    return n ? r.unshift(i) : r.push(i), i;
  }
}
const Ct = (e) => (t, s = Oe) => {
  (!fs || e === "sp") && Hs(e, (...n) => t(...n), s);
}, ga = Ct("bm"), Dn = Ct("m"), ma = Ct(
  "bu"
), ya = Ct("u"), ba = Ct(
  "bum"
), Kn = Ct("um"), _a = Ct(
  "sp"
), va = Ct("rtg"), Sa = Ct("rtc");
function wa(e, t = Oe) {
  Hs("ec", e, t);
}
const Ia = "components", Ii = /* @__PURE__ */ Symbol.for("v-ndc");
function xa(e) {
  return ve(e) ? Ca(Ia, e, !1) || e : e || Ii;
}
function Ca(e, t, s = !0, n = !1) {
  const r = Te || Oe;
  if (r) {
    const i = r.type;
    {
      const a = ll(
        i,
        !1
      );
      if (a && (a === t || a === Ae(t) || a === Ds(Ae(t))))
        return i;
    }
    const o = (
      // local registration
      // check instance[type] first which is resolved for options API
      lr(r[e] || i[e], t) || // global registration
      lr(r.appContext[e], t)
    );
    return !o && n ? i : o;
  }
}
function lr(e, t) {
  return e && (e[t] || e[Ae(t)] || e[Ds(Ae(t))]);
}
function Be(e, t, s, n) {
  let r;
  const i = s, o = z(e);
  if (o || ve(e)) {
    const a = o && /* @__PURE__ */ Mt(e);
    let l = !1, f = !1;
    a && (l = !/* @__PURE__ */ Xe(e), f = /* @__PURE__ */ It(e), e = Ls(e)), r = new Array(e.length);
    for (let c = 0, d = e.length; c < d; c++)
      r[c] = t(
        l ? f ? Wt(tt(e[c])) : tt(e[c]) : e[c],
        c,
        void 0,
        i
      );
  } else if (typeof e == "number") {
    r = new Array(e);
    for (let a = 0; a < e; a++)
      r[a] = t(a + 1, a, void 0, i);
  } else if (de(e))
    if (e[Symbol.iterator])
      r = Array.from(
        e,
        (a, l) => t(a, l, void 0, i)
      );
    else {
      const a = Object.keys(e);
      r = new Array(a.length);
      for (let l = 0, f = a.length; l < f; l++) {
        const c = a[l];
        r[l] = t(e[c], c, l, i);
      }
    }
  else
    r = [];
  return r;
}
function xi(e, t) {
  for (let s = 0; s < t.length; s++) {
    const n = t[s];
    if (z(n))
      for (let r = 0; r < n.length; r++)
        e[n[r].name] = n[r].fn;
    else n && (e[n.name] = n.key ? (...r) => {
      const i = n.fn(...r);
      return i && (i.key = n.key), i;
    } : n.fn);
  }
  return e;
}
function Et(e, t, s = {}, n, r) {
  if (Te.ce || Te.parent && Ht(Te.parent) && Te.parent.ce) {
    const f = Object.keys(s).length > 0;
    return t !== "default" && (s.name = t), x(), st(
      be,
      null,
      [Me("slot", s, n && n())],
      f ? -2 : 64
    );
  }
  let i = e[t];
  i && i._c && (i._d = !1), x();
  const o = i && Ci(i(s)), a = s.key || // slot content array of a dynamic conditional slot may have a branch
  // key attached in the `createSlots` helper, respect that
  o && o.key, l = st(
    be,
    {
      key: (a && !et(a) ? a : `_${t}`) + // #7256 force differentiate fallback content from actual content
      (!o && n ? "_fb" : "")
    },
    o || (n ? n() : []),
    o && e._ === 1 ? 64 : -2
  );
  return i && i._c && (i._d = !0), l;
}
function Ci(e) {
  return e.some((t) => cs(t) ? !(t.type === xt || t.type === be && !Ci(t.children)) : !0) ? e : null;
}
const gn = (e) => e ? zi(e) ? zs(e) : gn(e.parent) : null, ns = (
  // Move PURE marker to new line to workaround compiler discarding it
  // due to type annotation
  /* @__PURE__ */ Se(/* @__PURE__ */ Object.create(null), {
    $: (e) => e,
    $el: (e) => e.vnode.el,
    $data: (e) => e.data,
    $props: (e) => e.props,
    $attrs: (e) => e.attrs,
    $slots: (e) => e.slots,
    $refs: (e) => e.refs,
    $parent: (e) => gn(e.parent),
    $root: (e) => gn(e.root),
    $host: (e) => e.ce,
    $emit: (e) => e.emit,
    $options: (e) => ki(e),
    $forceUpdate: (e) => e.f || (e.f = () => {
      Nn(e.update);
    }),
    $nextTick: (e) => e.n || (e.n = jn.bind(e.proxy)),
    $watch: (e) => la.bind(e)
  })
), Zs = (e, t) => e !== pe && !e.__isScriptSetup && ce(e, t), Aa = {
  get({ _: e }, t) {
    if (t === "__v_skip")
      return !0;
    const { ctx: s, setupState: n, data: r, props: i, accessCache: o, type: a, appContext: l } = e;
    if (t[0] !== "$") {
      const g = o[t];
      if (g !== void 0)
        switch (g) {
          case 1:
            return n[t];
          case 2:
            return r[t];
          case 4:
            return s[t];
          case 3:
            return i[t];
        }
      else {
        if (Zs(n, t))
          return o[t] = 1, n[t];
        if (r !== pe && ce(r, t))
          return o[t] = 2, r[t];
        if (ce(i, t))
          return o[t] = 3, i[t];
        if (s !== pe && ce(s, t))
          return o[t] = 4, s[t];
        mn && (o[t] = 0);
      }
    }
    const f = ns[t];
    let c, d;
    if (f)
      return t === "$attrs" && Re(e.attrs, "get", ""), f(e);
    if (
      // css module (injected by vue-loader)
      (c = a.__cssModules) && (c = c[t])
    )
      return c;
    if (s !== pe && ce(s, t))
      return o[t] = 4, s[t];
    if (
      // global properties
      d = l.config.globalProperties, ce(d, t)
    )
      return d[t];
  },
  set({ _: e }, t, s) {
    const { data: n, setupState: r, ctx: i } = e;
    return Zs(r, t) ? (r[t] = s, !0) : n !== pe && ce(n, t) ? (n[t] = s, !0) : ce(e.props, t) || t[0] === "$" && t.slice(1) in e ? !1 : (i[t] = s, !0);
  },
  has({
    _: { data: e, setupState: t, accessCache: s, ctx: n, appContext: r, props: i, type: o }
  }, a) {
    let l;
    return !!(s[a] || e !== pe && a[0] !== "$" && ce(e, a) || Zs(t, a) || ce(i, a) || ce(n, a) || ce(ns, a) || ce(r.config.globalProperties, a) || (l = o.__cssModules) && l[a]);
  },
  defineProperty(e, t, s) {
    return s.get != null ? e._.accessCache[t] = 0 : ce(s, "value") && this.set(e, t, s.value, null), Reflect.defineProperty(e, t, s);
  }
};
function cr(e) {
  return z(e) ? e.reduce(
    (t, s) => (t[s] = null, t),
    {}
  ) : e;
}
let mn = !0;
function ka(e) {
  const t = ki(e), s = e.proxy, n = e.ctx;
  mn = !1, t.beforeCreate && ur(t.beforeCreate, e, "bc");
  const {
    // state
    data: r,
    computed: i,
    methods: o,
    watch: a,
    provide: l,
    inject: f,
    // lifecycle
    created: c,
    beforeMount: d,
    mounted: g,
    beforeUpdate: _,
    updated: M,
    activated: p,
    deactivated: $,
    beforeDestroy: K,
    beforeUnmount: E,
    destroyed: L,
    unmounted: R,
    render: B,
    renderTracked: m,
    renderTriggered: k,
    errorCaptured: H,
    serverPrefetch: se,
    // public API
    expose: ne,
    inheritAttrs: Pe,
    // assets
    components: ke,
    directives: q,
    filters: U
  } = t;
  if (f && Ea(f, n, null), o)
    for (const Q in o) {
      const re = o[Q];
      Z(re) && (n[Q] = re.bind(s));
    }
  if (r) {
    const Q = r.call(s, s);
    de(Q) && (e.data = /* @__PURE__ */ Us(Q));
  }
  if (mn = !0, i)
    for (const Q in i) {
      const re = i[Q], ge = Z(re) ? re.bind(s, s) : Z(re.get) ? re.get.bind(s, s) : ft, je = !Z(re) && Z(re.set) ? re.set.bind(s) : ft, xe = fe({
        get: ge,
        set: je
      });
      Object.defineProperty(n, Q, {
        enumerable: !0,
        configurable: !0,
        get: () => xe.value,
        set: (le) => xe.value = le
      });
    }
  if (a)
    for (const Q in a)
      Ai(a[Q], n, s, Q);
  if (l) {
    const Q = Z(l) ? l.call(s) : l;
    Reflect.ownKeys(Q).forEach((re) => {
      ia(re, Q[re]);
    });
  }
  c && ur(c, e, "c");
  function Y(Q, re) {
    z(re) ? re.forEach((ge) => Q(ge.bind(s))) : re && Q(re.bind(s));
  }
  if (Y(ga, d), Y(Dn, g), Y(ma, _), Y(ya, M), Y(da, p), Y(ha, $), Y(wa, H), Y(Sa, m), Y(va, k), Y(ba, E), Y(Kn, R), Y(_a, se), z(ne))
    if (ne.length) {
      const Q = e.exposed || (e.exposed = {});
      ne.forEach((re) => {
        Object.defineProperty(Q, re, {
          get: () => s[re],
          set: (ge) => s[re] = ge,
          enumerable: !0
        });
      });
    } else e.exposed || (e.exposed = {});
  B && e.render === ft && (e.render = B), Pe != null && (e.inheritAttrs = Pe), ke && (e.components = ke), q && (e.directives = q), se && vi(e);
}
function Ea(e, t, s = ft) {
  z(e) && (e = yn(e));
  for (const n in e) {
    const r = e[n];
    let i;
    de(r) ? "default" in r ? i = ws(
      r.from || n,
      r.default,
      !0
    ) : i = ws(r.from || n) : i = ws(r), /* @__PURE__ */ qe(i) ? Object.defineProperty(t, n, {
      enumerable: !0,
      configurable: !0,
      get: () => i.value,
      set: (o) => i.value = o
    }) : t[n] = i;
  }
}
function ur(e, t, s) {
  dt(
    z(e) ? e.map((n) => n.bind(t.proxy)) : e.bind(t.proxy),
    t,
    s
  );
}
function Ai(e, t, s, n) {
  let r = n.includes(".") ? _i(s, n) : () => s[n];
  if (ve(e)) {
    const i = t[e];
    Z(i) && qt(r, i);
  } else if (Z(e))
    qt(r, e.bind(s));
  else if (de(e))
    if (z(e))
      e.forEach((i) => Ai(i, t, s, n));
    else {
      const i = Z(e.handler) ? e.handler.bind(s) : t[e.handler];
      Z(i) && qt(r, i, e);
    }
}
function ki(e) {
  const t = e.type, { mixins: s, extends: n } = t, {
    mixins: r,
    optionsCache: i,
    config: { optionMergeStrategies: o }
  } = e.appContext, a = i.get(t);
  let l;
  return a ? l = a : !r.length && !s && !n ? l = t : (l = {}, r.length && r.forEach(
    (f) => Ps(l, f, o, !0)
  ), Ps(l, t, o)), de(t) && i.set(t, l), l;
}
function Ps(e, t, s, n = !1) {
  const { mixins: r, extends: i } = t;
  i && Ps(e, i, s, !0), r && r.forEach(
    (o) => Ps(e, o, s, !0)
  );
  for (const o in t)
    if (!(n && o === "expose")) {
      const a = Ta[o] || s && s[o];
      e[o] = a ? a(e[o], t[o]) : t[o];
    }
  return e;
}
const Ta = {
  data: fr,
  props: dr,
  emits: dr,
  // objects
  methods: Qt,
  computed: Qt,
  // lifecycle
  beforeCreate: Ne,
  created: Ne,
  beforeMount: Ne,
  mounted: Ne,
  beforeUpdate: Ne,
  updated: Ne,
  beforeDestroy: Ne,
  beforeUnmount: Ne,
  destroyed: Ne,
  unmounted: Ne,
  activated: Ne,
  deactivated: Ne,
  errorCaptured: Ne,
  serverPrefetch: Ne,
  // assets
  components: Qt,
  directives: Qt,
  // watch
  watch: $a,
  // provide / inject
  provide: fr,
  inject: Pa
};
function fr(e, t) {
  return t ? e ? function() {
    return Se(
      Z(e) ? e.call(this, this) : e,
      Z(t) ? t.call(this, this) : t
    );
  } : t : e;
}
function Pa(e, t) {
  return Qt(yn(e), yn(t));
}
function yn(e) {
  if (z(e)) {
    const t = {};
    for (let s = 0; s < e.length; s++)
      t[e[s]] = e[s];
    return t;
  }
  return e;
}
function Ne(e, t) {
  return e ? [...new Set([].concat(e, t))] : t;
}
function Qt(e, t) {
  return e ? Se(/* @__PURE__ */ Object.create(null), e, t) : t;
}
function dr(e, t) {
  return e ? z(e) && z(t) ? [.../* @__PURE__ */ new Set([...e, ...t])] : Se(
    /* @__PURE__ */ Object.create(null),
    cr(e),
    cr(t ?? {})
  ) : t;
}
function $a(e, t) {
  if (!e) return t;
  if (!t) return e;
  const s = Se(/* @__PURE__ */ Object.create(null), e);
  for (const n in t)
    s[n] = Ne(e[n], t[n]);
  return s;
}
function Ei() {
  return {
    app: null,
    config: {
      isNativeTag: Hr,
      performance: !1,
      globalProperties: {},
      optionMergeStrategies: {},
      errorHandler: void 0,
      warnHandler: void 0,
      compilerOptions: {}
    },
    mixins: [],
    components: {},
    directives: {},
    provides: /* @__PURE__ */ Object.create(null),
    optionsCache: /* @__PURE__ */ new WeakMap(),
    propsCache: /* @__PURE__ */ new WeakMap(),
    emitsCache: /* @__PURE__ */ new WeakMap()
  };
}
let Ra = 0;
function Oa(e, t) {
  return function(n, r = null) {
    Z(n) || (n = Se({}, n)), r != null && !de(r) && (r = null);
    const i = Ei(), o = /* @__PURE__ */ new WeakSet(), a = [];
    let l = !1;
    const f = i.app = {
      _uid: Ra++,
      _component: n,
      _props: r,
      _container: null,
      _context: i,
      _instance: null,
      version: fl,
      get config() {
        return i.config;
      },
      set config(c) {
      },
      use(c, ...d) {
        return o.has(c) || (c && Z(c.install) ? (o.add(c), c.install(f, ...d)) : Z(c) && (o.add(c), c(f, ...d))), f;
      },
      mixin(c) {
        return i.mixins.includes(c) || i.mixins.push(c), f;
      },
      component(c, d) {
        return d ? (i.components[c] = d, f) : i.components[c];
      },
      directive(c, d) {
        return d ? (i.directives[c] = d, f) : i.directives[c];
      },
      mount(c, d, g) {
        if (!l) {
          const _ = f._ceVNode || Me(n, r);
          return _.appContext = i, g === !0 ? g = "svg" : g === !1 && (g = void 0), e(_, c, g), l = !0, f._container = c, c.__vue_app__ = f, zs(_.component);
        }
      },
      onUnmount(c) {
        a.push(c);
      },
      unmount() {
        l && (dt(
          a,
          f._instance,
          16
        ), e(null, f._container), delete f._container.__vue_app__);
      },
      provide(c, d) {
        return i.provides[c] = d, f;
      },
      runWithContext(c) {
        const d = Vt;
        Vt = f;
        try {
          return c();
        } finally {
          Vt = d;
        }
      }
    };
    return f;
  };
}
let Vt = null;
const Ma = (e, t) => t === "modelValue" || t === "model-value" ? e.modelModifiers : e[`${t}Modifiers`] || e[`${Ae(t)}Modifiers`] || e[`${Ge(t)}Modifiers`];
function qa(e, t, ...s) {
  if (e.isUnmounted) return;
  const n = e.vnode.props || pe;
  let r = s;
  const i = t.startsWith("update:"), o = i && Ma(n, t.slice(7));
  o && (o.trim && (r = s.map((c) => ve(c) ? c.trim() : c)), o.number && (r = s.map(kn)));
  let a, l = n[a = Js(t)] || // also try camelCase event handler (#2249)
  n[a = Js(Ae(t))];
  !l && i && (l = n[a = Js(Ge(t))]), l && dt(
    l,
    e,
    6,
    r
  );
  const f = n[a + "Once"];
  if (f) {
    if (!e.emitted)
      e.emitted = {};
    else if (e.emitted[a])
      return;
    e.emitted[a] = !0, dt(
      f,
      e,
      6,
      r
    );
  }
}
const ja = /* @__PURE__ */ new WeakMap();
function Ti(e, t, s = !1) {
  const n = s ? ja : t.emitsCache, r = n.get(e);
  if (r !== void 0)
    return r;
  const i = e.emits;
  let o = {}, a = !1;
  if (!Z(e)) {
    const l = (f) => {
      const c = Ti(f, t, !0);
      c && (a = !0, Se(o, c));
    };
    !s && t.mixins.length && t.mixins.forEach(l), e.extends && l(e.extends), e.mixins && e.mixins.forEach(l);
  }
  return !i && !a ? (de(e) && n.set(e, null), null) : (z(i) ? i.forEach((l) => o[l] = null) : Se(o, i), de(e) && n.set(e, o), o);
}
function Vs(e, t) {
  return !e || !Ms(t) ? !1 : (t = t.slice(2).replace(/Once$/, ""), ce(e, t[0].toLowerCase() + t.slice(1)) || ce(e, Ge(t)) || ce(e, t));
}
function hr(e) {
  const {
    type: t,
    vnode: s,
    proxy: n,
    withProxy: r,
    propsOptions: [i],
    slots: o,
    attrs: a,
    emit: l,
    render: f,
    renderCache: c,
    props: d,
    data: g,
    setupState: _,
    ctx: M,
    inheritAttrs: p
  } = e, $ = ks(e);
  let K, E;
  try {
    if (s.shapeFlag & 4) {
      const R = r || n, B = R;
      K = ct(
        f.call(
          B,
          R,
          c,
          d,
          _,
          g,
          M
        )
      ), E = a;
    } else {
      const R = t;
      K = ct(
        R.length > 1 ? R(
          d,
          { attrs: a, slots: o, emit: l }
        ) : R(
          d,
          null
        )
      ), E = t.props ? a : Na(a);
    }
  } catch (R) {
    rs.length = 0, Bs(R, e, 1), K = Me(xt);
  }
  let L = K;
  if (E && p !== !1) {
    const R = Object.keys(E), { shapeFlag: B } = L;
    R.length && B & 7 && (i && R.some(qs) && (E = Fa(
      E,
      i
    )), L = zt(L, E, !1, !0));
  }
  return s.dirs && (L = zt(L, null, !1, !0), L.dirs = L.dirs ? L.dirs.concat(s.dirs) : s.dirs), s.transition && Fn(L, s.transition), K = L, ks($), K;
}
const Na = (e) => {
  let t;
  for (const s in e)
    (s === "class" || s === "style" || Ms(s)) && ((t || (t = {}))[s] = e[s]);
  return t;
}, Fa = (e, t) => {
  const s = {};
  for (const n in e)
    (!qs(n) || !(n.slice(9) in t)) && (s[n] = e[n]);
  return s;
};
function Da(e, t, s) {
  const { props: n, children: r, component: i } = e, { props: o, children: a, patchFlag: l } = t, f = i.emitsOptions;
  if (t.dirs || t.transition)
    return !0;
  if (s && l >= 0) {
    if (l & 1024)
      return !0;
    if (l & 16)
      return n ? pr(n, o, f) : !!o;
    if (l & 8) {
      const c = t.dynamicProps;
      for (let d = 0; d < c.length; d++) {
        const g = c[d];
        if (Pi(o, n, g) && !Vs(f, g))
          return !0;
      }
    }
  } else
    return (r || a) && (!a || !a.$stable) ? !0 : n === o ? !1 : n ? o ? pr(n, o, f) : !0 : !!o;
  return !1;
}
function pr(e, t, s) {
  const n = Object.keys(t);
  if (n.length !== Object.keys(e).length)
    return !0;
  for (let r = 0; r < n.length; r++) {
    const i = n[r];
    if (Pi(t, e, i) && !Vs(s, i))
      return !0;
  }
  return !1;
}
function Pi(e, t, s) {
  const n = e[s], r = t[s];
  return s === "style" && de(n) && de(r) ? !jt(n, r) : n !== r;
}
function Ka({ vnode: e, parent: t, suspense: s }, n) {
  for (; t; ) {
    const r = t.subTree;
    if (r.suspense && r.suspense.activeBranch === e && (r.suspense.vnode.el = r.el = n, e = r), r === e)
      (e = t.vnode).el = n, t = t.parent;
    else
      break;
  }
  s && s.activeBranch === e && (s.vnode.el = n);
}
const $i = {}, Ri = () => Object.create($i), Oi = (e) => Object.getPrototypeOf(e) === $i;
function La(e, t, s, n = !1) {
  const r = {}, i = Ri();
  e.propsDefaults = /* @__PURE__ */ Object.create(null), Mi(e, t, r, i);
  for (const o in e.propsOptions[0])
    o in r || (r[o] = void 0);
  s ? e.props = n ? r : /* @__PURE__ */ zo(r) : e.type.props ? e.props = r : e.props = i, e.attrs = i;
}
function Ua(e, t, s, n) {
  const {
    props: r,
    attrs: i,
    vnode: { patchFlag: o }
  } = e, a = /* @__PURE__ */ ue(r), [l] = e.propsOptions;
  let f = !1;
  if (
    // always force full diff in dev
    // - #1942 if hmr is enabled with sfc component
    // - vite#872 non-sfc component used by sfc component
    (n || o > 0) && !(o & 16)
  ) {
    if (o & 8) {
      const c = e.vnode.dynamicProps;
      for (let d = 0; d < c.length; d++) {
        let g = c[d];
        if (Vs(e.emitsOptions, g))
          continue;
        const _ = t[g];
        if (l)
          if (ce(i, g))
            _ !== i[g] && (i[g] = _, f = !0);
          else {
            const M = Ae(g);
            r[M] = bn(
              l,
              a,
              M,
              _,
              e,
              !1
            );
          }
        else
          _ !== i[g] && (i[g] = _, f = !0);
      }
    }
  } else {
    Mi(e, t, r, i) && (f = !0);
    let c;
    for (const d in a)
      (!t || // for camelCase
      !ce(t, d) && // it's possible the original props was passed in as kebab-case
      // and converted to camelCase (#955)
      ((c = Ge(d)) === d || !ce(t, c))) && (l ? s && // for camelCase
      (s[d] !== void 0 || // for kebab-case
      s[c] !== void 0) && (r[d] = bn(
        l,
        a,
        d,
        void 0,
        e,
        !0
      )) : delete r[d]);
    if (i !== a)
      for (const d in i)
        (!t || !ce(t, d)) && (delete i[d], f = !0);
  }
  f && bt(e.attrs, "set", "");
}
function Mi(e, t, s, n) {
  const [r, i] = e.propsOptions;
  let o = !1, a;
  if (t)
    for (let l in t) {
      if (Zt(l))
        continue;
      const f = t[l];
      let c;
      r && ce(r, c = Ae(l)) ? !i || !i.includes(c) ? s[c] = f : (a || (a = {}))[c] = f : Vs(e.emitsOptions, l) || (!(l in n) || f !== n[l]) && (n[l] = f, o = !0);
    }
  if (i) {
    const l = /* @__PURE__ */ ue(s), f = a || pe;
    for (let c = 0; c < i.length; c++) {
      const d = i[c];
      s[d] = bn(
        r,
        l,
        d,
        f[d],
        e,
        !ce(f, d)
      );
    }
  }
  return o;
}
function bn(e, t, s, n, r, i) {
  const o = e[s];
  if (o != null) {
    const a = ce(o, "default");
    if (a && n === void 0) {
      const l = o.default;
      if (o.type !== Function && !o.skipFactory && Z(l)) {
        const { propsDefaults: f } = r;
        if (s in f)
          n = f[s];
        else {
          const c = gs(r);
          n = f[s] = l.call(
            null,
            t
          ), c();
        }
      } else
        n = l;
      r.ce && r.ce._setProp(s, n);
    }
    o[
      0
      /* shouldCast */
    ] && (i && !a ? n = !1 : o[
      1
      /* shouldCastTrue */
    ] && (n === "" || n === Ge(s)) && (n = !0));
  }
  return n;
}
const Ba = /* @__PURE__ */ new WeakMap();
function qi(e, t, s = !1) {
  const n = s ? Ba : t.propsCache, r = n.get(e);
  if (r)
    return r;
  const i = e.props, o = {}, a = [];
  let l = !1;
  if (!Z(e)) {
    const c = (d) => {
      l = !0;
      const [g, _] = qi(d, t, !0);
      Se(o, g), _ && a.push(..._);
    };
    !s && t.mixins.length && t.mixins.forEach(c), e.extends && c(e.extends), e.mixins && e.mixins.forEach(c);
  }
  if (!i && !l)
    return de(e) && n.set(e, Lt), Lt;
  if (z(i))
    for (let c = 0; c < i.length; c++) {
      const d = Ae(i[c]);
      gr(d) && (o[d] = pe);
    }
  else if (i)
    for (const c in i) {
      const d = Ae(c);
      if (gr(d)) {
        const g = i[c], _ = o[d] = z(g) || Z(g) ? { type: g } : Se({}, g), M = _.type;
        let p = !1, $ = !0;
        if (z(M))
          for (let K = 0; K < M.length; ++K) {
            const E = M[K], L = Z(E) && E.name;
            if (L === "Boolean") {
              p = !0;
              break;
            } else L === "String" && ($ = !1);
          }
        else
          p = Z(M) && M.name === "Boolean";
        _[
          0
          /* shouldCast */
        ] = p, _[
          1
          /* shouldCastTrue */
        ] = $, (p || ce(_, "default")) && a.push(d);
      }
    }
  const f = [o, a];
  return de(e) && n.set(e, f), f;
}
function gr(e) {
  return e[0] !== "$" && !Zt(e);
}
const Ln = (e) => e === "_" || e === "_ctx" || e === "$stable", Un = (e) => z(e) ? e.map(ct) : [ct(e)], Ha = (e, t, s) => {
  if (t._n)
    return t;
  const n = Es((...r) => Un(t(...r)), s);
  return n._c = !1, n;
}, ji = (e, t, s) => {
  const n = e._ctx;
  for (const r in e) {
    if (Ln(r)) continue;
    const i = e[r];
    if (Z(i))
      t[r] = Ha(r, i, n);
    else if (i != null) {
      const o = Un(i);
      t[r] = () => o;
    }
  }
}, Ni = (e, t) => {
  const s = Un(t);
  e.slots.default = () => s;
}, Fi = (e, t, s) => {
  for (const n in t)
    (s || !Ln(n)) && (e[n] = t[n]);
}, Va = (e, t, s) => {
  const n = e.slots = Ri();
  if (e.vnode.shapeFlag & 32) {
    const r = t._;
    r ? (Fi(n, t, s), s && zr(n, "_", r, !0)) : ji(t, n);
  } else t && Ni(e, t);
}, Wa = (e, t, s) => {
  const { vnode: n, slots: r } = e;
  let i = !0, o = pe;
  if (n.shapeFlag & 32) {
    const a = t._;
    a ? s && a === 1 ? i = !1 : Fi(r, t, s) : (i = !t.$stable, ji(t, r)), o = t;
  } else t && (Ni(e, t), o = { default: 1 });
  if (i)
    for (const a in r)
      !Ln(a) && o[a] == null && delete r[a];
}, Ke = Xa;
function za(e) {
  return Ja(e);
}
function Ja(e, t) {
  const s = Ks();
  s.__VUE__ = !0;
  const {
    insert: n,
    remove: r,
    patchProp: i,
    createElement: o,
    createText: a,
    createComment: l,
    setText: f,
    setElementText: c,
    parentNode: d,
    nextSibling: g,
    setScopeId: _ = ft,
    insertStaticContent: M
  } = e, p = (u, h, b, C = null, S = null, w = null, j = void 0, O = null, T = !!h.dynamicChildren) => {
    if (u === h)
      return;
    u && !Xt(u, h) && (C = oe(u), le(u, S, w, !0), u = null), h.patchFlag === -2 && (T = !1, h.dynamicChildren = null);
    const { type: I, ref: J, shapeFlag: F } = h;
    switch (I) {
      case Ws:
        $(u, h, b, C);
        break;
      case xt:
        K(u, h, b, C);
        break;
      case tn:
        u == null && E(h, b, C, j);
        break;
      case be:
        ke(
          u,
          h,
          b,
          C,
          S,
          w,
          j,
          O,
          T
        );
        break;
      default:
        F & 1 ? B(
          u,
          h,
          b,
          C,
          S,
          w,
          j,
          O,
          T
        ) : F & 6 ? q(
          u,
          h,
          b,
          C,
          S,
          w,
          j,
          O,
          T
        ) : (F & 64 || F & 128) && I.process(
          u,
          h,
          b,
          C,
          S,
          w,
          j,
          O,
          T,
          we
        );
    }
    J != null && S ? ss(J, u && u.ref, w, h || u, !h) : J == null && u && u.ref != null && ss(u.ref, null, w, u, !0);
  }, $ = (u, h, b, C) => {
    if (u == null)
      n(
        h.el = a(h.children),
        b,
        C
      );
    else {
      const S = h.el = u.el;
      h.children !== u.children && f(S, h.children);
    }
  }, K = (u, h, b, C) => {
    u == null ? n(
      h.el = l(h.children || ""),
      b,
      C
    ) : h.el = u.el;
  }, E = (u, h, b, C) => {
    [u.el, u.anchor] = M(
      u.children,
      h,
      b,
      C,
      u.el,
      u.anchor
    );
  }, L = ({ el: u, anchor: h }, b, C) => {
    let S;
    for (; u && u !== h; )
      S = g(u), n(u, b, C), u = S;
    n(h, b, C);
  }, R = ({ el: u, anchor: h }) => {
    let b;
    for (; u && u !== h; )
      b = g(u), r(u), u = b;
    r(h);
  }, B = (u, h, b, C, S, w, j, O, T) => {
    if (h.type === "svg" ? j = "svg" : h.type === "math" && (j = "mathml"), u == null)
      m(
        h,
        b,
        C,
        S,
        w,
        j,
        O,
        T
      );
    else {
      const I = u.el && u.el._isVueCE ? u.el : null;
      try {
        I && I._beginPatch(), se(
          u,
          h,
          S,
          w,
          j,
          O,
          T
        );
      } finally {
        I && I._endPatch();
      }
    }
  }, m = (u, h, b, C, S, w, j, O) => {
    let T, I;
    const { props: J, shapeFlag: F, transition: W, dirs: X } = u;
    if (T = u.el = o(
      u.type,
      w,
      J && J.is,
      J
    ), F & 8 ? c(T, u.children) : F & 16 && H(
      u.children,
      T,
      null,
      C,
      S,
      en(u, w),
      j,
      O
    ), X && Pt(u, null, C, "created"), k(T, u, u.scopeId, j, C), J) {
      for (const he in J)
        he !== "value" && !Zt(he) && i(T, he, null, J[he], w, C);
      "value" in J && i(T, "value", null, J.value, w), (I = J.onVnodeBeforeMount) && ot(I, C, u);
    }
    X && Pt(u, null, C, "beforeMount");
    const ae = Ga(S, W);
    ae && W.beforeEnter(T), n(T, h, b), ((I = J && J.onVnodeMounted) || ae || X) && Ke(() => {
      try {
        I && ot(I, C, u), ae && W.enter(T), X && Pt(u, null, C, "mounted");
      } finally {
      }
    }, S);
  }, k = (u, h, b, C, S) => {
    if (b && _(u, b), C)
      for (let w = 0; w < C.length; w++)
        _(u, C[w]);
    if (S) {
      let w = S.subTree;
      if (h === w || Ui(w.type) && (w.ssContent === h || w.ssFallback === h)) {
        const j = S.vnode;
        k(
          u,
          j,
          j.scopeId,
          j.slotScopeIds,
          S.parent
        );
      }
    }
  }, H = (u, h, b, C, S, w, j, O, T = 0) => {
    for (let I = T; I < u.length; I++) {
      const J = u[I] = O ? yt(u[I]) : ct(u[I]);
      p(
        null,
        J,
        h,
        b,
        C,
        S,
        w,
        j,
        O
      );
    }
  }, se = (u, h, b, C, S, w, j) => {
    const O = h.el = u.el;
    let { patchFlag: T, dynamicChildren: I, dirs: J } = h;
    T |= u.patchFlag & 16;
    const F = u.props || pe, W = h.props || pe;
    let X;
    if (b && $t(b, !1), (X = W.onVnodeBeforeUpdate) && ot(X, b, h, u), J && Pt(h, u, b, "beforeUpdate"), b && $t(b, !0), (F.innerHTML && W.innerHTML == null || F.textContent && W.textContent == null) && c(O, ""), I ? ne(
      u.dynamicChildren,
      I,
      O,
      b,
      C,
      en(h, S),
      w
    ) : j || re(
      u,
      h,
      O,
      null,
      b,
      C,
      en(h, S),
      w,
      !1
    ), T > 0) {
      if (T & 16)
        Pe(O, F, W, b, S);
      else if (T & 2 && F.class !== W.class && i(O, "class", null, W.class, S), T & 4 && i(O, "style", F.style, W.style, S), T & 8) {
        const ae = h.dynamicProps;
        for (let he = 0; he < ae.length; he++) {
          const me = ae[he], Ie = F[me], Ee = W[me];
          (Ee !== Ie || me === "value") && i(O, me, Ie, Ee, S, b);
        }
      }
      T & 1 && u.children !== h.children && c(O, h.children);
    } else !j && I == null && Pe(O, F, W, b, S);
    ((X = W.onVnodeUpdated) || J) && Ke(() => {
      X && ot(X, b, h, u), J && Pt(h, u, b, "updated");
    }, C);
  }, ne = (u, h, b, C, S, w, j) => {
    for (let O = 0; O < h.length; O++) {
      const T = u[O], I = h[O], J = (
        // oldVNode may be an errored async setup() component inside Suspense
        // which will not have a mounted element
        T.el && // - In the case of a Fragment, we need to provide the actual parent
        // of the Fragment itself so it can move its children.
        (T.type === be || // - In the case of different nodes, there is going to be a replacement
        // which also requires the correct parent container
        !Xt(T, I) || // - In the case of a component, it could contain anything.
        T.shapeFlag & 198) ? d(T.el) : (
          // In other cases, the parent container is not actually used so we
          // just pass the block element here to avoid a DOM parentNode call.
          b
        )
      );
      p(
        T,
        I,
        J,
        null,
        C,
        S,
        w,
        j,
        !0
      );
    }
  }, Pe = (u, h, b, C, S) => {
    if (h !== b) {
      if (h !== pe)
        for (const w in h)
          !Zt(w) && !(w in b) && i(
            u,
            w,
            h[w],
            null,
            S,
            C
          );
      for (const w in b) {
        if (Zt(w)) continue;
        const j = b[w], O = h[w];
        j !== O && w !== "value" && i(u, w, O, j, S, C);
      }
      "value" in b && i(u, "value", h.value, b.value, S);
    }
  }, ke = (u, h, b, C, S, w, j, O, T) => {
    const I = h.el = u ? u.el : a(""), J = h.anchor = u ? u.anchor : a("");
    let { patchFlag: F, dynamicChildren: W, slotScopeIds: X } = h;
    X && (O = O ? O.concat(X) : X), u == null ? (n(I, b, C), n(J, b, C), H(
      // #10007
      // such fragment like `<></>` will be compiled into
      // a fragment which doesn't have a children.
      // In this case fallback to an empty array
      h.children || [],
      b,
      J,
      S,
      w,
      j,
      O,
      T
    )) : F > 0 && F & 64 && W && // #2715 the previous fragment could've been a BAILed one as a result
    // of renderSlot() with no valid children
    u.dynamicChildren && u.dynamicChildren.length === W.length ? (ne(
      u.dynamicChildren,
      W,
      b,
      S,
      w,
      j,
      O
    ), // #2080 if the stable fragment has a key, it's a <template v-for> that may
    //  get moved around. Make sure all root level vnodes inherit el.
    // #2134 or if it's a component root, it may also get moved around
    // as the component is being moved.
    (h.key != null || S && h === S.subTree) && Di(
      u,
      h,
      !0
      /* shallow */
    )) : re(
      u,
      h,
      b,
      J,
      S,
      w,
      j,
      O,
      T
    );
  }, q = (u, h, b, C, S, w, j, O, T) => {
    h.slotScopeIds = O, u == null ? h.shapeFlag & 512 ? S.ctx.activate(
      h,
      b,
      C,
      j,
      T
    ) : U(
      h,
      b,
      C,
      S,
      w,
      j,
      T
    ) : G(u, h, T);
  }, U = (u, h, b, C, S, w, j) => {
    const O = u.component = sl(
      u,
      C,
      S
    );
    if (Si(u) && (O.ctx.renderer = we), rl(O, !1, j), O.asyncDep) {
      if (S && S.registerDep(O, Y, j), !u.el) {
        const T = O.subTree = Me(xt);
        K(null, T, h, b), u.placeholder = T.el;
      }
    } else
      Y(
        O,
        u,
        h,
        b,
        S,
        w,
        j
      );
  }, G = (u, h, b) => {
    const C = h.component = u.component;
    if (Da(u, h, b))
      if (C.asyncDep && !C.asyncResolved) {
        Q(C, h, b);
        return;
      } else
        C.next = h, C.update();
    else
      h.el = u.el, C.vnode = h;
  }, Y = (u, h, b, C, S, w, j) => {
    const O = () => {
      if (u.isMounted) {
        let { next: F, bu: W, u: X, parent: ae, vnode: he } = u;
        {
          const rt = Ki(u);
          if (rt) {
            F && (F.el = he.el, Q(u, F, j)), rt.asyncDep.then(() => {
              Ke(() => {
                u.isUnmounted || I();
              }, S);
            });
            return;
          }
        }
        let me = F, Ie;
        $t(u, !1), F ? (F.el = he.el, Q(u, F, j)) : F = he, W && Ss(W), (Ie = F.props && F.props.onVnodeBeforeUpdate) && ot(Ie, ae, F, he), $t(u, !0);
        const Ee = hr(u), nt = u.subTree;
        u.subTree = Ee, p(
          nt,
          Ee,
          // parent may have changed if it's in a teleport
          d(nt.el),
          // anchor may have changed if it's in a fragment
          oe(nt),
          u,
          S,
          w
        ), F.el = Ee.el, me === null && Ka(u, Ee.el), X && Ke(X, S), (Ie = F.props && F.props.onVnodeUpdated) && Ke(
          () => ot(Ie, ae, F, he),
          S
        );
      } else {
        let F;
        const { el: W, props: X } = h, { bm: ae, m: he, parent: me, root: Ie, type: Ee } = u, nt = Ht(h);
        $t(u, !1), ae && Ss(ae), !nt && (F = X && X.onVnodeBeforeMount) && ot(F, me, h), $t(u, !0);
        {
          Ie.ce && Ie.ce._hasShadowRoot() && Ie.ce._injectChildStyle(
            Ee,
            u.parent ? u.parent.type : void 0
          );
          const rt = u.subTree = hr(u);
          p(
            null,
            rt,
            b,
            C,
            u,
            S,
            w
          ), h.el = rt.el;
        }
        if (he && Ke(he, S), !nt && (F = X && X.onVnodeMounted)) {
          const rt = h;
          Ke(
            () => ot(F, me, rt),
            S
          );
        }
        (h.shapeFlag & 256 || me && Ht(me.vnode) && me.vnode.shapeFlag & 256) && u.a && Ke(u.a, S), u.isMounted = !0, h = b = C = null;
      }
    };
    u.scope.on();
    const T = u.effect = new Qr(O);
    u.scope.off();
    const I = u.update = T.run.bind(T), J = u.job = T.runIfDirty.bind(T);
    J.i = u, J.id = u.uid, T.scheduler = () => Nn(J), $t(u, !0), I();
  }, Q = (u, h, b) => {
    h.component = u;
    const C = u.vnode.props;
    u.vnode = h, u.next = null, Ua(u, h.props, C, b), Wa(u, h.children, b), St(), ir(u), wt();
  }, re = (u, h, b, C, S, w, j, O, T = !1) => {
    const I = u && u.children, J = u ? u.shapeFlag : 0, F = h.children, { patchFlag: W, shapeFlag: X } = h;
    if (W > 0) {
      if (W & 128) {
        je(
          I,
          F,
          b,
          C,
          S,
          w,
          j,
          O,
          T
        );
        return;
      } else if (W & 256) {
        ge(
          I,
          F,
          b,
          C,
          S,
          w,
          j,
          O,
          T
        );
        return;
      }
    }
    X & 8 ? (J & 16 && V(I, S, w), F !== I && c(b, F)) : J & 16 ? X & 16 ? je(
      I,
      F,
      b,
      C,
      S,
      w,
      j,
      O,
      T
    ) : V(I, S, w, !0) : (J & 8 && c(b, ""), X & 16 && H(
      F,
      b,
      C,
      S,
      w,
      j,
      O,
      T
    ));
  }, ge = (u, h, b, C, S, w, j, O, T) => {
    u = u || Lt, h = h || Lt;
    const I = u.length, J = h.length, F = Math.min(I, J);
    let W;
    for (W = 0; W < F; W++) {
      const X = h[W] = T ? yt(h[W]) : ct(h[W]);
      p(
        u[W],
        X,
        b,
        null,
        S,
        w,
        j,
        O,
        T
      );
    }
    I > J ? V(
      u,
      S,
      w,
      !0,
      !1,
      F
    ) : H(
      h,
      b,
      C,
      S,
      w,
      j,
      O,
      T,
      F
    );
  }, je = (u, h, b, C, S, w, j, O, T) => {
    let I = 0;
    const J = h.length;
    let F = u.length - 1, W = J - 1;
    for (; I <= F && I <= W; ) {
      const X = u[I], ae = h[I] = T ? yt(h[I]) : ct(h[I]);
      if (Xt(X, ae))
        p(
          X,
          ae,
          b,
          null,
          S,
          w,
          j,
          O,
          T
        );
      else
        break;
      I++;
    }
    for (; I <= F && I <= W; ) {
      const X = u[F], ae = h[W] = T ? yt(h[W]) : ct(h[W]);
      if (Xt(X, ae))
        p(
          X,
          ae,
          b,
          null,
          S,
          w,
          j,
          O,
          T
        );
      else
        break;
      F--, W--;
    }
    if (I > F) {
      if (I <= W) {
        const X = W + 1, ae = X < J ? h[X].el : C;
        for (; I <= W; )
          p(
            null,
            h[I] = T ? yt(h[I]) : ct(h[I]),
            b,
            ae,
            S,
            w,
            j,
            O,
            T
          ), I++;
      }
    } else if (I > W)
      for (; I <= F; )
        le(u[I], S, w, !0), I++;
    else {
      const X = I, ae = I, he = /* @__PURE__ */ new Map();
      for (I = ae; I <= W; I++) {
        const Ue = h[I] = T ? yt(h[I]) : ct(h[I]);
        Ue.key != null && he.set(Ue.key, I);
      }
      let me, Ie = 0;
      const Ee = W - ae + 1;
      let nt = !1, rt = 0;
      const Gt = new Array(Ee);
      for (I = 0; I < Ee; I++) Gt[I] = 0;
      for (I = X; I <= F; I++) {
        const Ue = u[I];
        if (Ie >= Ee) {
          le(Ue, S, w, !0);
          continue;
        }
        let it;
        if (Ue.key != null)
          it = he.get(Ue.key);
        else
          for (me = ae; me <= W; me++)
            if (Gt[me - ae] === 0 && Xt(Ue, h[me])) {
              it = me;
              break;
            }
        it === void 0 ? le(Ue, S, w, !0) : (Gt[it - ae] = I + 1, it >= rt ? rt = it : nt = !0, p(
          Ue,
          h[it],
          b,
          null,
          S,
          w,
          j,
          O,
          T
        ), Ie++);
      }
      const Xn = nt ? Ya(Gt) : Lt;
      for (me = Xn.length - 1, I = Ee - 1; I >= 0; I--) {
        const Ue = ae + I, it = h[Ue], Qn = h[Ue + 1], Zn = Ue + 1 < J ? (
          // #13559, #14173 fallback to el placeholder for unresolved async component
          Qn.el || Li(Qn)
        ) : C;
        Gt[I] === 0 ? p(
          null,
          it,
          b,
          Zn,
          S,
          w,
          j,
          O,
          T
        ) : nt && (me < 0 || I !== Xn[me] ? xe(it, b, Zn, 2) : me--);
      }
    }
  }, xe = (u, h, b, C, S = null) => {
    const { el: w, type: j, transition: O, children: T, shapeFlag: I } = u;
    if (I & 6) {
      xe(u.component.subTree, h, b, C);
      return;
    }
    if (I & 128) {
      u.suspense.move(h, b, C);
      return;
    }
    if (I & 64) {
      j.move(u, h, b, we);
      return;
    }
    if (j === be) {
      n(w, h, b);
      for (let F = 0; F < T.length; F++)
        xe(T[F], h, b, C);
      n(u.anchor, h, b);
      return;
    }
    if (j === tn) {
      L(u, h, b);
      return;
    }
    if (C !== 2 && I & 1 && O)
      if (C === 0)
        O.beforeEnter(w), n(w, h, b), Ke(() => O.enter(w), S);
      else {
        const { leave: F, delayLeave: W, afterLeave: X } = O, ae = () => {
          u.ctx.isUnmounted ? r(w) : n(w, h, b);
        }, he = () => {
          w._isLeaving && w[fa](
            !0
            /* cancelled */
          ), F(w, () => {
            ae(), X && X();
          });
        };
        W ? W(w, ae, he) : he();
      }
    else
      n(w, h, b);
  }, le = (u, h, b, C = !1, S = !1) => {
    const {
      type: w,
      props: j,
      ref: O,
      children: T,
      dynamicChildren: I,
      shapeFlag: J,
      patchFlag: F,
      dirs: W,
      cacheIndex: X,
      memo: ae
    } = u;
    if (F === -2 && (S = !1), O != null && (St(), ss(O, null, b, u, !0), wt()), X != null && (h.renderCache[X] = void 0), J & 256) {
      h.ctx.deactivate(u);
      return;
    }
    const he = J & 1 && W, me = !Ht(u);
    let Ie;
    if (me && (Ie = j && j.onVnodeBeforeUnmount) && ot(Ie, h, u), J & 6)
      v(u.component, b, C);
    else {
      if (J & 128) {
        u.suspense.unmount(b, C);
        return;
      }
      he && Pt(u, null, h, "beforeUnmount"), J & 64 ? u.type.remove(
        u,
        h,
        b,
        we,
        C
      ) : I && // #5154
      // when v-once is used inside a block, setBlockTracking(-1) marks the
      // parent block with hasOnce: true
      // so that it doesn't take the fast path during unmount - otherwise
      // components nested in v-once are never unmounted.
      !I.hasOnce && // #1153: fast path should not be taken for non-stable (v-for) fragments
      (w !== be || F > 0 && F & 64) ? V(
        I,
        h,
        b,
        !1,
        !0
      ) : (w === be && F & 384 || !S && J & 16) && V(T, h, b), C && D(u);
    }
    const Ee = ae != null && X == null;
    (me && (Ie = j && j.onVnodeUnmounted) || he || Ee) && Ke(() => {
      Ie && ot(Ie, h, u), he && Pt(u, null, h, "unmounted"), Ee && (u.el = null);
    }, b);
  }, D = (u) => {
    const { type: h, el: b, anchor: C, transition: S } = u;
    if (h === be) {
      y(b, C);
      return;
    }
    if (h === tn) {
      R(u);
      return;
    }
    const w = () => {
      r(b), S && !S.persisted && S.afterLeave && S.afterLeave();
    };
    if (u.shapeFlag & 1 && S && !S.persisted) {
      const { leave: j, delayLeave: O } = S, T = () => j(b, w);
      O ? O(u.el, w, T) : T();
    } else
      w();
  }, y = (u, h) => {
    let b;
    for (; u !== h; )
      b = g(u), r(u), u = b;
    r(h);
  }, v = (u, h, b) => {
    const { bum: C, scope: S, job: w, subTree: j, um: O, m: T, a: I } = u;
    mr(T), mr(I), C && Ss(C), S.stop(), w && (w.flags |= 8, le(j, u, h, b)), O && Ke(O, h), Ke(() => {
      u.isUnmounted = !0;
    }, h);
  }, V = (u, h, b, C = !1, S = !1, w = 0) => {
    for (let j = w; j < u.length; j++)
      le(u[j], h, b, C, S);
  }, oe = (u) => {
    if (u.shapeFlag & 6)
      return oe(u.component.subTree);
    if (u.shapeFlag & 128)
      return u.suspense.next();
    const h = g(u.anchor || u.el), b = h && h[ca];
    return b ? g(b) : h;
  };
  let P = !1;
  const ee = (u, h, b) => {
    let C;
    u == null ? h._vnode && (le(h._vnode, null, null, !0), C = h._vnode.component) : p(
      h._vnode || null,
      u,
      h,
      null,
      null,
      null,
      b
    ), h._vnode = u, P || (P = !0, ir(C), gi(), P = !1);
  }, we = {
    p,
    um: le,
    m: xe,
    r: D,
    mt: U,
    mc: H,
    pc: re,
    pbc: ne,
    n: oe,
    o: e
  };
  return {
    render: ee,
    hydrate: void 0,
    createApp: Oa(ee)
  };
}
function en({ type: e, props: t }, s) {
  return s === "svg" && e === "foreignObject" || s === "mathml" && e === "annotation-xml" && t && t.encoding && t.encoding.includes("html") ? void 0 : s;
}
function $t({ effect: e, job: t }, s) {
  s ? (e.flags |= 32, t.flags |= 4) : (e.flags &= -33, t.flags &= -5);
}
function Ga(e, t) {
  return (!e || e && !e.pendingBranch) && t && !t.persisted;
}
function Di(e, t, s = !1) {
  const n = e.children, r = t.children;
  if (z(n) && z(r))
    for (let i = 0; i < n.length; i++) {
      const o = n[i];
      let a = r[i];
      a.shapeFlag & 1 && !a.dynamicChildren && ((a.patchFlag <= 0 || a.patchFlag === 32) && (a = r[i] = yt(r[i]), a.el = o.el), !s && a.patchFlag !== -2 && Di(o, a)), a.type === Ws && (a.patchFlag === -1 && (a = r[i] = yt(a)), a.el = o.el), a.type === xt && !a.el && (a.el = o.el);
    }
}
function Ya(e) {
  const t = e.slice(), s = [0];
  let n, r, i, o, a;
  const l = e.length;
  for (n = 0; n < l; n++) {
    const f = e[n];
    if (f !== 0) {
      if (r = s[s.length - 1], e[r] < f) {
        t[n] = r, s.push(n);
        continue;
      }
      for (i = 0, o = s.length - 1; i < o; )
        a = i + o >> 1, e[s[a]] < f ? i = a + 1 : o = a;
      f < e[s[i]] && (i > 0 && (t[n] = s[i - 1]), s[i] = n);
    }
  }
  for (i = s.length, o = s[i - 1]; i-- > 0; )
    s[i] = o, o = t[o];
  return s;
}
function Ki(e) {
  const t = e.subTree.component;
  if (t)
    return t.asyncDep && !t.asyncResolved ? t : Ki(t);
}
function mr(e) {
  if (e)
    for (let t = 0; t < e.length; t++)
      e[t].flags |= 8;
}
function Li(e) {
  if (e.placeholder)
    return e.placeholder;
  const t = e.component;
  return t ? Li(t.subTree) : null;
}
const Ui = (e) => e.__isSuspense;
function Xa(e, t) {
  t && t.pendingBranch ? z(e) ? t.effects.push(...e) : t.effects.push(e) : ra(e);
}
const be = /* @__PURE__ */ Symbol.for("v-fgt"), Ws = /* @__PURE__ */ Symbol.for("v-txt"), xt = /* @__PURE__ */ Symbol.for("v-cmt"), tn = /* @__PURE__ */ Symbol.for("v-stc"), rs = [];
let We = null;
function x(e = !1) {
  rs.push(We = e ? null : []);
}
function Qa() {
  rs.pop(), We = rs[rs.length - 1] || null;
}
let ls = 1;
function $s(e, t = !1) {
  ls += e, e < 0 && We && t && (We.hasOnce = !0);
}
function Bi(e) {
  return e.dynamicChildren = ls > 0 ? We || Lt : null, Qa(), ls > 0 && We && We.push(e), e;
}
function A(e, t, s, n, r, i) {
  return Bi(
    N(
      e,
      t,
      s,
      n,
      r,
      i,
      !0
    )
  );
}
function st(e, t, s, n, r) {
  return Bi(
    Me(
      e,
      t,
      s,
      n,
      r,
      !0
    )
  );
}
function cs(e) {
  return e ? e.__v_isVNode === !0 : !1;
}
function Xt(e, t) {
  return e.type === t.type && e.key === t.key;
}
const Hi = ({ key: e }) => e ?? null, Is = ({
  ref: e,
  ref_key: t,
  ref_for: s
}) => (typeof e == "number" && (e = "" + e), e != null ? ve(e) || /* @__PURE__ */ qe(e) || Z(e) ? { i: Te, r: e, k: t, f: !!s } : e : null);
function N(e, t = null, s = null, n = 0, r = null, i = e === be ? 0 : 1, o = !1, a = !1) {
  const l = {
    __v_isVNode: !0,
    __v_skip: !0,
    type: e,
    props: t,
    key: t && Hi(t),
    ref: t && Is(t),
    scopeId: yi,
    slotScopeIds: null,
    children: s,
    component: null,
    suspense: null,
    ssContent: null,
    ssFallback: null,
    dirs: null,
    transition: null,
    el: null,
    anchor: null,
    target: null,
    targetStart: null,
    targetAnchor: null,
    staticCount: 0,
    shapeFlag: i,
    patchFlag: n,
    dynamicProps: r,
    dynamicChildren: null,
    appContext: null,
    ctx: Te
  };
  return a ? (Bn(l, s), i & 128 && e.normalize(l)) : s && (l.shapeFlag |= ve(s) ? 8 : 16), ls > 0 && // avoid a block node from tracking itself
  !o && // has current parent block
  We && // presence of a patch flag indicates this node needs patching on updates.
  // component nodes also should always be patched, because even if the
  // component doesn't need to update, it needs to persist the instance on to
  // the next vnode so that it can be properly unmounted later.
  (l.patchFlag > 0 || i & 6) && // the EVENTS flag is only for hydration and if it is the only flag, the
  // vnode should not be considered dynamic due to handler caching.
  l.patchFlag !== 32 && We.push(l), l;
}
const Me = Za;
function Za(e, t = null, s = null, n = 0, r = null, i = !1) {
  if ((!e || e === Ii) && (e = xt), cs(e)) {
    const a = zt(
      e,
      t,
      !0
      /* mergeRef: true */
    );
    return s && Bn(a, s), ls > 0 && !i && We && (a.shapeFlag & 6 ? We[We.indexOf(e)] = a : We.push(a)), a.patchFlag = -2, a;
  }
  if (cl(e) && (e = e.__vccOpts), t) {
    t = Vi(t);
    let { class: a, style: l } = t;
    a && !ve(a) && (t.class = Ye(a)), de(l) && (/* @__PURE__ */ Mn(l) && !z(l) && (l = Se({}, l)), t.style = hs(l));
  }
  const o = ve(e) ? 1 : Ui(e) ? 128 : ua(e) ? 64 : de(e) ? 4 : Z(e) ? 2 : 0;
  return N(
    e,
    t,
    s,
    n,
    r,
    o,
    i,
    !0
  );
}
function Vi(e) {
  return e ? /* @__PURE__ */ Mn(e) || Oi(e) ? Se({}, e) : e : null;
}
function zt(e, t, s = !1, n = !1) {
  const { props: r, ref: i, patchFlag: o, children: a, transition: l } = e, f = t ? Wi(r || {}, t) : r, c = {
    __v_isVNode: !0,
    __v_skip: !0,
    type: e.type,
    props: f,
    key: f && Hi(f),
    ref: t && t.ref ? (
      // #2078 in the case of <component :is="vnode" ref="extra"/>
      // if the vnode itself already has a ref, cloneVNode will need to merge
      // the refs so the single vnode can be set on multiple refs
      s && i ? z(i) ? i.concat(Is(t)) : [i, Is(t)] : Is(t)
    ) : i,
    scopeId: e.scopeId,
    slotScopeIds: e.slotScopeIds,
    children: a,
    target: e.target,
    targetStart: e.targetStart,
    targetAnchor: e.targetAnchor,
    staticCount: e.staticCount,
    shapeFlag: e.shapeFlag,
    // if the vnode is cloned with extra props, we can no longer assume its
    // existing patch flag to be reliable and need to add the FULL_PROPS flag.
    // note: preserve flag for fragments since they use the flag for children
    // fast paths only.
    patchFlag: t && e.type !== be ? o === -1 ? 16 : o | 16 : o,
    dynamicProps: e.dynamicProps,
    dynamicChildren: e.dynamicChildren,
    appContext: e.appContext,
    dirs: e.dirs,
    transition: l,
    // These should technically only be non-null on mounted VNodes. However,
    // they *should* be copied for kept-alive vnodes. So we just always copy
    // them since them being non-null during a mount doesn't affect the logic as
    // they will simply be overwritten.
    component: e.component,
    suspense: e.suspense,
    ssContent: e.ssContent && zt(e.ssContent),
    ssFallback: e.ssFallback && zt(e.ssFallback),
    placeholder: e.placeholder,
    el: e.el,
    anchor: e.anchor,
    ctx: e.ctx,
    ce: e.ce
  };
  return l && n && Fn(
    c,
    l.clone(c)
  ), c;
}
function us(e = " ", t = 0) {
  return Me(Ws, null, e, t);
}
function ie(e = "", t = !1) {
  return t ? (x(), st(xt, null, e)) : Me(xt, null, e);
}
function ct(e) {
  return e == null || typeof e == "boolean" ? Me(xt) : z(e) ? Me(
    be,
    null,
    // #3666, avoid reference pollution when reusing vnode
    e.slice()
  ) : cs(e) ? yt(e) : Me(Ws, null, String(e));
}
function yt(e) {
  return e.el === null && e.patchFlag !== -1 || e.memo ? e : zt(e);
}
function Bn(e, t) {
  let s = 0;
  const { shapeFlag: n } = e;
  if (t == null)
    t = null;
  else if (z(t))
    s = 16;
  else if (typeof t == "object")
    if (n & 65) {
      const r = t.default;
      r && (r._c && (r._d = !1), Bn(e, r()), r._c && (r._d = !0));
      return;
    } else {
      s = 32;
      const r = t._;
      !r && !Oi(t) ? t._ctx = Te : r === 3 && Te && (Te.slots._ === 1 ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024));
    }
  else Z(t) ? (t = { default: t, _ctx: Te }, s = 32) : (t = String(t), n & 64 ? (s = 16, t = [us(t)]) : s = 8);
  e.children = t, e.shapeFlag |= s;
}
function Wi(...e) {
  const t = {};
  for (let s = 0; s < e.length; s++) {
    const n = e[s];
    for (const r in n)
      if (r === "class")
        t.class !== n.class && (t.class = Ye([t.class, n.class]));
      else if (r === "style")
        t.style = hs([t.style, n.style]);
      else if (Ms(r)) {
        const i = t[r], o = n[r];
        o && i !== o && !(z(i) && i.includes(o)) ? t[r] = i ? [].concat(i, o) : o : o == null && i == null && // mergeProps({ 'onUpdate:modelValue': undefined }) should not retain
        // the model listener.
        !qs(r) && (t[r] = o);
      } else r !== "" && (t[r] = n[r]);
  }
  return t;
}
function ot(e, t, s, n = null) {
  dt(e, t, 7, [
    s,
    n
  ]);
}
const el = Ei();
let tl = 0;
function sl(e, t, s) {
  const n = e.type, r = (t ? t.appContext : e.appContext) || el, i = {
    uid: tl++,
    vnode: e,
    type: n,
    parent: t,
    appContext: r,
    root: null,
    // to be immediately set
    next: null,
    subTree: null,
    // will be set synchronously right after creation
    effect: null,
    update: null,
    // will be set synchronously right after creation
    job: null,
    scope: new ko(
      !0
      /* detached */
    ),
    render: null,
    proxy: null,
    exposed: null,
    exposeProxy: null,
    withProxy: null,
    provides: t ? t.provides : Object.create(r.provides),
    ids: t ? t.ids : ["", 0, 0],
    accessCache: null,
    renderCache: [],
    // local resolved assets
    components: null,
    directives: null,
    // resolved props and emits options
    propsOptions: qi(n, r),
    emitsOptions: Ti(n, r),
    // emit
    emit: null,
    // to be set immediately
    emitted: null,
    // props default value
    propsDefaults: pe,
    // inheritAttrs
    inheritAttrs: n.inheritAttrs,
    // state
    ctx: pe,
    data: pe,
    props: pe,
    attrs: pe,
    slots: pe,
    refs: pe,
    setupState: pe,
    setupContext: null,
    // suspense related
    suspense: s,
    suspenseId: s ? s.pendingId : 0,
    asyncDep: null,
    asyncResolved: !1,
    // lifecycle hooks
    // not using enums here because it results in computed properties
    isMounted: !1,
    isUnmounted: !1,
    isDeactivated: !1,
    bc: null,
    c: null,
    bm: null,
    m: null,
    bu: null,
    u: null,
    um: null,
    bum: null,
    da: null,
    a: null,
    rtg: null,
    rtc: null,
    ec: null,
    sp: null
  };
  return i.ctx = { _: i }, i.root = t ? t.root : i, i.emit = qa.bind(null, i), e.ce && e.ce(i), i;
}
let Oe = null;
const nl = () => Oe || Te;
let Rs, _n;
{
  const e = Ks(), t = (s, n) => {
    let r;
    return (r = e[s]) || (r = e[s] = []), r.push(n), (i) => {
      r.length > 1 ? r.forEach((o) => o(i)) : r[0](i);
    };
  };
  Rs = t(
    "__VUE_INSTANCE_SETTERS__",
    (s) => Oe = s
  ), _n = t(
    "__VUE_SSR_SETTERS__",
    (s) => fs = s
  );
}
const gs = (e) => {
  const t = Oe;
  return Rs(e), e.scope.on(), () => {
    e.scope.off(), Rs(t);
  };
}, yr = () => {
  Oe && Oe.scope.off(), Rs(null);
};
function zi(e) {
  return e.vnode.shapeFlag & 4;
}
let fs = !1;
function rl(e, t = !1, s = !1) {
  t && _n(t);
  const { props: n, children: r } = e.vnode, i = zi(e);
  La(e, n, i, t), Va(e, r, s || t);
  const o = i ? il(e, t) : void 0;
  return t && _n(!1), o;
}
function il(e, t) {
  const s = e.type;
  e.accessCache = /* @__PURE__ */ Object.create(null), e.proxy = new Proxy(e.ctx, Aa);
  const { setup: n } = s;
  if (n) {
    St();
    const r = e.setupContext = n.length > 1 ? al(e) : null, i = gs(e), o = ps(
      n,
      e,
      0,
      [
        e.props,
        r
      ]
    ), a = Vr(o);
    if (wt(), i(), (a || e.sp) && !Ht(e) && vi(e), a) {
      if (o.then(yr, yr), t)
        return o.then((l) => {
          br(e, l);
        }).catch((l) => {
          Bs(l, e, 0);
        });
      e.asyncDep = o;
    } else
      br(e, o);
  } else
    Ji(e);
}
function br(e, t, s) {
  Z(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : de(t) && (e.setupState = di(t)), Ji(e);
}
function Ji(e, t, s) {
  const n = e.type;
  e.render || (e.render = n.render || ft);
  {
    const r = gs(e);
    St();
    try {
      ka(e);
    } finally {
      wt(), r();
    }
  }
}
const ol = {
  get(e, t) {
    return Re(e, "get", ""), e[t];
  }
};
function al(e) {
  const t = (s) => {
    e.exposed = s || {};
  };
  return {
    attrs: new Proxy(e.attrs, ol),
    slots: e.slots,
    emit: e.emit,
    expose: t
  };
}
function zs(e) {
  return e.exposed ? e.exposeProxy || (e.exposeProxy = new Proxy(di(Jo(e.exposed)), {
    get(t, s) {
      if (s in t)
        return t[s];
      if (s in ns)
        return ns[s](e);
    },
    has(t, s) {
      return s in t || s in ns;
    }
  })) : e.proxy;
}
function ll(e, t = !0) {
  return Z(e) ? e.displayName || e.name : e.name || t && e.__name;
}
function cl(e) {
  return Z(e) && "__vccOpts" in e;
}
const fe = (e, t) => /* @__PURE__ */ Zo(e, t, fs);
function ul(e, t, s) {
  try {
    $s(-1);
    const n = arguments.length;
    return n === 2 ? de(t) && !z(t) ? cs(t) ? Me(e, null, [t]) : Me(e, t) : Me(e, null, t) : (n > 3 ? s = Array.prototype.slice.call(arguments, 2) : n === 3 && cs(s) && (s = [s]), Me(e, t, s));
  } finally {
    $s(1);
  }
}
const fl = "3.5.31";
/**
* @vue/runtime-dom v3.5.31
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
let vn;
const _r = typeof window < "u" && window.trustedTypes;
if (_r)
  try {
    vn = /* @__PURE__ */ _r.createPolicy("vue", {
      createHTML: (e) => e
    });
  } catch {
  }
const Gi = vn ? (e) => vn.createHTML(e) : (e) => e, dl = "http://www.w3.org/2000/svg", hl = "http://www.w3.org/1998/Math/MathML", mt = typeof document < "u" ? document : null, vr = mt && /* @__PURE__ */ mt.createElement("template"), pl = {
  insert: (e, t, s) => {
    t.insertBefore(e, s || null);
  },
  remove: (e) => {
    const t = e.parentNode;
    t && t.removeChild(e);
  },
  createElement: (e, t, s, n) => {
    const r = t === "svg" ? mt.createElementNS(dl, e) : t === "mathml" ? mt.createElementNS(hl, e) : s ? mt.createElement(e, { is: s }) : mt.createElement(e);
    return e === "select" && n && n.multiple != null && r.setAttribute("multiple", n.multiple), r;
  },
  createText: (e) => mt.createTextNode(e),
  createComment: (e) => mt.createComment(e),
  setText: (e, t) => {
    e.nodeValue = t;
  },
  setElementText: (e, t) => {
    e.textContent = t;
  },
  parentNode: (e) => e.parentNode,
  nextSibling: (e) => e.nextSibling,
  querySelector: (e) => mt.querySelector(e),
  setScopeId(e, t) {
    e.setAttribute(t, "");
  },
  // __UNSAFE__
  // Reason: innerHTML.
  // Static content here can only come from compiled templates.
  // As long as the user only uses trusted templates, this is safe.
  insertStaticContent(e, t, s, n, r, i) {
    const o = s ? s.previousSibling : t.lastChild;
    if (r && (r === i || r.nextSibling))
      for (; t.insertBefore(r.cloneNode(!0), s), !(r === i || !(r = r.nextSibling)); )
        ;
    else {
      vr.innerHTML = Gi(
        n === "svg" ? `<svg>${e}</svg>` : n === "mathml" ? `<math>${e}</math>` : e
      );
      const a = vr.content;
      if (n === "svg" || n === "mathml") {
        const l = a.firstChild;
        for (; l.firstChild; )
          a.appendChild(l.firstChild);
        a.removeChild(l);
      }
      t.insertBefore(a, s);
    }
    return [
      // first
      o ? o.nextSibling : t.firstChild,
      // last
      s ? s.previousSibling : t.lastChild
    ];
  }
}, gl = /* @__PURE__ */ Symbol("_vtc");
function ml(e, t, s) {
  const n = e[gl];
  n && (t = (t ? [t, ...n] : [...n]).join(" ")), t == null ? e.removeAttribute("class") : s ? e.setAttribute("class", t) : e.className = t;
}
const Sr = /* @__PURE__ */ Symbol("_vod"), yl = /* @__PURE__ */ Symbol("_vsh"), bl = /* @__PURE__ */ Symbol(""), _l = /(?:^|;)\s*display\s*:/;
function vl(e, t, s) {
  const n = e.style, r = ve(s);
  let i = !1;
  if (s && !r) {
    if (t)
      if (ve(t))
        for (const o of t.split(";")) {
          const a = o.slice(0, o.indexOf(":")).trim();
          s[a] == null && xs(n, a, "");
        }
      else
        for (const o in t)
          s[o] == null && xs(n, o, "");
    for (const o in s)
      o === "display" && (i = !0), xs(n, o, s[o]);
  } else if (r) {
    if (t !== s) {
      const o = n[bl];
      o && (s += ";" + o), n.cssText = s, i = _l.test(s);
    }
  } else t && e.removeAttribute("style");
  Sr in e && (e[Sr] = i ? n.display : "", e[yl] && (n.display = "none"));
}
const wr = /\s*!important$/;
function xs(e, t, s) {
  if (z(s))
    s.forEach((n) => xs(e, t, n));
  else if (s == null && (s = ""), t.startsWith("--"))
    e.setProperty(t, s);
  else {
    const n = Sl(e, t);
    wr.test(s) ? e.setProperty(
      Ge(n),
      s.replace(wr, ""),
      "important"
    ) : e[n] = s;
  }
}
const Ir = ["Webkit", "Moz", "ms"], sn = {};
function Sl(e, t) {
  const s = sn[t];
  if (s)
    return s;
  let n = Ae(t);
  if (n !== "filter" && n in e)
    return sn[t] = n;
  n = Ds(n);
  for (let r = 0; r < Ir.length; r++) {
    const i = Ir[r] + n;
    if (i in e)
      return sn[t] = i;
  }
  return t;
}
const xr = "http://www.w3.org/1999/xlink";
function Cr(e, t, s, n, r, i = Co(t)) {
  n && t.startsWith("xlink:") ? s == null ? e.removeAttributeNS(xr, t.slice(6, t.length)) : e.setAttributeNS(xr, t, s) : s == null || i && !Jr(s) ? e.removeAttribute(t) : e.setAttribute(
    t,
    i ? "" : et(s) ? String(s) : s
  );
}
function Ar(e, t, s, n, r) {
  if (t === "innerHTML" || t === "textContent") {
    s != null && (e[t] = t === "innerHTML" ? Gi(s) : s);
    return;
  }
  const i = e.tagName;
  if (t === "value" && i !== "PROGRESS" && // custom elements may use _value internally
  !i.includes("-")) {
    const a = i === "OPTION" ? e.getAttribute("value") || "" : e.value, l = s == null ? (
      // #11647: value should be set as empty string for null and undefined,
      // but <input type="checkbox"> should be set as 'on'.
      e.type === "checkbox" ? "on" : ""
    ) : String(s);
    (a !== l || !("_value" in e)) && (e.value = l), s == null && e.removeAttribute(t), e._value = s;
    return;
  }
  let o = !1;
  if (s === "" || s == null) {
    const a = typeof e[t];
    a === "boolean" ? s = Jr(s) : s == null && a === "string" ? (s = "", o = !0) : a === "number" && (s = 0, o = !0);
  }
  try {
    e[t] = s;
  } catch {
  }
  o && e.removeAttribute(r || t);
}
function Tt(e, t, s, n) {
  e.addEventListener(t, s, n);
}
function wl(e, t, s, n) {
  e.removeEventListener(t, s, n);
}
const kr = /* @__PURE__ */ Symbol("_vei");
function Il(e, t, s, n, r = null) {
  const i = e[kr] || (e[kr] = {}), o = i[t];
  if (n && o)
    o.value = n;
  else {
    const [a, l] = xl(t);
    if (n) {
      const f = i[t] = kl(
        n,
        r
      );
      Tt(e, a, f, l);
    } else o && (wl(e, a, o, l), i[t] = void 0);
  }
}
const Er = /(?:Once|Passive|Capture)$/;
function xl(e) {
  let t;
  if (Er.test(e)) {
    t = {};
    let n;
    for (; n = e.match(Er); )
      e = e.slice(0, e.length - n[0].length), t[n[0].toLowerCase()] = !0;
  }
  return [e[2] === ":" ? e.slice(3) : Ge(e.slice(2)), t];
}
let nn = 0;
const Cl = /* @__PURE__ */ Promise.resolve(), Al = () => nn || (Cl.then(() => nn = 0), nn = Date.now());
function kl(e, t) {
  const s = (n) => {
    if (!n._vts)
      n._vts = Date.now();
    else if (n._vts <= s.attached)
      return;
    dt(
      El(n, s.value),
      t,
      5,
      [n]
    );
  };
  return s.value = e, s.attached = Al(), s;
}
function El(e, t) {
  if (z(t)) {
    const s = e.stopImmediatePropagation;
    return e.stopImmediatePropagation = () => {
      s.call(e), e._stopped = !0;
    }, t.map(
      (n) => (r) => !r._stopped && n && n(r)
    );
  } else
    return t;
}
const Tr = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && // lowercase letter
e.charCodeAt(2) > 96 && e.charCodeAt(2) < 123, Tl = (e, t, s, n, r, i) => {
  const o = r === "svg";
  t === "class" ? ml(e, n, o) : t === "style" ? vl(e, s, n) : Ms(t) ? qs(t) || Il(e, t, s, n, i) : (t[0] === "." ? (t = t.slice(1), !0) : t[0] === "^" ? (t = t.slice(1), !1) : Pl(e, t, n, o)) ? (Ar(e, t, n), !e.tagName.includes("-") && (t === "value" || t === "checked" || t === "selected") && Cr(e, t, n, o, i, t !== "value")) : /* #11081 force set props for possible async custom element */ e._isVueCE && // #12408 check if it's declared prop or it's async custom element
  ($l(e, t) || // @ts-expect-error _def is private
  e._def.__asyncLoader && (/[A-Z]/.test(t) || !ve(n))) ? Ar(e, Ae(t), n, i, t) : (t === "true-value" ? e._trueValue = n : t === "false-value" && (e._falseValue = n), Cr(e, t, n, o));
};
function Pl(e, t, s, n) {
  if (n)
    return !!(t === "innerHTML" || t === "textContent" || t in e && Tr(t) && Z(s));
  if (t === "spellcheck" || t === "draggable" || t === "translate" || t === "autocorrect" || t === "sandbox" && e.tagName === "IFRAME" || t === "form" || t === "list" && e.tagName === "INPUT" || t === "type" && e.tagName === "TEXTAREA")
    return !1;
  if (t === "width" || t === "height") {
    const r = e.tagName;
    if (r === "IMG" || r === "VIDEO" || r === "CANVAS" || r === "SOURCE")
      return !1;
  }
  return Tr(t) && ve(s) ? !1 : t in e;
}
function $l(e, t) {
  const s = (
    // @ts-expect-error _def is private
    e._def.props
  );
  if (!s)
    return !1;
  const n = Ae(t);
  return Array.isArray(s) ? s.some((r) => Ae(r) === n) : Object.keys(s).some((r) => Ae(r) === n);
}
const Pr = {};
// @__NO_SIDE_EFFECTS__
function Rl(e, t, s) {
  let n = /* @__PURE__ */ ht(e, t);
  Ns(n) && (n = Se({}, n, t));
  class r extends Hn {
    constructor(o) {
      super(n, o, s);
    }
  }
  return r.def = n, r;
}
const Ol = typeof HTMLElement < "u" ? HTMLElement : class {
};
class Hn extends Ol {
  constructor(t, s = {}, n = wn) {
    super(), this._def = t, this._props = s, this._createApp = n, this._isVueCE = !0, this._instance = null, this._app = null, this._nonce = this._def.nonce, this._connected = !1, this._resolved = !1, this._patching = !1, this._dirty = !1, this._numberProps = null, this._styleChildren = /* @__PURE__ */ new WeakSet(), this._styleAnchors = /* @__PURE__ */ new WeakMap(), this._ob = null, this.shadowRoot && n !== wn ? this._root = this.shadowRoot : t.shadowRoot !== !1 ? (this.attachShadow(
      Se({}, t.shadowRootOptions, {
        mode: "open"
      })
    ), this._root = this.shadowRoot) : this._root = this;
  }
  connectedCallback() {
    if (!this.isConnected) return;
    !this.shadowRoot && !this._resolved && this._parseSlots(), this._connected = !0;
    let t = this;
    for (; t = t && // #12479 should check assignedSlot first to get correct parent
    (t.assignedSlot || t.parentNode || t.host); )
      if (t instanceof Hn) {
        this._parent = t;
        break;
      }
    this._instance || (this._resolved ? this._mount(this._def) : t && t._pendingResolve ? this._pendingResolve = t._pendingResolve.then(() => {
      this._pendingResolve = void 0, this._resolveDef();
    }) : this._resolveDef());
  }
  _setParent(t = this._parent) {
    t && (this._instance.parent = t._instance, this._inheritParentContext(t));
  }
  _inheritParentContext(t = this._parent) {
    t && this._app && Object.setPrototypeOf(
      this._app._context.provides,
      t._instance.provides
    );
  }
  disconnectedCallback() {
    this._connected = !1, jn(() => {
      this._connected || (this._ob && (this._ob.disconnect(), this._ob = null), this._app && this._app.unmount(), this._instance && (this._instance.ce = void 0), this._app = this._instance = null, this._teleportTargets && (this._teleportTargets.clear(), this._teleportTargets = void 0));
    });
  }
  _processMutations(t) {
    for (const s of t)
      this._setAttr(s.attributeName);
  }
  /**
   * resolve inner component definition (handle possible async component)
   */
  _resolveDef() {
    if (this._pendingResolve)
      return;
    for (let n = 0; n < this.attributes.length; n++)
      this._setAttr(this.attributes[n].name);
    this._ob = new MutationObserver(this._processMutations.bind(this)), this._ob.observe(this, { attributes: !0 });
    const t = (n, r = !1) => {
      this._resolved = !0, this._pendingResolve = void 0;
      const { props: i, styles: o } = n;
      let a;
      if (i && !z(i))
        for (const l in i) {
          const f = i[l];
          (f === Number || f && f.type === Number) && (l in this._props && (this._props[l] = tr(this._props[l])), (a || (a = /* @__PURE__ */ Object.create(null)))[Ae(l)] = !0);
        }
      this._numberProps = a, this._resolveProps(n), this.shadowRoot && this._applyStyles(o), this._mount(n);
    }, s = this._def.__asyncLoader;
    s ? this._pendingResolve = s().then((n) => {
      n.configureApp = this._def.configureApp, t(this._def = n, !0);
    }) : t(this._def);
  }
  _mount(t) {
    this._app = this._createApp(t), this._inheritParentContext(), t.configureApp && t.configureApp(this._app), this._app._ceVNode = this._createVNode(), this._app.mount(this._root);
    const s = this._instance && this._instance.exposed;
    if (s)
      for (const n in s)
        ce(this, n) || Object.defineProperty(this, n, {
          // unwrap ref to be consistent with public instance behavior
          get: () => qn(s[n])
        });
  }
  _resolveProps(t) {
    const { props: s } = t, n = z(s) ? s : Object.keys(s || {});
    for (const r of Object.keys(this))
      r[0] !== "_" && n.includes(r) && this._setProp(r, this[r]);
    for (const r of n.map(Ae))
      Object.defineProperty(this, r, {
        get() {
          return this._getProp(r);
        },
        set(i) {
          this._setProp(r, i, !0, !this._patching);
        }
      });
  }
  _setAttr(t) {
    if (t.startsWith("data-v-")) return;
    const s = this.hasAttribute(t);
    let n = s ? this.getAttribute(t) : Pr;
    const r = Ae(t);
    s && this._numberProps && this._numberProps[r] && (n = tr(n)), this._setProp(r, n, !1, !0);
  }
  /**
   * @internal
   */
  _getProp(t) {
    return this._props[t];
  }
  /**
   * @internal
   */
  _setProp(t, s, n = !0, r = !1) {
    if (s !== this._props[t] && (this._dirty = !0, s === Pr ? delete this._props[t] : (this._props[t] = s, t === "key" && this._app && (this._app._ceVNode.key = s)), r && this._instance && this._update(), n)) {
      const i = this._ob;
      i && (this._processMutations(i.takeRecords()), i.disconnect()), s === !0 ? this.setAttribute(Ge(t), "") : typeof s == "string" || typeof s == "number" ? this.setAttribute(Ge(t), s + "") : s || this.removeAttribute(Ge(t)), i && i.observe(this, { attributes: !0 });
    }
  }
  _update() {
    const t = this._createVNode();
    this._app && (t.appContext = this._app._context), Dl(t, this._root);
  }
  _createVNode() {
    const t = {};
    this.shadowRoot || (t.onVnodeMounted = t.onVnodeUpdated = this._renderSlots.bind(this));
    const s = Me(this._def, Se(t, this._props));
    return this._instance || (s.ce = (n) => {
      this._instance = n, n.ce = this, n.isCE = !0;
      const r = (i, o) => {
        this.dispatchEvent(
          new CustomEvent(
            i,
            Ns(o[0]) ? Se({ detail: o }, o[0]) : { detail: o }
          )
        );
      };
      n.emit = (i, ...o) => {
        r(i, o), Ge(i) !== i && r(Ge(i), o);
      }, this._setParent();
    }), s;
  }
  _applyStyles(t, s, n) {
    if (!t) return;
    if (s) {
      if (s === this._def || this._styleChildren.has(s))
        return;
      this._styleChildren.add(s);
    }
    const r = this._nonce, i = this.shadowRoot, o = n ? this._getStyleAnchor(n) || this._getStyleAnchor(this._def) : this._getRootStyleInsertionAnchor(i);
    let a = null;
    for (let l = t.length - 1; l >= 0; l--) {
      const f = document.createElement("style");
      r && f.setAttribute("nonce", r), f.textContent = t[l], i.insertBefore(f, a || o), a = f, l === 0 && (n || this._styleAnchors.set(this._def, f), s && this._styleAnchors.set(s, f));
    }
  }
  _getStyleAnchor(t) {
    if (!t)
      return null;
    const s = this._styleAnchors.get(t);
    return s && s.parentNode === this.shadowRoot ? s : (s && this._styleAnchors.delete(t), null);
  }
  _getRootStyleInsertionAnchor(t) {
    for (let s = 0; s < t.childNodes.length; s++) {
      const n = t.childNodes[s];
      if (!(n instanceof HTMLStyleElement))
        return n;
    }
    return null;
  }
  /**
   * Only called when shadowRoot is false
   */
  _parseSlots() {
    const t = this._slots = {};
    let s;
    for (; s = this.firstChild; ) {
      const n = s.nodeType === 1 && s.getAttribute("slot") || "default";
      (t[n] || (t[n] = [])).push(s), this.removeChild(s);
    }
  }
  /**
   * Only called when shadowRoot is false
   */
  _renderSlots() {
    const t = this._getSlots(), s = this._instance.type.__scopeId;
    for (let n = 0; n < t.length; n++) {
      const r = t[n], i = r.getAttribute("name") || "default", o = this._slots[i], a = r.parentNode;
      if (o)
        for (const l of o) {
          if (s && l.nodeType === 1) {
            const f = s + "-s", c = document.createTreeWalker(l, 1);
            l.setAttribute(f, "");
            let d;
            for (; d = c.nextNode(); )
              d.setAttribute(f, "");
          }
          a.insertBefore(l, r);
        }
      else
        for (; r.firstChild; ) a.insertBefore(r.firstChild, r);
      a.removeChild(r);
    }
  }
  /**
   * @internal
   */
  _getSlots() {
    const t = [this];
    this._teleportTargets && t.push(...this._teleportTargets);
    const s = /* @__PURE__ */ new Set();
    for (const n of t) {
      const r = n.querySelectorAll("slot");
      for (let i = 0; i < r.length; i++)
        s.add(r[i]);
    }
    return Array.from(s);
  }
  /**
   * @internal
   */
  _injectChildStyle(t, s) {
    this._applyStyles(t.styles, t, s);
  }
  /**
   * @internal
   */
  _beginPatch() {
    this._patching = !0, this._dirty = !1;
  }
  /**
   * @internal
   */
  _endPatch() {
    this._patching = !1, this._dirty && this._instance && this._update();
  }
  /**
   * @internal
   */
  _hasShadowRoot() {
    return this._def.shadowRoot !== !1;
  }
  /**
   * @internal
   */
  _removeChildStyle(t) {
  }
}
const Jt = (e) => {
  const t = e.props["onUpdate:modelValue"] || !1;
  return z(t) ? (s) => Ss(t, s) : t;
};
function Ml(e) {
  e.target.composing = !0;
}
function $r(e) {
  const t = e.target;
  t.composing && (t.composing = !1, t.dispatchEvent(new Event("input")));
}
const vt = /* @__PURE__ */ Symbol("_assign");
function Rr(e, t, s) {
  return t && (e = e.trim()), s && (e = kn(e)), e;
}
const Sn = {
  created(e, { modifiers: { lazy: t, trim: s, number: n } }, r) {
    e[vt] = Jt(r);
    const i = n || r.props && r.props.type === "number";
    Tt(e, t ? "change" : "input", (o) => {
      o.target.composing || e[vt](Rr(e.value, s, i));
    }), (s || i) && Tt(e, "change", () => {
      e.value = Rr(e.value, s, i);
    }), t || (Tt(e, "compositionstart", Ml), Tt(e, "compositionend", $r), Tt(e, "change", $r));
  },
  // set value on mounted so it's after min/max for type="range"
  mounted(e, { value: t }) {
    e.value = t ?? "";
  },
  beforeUpdate(e, { value: t, oldValue: s, modifiers: { lazy: n, trim: r, number: i } }, o) {
    if (e[vt] = Jt(o), e.composing) return;
    const a = (i || e.type === "number") && !/^0\d/.test(e.value) ? kn(e.value) : e.value, l = t ?? "";
    if (a === l)
      return;
    const f = e.getRootNode();
    (f instanceof Document || f instanceof ShadowRoot) && f.activeElement === e && e.type !== "range" && (n && t === s || r && e.value.trim() === l) || (e.value = l);
  }
}, Or = {
  // #4096 array checkboxes need to be deep traversed
  deep: !0,
  created(e, t, s) {
    e[vt] = Jt(s), Tt(e, "change", () => {
      const n = e._modelValue, r = Yi(e), i = e.checked, o = e[vt];
      if (z(n)) {
        const a = Gr(n, r), l = a !== -1;
        if (i && !l)
          o(n.concat(r));
        else if (!i && l) {
          const f = [...n];
          f.splice(a, 1), o(f);
        }
      } else if (js(n)) {
        const a = new Set(n);
        i ? a.add(r) : a.delete(r), o(a);
      } else
        o(Xi(e, i));
    });
  },
  // set initial checked on mount to wait for true-value/false-value
  mounted: Mr,
  beforeUpdate(e, t, s) {
    e[vt] = Jt(s), Mr(e, t, s);
  }
};
function Mr(e, { value: t, oldValue: s }, n) {
  e._modelValue = t;
  let r;
  if (z(t))
    r = Gr(t, n.props.value) > -1;
  else if (js(t))
    r = t.has(n.props.value);
  else {
    if (t === s) return;
    r = jt(t, Xi(e, !0));
  }
  e.checked !== r && (e.checked = r);
}
const ql = {
  created(e, { value: t }, s) {
    e.checked = jt(t, s.props.value), e[vt] = Jt(s), Tt(e, "change", () => {
      e[vt](Yi(e));
    });
  },
  beforeUpdate(e, { value: t, oldValue: s }, n) {
    e[vt] = Jt(n), t !== s && (e.checked = jt(t, n.props.value));
  }
};
function Yi(e) {
  return "_value" in e ? e._value : e.value;
}
function Xi(e, t) {
  const s = t ? "_trueValue" : "_falseValue";
  return s in e ? e[s] : t;
}
const jl = ["ctrl", "shift", "alt", "meta"], Nl = {
  stop: (e) => e.stopPropagation(),
  prevent: (e) => e.preventDefault(),
  self: (e) => e.target !== e.currentTarget,
  ctrl: (e) => !e.ctrlKey,
  shift: (e) => !e.shiftKey,
  alt: (e) => !e.altKey,
  meta: (e) => !e.metaKey,
  left: (e) => "button" in e && e.button !== 0,
  middle: (e) => "button" in e && e.button !== 1,
  right: (e) => "button" in e && e.button !== 2,
  exact: (e, t) => jl.some((s) => e[`${s}Key`] && !t.includes(s))
}, Qi = (e, t) => {
  if (!e) return e;
  const s = e._withMods || (e._withMods = {}), n = t.join(".");
  return s[n] || (s[n] = ((r, ...i) => {
    for (let o = 0; o < t.length; o++) {
      const a = Nl[t[o]];
      if (a && a(r, t)) return;
    }
    return e(r, ...i);
  }));
}, Fl = /* @__PURE__ */ Se({ patchProp: Tl }, pl);
let qr;
function Zi() {
  return qr || (qr = za(Fl));
}
const Dl = ((...e) => {
  Zi().render(...e);
}), wn = ((...e) => {
  const t = Zi().createApp(...e), { mount: s } = t;
  return t.mount = (n) => {
    const r = Ll(n);
    if (!r) return;
    const i = t._component;
    !Z(i) && !i.render && !i.template && (i.template = r.innerHTML), r.nodeType === 1 && (r.textContent = "");
    const o = s(r, !1, Kl(r));
    return r instanceof Element && (r.removeAttribute("v-cloak"), r.setAttribute("data-v-app", "")), o;
  }, t;
});
function Kl(e) {
  if (e instanceof SVGElement)
    return "svg";
  if (typeof MathMLElement == "function" && e instanceof MathMLElement)
    return "mathml";
}
function Ll(e) {
  return ve(e) ? document.querySelector(e) : e;
}
let jr = 0;
function He(e = "c") {
  jr += 1;
  const t = Math.random().toString(36).slice(2, 8);
  return `${e}_${Date.now().toString(36)}_${jr}_${t}`;
}
function Je() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
function Vn(e) {
  return {
    sessionId: e,
    turnStatus: "idle",
    messages: [],
    error: null
  };
}
function Ul(e) {
  return e.blocks.filter((t) => t.type === "text").map((t) => t.text).join("");
}
function Bl(e) {
  return e.startsWith("debug.");
}
function _e(e, t, s = {}) {
  return {
    protocolVersion: "1.0",
    type: e,
    timestamp: Je(),
    data: t,
    ...s
  };
}
const Hl = {
  form: "form",
  text_question: "text_question",
  textquestion: "text_question",
  select: "select",
  choice: "choice",
  multi_select: "multi_select",
  multiselect: "multi_select",
  confirm: "confirm",
  table: "table",
  detail: "detail",
  card: "card",
  report: "report",
  summary_card: "summary_card",
  summarycard: "summary_card",
  list_card: "list_card",
  listcard: "list_card",
  output_card: "output_card",
  outputcard: "output_card",
  page_action: "page_action",
  pageaction: "page_action",
  custom: "custom"
}, Vl = /* @__PURE__ */ new Set([
  "table",
  "detail",
  "card",
  "report",
  "summary_card",
  "list_card",
  "output_card"
]);
function Qe(e) {
  return !e || typeof e != "object" || Array.isArray(e) ? null : e;
}
function Ve(e) {
  if (e == null) return;
  const t = String(e).trim();
  return t || void 0;
}
function Wl(e) {
  var s;
  const t = ((s = Ve(e)) == null ? void 0 : s.toLowerCase().replace(/[\s-]+/g, "_")) || "custom";
  return Hl[t] || t;
}
function zl(e) {
  if (!Array.isArray(e)) return;
  const t = [];
  for (const s of e) {
    const n = Qe(s);
    if (!n) continue;
    const r = Ve(n.key) || Ve(n.name) || Ve(n.id);
    if (!r) continue;
    const i = Array.isArray(n.options) ? n.options.map((o) => {
      const a = Qe(o);
      return a ? {
        value: a.value ?? a.id ?? "",
        label: String(a.label ?? a.name ?? a.value ?? "")
      } : null;
    }).filter((o) => !!o) : void 0;
    t.push({
      key: r,
      name: Ve(n.name),
      label: String(n.label ?? n.name ?? r),
      type: String(n.type ?? "string"),
      required: n.required === !0,
      targetPath: Ve(n.targetPath),
      options: i,
      placeholder: Ve(n.placeholder),
      source: Qe(n.source) || void 0
    });
  }
  return t.length ? t : void 0;
}
function Jl(e) {
  if (!Array.isArray(e)) return;
  const t = [];
  for (const s of e) {
    const n = Qe(s);
    n && t.push({ ...n });
  }
  return t.length ? t : void 0;
}
function Gl(e, t, s) {
  const n = `${e}|${t || ""}|${s || ""}`.slice(0, 80);
  let r = 0;
  for (let i = 0; i < n.length; i += 1)
    r = (r << 5) - r + n.charCodeAt(i) | 0;
  return `local:readonly:${e}:${Math.abs(r).toString(36)}`;
}
function Yl(e) {
  const t = Qe(e);
  if (!t) return null;
  const s = Wl(t.component ?? t.type), n = Ve(t.title), r = Ve(t.message);
  let i = Ve(t.interactionId);
  i || (Vl.has(s) ? i = Gl(s, n, r) : i = He("interaction"));
  const o = Qe(t.extension) || void 0;
  return {
    schemaVersion: "1.0",
    interactionId: i,
    traceId: Ve(t.traceId),
    type: Ve(t.type),
    component: s,
    title: n,
    message: r,
    ttlSeconds: typeof t.ttlSeconds == "number" ? t.ttlSeconds : void 0,
    expiresAt: Ve(t.expiresAt),
    fields: zl(t.fields),
    prefilled: Qe(t.prefilled) || void 0,
    missing: Array.isArray(t.missing) ? t.missing.map(String) : void 0,
    summary: Qe(t.summary) || void 0,
    data: t.data,
    schema: Qe(t.schema) || void 0,
    actions: Jl(t.actions),
    datasources: Qe(t.datasources) || void 0,
    behavior: Qe(t.behavior) || void 0,
    extension: o
  };
}
function $e(e) {
  return {
    ...e,
    messages: e.messages.map((t) => ({
      ...t,
      blocks: t.blocks.map((s) => ({ ...s })),
      metadata: t.metadata ? { ...t.metadata } : void 0,
      completion: t.completion ? { ...t.completion } : void 0
    })),
    metadata: e.metadata ? { ...e.metadata } : void 0
  };
}
function Xl(e, t) {
  return e.id === t || e.transportMessageId === t;
}
function Wn(e) {
  for (let t = e.messages.length - 1; t >= 0; t -= 1) {
    const s = e.messages[t];
    if (s.role === "assistant" && (s.status === "streaming" || s.status === "pending"))
      return s;
  }
}
function Nr(e, t) {
  return Wn(e);
}
function Ql(e) {
  for (let t = e.messages.length - 1; t >= 0; t -= 1)
    if (e.messages[t].role === "assistant") return e.messages[t];
}
function At(e, t, s, n = {}) {
  if (t) {
    const o = e.messages.find((a) => Xl(a, t));
    if (o && (o.status === "pending" || o.status === "streaming" || n.reuseCompleted))
      return s && (o.metadata = { ...o.metadata || {}, ...s }), o;
  }
  const r = Wn(e);
  if (r)
    return t && r.transportMessageId !== t && (r.transportMessageId = t), s && (r.metadata = { ...r.metadata || {}, ...s }), r;
  if (n.reuseCompleted) {
    const o = Ql(e);
    if (o)
      return s && (o.metadata = { ...o.metadata || {}, ...s }), o;
  }
  const i = {
    id: He("msg"),
    role: "assistant",
    status: "streaming",
    blocks: [],
    createdAt: Je(),
    metadata: s,
    transportMessageId: t
  };
  return e.messages.push(i), i;
}
function eo(e, t) {
  return e.blocks.find(
    (s) => s.type === "interaction" && s.request.interactionId === t
  );
}
function Fr(e, t) {
  if (!t) return;
  const s = e.blocks[e.blocks.length - 1];
  if (s && s.type === "text" && s.status !== "completed")
    s.text += t, s.status = "streaming";
  else {
    const n = {
      id: He("blk"),
      type: "text",
      text: t,
      status: "streaming"
    };
    e.blocks.push(n);
  }
  e.status = "streaming", e.updatedAt = Je();
}
function Dr(e, t, s = "waiting") {
  const n = Yl(t);
  if (!n) return;
  const r = eo(e, n.interactionId);
  if (r) {
    r.request = n, (r.state === "waiting" || r.state === "failed") && (r.state = s), e.updatedAt = Je();
    return;
  }
  e.blocks.push({
    id: He("blk"),
    type: "interaction",
    request: n,
    state: s
  }), e.updatedAt = Je();
}
function rn(e) {
  for (const t of e.blocks)
    t.type === "text" && t.status === "streaming" && (t.status = "completed");
}
function ze(e, t) {
  switch (t.type) {
    case "reset":
      return Vn(t.sessionId);
    case "restore":
      return $e(t.snapshot);
    case "set_session": {
      const s = $e(e);
      return s.sessionId = t.sessionId, s;
    }
    case "set_error": {
      const s = $e(e);
      return s.error = t.error, s;
    }
    case "append_user_message": {
      const s = $e(e);
      return s.messages.push({
        id: t.id || He("msg"),
        role: "user",
        status: "completed",
        blocks: [{ id: He("blk"), type: "text", text: t.text, status: "completed" }],
        createdAt: Je(),
        metadata: t.metadata
      }), s.error = null, s;
    }
    case "begin_assistant_placeholder": {
      const s = $e(e), n = Wn(s);
      return n && (!t.turnId || !n.turnId || n.turnId === t.turnId) ? (t.turnId && (n.turnId = t.turnId, s.turnId = t.turnId), s) : (s.messages.push({
        id: He("msg"),
        role: "assistant",
        status: "pending",
        blocks: [],
        createdAt: Je(),
        turnId: t.turnId,
        localPlaceholder: !0
      }), t.turnId && (s.turnId = t.turnId), s.error = null, s);
    }
    case "start_assistant_message": {
      const s = $e(e), n = At(s, t.id, t.metadata);
      return n.status === "pending" && (n.status = "streaming"), n.updatedAt = Je(), s.turnStatus = s.turnStatus === "waiting" ? "waiting" : "streaming", s.error = null, s;
    }
    case "append_text_delta": {
      const s = $e(e), n = At(s, t.messageId);
      return Fr(n, t.text), (s.turnStatus === "idle" || s.turnStatus === "sending") && (s.turnStatus = "streaming"), s;
    }
    case "add_interaction": {
      const s = $e(e), n = At(s, t.messageId);
      return Dr(n, t.request, t.state || "waiting"), (s.turnStatus === "idle" || s.turnStatus === "sending") && (s.turnStatus = "streaming"), s;
    }
    case "update_interaction_state": {
      const s = $e(e);
      for (const n of s.messages) {
        const r = eo(n, t.interactionId);
        if (r) {
          r.state = t.state, t.result && (r.result = t.result), t.errorMessage !== void 0 && (r.errorMessage = t.errorMessage), n.updatedAt = Je();
          break;
        }
      }
      return s;
    }
    case "add_notice": {
      const s = $e(e);
      return At(s, t.messageId).blocks.push({
        id: He("blk"),
        type: "notice",
        level: t.level || "info",
        text: t.text
      }), s;
    }
    case "add_error_block": {
      const s = $e(e), n = At(s, t.messageId);
      return n.blocks.push({
        id: He("blk"),
        type: "error",
        text: t.text,
        retryable: t.retryable
      }), n.status = "failed", s;
    }
    case "add_page_action": {
      const s = $e(e), n = At(s, t.messageId);
      return n.blocks.some(
        (i) => i.type === "page_action" && i.requestId === t.requestId
      ) || !t.requestId || n.blocks.push({
        id: He("blk"),
        type: "page_action",
        requestId: t.requestId,
        actionKey: t.actionKey,
        title: t.title,
        args: t.args,
        status: "pending"
      }), s;
    }
    case "set_turn_status": {
      const s = $e(e);
      return s.turnStatus = t.status, s;
    }
    case "complete_turn": {
      const s = $e(e);
      t.sessionId && (s.sessionId = t.sessionId);
      const n = At(s, void 0, void 0, { reuseCompleted: !0 });
      t.answer && (n.blocks.some((o) => o.type === "text" && o.text) || Fr(n, t.answer)), t.uiRequest && Dr(n, t.uiRequest, "waiting"), rn(n);
      const r = n.blocks.some(
        (i) => i.type === "interaction" && i.state === "waiting"
      );
      return n.status = "completed", n.updatedAt = Je(), t.metadata && (n.metadata = { ...n.metadata || {}, ...t.metadata }, s.metadata = { ...s.metadata || {}, ...t.metadata }), t.completion && (n.completion = {
        ...n.completion || {},
        ...t.completion
      }), s.turnStatus = r ? "waiting" : "completed", s.error = null, s;
    }
    case "fail_turn": {
      const s = $e(e), n = Nr(s) || At(s);
      return rn(n), n.status = "failed", n.blocks.push({
        id: He("blk"),
        type: "error",
        text: t.message,
        retryable: !0
      }), t.metadata && (n.metadata = { ...n.metadata || {}, ...t.metadata }, s.metadata = { ...s.metadata || {}, ...t.metadata }), n.updatedAt = Je(), s.turnStatus = "failed", s.error = t.message, s;
    }
    case "cancel_turn": {
      const s = $e(e), n = Nr(s);
      return n && (rn(n), n.status = "cancelled", n.updatedAt = Je()), s.turnStatus = "cancelled", s.error = null, s;
    }
    case "apply_event":
      return Zl(e, t.event);
    default:
      return e;
  }
}
function Zl(e, t) {
  const s = t.type, n = t.data && typeof t.data == "object" ? t.data : {}, r = t.turnId && e.turnId !== t.turnId ? { ...e, turnId: t.turnId } : e;
  switch (s) {
    case "session.created":
    case "session.restored":
      return s === "session.restored" && t.data && typeof t.data == "object" && "messages" in t.data ? ze(r, { type: "restore", snapshot: t.data }) : ze(r, { type: "set_session", sessionId: t.sessionId || Ce(n.sessionId) });
    case "turn.started":
      return ze(r, { type: "set_turn_status", status: "sending" });
    case "message.started":
      return ze(r, {
        type: "start_assistant_message",
        id: Ce(n.messageId)
      });
    case "message.delta": {
      const i = typeof n.text == "string" ? n.text : typeof t.data == "string" ? t.data : "";
      return ze(r, {
        type: "append_text_delta",
        text: i,
        messageId: Ce(n.messageId)
      });
    }
    case "ui.requested":
      return ze(r, {
        type: "add_interaction",
        request: n.uiRequest ?? t.data,
        messageId: Ce(n.messageId)
      });
    case "page.action.requested":
      return ze(r, {
        type: "add_page_action",
        requestId: String(n.requestId || ""),
        actionKey: String(n.actionKey || ""),
        title: Ce(n.title),
        args: n.args || void 0,
        messageId: Ce(n.messageId)
      });
    case "turn.waiting":
      return ze(r, {
        type: "complete_turn",
        answer: Ce(n.answer),
        uiRequest: n.uiRequest,
        sessionId: t.sessionId || Ce(n.sessionId),
        metadata: on(n.metadata, n.result),
        completion: {
          intentType: n.intentType,
          toolCalls: n.toolCalls,
          result: n.result
        }
      });
    case "turn.completed":
      return ze(r, {
        type: "complete_turn",
        answer: Ce(n.answer),
        uiRequest: n.uiRequest,
        sessionId: t.sessionId || Ce(n.sessionId),
        metadata: {
          ...on(n.metadata, n.result),
          ...t.traceId ? { traceId: t.traceId } : {},
          ...n.traceId ? { traceId: n.traceId } : {}
        },
        completion: {
          intentType: n.intentType,
          toolCalls: n.toolCalls,
          result: n.result
        }
      });
    case "turn.cancelled":
      return ze(r, { type: "cancel_turn" });
    case "turn.failed": {
      const i = on(n.metadata, n.result), o = t.traceId || Ce(n.traceId) || Ce(i.traceId), a = Ce(n.code) || Ce(i.code);
      return ze(r, {
        type: "fail_turn",
        message: Ce(n.message) || Ce(n.error) || "对话失败",
        metadata: {
          ...i,
          success: !1,
          ...a ? { code: a } : {},
          ...o ? { traceId: o } : {},
          ...t.sessionId || Ce(n.sessionId) ? { sessionId: t.sessionId || Ce(n.sessionId) } : {}
        }
      });
    }
    default:
      return r;
  }
}
function Ce(e) {
  if (e == null) return;
  const t = String(e);
  return t || void 0;
}
function on(e, t) {
  if (e && typeof e == "object" && !Array.isArray(e)) {
    const s = e;
    if (s.metadata && typeof s.metadata == "object" && !Array.isArray(s.metadata) && ("answer" in s || "uiRequest" in s || "sessionId" in s)) {
      const r = { ...s.metadata };
      return "success" in s && (r.success = s.success), s.code != null && (r.code = s.code), s.traceId != null && (r.traceId = s.traceId), r;
    }
    if (!("answer" in s) && !("uiRequest" in s))
      return { ...s };
    const n = {};
    if ("success" in s && (n.success = s.success), s.code != null && (n.code = s.code), s.traceId != null && (n.traceId = s.traceId), t && typeof t == "object" && !Array.isArray(t)) {
      const r = t.metadata;
      if (r && typeof r == "object" && !Array.isArray(r))
        return { ...r, ...n };
    }
    return n;
  }
  if (t && typeof t == "object" && !Array.isArray(t)) {
    const s = t, n = s.metadata, r = {};
    return "success" in s && (r.success = s.success), n && typeof n == "object" && !Array.isArray(n) ? { ...n, ...r } : r;
  }
  return {};
}
function ec(e) {
  return Vn(e);
}
function tc(e) {
  const t = e.trim();
  if (!t) return "";
  try {
    return JSON.parse(t);
  } catch {
    return e;
  }
}
function to(e) {
  const s = e.replace(/\r\n/g, `
`).replace(/\r/g, `
`).split(`
`);
  let n = "message", r;
  const i = [];
  for (const a of s)
    if (!(!a || a.startsWith(":"))) {
      if (a.startsWith("event:")) {
        n = a.slice(6).trim();
        continue;
      }
      if (a.startsWith("id:")) {
        r = a.slice(3).trim();
        continue;
      }
      a.startsWith("data:") && i.push(a.slice(5).replace(/^ /, ""));
    }
  if (!i.length && n === "message") return null;
  const o = i.join(`
`);
  return {
    event: n,
    rawData: o,
    data: tc(o),
    id: r
  };
}
function sc(e) {
  const t = [];
  let s = e.replace(/\r\n/g, `
`).replace(/\r/g, `
`), n = s.indexOf(`

`);
  for (; n >= 0; ) {
    const r = s.slice(0, n);
    s = s.slice(n + 2);
    const i = to(r);
    i && t.push(i), n = s.indexOf(`

`);
  }
  return { frames: t, rest: s };
}
async function* nc(e, t = {}) {
  const s = e.getReader(), n = new TextDecoder();
  let r = "";
  const i = t.signal, o = () => {
    if (i != null && i.aborted)
      throw new DOMException("The operation was aborted.", "AbortError");
  };
  try {
    for (; ; ) {
      o();
      const { done: a, value: l } = await s.read();
      if (a) break;
      o(), r += n.decode(l, { stream: !0 });
      const f = sc(r);
      r = f.rest;
      for (const c of f.frames)
        yield c;
    }
    if (r += n.decode(), r.trim()) {
      const a = to(r.trim());
      a && (yield a);
    }
  } finally {
    try {
      s.releaseLock();
    } catch {
    }
  }
}
function Os(e) {
  return !e || typeof e != "object" ? !1 : e.name === "AbortError";
}
const rc = /* @__PURE__ */ new Set([
  "message.delta",
  "ui.requested",
  "page.action.requested",
  "turn.started",
  "turn.waiting",
  "turn.completed",
  "turn.failed",
  "turn.cancelled",
  "interaction.submitted",
  "interaction.cancelled"
]);
function ic(e) {
  const { transport: t, onDebugEvent: s, onPublicEvent: n } = e;
  let r = ec(e.initialSessionId);
  const i = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Set();
  let a = !1, l = null, f = 0, c;
  const d = /* @__PURE__ */ new Set(), g = /* @__PURE__ */ new Set(), _ = /* @__PURE__ */ new Set();
  function M() {
    var m;
    (m = e.onChange) == null || m.call(e, r);
    for (const k of i) k(r);
  }
  function p(m) {
    r = ze(r, m), M();
  }
  function $(m) {
    return m.turnId || !c ? m : { ...m, turnId: c };
  }
  function K(m) {
    if (!rc.has(m.type)) return !1;
    const k = m.data && typeof m.data == "object" ? m.data : {}, H = m.turnId || c || "";
    if (m.type === "message.delta")
      return !0;
    if (m.type === "page.action.requested") {
      const se = String(k.requestId || "");
      if (!se) return !0;
      const ne = `page.action.requested:${se}`;
      return _.has(ne) ? !1 : (_.add(ne), !0);
    }
    if (m.type === "ui.requested") {
      const se = k.uiRequest, ne = `ui.requested:${H}:${(se == null ? void 0 : se.interactionId) || JSON.stringify(k.uiRequest || "")}`;
      return g.has(ne) ? !1 : (g.add(ne), !0);
    }
    if (m.type === "turn.completed" || m.type === "turn.waiting" || m.type === "turn.failed" || m.type === "turn.cancelled") {
      const se = m.sessionId || (k.sessionId != null ? String(k.sessionId) : "") || r.sessionId || "", ne = `${m.type}:${se}:${H}`;
      return d.has(ne) ? !1 : (d.add(ne), !0);
    }
    if (m.type === "interaction.submitted" || m.type === "interaction.cancelled") {
      const se = `${m.type}:${H}:${String(k.interactionId || "")}:${String(k.action || "")}`;
      return d.has(se) ? !1 : (d.add(se), !0);
    }
    return !0;
  }
  function E(m) {
    const k = $(m);
    K(k) && (n == null || n(k));
  }
  function L(m) {
    const k = $(m);
    if (Bl(k.type)) {
      s == null || s(k);
      return;
    }
    if (k.type === "page.action.requested") {
      const H = k.data && typeof k.data == "object" ? k.data : {}, se = String(H.requestId || "");
      if (se) {
        const ne = `page.action.requested:${se}`;
        if (_.has(ne))
          return;
      }
    }
    E(k), p({ type: "apply_event", event: k });
  }
  async function R(m, k) {
    for await (const H of m) {
      if (a || k !== f) break;
      L(H);
    }
  }
  async function B(m, k) {
    var Pe, ke, q, U;
    if (a) return;
    const H = ++f;
    c = He("turn"), k === "start" || ((Pe = m.uiSubmit) == null ? void 0 : Pe.action) !== "cancel" ? (l == null || l.abort(), l = new AbortController()) : (!l || l.signal.aborted) && (l = new AbortController());
    const se = l.signal;
    p({ type: "set_turn_status", status: "sending" }), p({ type: "set_error", error: null }), k === "start" && m.message && p({ type: "append_user_message", text: m.message }), (k === "start" || ((ke = m.uiSubmit) == null ? void 0 : ke.action) !== "cancel") && p({ type: "begin_assistant_placeholder", turnId: c });
    try {
      const G = k === "resume" && t.resumeInteraction && m.interactionId ? t.resumeInteraction(
        m.interactionId,
        ((q = m.uiSubmit) == null ? void 0 : q.action) || "submit",
        ((U = m.uiSubmit) == null ? void 0 : U.values) || m.values || {},
        se
      ) : t.startTurn(m, se);
      if (await R(G, H), H !== f) return;
      (r.turnStatus === "sending" || r.turnStatus === "streaming") && p({ type: "set_turn_status", status: "completed" });
    } catch (G) {
      if (H !== f) return;
      if (Os(G) || se.aborted) {
        p({ type: "cancel_turn" }), E(_e("turn.cancelled", {}, { sessionId: r.sessionId, turnId: c }));
        return;
      }
      const Y = G instanceof Error ? G.message : String(G);
      p({ type: "fail_turn", message: Y }), E(_e("turn.failed", { message: Y, error: Y }, {
        sessionId: r.sessionId,
        turnId: c
      }));
    }
  }
  return {
    getState() {
      return r;
    },
    subscribe(m) {
      return i.add(m), m(r), () => i.delete(m);
    },
    async send(m) {
      const k = typeof m == "string" ? { message: m } : m;
      !k.message && !k.values && !k.uiSubmit || await B(k, "start");
    },
    async submitInteraction(m, k, H = {}) {
      if (!m || o.has(m)) return;
      o.add(m);
      const se = k === "cancel";
      p({
        type: "update_interaction_state",
        interactionId: m,
        state: "submitting",
        result: { action: k, values: H }
      });
      try {
        await B(
          {
            interactionId: m,
            uiSubmit: { action: k, values: H },
            values: H,
            message: void 0
          },
          "resume"
        ), se && r.turnStatus === "cancelled" ? (p({
          type: "update_interaction_state",
          interactionId: m,
          state: "cancelled",
          result: { action: k, values: H }
        }), E(_e(
          "interaction.cancelled",
          { interactionId: m, action: k, values: H },
          { sessionId: r.sessionId, turnId: c }
        ))) : r.turnStatus === "failed" ? p({
          type: "update_interaction_state",
          interactionId: m,
          state: "failed",
          errorMessage: r.error || "提交失败"
        }) : se ? (p({
          type: "update_interaction_state",
          interactionId: m,
          state: "cancelled",
          result: { action: k, values: H }
        }), E(_e(
          "interaction.cancelled",
          { interactionId: m, action: k, values: H },
          { sessionId: r.sessionId, turnId: c }
        ))) : r.turnStatus === "cancelled" ? p({
          type: "update_interaction_state",
          interactionId: m,
          state: "cancelled",
          result: { action: k, values: H }
        }) : (p({
          type: "update_interaction_state",
          interactionId: m,
          state: "resolved",
          result: { action: k, values: H }
        }), E(_e(
          "interaction.submitted",
          { interactionId: m, action: k, values: H },
          { sessionId: r.sessionId, turnId: c }
        )));
      } catch (ne) {
        Os(ne) || r.turnStatus === "cancelled" ? p({
          type: "update_interaction_state",
          interactionId: m,
          state: "failed",
          errorMessage: "交互提交被中断"
        }) : p({
          type: "update_interaction_state",
          interactionId: m,
          state: "failed",
          errorMessage: ne instanceof Error ? ne.message : String(ne)
        });
      } finally {
        o.delete(m);
      }
    },
    async cancel() {
      var m;
      f += 1, c = He("turn"), l == null || l.abort(), l = null;
      try {
        await ((m = t.cancelTurn) == null ? void 0 : m.call(t));
      } catch {
      }
      p({ type: "cancel_turn" }), E(_e("turn.cancelled", {}, { sessionId: r.sessionId, turnId: c }));
    },
    async clearSession() {
      var m;
      f += 1, c = void 0, l == null || l.abort(), l = null, await ((m = t.clearSession) == null ? void 0 : m.call(t)), d.clear(), g.clear(), _.clear(), p({ type: "reset", sessionId: void 0 });
    },
    async restore() {
      var k;
      const m = await ((k = t.restoreSession) == null ? void 0 : k.call(t));
      return m ? (p({ type: "restore", snapshot: m }), m) : null;
    },
    dispose() {
      a = !0, f += 1, c = void 0, l == null || l.abort(), l = null, i.clear(), d.clear(), g.clear(), _.clear(), t.dispose();
    }
  };
}
function zn(e) {
  return !e || typeof e != "object" || Array.isArray(e) ? null : e;
}
function oc(e) {
  const t = zn(e);
  return t && "text" in t ? String(t.text ?? "") : typeof e == "string" ? e : "";
}
function so(e) {
  if (!e) return;
  const t = zn(e.metadata);
  if (t) return { ...t };
  if (!("answer" in e) && !("uiRequest" in e) && !("sessionId" in e) && !("toolCalls" in e))
    return { ...e };
}
function ac(e, t, s, n) {
  const r = so(e || void 0);
  return {
    answer: n,
    sessionId: s,
    result: t,
    metadata: r,
    intentType: e == null ? void 0 : e.intentType,
    toolCalls: e == null ? void 0 : e.toolCalls,
    uiRequest: e == null ? void 0 : e.uiRequest
  };
}
function no(e, t, s = {}) {
  const n = zn(t), r = s.sessionId || (n != null && n.sessionId ? String(n.sessionId) : void 0);
  switch (e) {
    case "message.delta": {
      const i = oc(t);
      return i ? _e("message.delta", { text: i }, { sessionId: r }) : null;
    }
    case "ui.requested":
      return _e("ui.requested", {
        uiRequest: (n == null ? void 0 : n.uiRequest) ?? t
      }, { sessionId: r });
    case "page.action.requested":
      return _e("page.action.requested", t, { sessionId: r });
    case "message.completed": {
      const i = (n == null ? void 0 : n.answer) != null ? String(n.answer) : void 0, o = n == null ? void 0 : n.uiRequest, a = ac(n, t, r, i);
      return o ? [
        _e("ui.requested", { uiRequest: o }, { sessionId: r }),
        _e("turn.waiting", a, { sessionId: r })
      ] : _e("turn.completed", a, { sessionId: r });
    }
    case "error":
    case "execution.error": {
      const i = (n == null ? void 0 : n.message) != null ? String(n.message) : typeof t == "string" ? t : "Embed 对话失败";
      return _e("turn.failed", { message: i, error: i }, { sessionId: r });
    }
    case "execution.started":
      return _e("turn.started", n || {}, { sessionId: r });
    case "execution.completed":
      return no("message.completed", t, s);
    case "supervisor.step":
    case "reasoning.delta":
      return null;
    default:
      return null;
  }
}
function* lc(e) {
  if (e) {
    if (Array.isArray(e)) {
      for (const t of e) yield t;
      return;
    }
    yield e;
  }
}
function cc(e) {
  return e === 404 || e === 405 || e === 415 || e === 501;
}
function uc(e) {
  return !e || typeof e != "object" ? !1 : e.name === "AbortError";
}
function an(e) {
  return e.aborted || uc(e.error) || e.bytesOrEventsConsumed || e.status == null ? !1 : cc(e.status);
}
function fc(e) {
  const t = e.fetchImpl || fetch, s = e.preferStream !== !1;
  let n = !1;
  const r = /* @__PURE__ */ new Set();
  let i = null;
  function o(p) {
    const $ = e.apiBase.replace(/\/$/, "");
    return p.startsWith("http") ? p : `${$}${p.startsWith("/") ? p : `/${p}`}`;
  }
  async function a(p, $, K) {
    const E = {
      "Content-Type": "application/json",
      ...$.headers
    }, L = e.tokenProvider();
    L && (E.Authorization = `Bearer ${L}`);
    let R = await t(p, { ...$, headers: E, signal: K });
    if (R.status === 401 && e.onUnauthorized) {
      const B = await e.onUnauthorized();
      if (typeof B == "string" && B)
        E.Authorization = `Bearer ${B}`;
      else {
        const m = e.tokenProvider();
        m && (E.Authorization = `Bearer ${m}`);
      }
      R = await t(p, { ...$, headers: E, signal: K });
    }
    return R;
  }
  async function l(p) {
    if (n) throw new Error("Embed transport disposed");
    const $ = e.getSessionId();
    return $ || (i || (i = (async () => {
      var m, k;
      const K = e.sessionsPath || "/chat/sessions", E = await a(o(K), {
        method: "POST",
        body: JSON.stringify(((m = e.createSessionPayload) == null ? void 0 : m.call(e)) || { context: (k = e.getContext) == null ? void 0 : k.call(e) })
      }, p);
      if (!E.ok)
        throw new Error(`Embed session create failed: HTTP ${E.status}`);
      const L = await E.json().catch(() => ({})), R = L.data && typeof L.data == "object" ? L.data : L, B = R.sessionId ? String(R.sessionId) : R.id ? String(R.id) : void 0;
      if (!B) throw new Error("Embed session create returned no sessionId");
      return e.setSessionId(B), B;
    })().finally(() => {
      i = null;
    })), i);
  }
  async function* f(p, $, K) {
    if (!p.body) throw new Error("Embed stream has no body");
    for await (const E of nc(p.body, { signal: K })) {
      const L = no(E.event, E.data, { sessionId: $ });
      for (const R of lc(L))
        yield R;
    }
  }
  function* c(p, $) {
    yield _e("turn.started", {}, { sessionId: $ }), p.answer && (yield _e("message.delta", { text: String(p.answer) }, { sessionId: $ }));
    const K = p.metadata && typeof p.metadata == "object" && !Array.isArray(p.metadata) ? { ...p.metadata } : void 0;
    p.uiRequest ? (yield _e("ui.requested", { uiRequest: p.uiRequest }, { sessionId: $ }), yield _e("turn.waiting", {
      answer: p.answer,
      uiRequest: p.uiRequest,
      sessionId: $,
      result: p,
      metadata: K,
      intentType: p.intentType,
      toolCalls: p.toolCalls
    }, { sessionId: $ })) : yield _e("turn.completed", {
      answer: p.answer,
      sessionId: $,
      result: p,
      metadata: K,
      intentType: p.intentType,
      toolCalls: p.toolCalls
    }, { sessionId: $ });
  }
  async function* d(p, $, K) {
    var m, k;
    const E = ((m = e.messagesJsonPath) == null ? void 0 : m.call(e, p)) || `/chat/sessions/${encodeURIComponent(p)}/messages`, L = await a(o(E), {
      method: "POST",
      body: JSON.stringify({
        message: $.message,
        context: (k = e.getContext) == null ? void 0 : k.call(e),
        interactionId: $.interactionId,
        uiSubmit: $.uiSubmit
      })
    }, K);
    if (!L.ok)
      throw new Error(`Embed message failed: HTTP ${L.status}`);
    const R = await L.json().catch(() => ({})), B = R.data && typeof R.data == "object" ? R.data : R;
    yield* c(B, p);
  }
  async function* g(p, $) {
    var L, R;
    if (n) return;
    const K = new AbortController();
    r.add(K);
    const E = () => K.abort();
    $ == null || $.addEventListener("abort", E);
    try {
      const B = await l(K.signal);
      if (!s) {
        yield* d(B, p, K.signal);
        return;
      }
      const m = ((L = e.messagesPath) == null ? void 0 : L.call(e, B)) || `/chat/sessions/${encodeURIComponent(B)}/messages/stream`, k = await a(o(m), {
        method: "POST",
        headers: { Accept: "text/event-stream" },
        body: JSON.stringify({
          message: p.message,
          context: (R = e.getContext) == null ? void 0 : R.call(e),
          interactionId: p.interactionId,
          uiSubmit: p.uiSubmit
        })
      }, K.signal), H = k.headers.get("content-type") || "";
      if (!k.ok || !k.body || !H.includes("text/event-stream")) {
        if (an({
          status: k.status,
          bytesOrEventsConsumed: !1,
          aborted: K.signal.aborted
        })) {
          yield* d(B, p, K.signal);
          return;
        }
        throw new Error(`Embed stream failed: HTTP ${k.status}`);
      }
      yield _e("turn.started", {}, { sessionId: B }), yield* f(k, B, K.signal);
    } catch (B) {
      if (Os(B) || K.signal.aborted) {
        yield _e("turn.cancelled", {}, { sessionId: e.getSessionId() });
        return;
      }
      throw B;
    } finally {
      $ == null || $.removeEventListener("abort", E), r.delete(K);
    }
  }
  async function* _(p, $, K, E, L) {
    var H, se;
    const R = ((H = e.interactionSubmitPath) == null ? void 0 : H.call(e, p, $)) || `/chat/sessions/${encodeURIComponent(p)}/interactions/${encodeURIComponent($)}/submit`, B = await a(o(R), {
      method: "POST",
      body: JSON.stringify({ action: K, values: E, context: (se = e.getContext) == null ? void 0 : se.call(e) })
    }, L);
    if (!B.ok)
      throw new Error(`Embed interaction submit failed: HTTP ${B.status}`);
    const m = await B.json().catch(() => ({})), k = m.data && typeof m.data == "object" ? m.data : m;
    yield* c(k, p);
  }
  async function* M(p, $, K, E) {
    var m, k;
    if (n) return;
    const L = e.getSessionId();
    if (!L) throw new Error("No embed session");
    if (!s) {
      yield* _(L, p, $, K, E);
      return;
    }
    const R = ((m = e.interactionSubmitStreamPath) == null ? void 0 : m.call(e, L, p)) || `/chat/sessions/${encodeURIComponent(L)}/interactions/${encodeURIComponent(p)}/submit/stream`;
    let B = !1;
    try {
      const H = await a(o(R), {
        method: "POST",
        headers: { Accept: "text/event-stream" },
        body: JSON.stringify({ action: $, values: K, context: (k = e.getContext) == null ? void 0 : k.call(e) })
      }, E), se = H.headers.get("content-type") || "";
      if (H.ok && H.body && se.includes("text/event-stream")) {
        yield _e("turn.started", {}, { sessionId: L }), B = !0, yield* f(H, L, E);
        return;
      }
      if (an({
        status: H.status,
        bytesOrEventsConsumed: !1,
        aborted: E == null ? void 0 : E.aborted
      })) {
        yield* _(L, p, $, K, E);
        return;
      }
      throw new Error(`Embed interaction stream failed: HTTP ${H.status}`);
    } catch (H) {
      if (Os(H) || E != null && E.aborted) {
        yield _e("turn.cancelled", {}, { sessionId: L });
        return;
      }
      if (an({
        status: H == null ? void 0 : H.status,
        bytesOrEventsConsumed: B,
        aborted: E == null ? void 0 : E.aborted,
        error: H
      })) {
        yield* _(L, p, $, K, E);
        return;
      }
      throw H;
    }
  }
  return {
    kind: "embed",
    capabilities: {
      eventStreaming: s,
      tokenStreaming: !0,
      abort: !0,
      restore: !1,
      structuredInitialInput: !1,
      pageActions: !0
    },
    startTurn: g,
    resumeInteraction: M,
    /** 供 facade / 测试显式预热会话（带去重） */
    ensureSession: l,
    async cancelTurn() {
      for (const p of r) p.abort();
      r.clear();
    },
    dispose() {
      n = !0, i = null;
      for (const p of r) p.abort();
      r.clear();
    }
  };
}
const dc = /* @__PURE__ */ new Map(), hc = {
  form: "form",
  text_question: "form",
  select: "select",
  choice: "select",
  multi_select: "select",
  confirm: "confirm",
  table: "table",
  detail: "detail",
  card: "output_card",
  report: "output_card",
  summary_card: "summary_card",
  list_card: "list_card",
  output_card: "output_card",
  page_action: "page_action",
  custom: "custom"
};
function pc(e) {
  const t = String(e || "custom").toLowerCase();
  return hc[t] || "custom";
}
function gc(e) {
  if (e)
    return dc.get(e);
}
const mc = ["aria-label"], yc = {
  key: 0,
  class: "reachai-interaction__header"
}, bc = { key: 0 }, _c = {
  key: 1,
  class: "reachai-interaction__badge"
}, vc = {
  key: 1,
  class: "reachai-interaction__message"
}, Sc = {
  key: 2,
  class: "reachai-interaction__state",
  "aria-live": "polite"
}, wc = { key: 0 }, Ic = ["onUpdate:modelValue", "disabled"], xc = ["onUpdate:modelValue", "disabled", "placeholder"], Cc = ["value", "multiple", "disabled", "onChange"], Ac = ["value"], kc = ["onUpdate:modelValue", "disabled"], Ec = ["value", "disabled", "placeholder", "onInput"], Tc = ["value", "disabled", "placeholder", "onInput"], Pc = {
  key: 0,
  class: "reachai-interaction__actions"
}, $c = ["disabled"], Rc = ["disabled"], Oc = {
  key: 5,
  class: "reachai-interaction__confirm"
}, Mc = {
  key: 0,
  class: "reachai-interaction__actions"
}, qc = ["disabled"], jc = ["disabled"], Nc = ["disabled"], Fc = {
  key: 6,
  class: "reachai-interaction__choice"
}, Dc = ["value", "disabled"], Kc = ["name", "value", "disabled"], Lc = {
  key: 0,
  class: "reachai-interaction__actions"
}, Uc = ["disabled"], Bc = ["disabled"], Hc = {
  key: 7,
  class: "reachai-interaction__table-wrap"
}, Vc = { class: "reachai-interaction__table" }, Wc = {
  key: 8,
  class: "reachai-interaction__detail"
}, zc = {
  key: 0,
  class: "reachai-interaction__actions"
}, Jc = ["disabled", "onClick"], Gc = {
  key: 9,
  class: "reachai-interaction__list"
}, Yc = {
  key: 10,
  class: "reachai-interaction__page-action"
}, Xc = { class: "reachai-interaction__actions" }, Qc = ["disabled"], Zc = ["disabled"], eu = {
  key: 11,
  class: "reachai-interaction__custom"
}, tu = { class: "reachai-interaction__warn" }, su = { class: "reachai-interaction__actions" }, nu = ["disabled"], ru = ["disabled"], iu = {
  key: 12,
  class: "reachai-interaction__error",
  role: "alert"
}, ou = {
  key: 13,
  class: "reachai-interaction__actions"
}, au = /* @__PURE__ */ ht({
  __name: "UnifiedInteractionRenderer",
  props: {
    request: {},
    state: {},
    errorMessage: {},
    disabled: { type: Boolean }
  },
  emits: ["submit", "cancel", "action"],
  setup(e, { emit: t }) {
    const s = e, n = t, r = fe(() => pc(s.request.component)), i = fe(() => s.state || "waiting"), o = fe(
      () => s.disabled || i.value === "submitting" || i.value === "resolved" || i.value === "expired" || i.value === "cancelled"
    ), a = fe(() => `reachai-choice-${s.request.interactionId || "default"}`), l = /* @__PURE__ */ De(""), f = fe(() => s.request.actions || []), c = fe(() => {
      var v;
      return ((v = s.request.behavior) == null ? void 0 : v.readonly) === !0 ? !0 : (/* @__PURE__ */ new Set(["table", "detail", "summary_card", "list_card", "output_card", "card", "report"])).has(r.value) && !f.value.length;
    }), d = fe(() => !c.value), g = fe(() => {
      switch (i.value) {
        case "submitting":
          return "提交中…";
        case "resolved":
          return "已提交";
        case "failed":
          return "提交失败";
        case "expired":
          return "已过期";
        case "cancelled":
          return "已取消";
        default:
          return "";
      }
    }), _ = /* @__PURE__ */ Us({}), M = /* @__PURE__ */ De(null), p = /* @__PURE__ */ De([]), $ = /* @__PURE__ */ De(null);
    function K(y, v) {
      return y == null ? v.type === "boolean" ? !1 : v.type === "multi_select" ? [] : "" : typeof y == "string" || typeof y == "number" || typeof y == "boolean" ? y : Array.isArray(y) ? y.map(String) : String(y);
    }
    qt(
      () => s.request,
      (y) => {
        var P, ee, we, pt;
        l.value = "", Object.keys(_).forEach((u) => delete _[u]);
        for (const u of y.fields || []) {
          const h = (P = y.prefilled) == null ? void 0 : P[u.key];
          _[u.key] = K(h, u);
        }
        const v = (ee = y.fields) == null ? void 0 : ee[0], V = v == null ? void 0 : v.key, oe = V && ((we = y.prefilled) == null ? void 0 : we[V]) !== void 0 ? y.prefilled[V] : (pt = y.prefilled) == null ? void 0 : pt.value;
        if (y.component === "multi_select") {
          Array.isArray(oe) ? p.value = [...oe] : oe == null ? p.value = [] : p.value = [oe], M.value = null;
          return;
        }
        oe !== void 0 && (typeof oe == "string" || typeof oe == "number" || typeof oe == "boolean" ? M.value = oe : oe == null ? M.value = null : M.value = String(oe));
      },
      { immediate: !0, deep: !0 }
    );
    function E(y) {
      var v;
      return y.type === "select" || y.type === "multi_select" || !!((v = y.options) != null && v.length);
    }
    function L(y) {
      const v = _[y.key];
      return y.type === "multi_select" ? Array.isArray(v) ? v.map(String) : [] : typeof v == "string" || typeof v == "number" ? v : v == null ? void 0 : String(v);
    }
    function R(y, v) {
      const V = v.target;
      y.type === "multi_select" ? _[y.key] = Array.from(V.selectedOptions).map((oe) => oe.value) : _[y.key] = V.value;
    }
    const B = fe(() => {
      var V, oe;
      const y = (V = s.request.fields) == null ? void 0 : V[0];
      if ((oe = y == null ? void 0 : y.options) != null && oe.length) return y.options;
      const v = s.request.data;
      return Array.isArray(v) ? v.map((P, ee) => {
        if (P && typeof P == "object") {
          const we = P;
          return { value: we.value ?? we.id ?? ee, label: String(we.label ?? we.name ?? we.value ?? ee) };
        }
        return { value: P, label: String(P) };
      }) : [];
    }), m = fe(() => {
      const y = s.request.data;
      return Array.isArray(y) ? y.map((v) => v && typeof v == "object" ? v : { value: v }) : y && typeof y == "object" ? [y] : s.request.summary ? [s.request.summary] : [];
    }), k = fe(() => {
      const y = H(s.request);
      if (y.length) return y;
      const v = m.value[0];
      return v ? Object.keys(v).map((V) => ({ key: V, label: V })) : [];
    });
    function H(y) {
      var V, oe;
      const v = [
        (V = y.schema) == null ? void 0 : V.columns,
        (oe = y.extension) == null ? void 0 : oe.columns,
        y.data && typeof y.data == "object" && !Array.isArray(y.data) ? y.data.columns : void 0
      ];
      for (const P of v)
        if (!(!Array.isArray(P) || !P.length))
          return P.map((ee, we) => {
            if (typeof ee == "string") return { key: ee, label: ee };
            if (ee && typeof ee == "object") {
              const pt = ee, u = String(pt.key ?? pt.field ?? pt.name ?? we);
              return { key: u, label: String(pt.label ?? pt.title ?? u) };
            }
            return { key: String(we), label: String(ee) };
          });
      return [];
    }
    const se = fe(() => {
      const y = s.request.summary || s.request.data || {};
      return Array.isArray(y) ? y.map((v, V) => ({
        key: String(V),
        label: `#${V + 1}`,
        value: v
      })) : Object.entries(y || {}).map(([v, V]) => ({ key: v, label: v, value: V }));
    }), ne = fe(() => {
      var v;
      const y = (v = s.request.extension) == null ? void 0 : v.pageActionRequest;
      return y && typeof y == "object" ? y : s.request.data && typeof s.request.data == "object" ? s.request.data : {};
    }), Pe = fe(
      () => String(ne.value.title || s.request.title || "页面动作")
    ), ke = fe(
      () => {
        var y;
        return (y = s.request.extension) != null && y.rendererKey ? String(s.request.extension.rendererKey) : "";
      }
    ), q = fe(() => {
      const y = ke.value;
      if (!y) return null;
      const v = gc(y);
      if (!v) return null;
      const V = v({
        request: s.request,
        state: i.value,
        disabled: o.value,
        onSubmit: (oe, P) => ge(oe, P),
        onCancel: () => le()
      });
      return V ? /* @__PURE__ */ ht({
        name: `ReachAiCustomInteraction_${y}`,
        setup() {
          return () => ul(V);
        }
      }) : null;
    });
    function U(y) {
      if (y == null) return "-";
      if (typeof y == "string") return y;
      try {
        return JSON.stringify(y);
      } catch {
        return String(y);
      }
    }
    function G(y) {
      return String(y.key || y.action || "submit");
    }
    function Y(y) {
      return String(y.label || y.key || y.action || "提交");
    }
    function Q(y) {
      return y.values && typeof y.values == "object" ? y.values : { ...y };
    }
    function re(y) {
      return y.type === "primary" || G(y) === "confirm" || G(y) === "submit";
    }
    function ge(y, v) {
      o.value && i.value !== "failed" || ($.value = { action: y, values: v }, n("submit", y, v), n("action", y, v));
    }
    function je(y) {
      for (const v of s.request.fields || [])
        if (v.required) {
          const V = _[v.key];
          if (V === "" || V == null || Array.isArray(V) && !V.length) {
            l.value = `请填写必填项：${v.label || v.key}`;
            return;
          }
        }
      l.value = "", ge(y, { ..._ });
    }
    function xe() {
      var y, v;
      if (s.request.component === "multi_select") {
        if (!p.value.length && ((y = s.request.fields) != null && y.some((V) => V.required))) {
          l.value = "请至少选择一项";
          return;
        }
        l.value = "", ge("choose", { value: [...p.value] });
      } else {
        if ((M.value === null || M.value === "") && ((v = s.request.fields) != null && v.some((V) => V.required))) {
          l.value = "请选择一项";
          return;
        }
        l.value = "", ge("choose", { value: M.value });
      }
    }
    function le() {
      o.value || (n("cancel"), n("action", "cancel", {}));
    }
    function D() {
      $.value && (n("submit", $.value.action, $.value.values), n("action", $.value.action, $.value.values));
    }
    return (y, v) => {
      var V, oe;
      return x(), A("div", {
        class: Ye(["reachai-interaction", [
          `reachai-interaction--${r.value}`,
          `reachai-interaction--${i.value}`,
          { "is-disabled": o.value }
        ]]),
        role: "region",
        "aria-label": e.request.title || e.request.component || "interaction"
      }, [
        e.request.title || (V = e.request.missing) != null && V.length ? (x(), A("header", yc, [
          e.request.title ? (x(), A("strong", bc, te(e.request.title), 1)) : ie("", !0),
          (oe = e.request.missing) != null && oe.length ? (x(), A("span", _c, "待补充 " + te(e.request.missing.length) + " 项", 1)) : ie("", !0)
        ])) : ie("", !0),
        e.request.message && r.value !== "form" ? (x(), A("p", vc, te(e.request.message), 1)) : ie("", !0),
        g.value ? (x(), A("div", Sc, te(g.value), 1)) : ie("", !0),
        q.value ? (x(), st(xa(q.value), {
          key: 3,
          class: "reachai-interaction__custom-host"
        })) : r.value === "form" ? (x(), A("form", {
          key: 4,
          class: "reachai-interaction__form",
          onSubmit: v[0] || (v[0] = Qi((P) => je("submit"), ["prevent"]))
        }, [
          (x(!0), A(be, null, Be(e.request.fields || [], (P) => (x(), A("label", {
            key: P.key,
            class: "reachai-interaction__field"
          }, [
            N("span", null, [
              us(te(P.label), 1),
              P.required ? (x(), A("em", wc, "*")) : ie("", !0)
            ]),
            P.type === "boolean" ? Kt((x(), A("input", {
              key: 0,
              "onUpdate:modelValue": (ee) => _[P.key] = ee,
              type: "checkbox",
              disabled: o.value
            }, null, 8, Ic)), [
              [Or, _[P.key]]
            ]) : P.type === "number" || P.type === "integer" ? Kt((x(), A("input", {
              key: 1,
              "onUpdate:modelValue": (ee) => _[P.key] = ee,
              type: "number",
              disabled: o.value,
              placeholder: P.placeholder
            }, null, 8, xc)), [
              [
                Sn,
                _[P.key],
                void 0,
                { number: !0 }
              ]
            ]) : E(P) ? (x(), A("select", {
              key: 2,
              value: L(P),
              multiple: P.type === "multi_select",
              disabled: o.value,
              onChange: (ee) => R(P, ee)
            }, [
              (x(!0), A(be, null, Be(P.options || [], (ee) => (x(), A("option", {
                key: String(ee.value),
                value: ee.value
              }, te(ee.label), 9, Ac))), 128))
            ], 40, Cc)) : P.type === "date" ? Kt((x(), A("input", {
              key: 3,
              "onUpdate:modelValue": (ee) => _[P.key] = ee,
              type: "date",
              disabled: o.value
            }, null, 8, kc)), [
              [Sn, _[P.key]]
            ]) : P.type === "textarea" || P.type === "object" || P.type === "array" ? (x(), A("textarea", {
              key: 4,
              value: String(_[P.key] ?? ""),
              rows: "3",
              disabled: o.value,
              placeholder: P.placeholder,
              onInput: (ee) => _[P.key] = ee.target.value
            }, null, 40, Ec)) : (x(), A("input", {
              key: 5,
              value: String(_[P.key] ?? ""),
              type: "text",
              disabled: o.value,
              placeholder: P.placeholder,
              onInput: (ee) => _[P.key] = ee.target.value
            }, null, 40, Tc))
          ]))), 128)),
          d.value ? (x(), A("div", Pc, [
            N("button", {
              type: "button",
              disabled: o.value,
              onClick: le
            }, "取消", 8, $c),
            N("button", {
              type: "submit",
              class: "is-primary",
              disabled: o.value
            }, "提交", 8, Rc)
          ])) : ie("", !0)
        ], 32)) : r.value === "confirm" ? (x(), A("div", Oc, [
          N("p", null, te(e.request.message || "请确认是否继续。"), 1),
          d.value ? (x(), A("div", Mc, [
            N("button", {
              type: "button",
              disabled: o.value,
              onClick: le
            }, "取消", 8, qc),
            N("button", {
              type: "button",
              disabled: o.value,
              onClick: v[1] || (v[1] = (P) => ge("reject", { confirm: !1 }))
            }, "拒绝", 8, jc),
            N("button", {
              type: "button",
              class: "is-primary",
              disabled: o.value,
              onClick: v[2] || (v[2] = (P) => ge("confirm", { confirm: !0 }))
            }, "确认", 8, Nc)
          ])) : ie("", !0)
        ])) : r.value === "select" ? (x(), A("div", Fc, [
          (x(!0), A(be, null, Be(B.value, (P) => (x(), A("label", {
            key: String(P.value),
            class: "reachai-interaction__option"
          }, [
            e.request.component === "multi_select" ? Kt((x(), A("input", {
              key: 0,
              "onUpdate:modelValue": v[3] || (v[3] = (ee) => p.value = ee),
              type: "checkbox",
              value: P.value,
              disabled: o.value
            }, null, 8, Dc)), [
              [Or, p.value]
            ]) : Kt((x(), A("input", {
              key: 1,
              "onUpdate:modelValue": v[4] || (v[4] = (ee) => M.value = ee),
              type: "radio",
              name: a.value,
              value: P.value,
              disabled: o.value
            }, null, 8, Kc)), [
              [ql, M.value]
            ]),
            N("span", null, te(P.label), 1)
          ]))), 128)),
          d.value ? (x(), A("div", Lc, [
            N("button", {
              type: "button",
              disabled: o.value,
              onClick: le
            }, "取消", 8, Uc),
            N("button", {
              type: "button",
              class: "is-primary",
              disabled: o.value,
              onClick: xe
            }, "选择", 8, Bc)
          ])) : ie("", !0)
        ])) : r.value === "table" ? (x(), A("div", Hc, [
          N("table", Vc, [
            N("thead", null, [
              N("tr", null, [
                (x(!0), A(be, null, Be(k.value, (P) => (x(), A("th", {
                  key: P.key
                }, te(P.label), 1))), 128))
              ])
            ]),
            N("tbody", null, [
              (x(!0), A(be, null, Be(m.value, (P, ee) => (x(), A("tr", { key: ee }, [
                (x(!0), A(be, null, Be(k.value, (we) => (x(), A("td", {
                  key: we.key
                }, te(U(P[we.key])), 1))), 128))
              ]))), 128))
            ])
          ])
        ])) : r.value === "detail" || r.value === "summary_card" || r.value === "output_card" ? (x(), A("div", Wc, [
          N("dl", null, [
            (x(!0), A(be, null, Be(se.value, (P) => (x(), A("div", {
              key: P.key
            }, [
              N("dt", null, te(P.label), 1),
              N("dd", null, te(U(P.value)), 1)
            ]))), 128))
          ]),
          d.value && f.value.length ? (x(), A("div", zc, [
            (x(!0), A(be, null, Be(f.value, (P) => (x(), A("button", {
              key: G(P),
              type: "button",
              class: Ye({ "is-primary": re(P) }),
              disabled: o.value,
              onClick: (ee) => ge(G(P), Q(P))
            }, te(Y(P)), 11, Jc))), 128))
          ])) : ie("", !0)
        ])) : r.value === "list_card" ? (x(), A("div", Gc, [
          (x(!0), A(be, null, Be(m.value, (P, ee) => (x(), A("article", {
            key: ee,
            class: "reachai-interaction__list-item"
          }, [
            N("strong", null, te(P.title || P.name || `#${ee + 1}`), 1),
            N("span", null, te(P.description || P.summary || U(P)), 1)
          ]))), 128))
        ])) : r.value === "page_action" ? (x(), A("div", Yc, [
          N("p", null, te(Pe.value), 1),
          N("dl", null, [
            N("div", null, [
              v[7] || (v[7] = N("dt", null, "actionKey", -1)),
              N("dd", null, te(ne.value.actionKey || "-"), 1)
            ]),
            N("div", null, [
              v[8] || (v[8] = N("dt", null, "requestId", -1)),
              N("dd", null, te(ne.value.requestId || e.request.interactionId || "-"), 1)
            ]),
            N("div", null, [
              v[9] || (v[9] = N("dt", null, "args", -1)),
              N("dd", null, te(U(ne.value.args || {})), 1)
            ])
          ]),
          N("div", Xc, [
            ne.value.confirm ? (x(), A("button", {
              key: 0,
              type: "button",
              disabled: o.value,
              onClick: le
            }, "取消", 8, Qc)) : ie("", !0),
            N("button", {
              type: "button",
              class: "is-primary",
              disabled: o.value,
              onClick: v[5] || (v[5] = (P) => ge("page_action_ack", { requestId: ne.value.requestId, actionKey: ne.value.actionKey }))
            }, " 已收到 ", 8, Zc)
          ])
        ])) : (x(), A("div", eu, [
          N("p", tu, te(ke.value ? `自定义渲染器未在宿主注册：${ke.value}` : `未注册的交互组件：${e.request.component || "unknown"}`), 1),
          N("pre", null, te(U(e.request.data ?? e.request.summary ?? {})), 1),
          N("div", su, [
            N("button", {
              type: "button",
              disabled: o.value,
              onClick: le
            }, "取消", 8, nu),
            N("button", {
              type: "button",
              class: "is-primary",
              disabled: o.value,
              onClick: v[6] || (v[6] = (P) => ge("submit", {}))
            }, "按原始值提交", 8, ru)
          ])
        ])),
        l.value || e.errorMessage ? (x(), A("p", iu, te(l.value || e.errorMessage), 1)) : ie("", !0),
        i.value === "failed" ? (x(), A("div", ou, [
          N("button", {
            type: "button",
            class: "is-primary",
            onClick: D
          }, "重试")
        ])) : ie("", !0)
      ], 10, mc);
    };
  }
}), Nt = (e, t) => {
  const s = e.__vccOpts || e;
  for (const [n, r] of t)
    s[n] = r;
  return s;
}, lu = /* @__PURE__ */ Nt(au, [["__scopeId", "data-v-3056692d"]]), cu = ["data-type"], uu = {
  key: 0,
  class: "reachai-block__caret",
  "aria-hidden": "true"
}, fu = {
  key: 2,
  class: "reachai-block__page-action"
}, du = { key: 0 }, hu = ["data-level"], pu = {
  key: 4,
  class: "reachai-block__error",
  role: "alert"
}, gu = /* @__PURE__ */ ht({
  __name: "ConversationBlockRenderer",
  props: {
    block: {}
  },
  emits: ["interaction-submit", "interaction-cancel", "retry"],
  setup(e, { emit: t }) {
    const s = t;
    function n(i, o, a) {
      i.type === "interaction" && s("interaction-submit", i.request.interactionId, o, a);
    }
    function r(i) {
      i.type === "interaction" && s("interaction-cancel", i.request.interactionId);
    }
    return (i, o) => (x(), A("div", {
      class: "reachai-block",
      "data-type": e.block.type
    }, [
      e.block.type === "text" ? (x(), A("div", {
        key: 0,
        class: Ye(["reachai-block__text", { "is-streaming": e.block.status === "streaming" }])
      }, [
        us(te(e.block.text) + " ", 1),
        e.block.status === "streaming" ? (x(), A("span", uu)) : ie("", !0)
      ], 2)) : e.block.type === "interaction" ? (x(), st(lu, {
        key: 1,
        request: e.block.request,
        state: e.block.state,
        "error-message": e.block.errorMessage,
        onSubmit: o[0] || (o[0] = (a, l) => n(e.block, a, l)),
        onCancel: o[1] || (o[1] = (a) => r(e.block))
      }, null, 8, ["request", "state", "error-message"])) : e.block.type === "page_action" ? (x(), A("div", fu, [
        N("strong", null, te(e.block.title || e.block.actionKey), 1),
        N("span", null, te(e.block.status), 1),
        e.block.message ? (x(), A("p", du, te(e.block.message), 1)) : ie("", !0)
      ])) : e.block.type === "notice" ? (x(), A("div", {
        key: 3,
        class: "reachai-block__notice",
        "data-level": e.block.level || "info"
      }, te(e.block.text), 9, hu)) : e.block.type === "error" ? (x(), A("div", pu, [
        us(te(e.block.text) + " ", 1),
        e.block.retryable ? (x(), A("button", {
          key: 0,
          type: "button",
          onClick: o[2] || (o[2] = (a) => i.$emit("retry"))
        }, "重试")) : ie("", !0)
      ])) : ie("", !0)
    ], 8, cu));
  }
}), Kr = /* @__PURE__ */ Nt(gu, [["__scopeId", "data-v-775b19fc"]]), mu = ["data-message-id", "data-role", "data-status"], yu = {
  key: 0,
  class: "reachai-message__user-row"
}, bu = { class: "reachai-message__user-bubble" }, _u = {
  key: 0,
  class: "reachai-message__user-avatar",
  "aria-hidden": "true"
}, vu = {
  key: 1,
  class: "reachai-message__assistant-row"
}, Su = {
  key: 0,
  class: "reachai-message__prism-avatar",
  "aria-hidden": "true"
}, wu = {
  key: 0,
  class: "reachai-message__card-heading"
}, Iu = {
  key: 0,
  class: "reachai-message__thinking-title"
}, xu = {
  key: 1,
  class: "reachai-message__weak-label"
}, Cu = {
  key: 2,
  class: "reachai-message__heading-spacer",
  "aria-hidden": "true"
}, Au = ["data-tone"], ku = {
  key: 1,
  class: "reachai-message__status-hint"
}, Eu = {
  key: 2,
  class: "reachai-message__thinking-details"
}, Tu = ["aria-expanded"], Pu = {
  class: "reachai-message__thinking-chevron",
  "aria-hidden": "true"
}, $u = {
  key: 0,
  class: "reachai-message__thinking-steps"
}, Ru = ["data-state"], Ou = { class: "reachai-message__thinking-step-body" }, Mu = { key: 0 }, qu = { class: "reachai-message__body" }, ju = {
  key: 0,
  class: "reachai-message__loading"
}, Nu = {
  key: 3,
  class: "reachai-message__meta"
}, Fu = /* @__PURE__ */ ht({
  __name: "ConversationMessageItem",
  props: {
    message: {},
    assistantLabel: { default: "" },
    statusHint: { default: "" },
    thinkingPresentation: { default: null },
    showAvatars: { type: Boolean, default: !0 },
    surface: { default: "admin" }
  },
  emits: ["interaction-submit", "interaction-cancel", "retry"],
  setup(e) {
    const t = e, s = /* @__PURE__ */ De(!1), n = fe(
      () => t.message.role !== "user" && (t.message.status === "pending" || t.message.status === "streaming")
    ), r = fe(() => n.value), i = fe(() => {
      var d;
      return ((d = t.thinkingPresentation) == null ? void 0 : d.steps) || [];
    });
    qt(
      () => t.message.id,
      () => {
        s.value = !1;
      }
    ), qt(n, (d) => {
      d || (s.value = !1);
    });
    const o = fe(
      () => !n.value && !!t.assistantLabel && t.message.role === "assistant" && t.surface === "admin"
    ), a = fe(() => [
      `reachai-message--${t.message.role}`,
      `reachai-message--${t.message.status}`,
      {
        "reachai-message--thinking": n.value,
        "reachai-message--prism": t.message.role !== "user"
      }
    ]), l = fe(() => ({
      "reachai-message__card-shell--thinking": n.value,
      "reachai-message__card-shell--response": !n.value,
      "reachai-message__card-shell--failed": t.message.status === "failed",
      "reachai-message__card-shell--cancelled": t.message.status === "cancelled"
    })), f = fe(() => ({
      "reachai-message__card--thinking": n.value,
      "reachai-message__card--response": !n.value,
      [`reachai-message__card--${t.message.status}`]: !0
    })), c = fe(() => n.value ? null : t.message.status === "failed" ? { label: "失败", tone: "danger" } : t.message.status === "cancelled" ? { label: "已取消", tone: "warning" } : null);
    return (d, g) => {
      var _;
      return x(), A("article", {
        class: Ye(["reachai-message", a.value]),
        "data-message-id": e.message.id,
        "data-role": e.message.role,
        "data-status": e.message.status
      }, [
        e.message.role === "user" ? (x(), A("div", yu, [
          N("div", bu, [
            (x(!0), A(be, null, Be(e.message.blocks, (M) => (x(), st(Kr, {
              key: M.id,
              block: M,
              onInteractionSubmit: g[0] || (g[0] = (...p) => d.$emit("interaction-submit", ...p)),
              onInteractionCancel: g[1] || (g[1] = (p) => d.$emit("interaction-cancel", p)),
              onRetry: g[2] || (g[2] = (p) => d.$emit("retry"))
            }, null, 8, ["block"]))), 128))
          ]),
          e.showAvatars ? (x(), A("div", _u, [...g[7] || (g[7] = [
            N("svg", {
              viewBox: "0 0 24 24",
              width: "18",
              height: "18",
              fill: "none",
              stroke: "currentColor",
              "stroke-width": "1.8"
            }, [
              N("circle", {
                cx: "12",
                cy: "8",
                r: "3.5"
              }),
              N("path", {
                d: "M5 19.5c1.2-3.2 3.6-4.8 7-4.8s5.8 1.6 7 4.8",
                "stroke-linecap": "round"
              })
            ], -1)
          ])])) : ie("", !0)
        ])) : (x(), A("div", vu, [
          e.showAvatars ? (x(), A("div", Su, [...g[8] || (g[8] = [
            N("span", { class: "reachai-message__prism-avatar-img" }, null, -1)
          ])])) : ie("", !0),
          N("div", {
            class: Ye(["reachai-message__card-shell", l.value])
          }, [
            N("div", {
              class: Ye(["reachai-message__card", f.value])
            }, [
              r.value || o.value || c.value ? (x(), A("header", wu, [
                r.value ? (x(), A("div", Iu, [...g[9] || (g[9] = [
                  N("span", {
                    class: "reachai-message__spark",
                    "aria-hidden": "true"
                  }, "✦", -1),
                  N("strong", null, "思考中…", -1),
                  N("span", {
                    class: "reachai-message__thinking-dots",
                    "aria-hidden": "true"
                  }, [
                    N("i"),
                    N("i"),
                    N("i")
                  ], -1)
                ])])) : o.value ? (x(), A("div", xu, te(e.assistantLabel), 1)) : (x(), A("span", Cu)),
                c.value ? (x(), A("span", {
                  key: 3,
                  class: "reachai-message__status-capsule",
                  "data-tone": c.value.tone
                }, te(c.value.label), 9, Au)) : ie("", !0)
              ])) : ie("", !0),
              r.value && e.statusHint ? (x(), A("p", ku, te(e.statusHint), 1)) : ie("", !0),
              r.value && ((_ = e.thinkingPresentation) != null && _.label) ? (x(), A("div", Eu, [
                N("button", {
                  type: "button",
                  class: "reachai-message__thinking-toggle",
                  "aria-expanded": s.value,
                  onClick: g[3] || (g[3] = (M) => s.value = !s.value)
                }, [
                  N("span", null, te(e.thinkingPresentation.label), 1),
                  N("span", Pu, te(s.value ? "▴" : "▾"), 1)
                ], 8, Tu),
                s.value && i.value.length ? (x(), A("ul", $u, [
                  (x(!0), A(be, null, Be(i.value, (M) => (x(), A("li", {
                    key: M.id,
                    class: "reachai-message__thinking-step",
                    "data-state": M.state
                  }, [
                    g[10] || (g[10] = N("span", {
                      class: "reachai-message__thinking-step-mark",
                      "aria-hidden": "true"
                    }, null, -1)),
                    N("div", Ou, [
                      N("strong", null, te(M.title), 1),
                      M.detail ? (x(), A("p", Mu, te(M.detail), 1)) : ie("", !0)
                    ])
                  ], 8, Ru))), 128))
                ])) : ie("", !0)
              ])) : ie("", !0),
              N("div", qu, [
                (x(!0), A(be, null, Be(e.message.blocks, (M) => (x(), st(Kr, {
                  key: M.id,
                  block: M,
                  onInteractionSubmit: g[4] || (g[4] = (...p) => d.$emit("interaction-submit", ...p)),
                  onInteractionCancel: g[5] || (g[5] = (p) => d.$emit("interaction-cancel", p)),
                  onRetry: g[6] || (g[6] = (p) => d.$emit("retry"))
                }, null, 8, ["block"]))), 128)),
                !e.message.blocks.length && n.value && !e.statusHint ? (x(), A("div", ju, " 正在处理 ")) : ie("", !0)
              ]),
              d.$slots.meta ? (x(), A("footer", Nu, [
                Et(d.$slots, "meta", { message: e.message }, void 0)
              ])) : ie("", !0)
            ], 2)
          ], 2)
        ]))
      ], 10, mu);
    };
  }
}), Du = /* @__PURE__ */ Nt(Fu, [["__scopeId", "data-v-05a4c2be"]]), Ku = {
  key: 0,
  class: "reachai-message-list__empty"
}, Lu = /* @__PURE__ */ ht({
  __name: "ConversationMessageList",
  props: {
    messages: {},
    autoFollow: { type: Boolean, default: !0 },
    assistantLabel: { default: "" },
    resolveStatusHint: {},
    resolveThinkingPresentation: {},
    showAvatars: { type: Boolean, default: !0 },
    surface: { default: "admin" }
  },
  emits: ["interaction-submit", "interaction-cancel", "retry"],
  setup(e, { expose: t }) {
    const s = e, n = /* @__PURE__ */ De(null), r = /* @__PURE__ */ De(!0), i = /* @__PURE__ */ De(!1);
    function o(c) {
      var d;
      return ((d = s.resolveStatusHint) == null ? void 0 : d.call(s, c)) || "";
    }
    function a(c) {
      var d;
      return ((d = s.resolveThinkingPresentation) == null ? void 0 : d.call(s, c)) || null;
    }
    function l() {
      const c = n.value;
      if (!c) return;
      const d = c.scrollHeight - c.scrollTop - c.clientHeight;
      r.value = d < 48, i.value = !r.value;
    }
    function f(c = !1) {
      const d = n.value;
      d && (!c && !r.value || (d.scrollTop = d.scrollHeight, i.value = !1, r.value = !0));
    }
    return qt(
      () => s.messages,
      async () => {
        s.autoFollow !== !1 && (await jn(), f());
      },
      { deep: !0 }
    ), Dn(() => f(!0)), t({ scrollToBottom: f }), (c, d) => (x(), A("div", {
      ref_key: "listEl",
      ref: n,
      class: "reachai-message-list",
      role: "log",
      "aria-live": "polite",
      onScroll: l
    }, [
      e.messages.length ? ie("", !0) : (x(), A("div", Ku, [
        Et(c.$slots, "empty", {}, () => [
          d[4] || (d[4] = us("开始对话吧", -1))
        ])
      ])),
      (x(!0), A(be, null, Be(e.messages, (g) => (x(), st(Du, {
        key: g.id,
        message: g,
        "assistant-label": e.assistantLabel,
        "status-hint": o(g),
        "thinking-presentation": a(g),
        "show-avatars": e.showAvatars,
        surface: e.surface,
        onInteractionSubmit: d[0] || (d[0] = (..._) => c.$emit("interaction-submit", ..._)),
        onInteractionCancel: d[1] || (d[1] = (_) => c.$emit("interaction-cancel", _)),
        onRetry: d[2] || (d[2] = (_) => c.$emit("retry"))
      }, xi({ _: 2 }, [
        c.$slots["message-meta"] ? {
          name: "meta",
          fn: Es((_) => [
            Et(c.$slots, "message-meta", Wi({ ref_for: !0 }, _), void 0, !0)
          ]),
          key: "0"
        } : void 0
      ]), 1032, ["message", "assistant-label", "status-hint", "thinking-presentation", "show-avatars", "surface"]))), 128)),
      i.value ? (x(), A("button", {
        key: 1,
        type: "button",
        class: "reachai-message-list__jump",
        onClick: d[3] || (d[3] = (g) => f(!0))
      }, " 回到底部 ")) : ie("", !0)
    ], 544));
  }
}), Uu = /* @__PURE__ */ Nt(Lu, [["__scopeId", "data-v-3cddb8bb"]]), Bu = ["placeholder", "disabled", "aria-label"], Hu = { class: "reachai-composer__actions" }, Vu = { class: "reachai-composer__buttons" }, Wu = ["disabled"], zu = /* @__PURE__ */ ht({
  __name: "ConversationComposer",
  props: {
    placeholder: { default: "输入消息" },
    disabled: { type: Boolean, default: !1 },
    showStop: { type: Boolean, default: !1 }
  },
  emits: ["send", "stop"],
  setup(e, { expose: t, emit: s }) {
    const n = s, r = /* @__PURE__ */ De(""), i = /* @__PURE__ */ De(null);
    function o() {
      const l = r.value.trim();
      l && (n("send", l), r.value = "");
    }
    function a(l) {
      (l.ctrlKey || l.metaKey) && l.key === "Enter" && (l.preventDefault(), o());
    }
    return t({
      focus() {
        var l;
        (l = i.value) == null || l.focus();
      },
      setValue(l) {
        r.value = l;
      }
    }), (l, f) => (x(), A("form", {
      class: "reachai-composer",
      onSubmit: Qi(o, ["prevent"])
    }, [
      Kt(N("textarea", {
        ref_key: "inputEl",
        ref: i,
        "onUpdate:modelValue": f[0] || (f[0] = (c) => r.value = c),
        class: "reachai-composer__input",
        rows: "2",
        placeholder: e.placeholder,
        disabled: e.disabled,
        "aria-label": e.placeholder,
        onKeydown: a
      }, null, 40, Bu), [
        [Sn, r.value]
      ]),
      N("div", Hu, [
        f[2] || (f[2] = N("span", { class: "reachai-composer__hint" }, [
          N("kbd", null, "Ctrl"),
          N("b", null, "+"),
          N("kbd", null, "Enter"),
          N("em", null, "发送")
        ], -1)),
        N("div", Vu, [
          e.showStop ? (x(), A("button", {
            key: 0,
            type: "button",
            class: "reachai-composer__stop",
            onClick: f[1] || (f[1] = (c) => l.$emit("stop"))
          }, " 停止 ")) : ie("", !0),
          N("button", {
            type: "submit",
            class: Ye(["reachai-composer__send", { "is-busy": e.showStop }]),
            disabled: e.disabled || !r.value.trim()
          }, te(e.showStop ? "思考中" : "发送"), 11, Wu)
        ])
      ])
    ], 32));
  }
}), Ju = /* @__PURE__ */ Nt(zu, [["__scopeId", "data-v-fe697210"]]);
function ro(e) {
  return `./${e}`;
}
const Gu = ro("agent-prism.webp"), Yu = ro("conversation-atmosphere.webp"), Xu = ["data-surface"], Qu = {
  key: 0,
  class: "reachai-conversation__header"
}, Zu = {
  key: 1,
  class: "reachai-conversation__error",
  role: "alert"
}, ef = {
  key: 2,
  class: "reachai-conversation__footer"
}, tf = /* @__PURE__ */ ht({
  __name: "ConversationView",
  props: {
    snapshot: {},
    density: { default: "comfortable" },
    chrome: { default: "panel" },
    placeholder: {},
    hideComposer: { type: Boolean, default: !1 },
    autoFollow: { type: Boolean, default: !0 },
    disableSendWhileBusy: { type: Boolean, default: !0 },
    atmosphere: { type: Boolean, default: !0 },
    assistantLabel: { default: "" },
    showAvatars: { type: Boolean, default: !0 },
    surface: { default: "admin" },
    resolveStatusHint: {},
    resolveThinkingPresentation: {}
  },
  emits: ["send", "stop", "retry", "interaction-submit", "interaction-cancel"],
  setup(e, { emit: t }) {
    const s = e, n = t, r = fe(() => ({
      "--reachai-chat-atmosphere-image": `url("${Yu}")`,
      "--reachai-chat-prism-avatar": `url("${Gu}")`
    })), i = fe(
      () => s.snapshot.turnStatus === "sending" || s.snapshot.turnStatus === "streaming"
    ), o = fe(() => i.value), a = fe(
      () => s.disableSendWhileBusy && (i.value || s.snapshot.turnStatus === "waiting")
    );
    function l(d) {
      n("send", d);
    }
    function f(d, g, _) {
      n("interaction-submit", d, g, _);
    }
    function c(d) {
      n("interaction-cancel", d);
    }
    return (d, g) => (x(), A("div", {
      class: Ye(["reachai-conversation", [
        `reachai-conversation--${e.density}`,
        `reachai-conversation--${e.chrome}`,
        {
          "reachai-conversation--atmosphere": e.atmosphere,
          "is-busy": i.value
        }
      ]]),
      "data-surface": e.surface,
      style: hs(r.value)
    }, [
      d.$slots.header ? (x(), A("header", Qu, [
        Et(d.$slots, "header", {}, void 0)
      ])) : ie("", !0),
      Me(Uu, {
        messages: e.snapshot.messages,
        "auto-follow": e.autoFollow,
        "assistant-label": e.assistantLabel,
        "resolve-status-hint": e.resolveStatusHint,
        "resolve-thinking-presentation": e.resolveThinkingPresentation,
        "show-avatars": e.showAvatars,
        surface: e.surface,
        onInteractionSubmit: f,
        onInteractionCancel: c,
        onRetry: g[0] || (g[0] = (_) => d.$emit("retry"))
      }, xi({ _: 2 }, [
        d.$slots.empty ? {
          name: "empty",
          fn: Es(() => [
            Et(d.$slots, "empty", {}, void 0, !0)
          ]),
          key: "0"
        } : void 0,
        d.$slots["message-meta"] ? {
          name: "message-meta",
          fn: Es((_) => [
            Et(d.$slots, "message-meta", Io(Vi(_)), void 0, !0)
          ]),
          key: "1"
        } : void 0
      ]), 1032, ["messages", "auto-follow", "assistant-label", "resolve-status-hint", "resolve-thinking-presentation", "show-avatars", "surface"]),
      e.snapshot.error ? (x(), A("div", Zu, [
        N("span", null, te(e.snapshot.error), 1),
        N("button", {
          type: "button",
          onClick: g[1] || (g[1] = (_) => d.$emit("retry"))
        }, "重试")
      ])) : ie("", !0),
      Et(d.$slots, "composer", {}, () => [
        e.hideComposer ? ie("", !0) : (x(), st(Ju, {
          key: 0,
          disabled: a.value,
          "show-stop": o.value,
          placeholder: e.placeholder,
          onSend: l,
          onStop: g[2] || (g[2] = (_) => d.$emit("stop"))
        }, null, 8, ["disabled", "show-stop", "placeholder"]))
      ]),
      d.$slots.footer ? (x(), A("footer", ef, [
        Et(d.$slots, "footer", {}, void 0)
      ])) : ie("", !0)
    ], 14, Xu));
  }
}), sf = /* @__PURE__ */ Nt(tf, [["__scopeId", "data-v-13c4a68e"]]), nf = "1.0.0";
function rf(e, t) {
  return {
    pageKey: t == null ? void 0 : t.pageKey,
    pageInstanceId: e.pageInstanceId,
    route: e.route || (typeof location < "u" ? location.pathname : "/"),
    bridgeActions: e.registeredActions,
    sdkVersion: nf
  };
}
const of = /* @__PURE__ */ ht({
  __name: "EmbedChatHost",
  props: {
    apiBase: {},
    tokenProvider: {},
    bridge: {},
    page: {},
    context: { default: () => ({}) },
    placeholder: { default: "输入消息" },
    preferStream: { type: Boolean, default: !0 },
    onEvent: {},
    onError: {},
    onUnauthorized: {}
  },
  setup(e, { expose: t }) {
    const s = e, n = /* @__PURE__ */ De(Vn());
    let r = "", i = { ...s.context }, o = "", a = !1, l = null;
    async function f() {
      const q = await s.tokenProvider();
      return o = String(q || ""), o;
    }
    f().catch(() => {
    });
    const c = fc({
      apiBase: s.apiBase,
      tokenProvider: () => o,
      getSessionId: () => r || void 0,
      setSessionId: (q) => {
        r = q || "";
      },
      getContext: () => i,
      createSessionPayload: () => ({
        ...rf(s.bridge, s.page)
      }),
      preferStream: s.preferStream,
      onUnauthorized: async () => {
        var U;
        const q = await ((U = s.onUnauthorized) == null ? void 0 : U.call(s));
        return typeof q == "string" && q ? (o = q, q) : f();
      }
    }), d = c, g = ic({
      transport: c,
      onPublicEvent: _,
      onChange(q) {
        n.value = q, q.sessionId && (r = q.sessionId), p(q);
      }
    });
    function _(q) {
      var Y, Q, re, ge, je, xe, le;
      const U = q.data, G = {
        sessionId: q.sessionId || r || void 0,
        turnId: q.turnId
      };
      switch (q.type) {
        case "message.delta":
          (Y = s.onEvent) == null || Y.call(s, { type: "message.delta", data: U, ...G });
          return;
        case "ui.requested":
          (Q = s.onEvent) == null || Q.call(s, { type: "ui.requested", data: U, ...G });
          return;
        case "page.action.requested":
          (re = s.onEvent) == null || re.call(s, { type: "page.action.requested", data: U, ...G });
          return;
        case "turn.completed":
        case "turn.waiting":
          (ge = s.onEvent) == null || ge.call(s, {
            type: "message.completed",
            data: M(q),
            ...G
          });
          return;
        case "turn.failed":
          (je = s.onEvent) == null || je.call(s, { type: "error", data: U, ...G });
          return;
        case "interaction.submitted":
          (xe = s.onEvent) == null || xe.call(s, { type: "interaction.submitted", data: U, ...G });
          return;
        case "interaction.cancelled":
          (le = s.onEvent) == null || le.call(s, { type: "interaction.cancelled", data: U, ...G });
          return;
        default:
          return;
      }
    }
    function M(q) {
      const U = q.data && typeof q.data == "object" ? q.data : {}, G = so(U) || (U.metadata && typeof U.metadata == "object" && !Array.isArray(U.metadata) ? { ...U.metadata } : void 0);
      return {
        answer: U.answer != null ? String(U.answer) : void 0,
        sessionId: q.sessionId || (U.sessionId != null ? String(U.sessionId) : r) || void 0,
        uiRequest: U.uiRequest,
        metadata: G,
        intentType: U.intentType,
        toolCalls: U.toolCalls,
        turnId: q.turnId
      };
    }
    function p(q) {
      if (!l) return;
      const U = q.turnStatus;
      if (U === "sending" || U === "streaming") {
        l.armed = !0;
        return;
      }
      if (!l.armed || U !== "completed" && U !== "waiting" && U !== "failed" && U !== "cancelled")
        return;
      const G = l;
      if (l = null, U === "failed") {
        G.reject(new Error(q.error || "Message failed"));
        return;
      }
      if (U === "cancelled") {
        G.reject(new DOMException("The operation was aborted.", "AbortError"));
        return;
      }
      G.resolve($(q));
    }
    function $(q) {
      var ge, je;
      let U = "", G, Y, Q, re;
      for (let xe = q.messages.length - 1; xe >= 0; xe -= 1) {
        const le = q.messages[xe];
        if (le.role === "assistant") {
          U = Ul(le);
          for (const D of le.blocks)
            D.type === "interaction" && (D.state === "waiting" || D.state === "submitting") && (G = D.request);
          Y = le.metadata ? { ...le.metadata } : void 0, Y && "metadata" in Y && typeof Y.metadata == "object" && (Y = { ...Y.metadata }), Q = (ge = le.completion) == null ? void 0 : ge.intentType, re = (je = le.completion) == null ? void 0 : je.toolCalls;
          break;
        }
      }
      return Y && (delete Y.result, delete Y.answer, delete Y.uiRequest, delete Y.sessionId, delete Y.intentType, delete Y.toolCalls), {
        answer: U,
        sessionId: q.sessionId || r || void 0,
        uiRequest: G,
        metadata: Y && Object.keys(Y).length ? Y : void 0,
        intentType: Q,
        toolCalls: re,
        turnId: q.turnId
      };
    }
    async function K(q) {
      if (a)
        throw new DOMException("The operation was aborted.", "AbortError");
      const U = q.trim();
      if (!U) return {};
      if (l)
        throw new Error("Another message is still in flight");
      return await f(), new Promise((G, Y) => {
        l = { resolve: G, reject: Y, armed: !1 }, g.send(U).catch((Q) => {
          l && (l = null, Y(Q));
        });
      });
    }
    function E(q) {
      i = { ...i, ...q };
    }
    function L() {
      return r || null;
    }
    function R() {
      return r || null;
    }
    async function B() {
      if (a) throw new DOMException("The operation was aborted.", "AbortError");
      if (await f(), r) return r;
      if (typeof d.ensureSession == "function")
        return d.ensureSession();
      throw new Error("Embed transport cannot ensure session");
    }
    function m(q) {
      return q.role !== "assistant" || q.status !== "pending" && q.status !== "streaming" ? void 0 : q.blocks.some((G) => G.type === "text" && G.text) ? "正在生成回答" : "正在处理";
    }
    function k(q) {
      K(q).catch(Pe);
    }
    function H() {
      g.cancel().then(() => {
        if (l) {
          const q = l;
          l = null, q.reject(new DOMException("The operation was aborted.", "AbortError"));
        }
      });
    }
    function se(q, U, G) {
      g.submitInteraction(q, U, G).catch(Pe);
    }
    function ne(q) {
      g.submitInteraction(q, "cancel", {}).catch(Pe);
    }
    function Pe(q) {
      var G;
      const U = { message: q instanceof Error ? q.message : String(q), cause: q };
      (G = s.onError) == null || G.call(s, U);
    }
    function ke() {
      if (a = !0, l) {
        const q = l;
        l = null, q.reject(new DOMException("The operation was aborted.", "AbortError"));
      }
      g.dispose();
    }
    return Kn(() => {
      ke();
    }), t({
      sendMessage: K,
      setContext: E,
      getSessionId: L,
      getExistingSessionId: R,
      ensureHostSession: B,
      disposeHost: ke
    }), (q, U) => (x(), st(qn(sf), {
      class: "eaf-chat__conversation",
      chrome: "inline",
      density: "compact",
      surface: "embed",
      atmosphere: "",
      snapshot: n.value,
      placeholder: e.placeholder,
      "resolve-status-hint": m,
      onSend: k,
      onStop: H,
      onInteractionSubmit: se,
      onInteractionCancel: ne
    }, null, 8, ["snapshot", "placeholder"]));
  }
}), io = /* @__PURE__ */ Nt(of, [["__scopeId", "data-v-6d4ebfab"]]);
function In(e) {
  var n;
  const t = (n = e.metadata) == null ? void 0 : n.pageActionQueue;
  if (!Array.isArray(t)) return [];
  const s = Gn(e.metadata);
  return t.map((r) => oo(r, s)).filter((r) => !!r);
}
function oo(e, t) {
  if (!e || typeof e != "object") return null;
  const s = e;
  if (s.type !== "page.action.requested" || typeof s.requestId != "string" || typeof s.actionKey != "string") return null;
  const n = s.metadata && typeof s.metadata == "object" ? { ...s.metadata } : {}, r = typeof s.pageKey == "string" ? s.pageKey : t;
  return r && !n.pageKey && (n.pageKey = r), {
    type: "page.action.requested",
    protocolVersion: typeof s.protocolVersion == "string" ? s.protocolVersion : void 0,
    requestId: s.requestId,
    actionKey: s.actionKey,
    title: typeof s.title == "string" ? s.title : void 0,
    args: s.args && typeof s.args == "object" ? s.args : void 0,
    target: s.target && typeof s.target == "object" ? s.target : void 0,
    confirm: s.confirm === !0,
    metadata: n
  };
}
async function Jn(e) {
  const t = oo(e.request, Gn(e.responseMetadata));
  if (!(t != null && t.requestId)) return;
  const s = t.requestId;
  if (e.handledPageActions.has(s)) return;
  const n = e.inFlightPageActions.get(s);
  if (n) {
    await n;
    return;
  }
  const r = (async () => {
    var i, o, a;
    if (!e.handledPageActions.has(s)) {
      e.handledPageActions.add(s), (i = e.onRequested) == null || i.call(e, t);
      try {
        const l = await af(
          t,
          e.bridge,
          e.responseMetadata,
          /* @__PURE__ */ new Set()
          // 已认领，内部不再二次 gated
        );
        if (!l) return;
        (l.status === "FAILED" || l.status === "TIMEOUT") && ((o = e.onError) == null || o.call(e, new Error(l.error || `Page action ${l.status}: ${t.actionKey}`)));
        let f = e.token;
        try {
          await Lr(
            e.apiBase,
            e.sessionId,
            f,
            l,
            e.fetchImpl
          );
        } catch (c) {
          if (!lo(c) || !e.refreshToken) throw c;
          f = await e.refreshToken(), await Lr(
            e.apiBase,
            e.sessionId,
            f,
            l,
            e.fetchImpl
          );
        }
      } catch (l) {
        (a = e.onError) == null || a.call(e, l);
      }
    }
  })();
  e.inFlightPageActions.set(s, r);
  try {
    await r;
  } finally {
    e.inFlightPageActions.delete(s);
  }
}
async function af(e, t, s, n) {
  const r = await t.handleEvent(e);
  if (r && r.status !== "ACTION_NOT_FOUND")
    return n.add(e.requestId), r;
  const i = await cf(e, s);
  return i ? (i.status !== "ACTION_NOT_FOUND" && n.add(e.requestId), i) : (r && n.add(e.requestId), r);
}
async function lf(e) {
  const t = In(e.response);
  for (const s of t)
    await Jn({
      request: s,
      bridge: e.bridge,
      sessionId: e.sessionId,
      apiBase: e.apiBase,
      token: e.token,
      handledPageActions: e.handledPageActions,
      inFlightPageActions: e.inFlightPageActions,
      responseMetadata: e.response.metadata,
      onRequested: e.onRequested,
      onError: e.onError,
      refreshToken: e.refreshToken,
      fetchImpl: e.fetchImpl
    });
}
async function cf(e, t) {
  const s = typeof window < "u" ? window.__REACHAI_PAGE_BRIDGE__ : void 0;
  if (!s || typeof s.execute != "function") return null;
  const n = uf(e) || Gn(t);
  if (!n)
    return {
      protocolVersion: e.protocolVersion || "1.0",
      type: "page.action.result",
      requestId: e.requestId,
      actionKey: e.actionKey,
      status: "ACTION_NOT_FOUND",
      error: "Page action pageKey is missing for window.__REACHAI_PAGE_BRIDGE__ fallback"
    };
  try {
    const r = await s.execute(n, e.actionKey, e.args || {}, {
      confirmed: !0,
      requestId: e.requestId
    }), i = r && typeof r == "object" ? r : { data: r }, o = String(i.status || "SUCCESS").toUpperCase(), a = o === "SUCCESS", l = i.error && typeof i.error == "object" ? String(i.error.message || i.message || "") : String(i.message || "");
    return {
      protocolVersion: e.protocolVersion || "1.0",
      type: "page.action.result",
      requestId: e.requestId,
      actionKey: e.actionKey,
      status: a ? "SUCCESS" : "FAILED",
      data: i.data ?? r,
      error: a ? void 0 : l || `Page action returned ${o}`
    };
  } catch (r) {
    return {
      protocolVersion: e.protocolVersion || "1.0",
      type: "page.action.result",
      requestId: e.requestId,
      actionKey: e.actionKey,
      status: "FAILED",
      error: r instanceof Error ? r.message : String(r)
    };
  }
}
function uf(e) {
  var s;
  const t = (s = e.metadata) == null ? void 0 : s.pageKey;
  return typeof t == "string" && t.trim() ? t.trim() : void 0;
}
function Gn(e) {
  const t = e == null ? void 0 : e.pageKey;
  return typeof t == "string" && t.trim() ? t.trim() : void 0;
}
async function Lr(e, t, s, n, r = fetch) {
  await df(
    `${e}/chat/sessions/${encodeURIComponent(t)}/page-actions/${encodeURIComponent(n.requestId)}/result`,
    n,
    s,
    r
  );
}
async function ff(e) {
  const t = e.fetchImpl || fetch, s = e.inFlightPageActions || /* @__PURE__ */ new Map(), n = `${e.apiBase}/chat/sessions/${encodeURIComponent(e.sessionId)}/page-actions/pending?limit=10`;
  let r;
  try {
    r = await Ur(n, e.token, t);
  } catch (i) {
    if (!lo(i) || !e.refreshToken) throw i;
    const o = await e.refreshToken();
    r = await Ur(n, o, t);
  }
  for (const i of r)
    i != null && i.requestId && await Jn({
      request: i,
      bridge: e.bridge,
      sessionId: e.sessionId,
      apiBase: e.apiBase,
      token: e.token,
      handledPageActions: e.handledPageActions,
      inFlightPageActions: s,
      responseMetadata: e.context,
      onRequested: (o) => {
        var a;
        return (a = e.onEvent) == null ? void 0 : a.call(e, { type: "page.action.requested", data: o });
      },
      onError: e.onError,
      refreshToken: e.refreshToken,
      fetchImpl: t
    });
}
async function df(e, t, s, n) {
  const r = await n(e, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${s}`
    },
    body: JSON.stringify(t)
  }), i = await r.json().catch(() => ({}));
  if (!r.ok || i.code && i.code !== 200 && i.code !== 0)
    throw ao(i.message || `Request failed: ${r.status}`, r.status);
  return i.data ?? i;
}
async function Ur(e, t, s) {
  const n = await s(e, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${t}`
    }
  }), r = await n.json().catch(() => ({}));
  if (!n.ok || r.code && r.code !== 200 && r.code !== 0)
    throw ao(r.message || `Request failed: ${n.status}`, n.status);
  return r.data ?? r;
}
function ao(e, t) {
  const s = new Error(e);
  return s.status = t, s;
}
function lo(e) {
  return !!(e && typeof e == "object" && e.status === 401);
}
function hf(e, t) {
  const s = String(t || "").trim();
  if (!s) return;
  e.style.setProperty("--reachai-chat-primary", s), e.style.setProperty("--reachai-chat-spectrum-anchor", s);
  const n = pf(s);
  n && e.style.setProperty("--reachai-chat-primary-rgb", `${n[0]} ${n[1]} ${n[2]}`);
}
function pf(e) {
  const t = e.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);
  if (t) {
    const n = t[1];
    return n.length === 3 ? [
      parseInt(n[0] + n[0], 16),
      parseInt(n[1] + n[1], 16),
      parseInt(n[2] + n[2], 16)
    ] : [
      parseInt(n.slice(0, 2), 16),
      parseInt(n.slice(2, 4), 16),
      parseInt(n.slice(4, 6), 16)
    ];
  }
  const s = e.match(/^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
  return s ? [Number(s[1]), Number(s[2]), Number(s[3])] : null;
}
async function kf(e) {
  var je, xe, le;
  if (!e.agentId) throw new Error("agentId is required");
  const t = typeof e.mount == "string" ? document.querySelector(e.mount) : e.mount;
  if (!t) throw new Error("mount element not found");
  const s = e.bridge || cn({ route: location.pathname }), n = If(e.apiBase, e.embedPathPrefix), r = xf(e.apiBase);
  let i = await e.tokenProvider(), o = { ...e.context || {} };
  const a = /* @__PURE__ */ new Set(), l = /* @__PURE__ */ new Set(), f = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Set();
  let d = !1, g, _ = !1, M = null, p = null, $ = !1;
  function K(D, y = {}) {
    var oe;
    const V = String((D && typeof D == "object" ? D : {}).requestId || "");
    if (V) {
      if (c.has(V)) return !1;
      c.add(V);
    }
    return (oe = e.onEvent) == null || oe.call(e, {
      type: "page.action.requested",
      data: D,
      sessionId: y.sessionId,
      turnId: y.turnId
    }), !0;
  }
  function E(D, y, v) {
    if (!_) {
      if (!y) {
        Q(new Error("Page action requires an active embed session; no sessionId available"));
        return;
      }
      Jn({
        request: D,
        bridge: s,
        sessionId: y,
        apiBase: n,
        token: i,
        handledPageActions: l,
        inFlightPageActions: f,
        responseMetadata: v,
        onRequested: (V) => K(V, { sessionId: y }),
        onError: Q,
        refreshToken: async () => (await G(), i)
      }).catch(Q);
    }
  }
  function L(D) {
    if (D.sessionId) return D.sessionId;
    const y = D.data && typeof D.data == "object" ? D.data : {};
    return y.sessionId != null && String(y.sessionId) ? String(y.sessionId) : (p == null ? void 0 : p.getExistingSessionId()) || (p == null ? void 0 : p.getSessionId()) || void 0;
  }
  function R(D) {
    var y, v;
    if (D.type === "page.action.requested") {
      K(D.data, {
        sessionId: D.sessionId,
        turnId: D.turnId
      }), E(
        D.data,
        L(D),
        D.data && typeof D.data == "object" ? D.data.metadata : void 0
      );
      return;
    }
    if (D.type === "message.completed") {
      const V = D.data;
      for (const oe of In(V))
        K(oe, { sessionId: V.sessionId, turnId: V.turnId });
      (y = e.onEvent) == null || y.call(e, D), B(V).catch(Q);
      return;
    }
    (v = e.onEvent) == null || v.call(e, D);
  }
  async function B(D) {
    if (!D || _) return;
    const y = D.sessionId || (p == null ? void 0 : p.getExistingSessionId()) || (p == null ? void 0 : p.getSessionId()), v = In(D);
    if (!y) {
      v.length > 0 && Q(new Error("Page action requires an active embed session; no sessionId available"));
      return;
    }
    await lf({
      response: D,
      bridge: s,
      sessionId: y,
      apiBase: n,
      token: i,
      handledPageActions: l,
      inFlightPageActions: f,
      onRequested: (V) => K(V, { sessionId: y }),
      onError: Q,
      refreshToken: async () => (await G(), i)
    });
  }
  const m = document.createElement("div");
  m.className = "eaf-chat", e.position && e.position !== "inline" && m.classList.add(`eaf-chat--${e.position}`), e.initialOpen === !1 && m.classList.add("eaf-chat--closed"), (je = e.theme) != null && je.primaryColor && hf(m, e.theme.primaryColor), m.innerHTML = `
    <div class="eaf-chat__header">
      <div class="eaf-chat__brand">${wf(((xe = e.theme) == null ? void 0 : xe.brandName) || "ReachAI")}</div>
      <button class="eaf-chat__toggle" type="button" aria-expanded="${e.initialOpen === !1 ? "false" : "true"}">
        ${e.initialOpen === !1 ? "+" : "-"}
      </button>
    </div>
    <div class="eaf-chat__body"></div>
  `, t.appendChild(m);
  const k = m.querySelector(".eaf-chat__toggle"), H = m.querySelector(".eaf-chat__body");
  M = wn(io, {
    apiBase: n,
    tokenProvider: () => i,
    bridge: s,
    page: e.page,
    context: o,
    placeholder: e.locale === "zh-CN" ? "输入消息" : "Type a message",
    preferStream: e.stream !== !1,
    onEvent: R,
    onError: (D) => Q(D.cause ?? new Error(D.message)),
    onUnauthorized: async () => (i = await e.tokenProvider(), i)
  }), p = M.mount(H);
  const se = window.setInterval(() => {
    re().catch(Q);
  }, 500), ne = s.onActionDefinitionsChange(() => ke());
  ke(0);
  function Pe(D) {
    var v;
    const y = { message: D instanceof Error ? D.message : String(D), cause: D };
    (v = e.onError) == null || v.call(e, y);
  }
  function ke(D = 250) {
    !e.pageRegistry || e.pageRegistry.registerOnStart === !1 || !e.page || (g && window.clearTimeout(g), g = window.setTimeout(() => {
      g = void 0, q().catch(Pe);
    }, D));
  }
  async function q() {
    _ || await gf(r, e, s);
  }
  function U() {
    const D = !m.classList.contains("eaf-chat--closed");
    k.textContent = D ? "-" : "+", k.setAttribute("aria-expanded", D ? "true" : "false");
  }
  async function G() {
    i = await e.tokenProvider();
  }
  async function Y(D) {
    const y = D.trim();
    if (!y || !p || _) return {};
    if ($) throw new Error("Another message is still in flight");
    $ = !0;
    try {
      const v = await p.sendMessage(y);
      return await B(v), v;
    } catch (v) {
      throw Sf(v) && await G(), Q(v), v;
    } finally {
      $ = !1;
    }
  }
  function Q(D) {
    var v;
    const y = { message: D instanceof Error ? D.message : String(D), cause: D };
    (v = e.onError) == null || v.call(e, y);
  }
  async function re() {
    if (d || _) return;
    const D = p == null ? void 0 : p.getExistingSessionId();
    if (D) {
      d = !0;
      try {
        await ff({
          apiBase: n,
          token: i,
          sessionId: D,
          bridge: s,
          handledPageActions: l,
          pendingPageActions: a,
          inFlightPageActions: f,
          context: o,
          // poll 自己已 dispatch；此处只 publish，禁止再走 emitPublicEvent→dispatch 递归
          onEvent: (y) => {
            y.type === "page.action.requested" && K(y.data, { sessionId: D });
          },
          onError: Q,
          refreshToken: async () => (await G(), i)
        });
      } finally {
        d = !1;
      }
    }
  }
  k.addEventListener("click", () => {
    m.classList.toggle("eaf-chat--closed"), U();
  }), U();
  const ge = {
    bridge: s,
    get sessionId() {
      return (p == null ? void 0 : p.getSessionId()) || null;
    },
    open() {
      m.classList.remove("eaf-chat--closed"), U();
    },
    close() {
      m.classList.add("eaf-chat--closed"), U();
    },
    toggle() {
      m.classList.toggle("eaf-chat--closed"), U();
    },
    send: Y,
    registerPageCatalog: q,
    setContext(D) {
      o = { ...o, ...D || {} }, p == null || p.setContext(D || {});
    },
    destroy() {
      _ = !0, ne(), g && window.clearTimeout(g), window.clearInterval(se), p == null || p.disposeHost(), M == null || M.unmount(), M = null, p = null, m.remove();
    }
  };
  return typeof process < "u" && ((le = process.env) != null && le.VITEST) && Object.assign(ge, {
    __emitPublicEventForTests: R
  }), ge;
}
async function gf(e, t, s) {
  const n = t.pageRegistry, r = t.page;
  !n || n.registerOnStart === !1 || !r || !n.projectCode || !n.appKey || !n.appSecret || await yf(
    `${e}/api/registry/projects/${encodeURIComponent(n.projectCode)}/pages/register`,
    {
      pageKey: r.pageKey,
      name: r.name || r.pageKey,
      routePattern: r.routePattern || s.route || location.pathname,
      origin: r.origin || location.origin,
      pageInstanceId: s.pageInstanceId,
      replaceActions: !0,
      actions: s.actionDefinitions.map(mf),
      metadata: r.metadata || {}
    },
    n
  );
}
function mf(e) {
  return {
    actionKey: e.actionKey,
    title: e.title || e.actionKey,
    description: e.description || "",
    confirmRequired: e.confirmRequired === !0,
    inputSchema: e.inputSchema || {},
    outputSchema: e.outputSchema || {},
    sampleArgs: e.sampleArgs || {},
    allowedAgentIds: e.allowedAgentIds || [],
    metadata: e.metadata || {}
  };
}
async function yf(e, t, s) {
  const n = String(Date.now()), r = _f(), i = await bf(s.appSecret, `${s.projectCode}
${n}
${r}`), o = await fetch(e, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-ReachAI-App-Key": s.appKey,
      "X-ReachAI-Timestamp": n,
      "X-ReachAI-Nonce": r,
      "X-ReachAI-Signature": i
    },
    body: JSON.stringify(t)
  }), a = await o.json().catch(() => ({}));
  if (!o.ok || a.code && a.code !== 200 && a.code !== 0)
    throw vf(a.message || `Page catalog registration failed: ${o.status}`, o.status);
  return a.data ?? a;
}
async function bf(e, t) {
  if (!(crypto != null && crypto.subtle))
    throw new Error("Web Crypto API is required for ReachAI page catalog registration");
  const s = new TextEncoder(), n = await crypto.subtle.importKey(
    "raw",
    s.encode(e),
    { name: "HMAC", hash: "SHA-256" },
    !1,
    ["sign"]
  ), r = await crypto.subtle.sign("HMAC", n, s.encode(t));
  return Array.from(new Uint8Array(r)).map((i) => i.toString(16).padStart(2, "0")).join("");
}
function _f() {
  return typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}
function vf(e, t) {
  const s = new Error(e);
  return s.status = t, s;
}
function Sf(e) {
  return !!(e && typeof e == "object" && e.status === 401);
}
function wf(e) {
  return e.replace(/[<>&"']/g, (t) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", '"': "&quot;", "'": "&#39;" })[t] || t);
}
function If(e, t) {
  const s = ms((e || "").trim());
  if (t !== void 0) {
    const n = Yn(t || "/api/embed");
    return Br(Cf(s, n), n);
  }
  return co(s) ? s : Br(s, "/api/embed");
}
function xf(e) {
  const t = ms((e || "").trim());
  return t ? co(t) ? t.replace(/\/api\/(?:reachai\/)?embed$/i, "") : t : "";
}
function Br(e, t) {
  const s = ms(e), n = Yn(t);
  return s ? n ? `${s}${n}` : s : n || "";
}
function Cf(e, t) {
  const s = Yn(t);
  return !e || !s ? e : e.toLowerCase().endsWith(s.toLowerCase()) ? ms(e.slice(0, -s.length)) : e;
}
function Yn(e) {
  const t = ms((e || "").trim());
  return t ? t.startsWith("/") ? t : `/${t}` : "";
}
function co(e) {
  return /\/api\/(?:reachai\/)?embed$/i.test(e);
}
function ms(e) {
  return e.endsWith("/") ? e.slice(0, -1) : e;
}
const Af = /* @__PURE__ */ ht({
  __name: "ReachAiChatElement.ce",
  props: {
    apiBase: { default: "/api/embed", type: String },
    token: { default: "", type: String },
    pageKey: { type: String },
    route: { type: String },
    placeholder: { default: "输入消息", type: String }
  },
  setup(e) {
    const t = e, s = /* @__PURE__ */ De(!1), n = /* @__PURE__ */ De(cn()), r = /* @__PURE__ */ De(void 0), i = /* @__PURE__ */ De({});
    function o() {
      return t.token;
    }
    async function a() {
      return t.token;
    }
    return Dn(() => {
      n.value = cn({
        route: t.route || (typeof location < "u" ? location.pathname : "/")
      }), t.pageKey && (r.value = { pageKey: t.pageKey }), s.value = !0;
    }), (l, f) => s.value ? (x(), st(io, {
      key: 0,
      "api-base": e.apiBase,
      "token-provider": o,
      bridge: n.value,
      page: r.value,
      context: i.value,
      placeholder: e.placeholder,
      "on-unauthorized": a
    }, null, 8, ["api-base", "bridge", "page", "context", "placeholder"])) : ie("", !0);
  }
});
let ln = !1;
function Ef(e = "reachai-chat") {
  if (!(ln || typeof customElements > "u")) {
    if (customElements.get(e)) {
      ln = !0;
      return;
    }
    customElements.define(e, /* @__PURE__ */ Rl(Af)), ln = !0;
  }
}
export {
  rf as buildEafChatSessionPayload,
  kf as createEafChat,
  cn as createEafPageBridge,
  Ef as defineReachAiChatElement,
  If as resolveEafChatEmbedApiRoot,
  xf as resolveEafChatPlatformBase
};
