function gs(e = {}) {
  const t = e.pageInstanceId || Ao(), n = Math.max(1e3, e.actionTimeoutMs || 15e3), s = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Set();
  function a() {
    return Array.from(s.keys()).map((u) => ({
      actionKey: u,
      ...r.get(u) || {}
    }));
  }
  function l(u) {
    i.forEach((h) => h(u));
  }
  function d() {
    const u = a();
    o.forEach((h) => h(u));
  }
  return {
    pageInstanceId: t,
    route: e.route,
    get registeredActions() {
      return Array.from(s.keys());
    },
    get actionDefinitions() {
      return a();
    },
    registerAction(u, h, m = {}) {
      return s.set(u, h), r.set(u, m), d(), () => {
        s.delete(u), r.delete(u), d();
      };
    },
    async handleEvent(u) {
      var k;
      if (!Io(u)) return null;
      const h = (k = u.target) == null ? void 0 : k.pageInstanceId;
      if (h && h !== t) return null;
      const m = s.get(u.actionKey);
      if (!m) {
        const I = In(u, "ACTION_NOT_FOUND", void 0, `Action is not registered: ${u.actionKey}`);
        return l(I), I;
      }
      if (!await So(u, e.confirmAction)) {
        const I = In(u, "CANCELLED", void 0, `Action was cancelled: ${u.actionKey}`);
        return l(I), I;
      }
      try {
        const I = await wo(m(u.args || {}, u), n), y = In(u, "SUCCESS", I);
        return l(y), y;
      } catch (I) {
        const y = I instanceof Error ? I.message : String(I), z = In(u, y === "Page action timed out" ? "TIMEOUT" : "FAILED", void 0, y);
        return l(z), z;
      }
    },
    onResult(u) {
      return i.add(u), () => i.delete(u);
    },
    onActionDefinitionsChange(u) {
      return o.add(u), () => o.delete(u);
    }
  };
}
async function So(e, t) {
  return e.confirm ? t ? await t(e) : typeof window < "u" && typeof window.confirm == "function" ? window.confirm(e.title || `Run page action: ${e.actionKey}`) : !1 : !0;
}
function In(e, t, n, s) {
  return {
    protocolVersion: e.protocolVersion || "1.0",
    type: "page.action.result",
    requestId: e.requestId,
    actionKey: e.actionKey,
    status: t,
    data: n,
    error: s
  };
}
async function wo(e, t) {
  let n;
  try {
    return await Promise.race([
      Promise.resolve(e),
      new Promise((s, r) => {
        n = setTimeout(() => r(new Error("Page action timed out")), t);
      })
    ]);
  } catch (s) {
    throw s instanceof Error && s.message === "Page action timed out", s;
  } finally {
    n && clearTimeout(n);
  }
}
function Io(e) {
  if (!e || typeof e != "object") return !1;
  const t = e;
  return t.type === "page.action.requested" && typeof t.requestId == "string" && typeof t.actionKey == "string";
}
function Ao() {
  return typeof crypto < "u" && "randomUUID" in crypto ? `page-${crypto.randomUUID()}` : `page-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}
/**
* @vue/shared v3.5.31
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
// @__NO_SIDE_EFFECTS__
function Ps(e) {
  const t = /* @__PURE__ */ Object.create(null);
  for (const n of e.split(",")) t[n] = 1;
  return (n) => n in t;
}
const ge = {}, Ht = [], ft = () => {
}, Qr = () => !1, Ln = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && // uppercase letter
(e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97), Un = (e) => e.startsWith("onUpdate:"), we = Object.assign, Rs = (e, t) => {
  const n = e.indexOf(t);
  n > -1 && e.splice(n, 1);
}, xo = Object.prototype.hasOwnProperty, ce = (e, t) => xo.call(e, t), W = Array.isArray, Bt = (e) => bn(e) === "[object Map]", Vn = (e) => bn(e) === "[object Set]", ar = (e) => bn(e) === "[object Date]", ee = (e) => typeof e == "function", Se = (e) => typeof e == "string", et = (e) => typeof e == "symbol", de = (e) => e !== null && typeof e == "object", Zr = (e) => (de(e) || ee(e)) && ee(e.then) && ee(e.catch), ei = Object.prototype.toString, bn = (e) => ei.call(e), Co = (e) => bn(e).slice(8, -1), Hn = (e) => bn(e) === "[object Object]", $s = (e) => Se(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e, sn = /* @__PURE__ */ Ps(
  // the leading comma is intentional so empty string "" is also included
  ",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"
), Bn = (e) => {
  const t = /* @__PURE__ */ Object.create(null);
  return ((n) => t[n] || (t[n] = e(n)));
}, ko = /-\w/g, xe = Bn(
  (e) => e.replace(ko, (t) => t.slice(1).toUpperCase())
), Eo = /\B([A-Z])/g, Xe = Bn(
  (e) => e.replace(Eo, "-$1").toLowerCase()
), Wn = Bn((e) => e.charAt(0).toUpperCase() + e.slice(1)), ts = Bn(
  (e) => e ? `on${Wn(e)}` : ""
), ut = (e, t) => !Object.is(e, t), En = (e, ...t) => {
  for (let n = 0; n < e.length; n++)
    e[n](...t);
}, ti = (e, t, n, s = !1) => {
  Object.defineProperty(e, t, {
    configurable: !0,
    enumerable: !1,
    writable: s,
    value: n
  });
}, Ms = (e) => {
  const t = parseFloat(e);
  return isNaN(t) ? e : t;
}, lr = (e) => {
  const t = Se(e) ? Number(e) : NaN;
  return isNaN(t) ? e : t;
};
let cr;
const zn = () => cr || (cr = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {});
function _n(e) {
  if (W(e)) {
    const t = {};
    for (let n = 0; n < e.length; n++) {
      const s = e[n], r = Se(s) ? $o(s) : _n(s);
      if (r)
        for (const i in r)
          t[i] = r[i];
    }
    return t;
  } else if (Se(e) || de(e))
    return e;
}
const To = /;(?![^(]*\))/g, Po = /:([^]+)/, Ro = /\/\*[^]*?\*\//g;
function $o(e) {
  const t = {};
  return e.replace(Ro, "").split(To).forEach((n) => {
    if (n) {
      const s = n.split(Po);
      s.length > 1 && (t[s[0].trim()] = s[1].trim());
    }
  }), t;
}
function Ke(e) {
  let t = "";
  if (Se(e))
    t = e;
  else if (W(e))
    for (let n = 0; n < e.length; n++) {
      const s = Ke(e[n]);
      s && (t += s + " ");
    }
  else if (de(e))
    for (const n in e)
      e[n] && (t += n + " ");
  return t.trim();
}
function Mo(e) {
  if (!e) return null;
  let { class: t, style: n } = e;
  return t && !Se(t) && (e.class = Ke(t)), n && (e.style = _n(n)), e;
}
const Oo = "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly", qo = /* @__PURE__ */ Ps(Oo);
function ni(e) {
  return !!e || e === "";
}
function jo(e, t) {
  if (e.length !== t.length) return !1;
  let n = !0;
  for (let s = 0; n && s < e.length; s++)
    n = Ft(e[s], t[s]);
  return n;
}
function Ft(e, t) {
  if (e === t) return !0;
  let n = ar(e), s = ar(t);
  if (n || s)
    return n && s ? e.getTime() === t.getTime() : !1;
  if (n = et(e), s = et(t), n || s)
    return e === t;
  if (n = W(e), s = W(t), n || s)
    return n && s ? jo(e, t) : !1;
  if (n = de(e), s = de(t), n || s) {
    if (!n || !s)
      return !1;
    const r = Object.keys(e).length, i = Object.keys(t).length;
    if (r !== i)
      return !1;
    for (const o in e) {
      const a = e.hasOwnProperty(o), l = t.hasOwnProperty(o);
      if (a && !l || !a && l || !Ft(e[o], t[o]))
        return !1;
    }
  }
  return String(e) === String(t);
}
function si(e, t) {
  return e.findIndex((n) => Ft(n, t));
}
const ri = (e) => !!(e && e.__v_isRef === !0), X = (e) => Se(e) ? e : e == null ? "" : W(e) || de(e) && (e.toString === ei || !ee(e.toString)) ? ri(e) ? X(e.value) : JSON.stringify(e, ii, 2) : String(e), ii = (e, t) => ri(t) ? ii(e, t.value) : Bt(t) ? {
  [`Map(${t.size})`]: [...t.entries()].reduce(
    (n, [s, r], i) => (n[ns(s, i) + " =>"] = r, n),
    {}
  )
} : Vn(t) ? {
  [`Set(${t.size})`]: [...t.values()].map((n) => ns(n))
} : et(t) ? ns(t) : de(t) && !W(t) && !Hn(t) ? String(t) : t, ns = (e, t = "") => {
  var n;
  return (
    // Symbol.description in es2019+ so we need to cast here to pass
    // the lib: es2016 check
    et(e) ? `Symbol(${(n = e.description) != null ? n : t})` : e
  );
};
/**
* @vue/reactivity v3.5.31
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
let De;
class No {
  // TODO isolatedDeclarations "__v_skip"
  constructor(t = !1) {
    this.detached = t, this._active = !0, this._on = 0, this.effects = [], this.cleanups = [], this._isPaused = !1, this.__v_skip = !0, this.parent = De, !t && De && (this.index = (De.scopes || (De.scopes = [])).push(
      this
    ) - 1);
  }
  get active() {
    return this._active;
  }
  pause() {
    if (this._active) {
      this._isPaused = !0;
      let t, n;
      if (this.scopes)
        for (t = 0, n = this.scopes.length; t < n; t++)
          this.scopes[t].pause();
      for (t = 0, n = this.effects.length; t < n; t++)
        this.effects[t].pause();
    }
  }
  /**
   * Resumes the effect scope, including all child scopes and effects.
   */
  resume() {
    if (this._active && this._isPaused) {
      this._isPaused = !1;
      let t, n;
      if (this.scopes)
        for (t = 0, n = this.scopes.length; t < n; t++)
          this.scopes[t].resume();
      for (t = 0, n = this.effects.length; t < n; t++)
        this.effects[t].resume();
    }
  }
  run(t) {
    if (this._active) {
      const n = De;
      try {
        return De = this, t();
      } finally {
        De = n;
      }
    }
  }
  /**
   * This should only be called on non-detached scopes
   * @internal
   */
  on() {
    ++this._on === 1 && (this.prevScope = De, De = this);
  }
  /**
   * This should only be called on non-detached scopes
   * @internal
   */
  off() {
    this._on > 0 && --this._on === 0 && (De = this.prevScope, this.prevScope = void 0);
  }
  stop(t) {
    if (this._active) {
      this._active = !1;
      let n, s;
      for (n = 0, s = this.effects.length; n < s; n++)
        this.effects[n].stop();
      for (this.effects.length = 0, n = 0, s = this.cleanups.length; n < s; n++)
        this.cleanups[n]();
      if (this.cleanups.length = 0, this.scopes) {
        for (n = 0, s = this.scopes.length; n < s; n++)
          this.scopes[n].stop(!0);
        this.scopes.length = 0;
      }
      if (!this.detached && this.parent && !t) {
        const r = this.parent.scopes.pop();
        r && r !== this && (this.parent.scopes[this.index] = r, r.index = this.index);
      }
      this.parent = void 0;
    }
  }
}
function Do() {
  return De;
}
let ye;
const ss = /* @__PURE__ */ new WeakSet();
class oi {
  constructor(t) {
    this.fn = t, this.deps = void 0, this.depsTail = void 0, this.flags = 5, this.next = void 0, this.cleanup = void 0, this.scheduler = void 0, De && De.active && De.effects.push(this);
  }
  pause() {
    this.flags |= 64;
  }
  resume() {
    this.flags & 64 && (this.flags &= -65, ss.has(this) && (ss.delete(this), this.trigger()));
  }
  /**
   * @internal
   */
  notify() {
    this.flags & 2 && !(this.flags & 32) || this.flags & 8 || li(this);
  }
  run() {
    if (!(this.flags & 1))
      return this.fn();
    this.flags |= 2, ur(this), ci(this);
    const t = ye, n = Ze;
    ye = this, Ze = !0;
    try {
      return this.fn();
    } finally {
      ui(this), ye = t, Ze = n, this.flags &= -3;
    }
  }
  stop() {
    if (this.flags & 1) {
      for (let t = this.deps; t; t = t.nextDep)
        js(t);
      this.deps = this.depsTail = void 0, ur(this), this.onStop && this.onStop(), this.flags &= -2;
    }
  }
  trigger() {
    this.flags & 64 ? ss.add(this) : this.scheduler ? this.scheduler() : this.runIfDirty();
  }
  /**
   * @internal
   */
  runIfDirty() {
    ms(this) && this.run();
  }
  get dirty() {
    return ms(this);
  }
}
let ai = 0, rn, on;
function li(e, t = !1) {
  if (e.flags |= 8, t) {
    e.next = on, on = e;
    return;
  }
  e.next = rn, rn = e;
}
function Os() {
  ai++;
}
function qs() {
  if (--ai > 0)
    return;
  if (on) {
    let t = on;
    for (on = void 0; t; ) {
      const n = t.next;
      t.next = void 0, t.flags &= -9, t = n;
    }
  }
  let e;
  for (; rn; ) {
    let t = rn;
    for (rn = void 0; t; ) {
      const n = t.next;
      if (t.next = void 0, t.flags &= -9, t.flags & 1)
        try {
          t.trigger();
        } catch (s) {
          e || (e = s);
        }
      t = n;
    }
  }
  if (e) throw e;
}
function ci(e) {
  for (let t = e.deps; t; t = t.nextDep)
    t.version = -1, t.prevActiveLink = t.dep.activeLink, t.dep.activeLink = t;
}
function ui(e) {
  let t, n = e.depsTail, s = n;
  for (; s; ) {
    const r = s.prevDep;
    s.version === -1 ? (s === n && (n = r), js(s), Fo(s)) : t = s, s.dep.activeLink = s.prevActiveLink, s.prevActiveLink = void 0, s = r;
  }
  e.deps = t, e.depsTail = n;
}
function ms(e) {
  for (let t = e.deps; t; t = t.nextDep)
    if (t.dep.version !== t.version || t.dep.computed && (fi(t.dep.computed) || t.dep.version !== t.version))
      return !0;
  return !!e._dirty;
}
function fi(e) {
  if (e.flags & 4 && !(e.flags & 16) || (e.flags &= -17, e.globalVersion === fn) || (e.globalVersion = fn, !e.isSSR && e.flags & 128 && (!e.deps && !e._dirty || !ms(e))))
    return;
  e.flags |= 2;
  const t = e.dep, n = ye, s = Ze;
  ye = e, Ze = !0;
  try {
    ci(e);
    const r = e.fn(e._value);
    (t.version === 0 || ut(r, e._value)) && (e.flags |= 128, e._value = r, t.version++);
  } catch (r) {
    throw t.version++, r;
  } finally {
    ye = n, Ze = s, ui(e), e.flags &= -3;
  }
}
function js(e, t = !1) {
  const { dep: n, prevSub: s, nextSub: r } = e;
  if (s && (s.nextSub = r, e.prevSub = void 0), r && (r.prevSub = s, e.nextSub = void 0), n.subs === e && (n.subs = s, !s && n.computed)) {
    n.computed.flags &= -5;
    for (let i = n.computed.deps; i; i = i.nextDep)
      js(i, !0);
  }
  !t && !--n.sc && n.map && n.map.delete(n.key);
}
function Fo(e) {
  const { prevDep: t, nextDep: n } = e;
  t && (t.nextDep = n, e.prevDep = void 0), n && (n.prevDep = t, e.nextDep = void 0);
}
let Ze = !0;
const di = [];
function wt() {
  di.push(Ze), Ze = !1;
}
function It() {
  const e = di.pop();
  Ze = e === void 0 ? !0 : e;
}
function ur(e) {
  const { cleanup: t } = e;
  if (e.cleanup = void 0, t) {
    const n = ye;
    ye = void 0;
    try {
      t();
    } finally {
      ye = n;
    }
  }
}
let fn = 0;
class Ko {
  constructor(t, n) {
    this.sub = t, this.dep = n, this.version = n.version, this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0;
  }
}
class Ns {
  // TODO isolatedDeclarations "__v_skip"
  constructor(t) {
    this.computed = t, this.version = 0, this.activeLink = void 0, this.subs = void 0, this.map = void 0, this.key = void 0, this.sc = 0, this.__v_skip = !0;
  }
  track(t) {
    if (!ye || !Ze || ye === this.computed)
      return;
    let n = this.activeLink;
    if (n === void 0 || n.sub !== ye)
      n = this.activeLink = new Ko(ye, this), ye.deps ? (n.prevDep = ye.depsTail, ye.depsTail.nextDep = n, ye.depsTail = n) : ye.deps = ye.depsTail = n, hi(n);
    else if (n.version === -1 && (n.version = this.version, n.nextDep)) {
      const s = n.nextDep;
      s.prevDep = n.prevDep, n.prevDep && (n.prevDep.nextDep = s), n.prevDep = ye.depsTail, n.nextDep = void 0, ye.depsTail.nextDep = n, ye.depsTail = n, ye.deps === n && (ye.deps = s);
    }
    return n;
  }
  trigger(t) {
    this.version++, fn++, this.notify(t);
  }
  notify(t) {
    Os();
    try {
      for (let n = this.subs; n; n = n.prevSub)
        n.sub.notify() && n.sub.dep.notify();
    } finally {
      qs();
    }
  }
}
function hi(e) {
  if (e.dep.sc++, e.sub.flags & 4) {
    const t = e.dep.computed;
    if (t && !e.dep.subs) {
      t.flags |= 20;
      for (let s = t.deps; s; s = s.nextDep)
        hi(s);
    }
    const n = e.dep.subs;
    n !== e && (e.prevSub = n, n && (n.nextSub = e)), e.dep.subs = e;
  }
}
const ys = /* @__PURE__ */ new WeakMap(), jt = /* @__PURE__ */ Symbol(
  ""
), bs = /* @__PURE__ */ Symbol(
  ""
), dn = /* @__PURE__ */ Symbol(
  ""
);
function $e(e, t, n) {
  if (Ze && ye) {
    let s = ys.get(e);
    s || ys.set(e, s = /* @__PURE__ */ new Map());
    let r = s.get(n);
    r || (s.set(n, r = new Ns()), r.map = s, r.key = n), r.track();
  }
}
function bt(e, t, n, s, r, i) {
  const o = ys.get(e);
  if (!o) {
    fn++;
    return;
  }
  const a = (l) => {
    l && l.trigger();
  };
  if (Os(), t === "clear")
    o.forEach(a);
  else {
    const l = W(e), d = l && $s(n);
    if (l && n === "length") {
      const u = Number(s);
      o.forEach((h, m) => {
        (m === "length" || m === dn || !et(m) && m >= u) && a(h);
      });
    } else
      switch ((n !== void 0 || o.has(void 0)) && a(o.get(n)), d && a(o.get(dn)), t) {
        case "add":
          l ? d && a(o.get("length")) : (a(o.get(jt)), Bt(e) && a(o.get(bs)));
          break;
        case "delete":
          l || (a(o.get(jt)), Bt(e) && a(o.get(bs)));
          break;
        case "set":
          Bt(e) && a(o.get(jt));
          break;
      }
  }
  qs();
}
function Lt(e) {
  const t = /* @__PURE__ */ fe(e);
  return t === e ? t : ($e(t, "iterate", dn), /* @__PURE__ */ Qe(e) ? t : t.map(tt));
}
function Jn(e) {
  return $e(e = /* @__PURE__ */ fe(e), "iterate", dn), e;
}
function lt(e, t) {
  return /* @__PURE__ */ At(e) ? Gt(/* @__PURE__ */ Nt(e) ? tt(t) : t) : tt(t);
}
const Lo = {
  __proto__: null,
  [Symbol.iterator]() {
    return rs(this, Symbol.iterator, (e) => lt(this, e));
  },
  concat(...e) {
    return Lt(this).concat(
      ...e.map((t) => W(t) ? Lt(t) : t)
    );
  },
  entries() {
    return rs(this, "entries", (e) => (e[1] = lt(this, e[1]), e));
  },
  every(e, t) {
    return gt(this, "every", e, t, void 0, arguments);
  },
  filter(e, t) {
    return gt(
      this,
      "filter",
      e,
      t,
      (n) => n.map((s) => lt(this, s)),
      arguments
    );
  },
  find(e, t) {
    return gt(
      this,
      "find",
      e,
      t,
      (n) => lt(this, n),
      arguments
    );
  },
  findIndex(e, t) {
    return gt(this, "findIndex", e, t, void 0, arguments);
  },
  findLast(e, t) {
    return gt(
      this,
      "findLast",
      e,
      t,
      (n) => lt(this, n),
      arguments
    );
  },
  findLastIndex(e, t) {
    return gt(this, "findLastIndex", e, t, void 0, arguments);
  },
  // flat, flatMap could benefit from ARRAY_ITERATE but are not straight-forward to implement
  forEach(e, t) {
    return gt(this, "forEach", e, t, void 0, arguments);
  },
  includes(...e) {
    return is(this, "includes", e);
  },
  indexOf(...e) {
    return is(this, "indexOf", e);
  },
  join(e) {
    return Lt(this).join(e);
  },
  // keys() iterator only reads `length`, no optimization required
  lastIndexOf(...e) {
    return is(this, "lastIndexOf", e);
  },
  map(e, t) {
    return gt(this, "map", e, t, void 0, arguments);
  },
  pop() {
    return Zt(this, "pop");
  },
  push(...e) {
    return Zt(this, "push", e);
  },
  reduce(e, ...t) {
    return fr(this, "reduce", e, t);
  },
  reduceRight(e, ...t) {
    return fr(this, "reduceRight", e, t);
  },
  shift() {
    return Zt(this, "shift");
  },
  // slice could use ARRAY_ITERATE but also seems to beg for range tracking
  some(e, t) {
    return gt(this, "some", e, t, void 0, arguments);
  },
  splice(...e) {
    return Zt(this, "splice", e);
  },
  toReversed() {
    return Lt(this).toReversed();
  },
  toSorted(e) {
    return Lt(this).toSorted(e);
  },
  toSpliced(...e) {
    return Lt(this).toSpliced(...e);
  },
  unshift(...e) {
    return Zt(this, "unshift", e);
  },
  values() {
    return rs(this, "values", (e) => lt(this, e));
  }
};
function rs(e, t, n) {
  const s = Jn(e), r = s[t]();
  return s !== e && !/* @__PURE__ */ Qe(e) && (r._next = r.next, r.next = () => {
    const i = r._next();
    return i.done || (i.value = n(i.value)), i;
  }), r;
}
const Uo = Array.prototype;
function gt(e, t, n, s, r, i) {
  const o = Jn(e), a = o !== e && !/* @__PURE__ */ Qe(e), l = o[t];
  if (l !== Uo[t]) {
    const h = l.apply(e, i);
    return a ? tt(h) : h;
  }
  let d = n;
  o !== e && (a ? d = function(h, m) {
    return n.call(this, lt(e, h), m, e);
  } : n.length > 2 && (d = function(h, m) {
    return n.call(this, h, m, e);
  }));
  const u = l.call(o, d, s);
  return a && r ? r(u) : u;
}
function fr(e, t, n, s) {
  const r = Jn(e), i = r !== e && !/* @__PURE__ */ Qe(e);
  let o = n, a = !1;
  r !== e && (i ? (a = s.length === 0, o = function(d, u, h) {
    return a && (a = !1, d = lt(e, d)), n.call(this, d, lt(e, u), h, e);
  }) : n.length > 3 && (o = function(d, u, h) {
    return n.call(this, d, u, h, e);
  }));
  const l = r[t](o, ...s);
  return a ? lt(e, l) : l;
}
function is(e, t, n) {
  const s = /* @__PURE__ */ fe(e);
  $e(s, "iterate", dn);
  const r = s[t](...n);
  return (r === -1 || r === !1) && /* @__PURE__ */ Ks(n[0]) ? (n[0] = /* @__PURE__ */ fe(n[0]), s[t](...n)) : r;
}
function Zt(e, t, n = []) {
  wt(), Os();
  const s = (/* @__PURE__ */ fe(e))[t].apply(e, n);
  return qs(), It(), s;
}
const Vo = /* @__PURE__ */ Ps("__proto__,__v_isRef,__isVue"), pi = new Set(
  /* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((e) => e !== "arguments" && e !== "caller").map((e) => Symbol[e]).filter(et)
);
function Ho(e) {
  et(e) || (e = String(e));
  const t = /* @__PURE__ */ fe(this);
  return $e(t, "has", e), t.hasOwnProperty(e);
}
class gi {
  constructor(t = !1, n = !1) {
    this._isReadonly = t, this._isShallow = n;
  }
  get(t, n, s) {
    if (n === "__v_skip") return t.__v_skip;
    const r = this._isReadonly, i = this._isShallow;
    if (n === "__v_isReactive")
      return !r;
    if (n === "__v_isReadonly")
      return r;
    if (n === "__v_isShallow")
      return i;
    if (n === "__v_raw")
      return s === (r ? i ? ea : _i : i ? bi : yi).get(t) || // receiver is not the reactive proxy, but has the same prototype
      // this means the receiver is a user proxy of the reactive proxy
      Object.getPrototypeOf(t) === Object.getPrototypeOf(s) ? t : void 0;
    const o = W(t);
    if (!r) {
      let l;
      if (o && (l = Lo[n]))
        return l;
      if (n === "hasOwnProperty")
        return Ho;
    }
    const a = Reflect.get(
      t,
      n,
      // if this is a proxy wrapping a ref, return methods using the raw ref
      // as receiver so that we don't have to call `toRaw` on the ref in all
      // its class methods
      /* @__PURE__ */ Oe(t) ? t : s
    );
    if ((et(n) ? pi.has(n) : Vo(n)) || (r || $e(t, "get", n), i))
      return a;
    if (/* @__PURE__ */ Oe(a)) {
      const l = o && $s(n) ? a : a.value;
      return r && de(l) ? /* @__PURE__ */ vs(l) : l;
    }
    return de(a) ? r ? /* @__PURE__ */ vs(a) : /* @__PURE__ */ Gn(a) : a;
  }
}
class mi extends gi {
  constructor(t = !1) {
    super(!1, t);
  }
  set(t, n, s, r) {
    let i = t[n];
    const o = W(t) && $s(n);
    if (!this._isShallow) {
      const d = /* @__PURE__ */ At(i);
      if (!/* @__PURE__ */ Qe(s) && !/* @__PURE__ */ At(s) && (i = /* @__PURE__ */ fe(i), s = /* @__PURE__ */ fe(s)), !o && /* @__PURE__ */ Oe(i) && !/* @__PURE__ */ Oe(s))
        return d || (i.value = s), !0;
    }
    const a = o ? Number(n) < t.length : ce(t, n), l = Reflect.set(
      t,
      n,
      s,
      /* @__PURE__ */ Oe(t) ? t : r
    );
    return t === /* @__PURE__ */ fe(r) && (a ? ut(s, i) && bt(t, "set", n, s) : bt(t, "add", n, s)), l;
  }
  deleteProperty(t, n) {
    const s = ce(t, n);
    t[n];
    const r = Reflect.deleteProperty(t, n);
    return r && s && bt(t, "delete", n, void 0), r;
  }
  has(t, n) {
    const s = Reflect.has(t, n);
    return (!et(n) || !pi.has(n)) && $e(t, "has", n), s;
  }
  ownKeys(t) {
    return $e(
      t,
      "iterate",
      W(t) ? "length" : jt
    ), Reflect.ownKeys(t);
  }
}
class Bo extends gi {
  constructor(t = !1) {
    super(!0, t);
  }
  set(t, n) {
    return !0;
  }
  deleteProperty(t, n) {
    return !0;
  }
}
const Wo = /* @__PURE__ */ new mi(), zo = /* @__PURE__ */ new Bo(), Jo = /* @__PURE__ */ new mi(!0);
const _s = (e) => e, An = (e) => Reflect.getPrototypeOf(e);
function Go(e, t, n) {
  return function(...s) {
    const r = this.__v_raw, i = /* @__PURE__ */ fe(r), o = Bt(i), a = e === "entries" || e === Symbol.iterator && o, l = e === "keys" && o, d = r[e](...s), u = n ? _s : t ? Gt : tt;
    return !t && $e(
      i,
      "iterate",
      l ? bs : jt
    ), we(
      // inheriting all iterator properties
      Object.create(d),
      {
        // iterator protocol
        next() {
          const { value: h, done: m } = d.next();
          return m ? { value: h, done: m } : {
            value: a ? [u(h[0]), u(h[1])] : u(h),
            done: m
          };
        }
      }
    );
  };
}
function xn(e) {
  return function(...t) {
    return e === "delete" ? !1 : e === "clear" ? void 0 : this;
  };
}
function Yo(e, t) {
  const n = {
    get(r) {
      const i = this.__v_raw, o = /* @__PURE__ */ fe(i), a = /* @__PURE__ */ fe(r);
      e || (ut(r, a) && $e(o, "get", r), $e(o, "get", a));
      const { has: l } = An(o), d = t ? _s : e ? Gt : tt;
      if (l.call(o, r))
        return d(i.get(r));
      if (l.call(o, a))
        return d(i.get(a));
      i !== o && i.get(r);
    },
    get size() {
      const r = this.__v_raw;
      return !e && $e(/* @__PURE__ */ fe(r), "iterate", jt), r.size;
    },
    has(r) {
      const i = this.__v_raw, o = /* @__PURE__ */ fe(i), a = /* @__PURE__ */ fe(r);
      return e || (ut(r, a) && $e(o, "has", r), $e(o, "has", a)), r === a ? i.has(r) : i.has(r) || i.has(a);
    },
    forEach(r, i) {
      const o = this, a = o.__v_raw, l = /* @__PURE__ */ fe(a), d = t ? _s : e ? Gt : tt;
      return !e && $e(l, "iterate", jt), a.forEach((u, h) => r.call(i, d(u), d(h), o));
    }
  };
  return we(
    n,
    e ? {
      add: xn("add"),
      set: xn("set"),
      delete: xn("delete"),
      clear: xn("clear")
    } : {
      add(r) {
        const i = /* @__PURE__ */ fe(this), o = An(i), a = /* @__PURE__ */ fe(r), l = !t && !/* @__PURE__ */ Qe(r) && !/* @__PURE__ */ At(r) ? a : r;
        return o.has.call(i, l) || ut(r, l) && o.has.call(i, r) || ut(a, l) && o.has.call(i, a) || (i.add(l), bt(i, "add", l, l)), this;
      },
      set(r, i) {
        !t && !/* @__PURE__ */ Qe(i) && !/* @__PURE__ */ At(i) && (i = /* @__PURE__ */ fe(i));
        const o = /* @__PURE__ */ fe(this), { has: a, get: l } = An(o);
        let d = a.call(o, r);
        d || (r = /* @__PURE__ */ fe(r), d = a.call(o, r));
        const u = l.call(o, r);
        return o.set(r, i), d ? ut(i, u) && bt(o, "set", r, i) : bt(o, "add", r, i), this;
      },
      delete(r) {
        const i = /* @__PURE__ */ fe(this), { has: o, get: a } = An(i);
        let l = o.call(i, r);
        l || (r = /* @__PURE__ */ fe(r), l = o.call(i, r)), a && a.call(i, r);
        const d = i.delete(r);
        return l && bt(i, "delete", r, void 0), d;
      },
      clear() {
        const r = /* @__PURE__ */ fe(this), i = r.size !== 0, o = r.clear();
        return i && bt(
          r,
          "clear",
          void 0,
          void 0
        ), o;
      }
    }
  ), [
    "keys",
    "values",
    "entries",
    Symbol.iterator
  ].forEach((r) => {
    n[r] = Go(r, e, t);
  }), n;
}
function Ds(e, t) {
  const n = Yo(e, t);
  return (s, r, i) => r === "__v_isReactive" ? !e : r === "__v_isReadonly" ? e : r === "__v_raw" ? s : Reflect.get(
    ce(n, r) && r in s ? n : s,
    r,
    i
  );
}
const Xo = {
  get: /* @__PURE__ */ Ds(!1, !1)
}, Qo = {
  get: /* @__PURE__ */ Ds(!1, !0)
}, Zo = {
  get: /* @__PURE__ */ Ds(!0, !1)
};
const yi = /* @__PURE__ */ new WeakMap(), bi = /* @__PURE__ */ new WeakMap(), _i = /* @__PURE__ */ new WeakMap(), ea = /* @__PURE__ */ new WeakMap();
function ta(e) {
  switch (e) {
    case "Object":
    case "Array":
      return 1;
    case "Map":
    case "Set":
    case "WeakMap":
    case "WeakSet":
      return 2;
    default:
      return 0;
  }
}
function na(e) {
  return e.__v_skip || !Object.isExtensible(e) ? 0 : ta(Co(e));
}
// @__NO_SIDE_EFFECTS__
function Gn(e) {
  return /* @__PURE__ */ At(e) ? e : Fs(
    e,
    !1,
    Wo,
    Xo,
    yi
  );
}
// @__NO_SIDE_EFFECTS__
function sa(e) {
  return Fs(
    e,
    !1,
    Jo,
    Qo,
    bi
  );
}
// @__NO_SIDE_EFFECTS__
function vs(e) {
  return Fs(
    e,
    !0,
    zo,
    Zo,
    _i
  );
}
function Fs(e, t, n, s, r) {
  if (!de(e) || e.__v_raw && !(t && e.__v_isReactive))
    return e;
  const i = na(e);
  if (i === 0)
    return e;
  const o = r.get(e);
  if (o)
    return o;
  const a = new Proxy(
    e,
    i === 2 ? s : n
  );
  return r.set(e, a), a;
}
// @__NO_SIDE_EFFECTS__
function Nt(e) {
  return /* @__PURE__ */ At(e) ? /* @__PURE__ */ Nt(e.__v_raw) : !!(e && e.__v_isReactive);
}
// @__NO_SIDE_EFFECTS__
function At(e) {
  return !!(e && e.__v_isReadonly);
}
// @__NO_SIDE_EFFECTS__
function Qe(e) {
  return !!(e && e.__v_isShallow);
}
// @__NO_SIDE_EFFECTS__
function Ks(e) {
  return e ? !!e.__v_raw : !1;
}
// @__NO_SIDE_EFFECTS__
function fe(e) {
  const t = e && e.__v_raw;
  return t ? /* @__PURE__ */ fe(t) : e;
}
function ra(e) {
  return !ce(e, "__v_skip") && Object.isExtensible(e) && ti(e, "__v_skip", !0), e;
}
const tt = (e) => de(e) ? /* @__PURE__ */ Gn(e) : e, Gt = (e) => de(e) ? /* @__PURE__ */ vs(e) : e;
// @__NO_SIDE_EFFECTS__
function Oe(e) {
  return e ? e.__v_isRef === !0 : !1;
}
// @__NO_SIDE_EFFECTS__
function Ee(e) {
  return ia(e, !1);
}
function ia(e, t) {
  return /* @__PURE__ */ Oe(e) ? e : new oa(e, t);
}
class oa {
  constructor(t, n) {
    this.dep = new Ns(), this.__v_isRef = !0, this.__v_isShallow = !1, this._rawValue = n ? t : /* @__PURE__ */ fe(t), this._value = n ? t : tt(t), this.__v_isShallow = n;
  }
  get value() {
    return this.dep.track(), this._value;
  }
  set value(t) {
    const n = this._rawValue, s = this.__v_isShallow || /* @__PURE__ */ Qe(t) || /* @__PURE__ */ At(t);
    t = s ? t : /* @__PURE__ */ fe(t), ut(t, n) && (this._rawValue = t, this._value = s ? t : tt(t), this.dep.trigger());
  }
}
function Ls(e) {
  return /* @__PURE__ */ Oe(e) ? e.value : e;
}
const aa = {
  get: (e, t, n) => t === "__v_raw" ? e : Ls(Reflect.get(e, t, n)),
  set: (e, t, n, s) => {
    const r = e[t];
    return /* @__PURE__ */ Oe(r) && !/* @__PURE__ */ Oe(n) ? (r.value = n, !0) : Reflect.set(e, t, n, s);
  }
};
function vi(e) {
  return /* @__PURE__ */ Nt(e) ? e : new Proxy(e, aa);
}
class la {
  constructor(t, n, s) {
    this.fn = t, this.setter = n, this._value = void 0, this.dep = new Ns(this), this.__v_isRef = !0, this.deps = void 0, this.depsTail = void 0, this.flags = 16, this.globalVersion = fn - 1, this.next = void 0, this.effect = this, this.__v_isReadonly = !n, this.isSSR = s;
  }
  /**
   * @internal
   */
  notify() {
    if (this.flags |= 16, !(this.flags & 8) && // avoid infinite self recursion
    ye !== this)
      return li(this, !0), !0;
  }
  get value() {
    const t = this.dep.track();
    return fi(this), t && (t.version = this.dep.version), this._value;
  }
  set value(t) {
    this.setter && this.setter(t);
  }
}
// @__NO_SIDE_EFFECTS__
function ca(e, t, n = !1) {
  let s, r;
  return ee(e) ? s = e : (s = e.get, r = e.set), new la(s, r, n);
}
const Cn = {}, $n = /* @__PURE__ */ new WeakMap();
let qt;
function ua(e, t = !1, n = qt) {
  if (n) {
    let s = $n.get(n);
    s || $n.set(n, s = []), s.push(e);
  }
}
function fa(e, t, n = ge) {
  const { immediate: s, deep: r, once: i, scheduler: o, augmentJob: a, call: l } = n, d = (R) => r ? R : /* @__PURE__ */ Qe(R) || r === !1 || r === 0 ? _t(R, 1) : _t(R);
  let u, h, m, k, I = !1, y = !1;
  if (/* @__PURE__ */ Oe(e) ? (h = () => e.value, I = /* @__PURE__ */ Qe(e)) : /* @__PURE__ */ Nt(e) ? (h = () => d(e), I = !0) : W(e) ? (y = !0, I = e.some((R) => /* @__PURE__ */ Nt(R) || /* @__PURE__ */ Qe(R)), h = () => e.map((R) => {
    if (/* @__PURE__ */ Oe(R))
      return R.value;
    if (/* @__PURE__ */ Nt(R))
      return d(R);
    if (ee(R))
      return l ? l(R, 2) : R();
  })) : ee(e) ? t ? h = l ? () => l(e, 2) : e : h = () => {
    if (m) {
      wt();
      try {
        m();
      } finally {
        It();
      }
    }
    const R = qt;
    qt = u;
    try {
      return l ? l(e, 3, [k]) : e(k);
    } finally {
      qt = R;
    }
  } : h = ft, t && r) {
    const R = h, K = r === !0 ? 1 / 0 : r;
    h = () => _t(R(), K);
  }
  const z = Do(), J = () => {
    u.stop(), z && z.active && Rs(z.effects, u);
  };
  if (i && t) {
    const R = t;
    t = (...K) => {
      R(...K), J();
    };
  }
  let S = y ? new Array(e.length).fill(Cn) : Cn;
  const j = (R) => {
    if (!(!(u.flags & 1) || !u.dirty && !R))
      if (t) {
        const K = u.run();
        if (r || I || (y ? K.some((_, E) => ut(_, S[E])) : ut(K, S))) {
          m && m();
          const _ = qt;
          qt = u;
          try {
            const E = [
              K,
              // pass undefined as the old value when it's changed for the first time
              S === Cn ? void 0 : y && S[0] === Cn ? [] : S,
              k
            ];
            S = K, l ? l(t, 3, E) : (
              // @ts-expect-error
              t(...E)
            );
          } finally {
            qt = _;
          }
        }
      } else
        u.run();
  };
  return a && a(j), u = new oi(h), u.scheduler = o ? () => o(j, !1) : j, k = (R) => ua(R, !1, u), m = u.onStop = () => {
    const R = $n.get(u);
    if (R) {
      if (l)
        l(R, 4);
      else
        for (const K of R) K();
      $n.delete(u);
    }
  }, t ? s ? j(!0) : S = u.run() : o ? o(j.bind(null, !0), !0) : u.run(), J.pause = u.pause.bind(u), J.resume = u.resume.bind(u), J.stop = J, J;
}
function _t(e, t = 1 / 0, n) {
  if (t <= 0 || !de(e) || e.__v_skip || (n = n || /* @__PURE__ */ new Map(), (n.get(e) || 0) >= t))
    return e;
  if (n.set(e, t), t--, /* @__PURE__ */ Oe(e))
    _t(e.value, t, n);
  else if (W(e))
    for (let s = 0; s < e.length; s++)
      _t(e[s], t, n);
  else if (Vn(e) || Bt(e))
    e.forEach((s) => {
      _t(s, t, n);
    });
  else if (Hn(e)) {
    for (const s in e)
      _t(e[s], t, n);
    for (const s of Object.getOwnPropertySymbols(e))
      Object.prototype.propertyIsEnumerable.call(e, s) && _t(e[s], t, n);
  }
  return e;
}
/**
* @vue/runtime-core v3.5.31
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
function vn(e, t, n, s) {
  try {
    return s ? e(...s) : e();
  } catch (r) {
    Yn(r, t, n);
  }
}
function dt(e, t, n, s) {
  if (ee(e)) {
    const r = vn(e, t, n, s);
    return r && Zr(r) && r.catch((i) => {
      Yn(i, t, n);
    }), r;
  }
  if (W(e)) {
    const r = [];
    for (let i = 0; i < e.length; i++)
      r.push(dt(e[i], t, n, s));
    return r;
  }
}
function Yn(e, t, n, s = !0) {
  const r = t ? t.vnode : null, { errorHandler: i, throwUnhandledErrorInProduction: o } = t && t.appContext.config || ge;
  if (t) {
    let a = t.parent;
    const l = t.proxy, d = `https://vuejs.org/error-reference/#runtime-${n}`;
    for (; a; ) {
      const u = a.ec;
      if (u) {
        for (let h = 0; h < u.length; h++)
          if (u[h](e, l, d) === !1)
            return;
      }
      a = a.parent;
    }
    if (i) {
      wt(), vn(i, null, 10, [
        e,
        l,
        d
      ]), It();
      return;
    }
  }
  da(e, n, r, s, o);
}
function da(e, t, n, s = !0, r = !1) {
  if (r)
    throw e;
  console.error(e);
}
const je = [];
let at = -1;
const Wt = [];
let Tt = null, Ut = 0;
const Si = /* @__PURE__ */ Promise.resolve();
let Mn = null;
function Us(e) {
  const t = Mn || Si;
  return e ? t.then(this ? e.bind(this) : e) : t;
}
function ha(e) {
  let t = at + 1, n = je.length;
  for (; t < n; ) {
    const s = t + n >>> 1, r = je[s], i = hn(r);
    i < e || i === e && r.flags & 2 ? t = s + 1 : n = s;
  }
  return t;
}
function Vs(e) {
  if (!(e.flags & 1)) {
    const t = hn(e), n = je[je.length - 1];
    !n || // fast path when the job id is larger than the tail
    !(e.flags & 2) && t >= hn(n) ? je.push(e) : je.splice(ha(t), 0, e), e.flags |= 1, wi();
  }
}
function wi() {
  Mn || (Mn = Si.then(Ai));
}
function pa(e) {
  W(e) ? Wt.push(...e) : Tt && e.id === -1 ? Tt.splice(Ut + 1, 0, e) : e.flags & 1 || (Wt.push(e), e.flags |= 1), wi();
}
function dr(e, t, n = at + 1) {
  for (; n < je.length; n++) {
    const s = je[n];
    if (s && s.flags & 2) {
      if (e && s.id !== e.uid)
        continue;
      je.splice(n, 1), n--, s.flags & 4 && (s.flags &= -2), s(), s.flags & 4 || (s.flags &= -2);
    }
  }
}
function Ii(e) {
  if (Wt.length) {
    const t = [...new Set(Wt)].sort(
      (n, s) => hn(n) - hn(s)
    );
    if (Wt.length = 0, Tt) {
      Tt.push(...t);
      return;
    }
    for (Tt = t, Ut = 0; Ut < Tt.length; Ut++) {
      const n = Tt[Ut];
      n.flags & 4 && (n.flags &= -2), n.flags & 8 || n(), n.flags &= -2;
    }
    Tt = null, Ut = 0;
  }
}
const hn = (e) => e.id == null ? e.flags & 2 ? -1 : 1 / 0 : e.id;
function Ai(e) {
  try {
    for (at = 0; at < je.length; at++) {
      const t = je[at];
      t && !(t.flags & 8) && (t.flags & 4 && (t.flags &= -2), vn(
        t,
        t.i,
        t.i ? 15 : 14
      ), t.flags & 4 || (t.flags &= -2));
    }
  } finally {
    for (; at < je.length; at++) {
      const t = je[at];
      t && (t.flags &= -2);
    }
    at = -1, je.length = 0, Ii(), Mn = null, (je.length || Wt.length) && Ai();
  }
}
let Te = null, xi = null;
function On(e) {
  const t = Te;
  return Te = e, xi = e && e.type.__scopeId || null, t;
}
function qn(e, t = Te, n) {
  if (!t || e._n)
    return e;
  const s = (...r) => {
    s._d && Dn(-1);
    const i = On(t);
    let o;
    try {
      o = e(...r);
    } finally {
      On(i), s._d && Dn(1);
    }
    return o;
  };
  return s._n = !0, s._c = !0, s._d = !0, s;
}
function Vt(e, t) {
  if (Te === null)
    return e;
  const n = es(Te), s = e.dirs || (e.dirs = []);
  for (let r = 0; r < t.length; r++) {
    let [i, o, a, l = ge] = t[r];
    i && (ee(i) && (i = {
      mounted: i,
      updated: i
    }), i.deep && _t(o), s.push({
      dir: i,
      instance: n,
      value: o,
      oldValue: void 0,
      arg: a,
      modifiers: l
    }));
  }
  return e;
}
function Mt(e, t, n, s) {
  const r = e.dirs, i = t && t.dirs;
  for (let o = 0; o < r.length; o++) {
    const a = r[o];
    i && (a.oldValue = i[o].value);
    let l = a.dir[s];
    l && (wt(), dt(l, n, 8, [
      e.el,
      a,
      e,
      t
    ]), It());
  }
}
function ga(e, t) {
  if (Me) {
    let n = Me.provides;
    const s = Me.parent && Me.parent.provides;
    s === n && (n = Me.provides = Object.create(s)), n[e] = t;
  }
}
function Tn(e, t, n = !1) {
  const s = hl();
  if (s || Jt) {
    let r = Jt ? Jt._context.provides : s ? s.parent == null || s.ce ? s.vnode.appContext && s.vnode.appContext.provides : s.parent.provides : void 0;
    if (r && e in r)
      return r[e];
    if (arguments.length > 1)
      return n && ee(t) ? t.call(s && s.proxy) : t;
  }
}
const ma = /* @__PURE__ */ Symbol.for("v-scx"), ya = () => Tn(ma);
function Dt(e, t, n) {
  return Ci(e, t, n);
}
function Ci(e, t, n = ge) {
  const { immediate: s, deep: r, flush: i, once: o } = n, a = we({}, n), l = t && s || !t && i !== "post";
  let d;
  if (yn) {
    if (i === "sync") {
      const k = ya();
      d = k.__watcherHandles || (k.__watcherHandles = []);
    } else if (!l) {
      const k = () => {
      };
      return k.stop = ft, k.resume = ft, k.pause = ft, k;
    }
  }
  const u = Me;
  a.call = (k, I, y) => dt(k, u, I, y);
  let h = !1;
  i === "post" ? a.scheduler = (k) => {
    Ne(k, u && u.suspense);
  } : i !== "sync" && (h = !0, a.scheduler = (k, I) => {
    I ? k() : Vs(k);
  }), a.augmentJob = (k) => {
    t && (k.flags |= 4), h && (k.flags |= 2, u && (k.id = u.uid, k.i = u));
  };
  const m = fa(e, t, a);
  return yn && (d ? d.push(m) : l && m()), m;
}
function ba(e, t, n) {
  const s = this.proxy, r = Se(e) ? e.includes(".") ? ki(s, e) : () => s[e] : e.bind(s, s);
  let i;
  ee(t) ? i = t : (i = t.handler, n = t);
  const o = Sn(this), a = Ci(r, i.bind(s), n);
  return o(), a;
}
function ki(e, t) {
  const n = t.split(".");
  return () => {
    let s = e;
    for (let r = 0; r < n.length && s; r++)
      s = s[n[r]];
    return s;
  };
}
const _a = /* @__PURE__ */ Symbol("_vte"), va = (e) => e.__isTeleport, Sa = /* @__PURE__ */ Symbol("_leaveCb");
function Hs(e, t) {
  e.shapeFlag & 6 && e.component ? (e.transition = t, Hs(e.component.subTree, t)) : e.shapeFlag & 128 ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t;
}
// @__NO_SIDE_EFFECTS__
function ht(e, t) {
  return ee(e) ? (
    // #8236: extend call and options.name access are considered side-effects
    // by Rollup, so we have to wrap it in a pure-annotated IIFE.
    we({ name: e.name }, t, { setup: e })
  ) : e;
}
function Ei(e) {
  e.ids = [e.ids[0] + e.ids[2]++ + "-", 0, 0];
}
function hr(e, t) {
  let n;
  return !!((n = Object.getOwnPropertyDescriptor(e, t)) && !n.configurable);
}
const jn = /* @__PURE__ */ new WeakMap();
function an(e, t, n, s, r = !1) {
  if (W(e)) {
    e.forEach(
      (y, z) => an(
        y,
        t && (W(t) ? t[z] : t),
        n,
        s,
        r
      )
    );
    return;
  }
  if (zt(s) && !r) {
    s.shapeFlag & 512 && s.type.__asyncResolved && s.component.subTree.component && an(e, t, n, s.component.subTree);
    return;
  }
  const i = s.shapeFlag & 4 ? es(s.component) : s.el, o = r ? null : i, { i: a, r: l } = e, d = t && t.r, u = a.refs === ge ? a.refs = {} : a.refs, h = a.setupState, m = /* @__PURE__ */ fe(h), k = h === ge ? Qr : (y) => hr(u, y) ? !1 : ce(m, y), I = (y, z) => !(z && hr(u, z));
  if (d != null && d !== l) {
    if (pr(t), Se(d))
      u[d] = null, k(d) && (h[d] = null);
    else if (/* @__PURE__ */ Oe(d)) {
      const y = t;
      I(d, y.k) && (d.value = null), y.k && (u[y.k] = null);
    }
  }
  if (ee(l))
    vn(l, a, 12, [o, u]);
  else {
    const y = Se(l), z = /* @__PURE__ */ Oe(l);
    if (y || z) {
      const J = () => {
        if (e.f) {
          const S = y ? k(l) ? h[l] : u[l] : I() || !e.k ? l.value : u[e.k];
          if (r)
            W(S) && Rs(S, i);
          else if (W(S))
            S.includes(i) || S.push(i);
          else if (y)
            u[l] = [i], k(l) && (h[l] = u[l]);
          else {
            const j = [i];
            I(l, e.k) && (l.value = j), e.k && (u[e.k] = j);
          }
        } else y ? (u[l] = o, k(l) && (h[l] = o)) : z && (I(l, e.k) && (l.value = o), e.k && (u[e.k] = o));
      };
      if (o) {
        const S = () => {
          J(), jn.delete(e);
        };
        S.id = -1, jn.set(e, S), Ne(S, n);
      } else
        pr(e), J();
    }
  }
}
function pr(e) {
  const t = jn.get(e);
  t && (t.flags |= 8, jn.delete(e));
}
zn().requestIdleCallback;
zn().cancelIdleCallback;
const zt = (e) => !!e.type.__asyncLoader, Ti = (e) => e.type.__isKeepAlive;
function wa(e, t) {
  Pi(e, "a", t);
}
function Ia(e, t) {
  Pi(e, "da", t);
}
function Pi(e, t, n = Me) {
  const s = e.__wdc || (e.__wdc = () => {
    let r = n;
    for (; r; ) {
      if (r.isDeactivated)
        return;
      r = r.parent;
    }
    return e();
  });
  if (Xn(t, s, n), n) {
    let r = n.parent;
    for (; r && r.parent; )
      Ti(r.parent.vnode) && Aa(s, t, n, r), r = r.parent;
  }
}
function Aa(e, t, n, s) {
  const r = Xn(
    t,
    e,
    s,
    !0
    /* prepend */
  );
  Ws(() => {
    Rs(s[t], r);
  }, n);
}
function Xn(e, t, n = Me, s = !1) {
  if (n) {
    const r = n[e] || (n[e] = []), i = t.__weh || (t.__weh = (...o) => {
      wt();
      const a = Sn(n), l = dt(t, n, e, o);
      return a(), It(), l;
    });
    return s ? r.unshift(i) : r.push(i), i;
  }
}
const Ct = (e) => (t, n = Me) => {
  (!yn || e === "sp") && Xn(e, (...s) => t(...s), n);
}, xa = Ct("bm"), Bs = Ct("m"), Ca = Ct(
  "bu"
), ka = Ct("u"), Ea = Ct(
  "bum"
), Ws = Ct("um"), Ta = Ct(
  "sp"
), Pa = Ct("rtg"), Ra = Ct("rtc");
function $a(e, t = Me) {
  Xn("ec", e, t);
}
const Ma = "components", Ri = /* @__PURE__ */ Symbol.for("v-ndc");
function Oa(e) {
  return Se(e) ? qa(Ma, e, !1) || e : e || Ri;
}
function qa(e, t, n = !0, s = !1) {
  const r = Te || Me;
  if (r) {
    const i = r.type;
    {
      const a = bl(
        i,
        !1
      );
      if (a && (a === t || a === xe(t) || a === Wn(xe(t))))
        return i;
    }
    const o = (
      // local registration
      // check instance[type] first which is resolved for options API
      gr(r[e] || i[e], t) || // global registration
      gr(r.appContext[e], t)
    );
    return !o && s ? i : o;
  }
}
function gr(e, t) {
  return e && (e[t] || e[xe(t)] || e[Wn(xe(t))]);
}
function Fe(e, t, n, s) {
  let r;
  const i = n, o = W(e);
  if (o || Se(e)) {
    const a = o && /* @__PURE__ */ Nt(e);
    let l = !1, d = !1;
    a && (l = !/* @__PURE__ */ Qe(e), d = /* @__PURE__ */ At(e), e = Jn(e)), r = new Array(e.length);
    for (let u = 0, h = e.length; u < h; u++)
      r[u] = t(
        l ? d ? Gt(tt(e[u])) : tt(e[u]) : e[u],
        u,
        void 0,
        i
      );
  } else if (typeof e == "number") {
    r = new Array(e);
    for (let a = 0; a < e; a++)
      r[a] = t(a + 1, a, void 0, i);
  } else if (de(e))
    if (e[Symbol.iterator])
      r = Array.from(
        e,
        (a, l) => t(a, l, void 0, i)
      );
    else {
      const a = Object.keys(e);
      r = new Array(a.length);
      for (let l = 0, d = a.length; l < d; l++) {
        const u = a[l];
        r[l] = t(e[u], u, l, i);
      }
    }
  else
    r = [];
  return r;
}
function $i(e, t) {
  for (let n = 0; n < t.length; n++) {
    const s = t[n];
    if (W(s))
      for (let r = 0; r < s.length; r++)
        e[s[r].name] = s[r].fn;
    else s && (e[s.name] = s.key ? (...r) => {
      const i = s.fn(...r);
      return i && (i.key = s.key), i;
    } : s.fn);
  }
  return e;
}
function Pt(e, t, n = {}, s, r) {
  if (Te.ce || Te.parent && zt(Te.parent) && Te.parent.ce) {
    const d = Object.keys(n).length > 0;
    return t !== "default" && (n.name = t), T(), pt(
      be,
      null,
      [Pe("slot", n, s && s())],
      d ? -2 : 64
    );
  }
  let i = e[t];
  i && i._c && (i._d = !1), T();
  const o = i && Mi(i(n)), a = n.key || // slot content array of a dynamic conditional slot may have a branch
  // key attached in the `createSlots` helper, respect that
  o && o.key, l = pt(
    be,
    {
      key: (a && !et(a) ? a : `_${t}`) + // #7256 force differentiate fallback content from actual content
      (!o && s ? "_fb" : "")
    },
    o || (s ? s() : []),
    o && e._ === 1 ? 64 : -2
  );
  return i && i._c && (i._d = !0), l;
}
function Mi(e) {
  return e.some((t) => gn(t) ? !(t.type === xt || t.type === be && !Mi(t.children)) : !0) ? e : null;
}
const Ss = (e) => e ? to(e) ? es(e) : Ss(e.parent) : null, ln = (
  // Move PURE marker to new line to workaround compiler discarding it
  // due to type annotation
  /* @__PURE__ */ we(/* @__PURE__ */ Object.create(null), {
    $: (e) => e,
    $el: (e) => e.vnode.el,
    $data: (e) => e.data,
    $props: (e) => e.props,
    $attrs: (e) => e.attrs,
    $slots: (e) => e.slots,
    $refs: (e) => e.refs,
    $parent: (e) => Ss(e.parent),
    $root: (e) => Ss(e.root),
    $host: (e) => e.ce,
    $emit: (e) => e.emit,
    $options: (e) => qi(e),
    $forceUpdate: (e) => e.f || (e.f = () => {
      Vs(e.update);
    }),
    $nextTick: (e) => e.n || (e.n = Us.bind(e.proxy)),
    $watch: (e) => ba.bind(e)
  })
), os = (e, t) => e !== ge && !e.__isScriptSetup && ce(e, t), ja = {
  get({ _: e }, t) {
    if (t === "__v_skip")
      return !0;
    const { ctx: n, setupState: s, data: r, props: i, accessCache: o, type: a, appContext: l } = e;
    if (t[0] !== "$") {
      const m = o[t];
      if (m !== void 0)
        switch (m) {
          case 1:
            return s[t];
          case 2:
            return r[t];
          case 4:
            return n[t];
          case 3:
            return i[t];
        }
      else {
        if (os(s, t))
          return o[t] = 1, s[t];
        if (r !== ge && ce(r, t))
          return o[t] = 2, r[t];
        if (ce(i, t))
          return o[t] = 3, i[t];
        if (n !== ge && ce(n, t))
          return o[t] = 4, n[t];
        ws && (o[t] = 0);
      }
    }
    const d = ln[t];
    let u, h;
    if (d)
      return t === "$attrs" && $e(e.attrs, "get", ""), d(e);
    if (
      // css module (injected by vue-loader)
      (u = a.__cssModules) && (u = u[t])
    )
      return u;
    if (n !== ge && ce(n, t))
      return o[t] = 4, n[t];
    if (
      // global properties
      h = l.config.globalProperties, ce(h, t)
    )
      return h[t];
  },
  set({ _: e }, t, n) {
    const { data: s, setupState: r, ctx: i } = e;
    return os(r, t) ? (r[t] = n, !0) : s !== ge && ce(s, t) ? (s[t] = n, !0) : ce(e.props, t) || t[0] === "$" && t.slice(1) in e ? !1 : (i[t] = n, !0);
  },
  has({
    _: { data: e, setupState: t, accessCache: n, ctx: s, appContext: r, props: i, type: o }
  }, a) {
    let l;
    return !!(n[a] || e !== ge && a[0] !== "$" && ce(e, a) || os(t, a) || ce(i, a) || ce(s, a) || ce(ln, a) || ce(r.config.globalProperties, a) || (l = o.__cssModules) && l[a]);
  },
  defineProperty(e, t, n) {
    return n.get != null ? e._.accessCache[t] = 0 : ce(n, "value") && this.set(e, t, n.value, null), Reflect.defineProperty(e, t, n);
  }
};
function mr(e) {
  return W(e) ? e.reduce(
    (t, n) => (t[n] = null, t),
    {}
  ) : e;
}
let ws = !0;
function Na(e) {
  const t = qi(e), n = e.proxy, s = e.ctx;
  ws = !1, t.beforeCreate && yr(t.beforeCreate, e, "bc");
  const {
    // state
    data: r,
    computed: i,
    methods: o,
    watch: a,
    provide: l,
    inject: d,
    // lifecycle
    created: u,
    beforeMount: h,
    mounted: m,
    beforeUpdate: k,
    updated: I,
    activated: y,
    deactivated: z,
    beforeDestroy: J,
    beforeUnmount: S,
    destroyed: j,
    unmounted: R,
    render: K,
    renderTracked: _,
    renderTriggered: E,
    errorCaptured: H,
    serverPrefetch: L,
    // public API
    expose: U,
    inheritAttrs: ie,
    // assets
    components: ne,
    directives: he,
    filters: te
  } = t;
  if (d && Da(d, s, null), o)
    for (const oe in o) {
      const se = o[oe];
      ee(se) && (s[oe] = se.bind(n));
    }
  if (r) {
    const oe = r.call(n, n);
    de(oe) && (e.data = /* @__PURE__ */ Gn(oe));
  }
  if (ws = !0, i)
    for (const oe in i) {
      const se = i[oe], Ce = ee(se) ? se.bind(n, n) : ee(se.get) ? se.get.bind(n, n) : ft, Je = !ee(se) && ee(se.set) ? se.set.bind(n) : ft, Le = le({
        get: Ce,
        set: Je
      });
      Object.defineProperty(s, oe, {
        enumerable: !0,
        configurable: !0,
        get: () => Le.value,
        set: (_e) => Le.value = _e
      });
    }
  if (a)
    for (const oe in a)
      Oi(a[oe], s, n, oe);
  if (l) {
    const oe = ee(l) ? l.call(n) : l;
    Reflect.ownKeys(oe).forEach((se) => {
      ga(se, oe[se]);
    });
  }
  u && yr(u, e, "c");
  function ue(oe, se) {
    W(se) ? se.forEach((Ce) => oe(Ce.bind(n))) : se && oe(se.bind(n));
  }
  if (ue(xa, h), ue(Bs, m), ue(Ca, k), ue(ka, I), ue(wa, y), ue(Ia, z), ue($a, H), ue(Ra, _), ue(Pa, E), ue(Ea, S), ue(Ws, R), ue(Ta, L), W(U))
    if (U.length) {
      const oe = e.exposed || (e.exposed = {});
      U.forEach((se) => {
        Object.defineProperty(oe, se, {
          get: () => n[se],
          set: (Ce) => n[se] = Ce,
          enumerable: !0
        });
      });
    } else e.exposed || (e.exposed = {});
  K && e.render === ft && (e.render = K), ie != null && (e.inheritAttrs = ie), ne && (e.components = ne), he && (e.directives = he), L && Ei(e);
}
function Da(e, t, n = ft) {
  W(e) && (e = Is(e));
  for (const s in e) {
    const r = e[s];
    let i;
    de(r) ? "default" in r ? i = Tn(
      r.from || s,
      r.default,
      !0
    ) : i = Tn(r.from || s) : i = Tn(r), /* @__PURE__ */ Oe(i) ? Object.defineProperty(t, s, {
      enumerable: !0,
      configurable: !0,
      get: () => i.value,
      set: (o) => i.value = o
    }) : t[s] = i;
  }
}
function yr(e, t, n) {
  dt(
    W(e) ? e.map((s) => s.bind(t.proxy)) : e.bind(t.proxy),
    t,
    n
  );
}
function Oi(e, t, n, s) {
  let r = s.includes(".") ? ki(n, s) : () => n[s];
  if (Se(e)) {
    const i = t[e];
    ee(i) && Dt(r, i);
  } else if (ee(e))
    Dt(r, e.bind(n));
  else if (de(e))
    if (W(e))
      e.forEach((i) => Oi(i, t, n, s));
    else {
      const i = ee(e.handler) ? e.handler.bind(n) : t[e.handler];
      ee(i) && Dt(r, i, e);
    }
}
function qi(e) {
  const t = e.type, { mixins: n, extends: s } = t, {
    mixins: r,
    optionsCache: i,
    config: { optionMergeStrategies: o }
  } = e.appContext, a = i.get(t);
  let l;
  return a ? l = a : !r.length && !n && !s ? l = t : (l = {}, r.length && r.forEach(
    (d) => Nn(l, d, o, !0)
  ), Nn(l, t, o)), de(t) && i.set(t, l), l;
}
function Nn(e, t, n, s = !1) {
  const { mixins: r, extends: i } = t;
  i && Nn(e, i, n, !0), r && r.forEach(
    (o) => Nn(e, o, n, !0)
  );
  for (const o in t)
    if (!(s && o === "expose")) {
      const a = Fa[o] || n && n[o];
      e[o] = a ? a(e[o], t[o]) : t[o];
    }
  return e;
}
const Fa = {
  data: br,
  props: _r,
  emits: _r,
  // objects
  methods: tn,
  computed: tn,
  // lifecycle
  beforeCreate: qe,
  created: qe,
  beforeMount: qe,
  mounted: qe,
  beforeUpdate: qe,
  updated: qe,
  beforeDestroy: qe,
  beforeUnmount: qe,
  destroyed: qe,
  unmounted: qe,
  activated: qe,
  deactivated: qe,
  errorCaptured: qe,
  serverPrefetch: qe,
  // assets
  components: tn,
  directives: tn,
  // watch
  watch: La,
  // provide / inject
  provide: br,
  inject: Ka
};
function br(e, t) {
  return t ? e ? function() {
    return we(
      ee(e) ? e.call(this, this) : e,
      ee(t) ? t.call(this, this) : t
    );
  } : t : e;
}
function Ka(e, t) {
  return tn(Is(e), Is(t));
}
function Is(e) {
  if (W(e)) {
    const t = {};
    for (let n = 0; n < e.length; n++)
      t[e[n]] = e[n];
    return t;
  }
  return e;
}
function qe(e, t) {
  return e ? [...new Set([].concat(e, t))] : t;
}
function tn(e, t) {
  return e ? we(/* @__PURE__ */ Object.create(null), e, t) : t;
}
function _r(e, t) {
  return e ? W(e) && W(t) ? [.../* @__PURE__ */ new Set([...e, ...t])] : we(
    /* @__PURE__ */ Object.create(null),
    mr(e),
    mr(t ?? {})
  ) : t;
}
function La(e, t) {
  if (!e) return t;
  if (!t) return e;
  const n = we(/* @__PURE__ */ Object.create(null), e);
  for (const s in t)
    n[s] = qe(e[s], t[s]);
  return n;
}
function ji() {
  return {
    app: null,
    config: {
      isNativeTag: Qr,
      performance: !1,
      globalProperties: {},
      optionMergeStrategies: {},
      errorHandler: void 0,
      warnHandler: void 0,
      compilerOptions: {}
    },
    mixins: [],
    components: {},
    directives: {},
    provides: /* @__PURE__ */ Object.create(null),
    optionsCache: /* @__PURE__ */ new WeakMap(),
    propsCache: /* @__PURE__ */ new WeakMap(),
    emitsCache: /* @__PURE__ */ new WeakMap()
  };
}
let Ua = 0;
function Va(e, t) {
  return function(s, r = null) {
    ee(s) || (s = we({}, s)), r != null && !de(r) && (r = null);
    const i = ji(), o = /* @__PURE__ */ new WeakSet(), a = [];
    let l = !1;
    const d = i.app = {
      _uid: Ua++,
      _component: s,
      _props: r,
      _container: null,
      _context: i,
      _instance: null,
      version: Sl,
      get config() {
        return i.config;
      },
      set config(u) {
      },
      use(u, ...h) {
        return o.has(u) || (u && ee(u.install) ? (o.add(u), u.install(d, ...h)) : ee(u) && (o.add(u), u(d, ...h))), d;
      },
      mixin(u) {
        return i.mixins.includes(u) || i.mixins.push(u), d;
      },
      component(u, h) {
        return h ? (i.components[u] = h, d) : i.components[u];
      },
      directive(u, h) {
        return h ? (i.directives[u] = h, d) : i.directives[u];
      },
      mount(u, h, m) {
        if (!l) {
          const k = d._ceVNode || Pe(s, r);
          return k.appContext = i, m === !0 ? m = "svg" : m === !1 && (m = void 0), e(k, u, m), l = !0, d._container = u, u.__vue_app__ = d, es(k.component);
        }
      },
      onUnmount(u) {
        a.push(u);
      },
      unmount() {
        l && (dt(
          a,
          d._instance,
          16
        ), e(null, d._container), delete d._container.__vue_app__);
      },
      provide(u, h) {
        return i.provides[u] = h, d;
      },
      runWithContext(u) {
        const h = Jt;
        Jt = d;
        try {
          return u();
        } finally {
          Jt = h;
        }
      }
    };
    return d;
  };
}
let Jt = null;
const Ha = (e, t) => t === "modelValue" || t === "model-value" ? e.modelModifiers : e[`${t}Modifiers`] || e[`${xe(t)}Modifiers`] || e[`${Xe(t)}Modifiers`];
function Ba(e, t, ...n) {
  if (e.isUnmounted) return;
  const s = e.vnode.props || ge;
  let r = n;
  const i = t.startsWith("update:"), o = i && Ha(s, t.slice(7));
  o && (o.trim && (r = n.map((u) => Se(u) ? u.trim() : u)), o.number && (r = n.map(Ms)));
  let a, l = s[a = ts(t)] || // also try camelCase event handler (#2249)
  s[a = ts(xe(t))];
  !l && i && (l = s[a = ts(Xe(t))]), l && dt(
    l,
    e,
    6,
    r
  );
  const d = s[a + "Once"];
  if (d) {
    if (!e.emitted)
      e.emitted = {};
    else if (e.emitted[a])
      return;
    e.emitted[a] = !0, dt(
      d,
      e,
      6,
      r
    );
  }
}
const Wa = /* @__PURE__ */ new WeakMap();
function Ni(e, t, n = !1) {
  const s = n ? Wa : t.emitsCache, r = s.get(e);
  if (r !== void 0)
    return r;
  const i = e.emits;
  let o = {}, a = !1;
  if (!ee(e)) {
    const l = (d) => {
      const u = Ni(d, t, !0);
      u && (a = !0, we(o, u));
    };
    !n && t.mixins.length && t.mixins.forEach(l), e.extends && l(e.extends), e.mixins && e.mixins.forEach(l);
  }
  return !i && !a ? (de(e) && s.set(e, null), null) : (W(i) ? i.forEach((l) => o[l] = null) : we(o, i), de(e) && s.set(e, o), o);
}
function Qn(e, t) {
  return !e || !Ln(t) ? !1 : (t = t.slice(2).replace(/Once$/, ""), ce(e, t[0].toLowerCase() + t.slice(1)) || ce(e, Xe(t)) || ce(e, t));
}
function vr(e) {
  const {
    type: t,
    vnode: n,
    proxy: s,
    withProxy: r,
    propsOptions: [i],
    slots: o,
    attrs: a,
    emit: l,
    render: d,
    renderCache: u,
    props: h,
    data: m,
    setupState: k,
    ctx: I,
    inheritAttrs: y
  } = e, z = On(e);
  let J, S;
  try {
    if (n.shapeFlag & 4) {
      const R = r || s, K = R;
      J = ct(
        d.call(
          K,
          R,
          u,
          h,
          k,
          m,
          I
        )
      ), S = a;
    } else {
      const R = t;
      J = ct(
        R.length > 1 ? R(
          h,
          { attrs: a, slots: o, emit: l }
        ) : R(
          h,
          null
        )
      ), S = t.props ? a : za(a);
    }
  } catch (R) {
    cn.length = 0, Yn(R, e, 1), J = Pe(xt);
  }
  let j = J;
  if (S && y !== !1) {
    const R = Object.keys(S), { shapeFlag: K } = j;
    R.length && K & 7 && (i && R.some(Un) && (S = Ja(
      S,
      i
    )), j = Yt(j, S, !1, !0));
  }
  return n.dirs && (j = Yt(j, null, !1, !0), j.dirs = j.dirs ? j.dirs.concat(n.dirs) : n.dirs), n.transition && Hs(j, n.transition), J = j, On(z), J;
}
const za = (e) => {
  let t;
  for (const n in e)
    (n === "class" || n === "style" || Ln(n)) && ((t || (t = {}))[n] = e[n]);
  return t;
}, Ja = (e, t) => {
  const n = {};
  for (const s in e)
    (!Un(s) || !(s.slice(9) in t)) && (n[s] = e[s]);
  return n;
};
function Ga(e, t, n) {
  const { props: s, children: r, component: i } = e, { props: o, children: a, patchFlag: l } = t, d = i.emitsOptions;
  if (t.dirs || t.transition)
    return !0;
  if (n && l >= 0) {
    if (l & 1024)
      return !0;
    if (l & 16)
      return s ? Sr(s, o, d) : !!o;
    if (l & 8) {
      const u = t.dynamicProps;
      for (let h = 0; h < u.length; h++) {
        const m = u[h];
        if (Di(o, s, m) && !Qn(d, m))
          return !0;
      }
    }
  } else
    return (r || a) && (!a || !a.$stable) ? !0 : s === o ? !1 : s ? o ? Sr(s, o, d) : !0 : !!o;
  return !1;
}
function Sr(e, t, n) {
  const s = Object.keys(t);
  if (s.length !== Object.keys(e).length)
    return !0;
  for (let r = 0; r < s.length; r++) {
    const i = s[r];
    if (Di(t, e, i) && !Qn(n, i))
      return !0;
  }
  return !1;
}
function Di(e, t, n) {
  const s = e[n], r = t[n];
  return n === "style" && de(s) && de(r) ? !Ft(s, r) : s !== r;
}
function Ya({ vnode: e, parent: t, suspense: n }, s) {
  for (; t; ) {
    const r = t.subTree;
    if (r.suspense && r.suspense.activeBranch === e && (r.suspense.vnode.el = r.el = s, e = r), r === e)
      (e = t.vnode).el = s, t = t.parent;
    else
      break;
  }
  n && n.activeBranch === e && (n.vnode.el = s);
}
const Fi = {}, Ki = () => Object.create(Fi), Li = (e) => Object.getPrototypeOf(e) === Fi;
function Xa(e, t, n, s = !1) {
  const r = {}, i = Ki();
  e.propsDefaults = /* @__PURE__ */ Object.create(null), Ui(e, t, r, i);
  for (const o in e.propsOptions[0])
    o in r || (r[o] = void 0);
  n ? e.props = s ? r : /* @__PURE__ */ sa(r) : e.type.props ? e.props = r : e.props = i, e.attrs = i;
}
function Qa(e, t, n, s) {
  const {
    props: r,
    attrs: i,
    vnode: { patchFlag: o }
  } = e, a = /* @__PURE__ */ fe(r), [l] = e.propsOptions;
  let d = !1;
  if (
    // always force full diff in dev
    // - #1942 if hmr is enabled with sfc component
    // - vite#872 non-sfc component used by sfc component
    (s || o > 0) && !(o & 16)
  ) {
    if (o & 8) {
      const u = e.vnode.dynamicProps;
      for (let h = 0; h < u.length; h++) {
        let m = u[h];
        if (Qn(e.emitsOptions, m))
          continue;
        const k = t[m];
        if (l)
          if (ce(i, m))
            k !== i[m] && (i[m] = k, d = !0);
          else {
            const I = xe(m);
            r[I] = As(
              l,
              a,
              I,
              k,
              e,
              !1
            );
          }
        else
          k !== i[m] && (i[m] = k, d = !0);
      }
    }
  } else {
    Ui(e, t, r, i) && (d = !0);
    let u;
    for (const h in a)
      (!t || // for camelCase
      !ce(t, h) && // it's possible the original props was passed in as kebab-case
      // and converted to camelCase (#955)
      ((u = Xe(h)) === h || !ce(t, u))) && (l ? n && // for camelCase
      (n[h] !== void 0 || // for kebab-case
      n[u] !== void 0) && (r[h] = As(
        l,
        a,
        h,
        void 0,
        e,
        !0
      )) : delete r[h]);
    if (i !== a)
      for (const h in i)
        (!t || !ce(t, h)) && (delete i[h], d = !0);
  }
  d && bt(e.attrs, "set", "");
}
function Ui(e, t, n, s) {
  const [r, i] = e.propsOptions;
  let o = !1, a;
  if (t)
    for (let l in t) {
      if (sn(l))
        continue;
      const d = t[l];
      let u;
      r && ce(r, u = xe(l)) ? !i || !i.includes(u) ? n[u] = d : (a || (a = {}))[u] = d : Qn(e.emitsOptions, l) || (!(l in s) || d !== s[l]) && (s[l] = d, o = !0);
    }
  if (i) {
    const l = /* @__PURE__ */ fe(n), d = a || ge;
    for (let u = 0; u < i.length; u++) {
      const h = i[u];
      n[h] = As(
        r,
        l,
        h,
        d[h],
        e,
        !ce(d, h)
      );
    }
  }
  return o;
}
function As(e, t, n, s, r, i) {
  const o = e[n];
  if (o != null) {
    const a = ce(o, "default");
    if (a && s === void 0) {
      const l = o.default;
      if (o.type !== Function && !o.skipFactory && ee(l)) {
        const { propsDefaults: d } = r;
        if (n in d)
          s = d[n];
        else {
          const u = Sn(r);
          s = d[n] = l.call(
            null,
            t
          ), u();
        }
      } else
        s = l;
      r.ce && r.ce._setProp(n, s);
    }
    o[
      0
      /* shouldCast */
    ] && (i && !a ? s = !1 : o[
      1
      /* shouldCastTrue */
    ] && (s === "" || s === Xe(n)) && (s = !0));
  }
  return s;
}
const Za = /* @__PURE__ */ new WeakMap();
function Vi(e, t, n = !1) {
  const s = n ? Za : t.propsCache, r = s.get(e);
  if (r)
    return r;
  const i = e.props, o = {}, a = [];
  let l = !1;
  if (!ee(e)) {
    const u = (h) => {
      l = !0;
      const [m, k] = Vi(h, t, !0);
      we(o, m), k && a.push(...k);
    };
    !n && t.mixins.length && t.mixins.forEach(u), e.extends && u(e.extends), e.mixins && e.mixins.forEach(u);
  }
  if (!i && !l)
    return de(e) && s.set(e, Ht), Ht;
  if (W(i))
    for (let u = 0; u < i.length; u++) {
      const h = xe(i[u]);
      wr(h) && (o[h] = ge);
    }
  else if (i)
    for (const u in i) {
      const h = xe(u);
      if (wr(h)) {
        const m = i[u], k = o[h] = W(m) || ee(m) ? { type: m } : we({}, m), I = k.type;
        let y = !1, z = !0;
        if (W(I))
          for (let J = 0; J < I.length; ++J) {
            const S = I[J], j = ee(S) && S.name;
            if (j === "Boolean") {
              y = !0;
              break;
            } else j === "String" && (z = !1);
          }
        else
          y = ee(I) && I.name === "Boolean";
        k[
          0
          /* shouldCast */
        ] = y, k[
          1
          /* shouldCastTrue */
        ] = z, (y || ce(k, "default")) && a.push(h);
      }
    }
  const d = [o, a];
  return de(e) && s.set(e, d), d;
}
function wr(e) {
  return e[0] !== "$" && !sn(e);
}
const zs = (e) => e === "_" || e === "_ctx" || e === "$stable", Js = (e) => W(e) ? e.map(ct) : [ct(e)], el = (e, t, n) => {
  if (t._n)
    return t;
  const s = qn((...r) => Js(t(...r)), n);
  return s._c = !1, s;
}, Hi = (e, t, n) => {
  const s = e._ctx;
  for (const r in e) {
    if (zs(r)) continue;
    const i = e[r];
    if (ee(i))
      t[r] = el(r, i, s);
    else if (i != null) {
      const o = Js(i);
      t[r] = () => o;
    }
  }
}, Bi = (e, t) => {
  const n = Js(t);
  e.slots.default = () => n;
}, Wi = (e, t, n) => {
  for (const s in t)
    (n || !zs(s)) && (e[s] = t[s]);
}, tl = (e, t, n) => {
  const s = e.slots = Ki();
  if (e.vnode.shapeFlag & 32) {
    const r = t._;
    r ? (Wi(s, t, n), n && ti(s, "_", r, !0)) : Hi(t, s);
  } else t && Bi(e, t);
}, nl = (e, t, n) => {
  const { vnode: s, slots: r } = e;
  let i = !0, o = ge;
  if (s.shapeFlag & 32) {
    const a = t._;
    a ? n && a === 1 ? i = !1 : Wi(r, t, n) : (i = !t.$stable, Hi(t, r)), o = t;
  } else t && (Bi(e, t), o = { default: 1 });
  if (i)
    for (const a in r)
      !zs(a) && o[a] == null && delete r[a];
}, Ne = al;
function sl(e) {
  return rl(e);
}
function rl(e, t) {
  const n = zn();
  n.__VUE__ = !0;
  const {
    insert: s,
    remove: r,
    patchProp: i,
    createElement: o,
    createText: a,
    createComment: l,
    setText: d,
    setElementText: u,
    parentNode: h,
    nextSibling: m,
    setScopeId: k = ft,
    insertStaticContent: I
  } = e, y = (c, f, g, w = null, A = null, P = null, N = void 0, M = null, O = !!f.dynamicChildren) => {
    if (c === f)
      return;
    c && !en(c, f) && (w = v(c), _e(c, A, P, !0), c = null), f.patchFlag === -2 && (O = !1, f.dynamicChildren = null);
    const { type: C, ref: V, shapeFlag: F } = f;
    switch (C) {
      case Zn:
        z(c, f, g, w);
        break;
      case xt:
        J(c, f, g, w);
        break;
      case ls:
        c == null && S(f, g, w, N);
        break;
      case be:
        ne(
          c,
          f,
          g,
          w,
          A,
          P,
          N,
          M,
          O
        );
        break;
      default:
        F & 1 ? K(
          c,
          f,
          g,
          w,
          A,
          P,
          N,
          M,
          O
        ) : F & 6 ? he(
          c,
          f,
          g,
          w,
          A,
          P,
          N,
          M,
          O
        ) : (F & 64 || F & 128) && C.process(
          c,
          f,
          g,
          w,
          A,
          P,
          N,
          M,
          O,
          b
        );
    }
    V != null && A ? an(V, c && c.ref, P, f || c, !f) : V == null && c && c.ref != null && an(c.ref, null, P, c, !0);
  }, z = (c, f, g, w) => {
    if (c == null)
      s(
        f.el = a(f.children),
        g,
        w
      );
    else {
      const A = f.el = c.el;
      f.children !== c.children && d(A, f.children);
    }
  }, J = (c, f, g, w) => {
    c == null ? s(
      f.el = l(f.children || ""),
      g,
      w
    ) : f.el = c.el;
  }, S = (c, f, g, w) => {
    [c.el, c.anchor] = I(
      c.children,
      f,
      g,
      w,
      c.el,
      c.anchor
    );
  }, j = ({ el: c, anchor: f }, g, w) => {
    let A;
    for (; c && c !== f; )
      A = m(c), s(c, g, w), c = A;
    s(f, g, w);
  }, R = ({ el: c, anchor: f }) => {
    let g;
    for (; c && c !== f; )
      g = m(c), r(c), c = g;
    r(f);
  }, K = (c, f, g, w, A, P, N, M, O) => {
    if (f.type === "svg" ? N = "svg" : f.type === "math" && (N = "mathml"), c == null)
      _(
        f,
        g,
        w,
        A,
        P,
        N,
        M,
        O
      );
    else {
      const C = c.el && c.el._isVueCE ? c.el : null;
      try {
        C && C._beginPatch(), L(
          c,
          f,
          A,
          P,
          N,
          M,
          O
        );
      } finally {
        C && C._endPatch();
      }
    }
  }, _ = (c, f, g, w, A, P, N, M) => {
    let O, C;
    const { props: V, shapeFlag: F, transition: B, dirs: Y } = c;
    if (O = c.el = o(
      c.type,
      P,
      V && V.is,
      V
    ), F & 8 ? u(O, c.children) : F & 16 && H(
      c.children,
      O,
      null,
      w,
      A,
      as(c, P),
      N,
      M
    ), Y && Mt(c, null, w, "created"), E(O, c, c.scopeId, N, w), V) {
      for (const pe in V)
        pe !== "value" && !sn(pe) && i(O, pe, null, V[pe], P, w);
      "value" in V && i(O, "value", null, V.value, P), (C = V.onVnodeBeforeMount) && ot(C, w, c);
    }
    Y && Mt(c, null, w, "beforeMount");
    const ae = il(A, B);
    ae && B.beforeEnter(O), s(O, f, g), ((C = V && V.onVnodeMounted) || ae || Y) && Ne(() => {
      try {
        C && ot(C, w, c), ae && B.enter(O), Y && Mt(c, null, w, "mounted");
      } finally {
      }
    }, A);
  }, E = (c, f, g, w, A) => {
    if (g && k(c, g), w)
      for (let P = 0; P < w.length; P++)
        k(c, w[P]);
    if (A) {
      let P = A.subTree;
      if (f === P || Yi(P.type) && (P.ssContent === f || P.ssFallback === f)) {
        const N = A.vnode;
        E(
          c,
          N,
          N.scopeId,
          N.slotScopeIds,
          A.parent
        );
      }
    }
  }, H = (c, f, g, w, A, P, N, M, O = 0) => {
    for (let C = O; C < c.length; C++) {
      const V = c[C] = M ? yt(c[C]) : ct(c[C]);
      y(
        null,
        V,
        f,
        g,
        w,
        A,
        P,
        N,
        M
      );
    }
  }, L = (c, f, g, w, A, P, N) => {
    const M = f.el = c.el;
    let { patchFlag: O, dynamicChildren: C, dirs: V } = f;
    O |= c.patchFlag & 16;
    const F = c.props || ge, B = f.props || ge;
    let Y;
    if (g && Ot(g, !1), (Y = B.onVnodeBeforeUpdate) && ot(Y, g, f, c), V && Mt(f, c, g, "beforeUpdate"), g && Ot(g, !0), (F.innerHTML && B.innerHTML == null || F.textContent && B.textContent == null) && u(M, ""), C ? U(
      c.dynamicChildren,
      C,
      M,
      g,
      w,
      as(f, A),
      P
    ) : N || se(
      c,
      f,
      M,
      null,
      g,
      w,
      as(f, A),
      P,
      !1
    ), O > 0) {
      if (O & 16)
        ie(M, F, B, g, A);
      else if (O & 2 && F.class !== B.class && i(M, "class", null, B.class, A), O & 4 && i(M, "style", F.style, B.style, A), O & 8) {
        const ae = f.dynamicProps;
        for (let pe = 0; pe < ae.length; pe++) {
          const me = ae[pe], Ie = F[me], ke = B[me];
          (ke !== Ie || me === "value") && i(M, me, Ie, ke, A, g);
        }
      }
      O & 1 && c.children !== f.children && u(M, f.children);
    } else !N && C == null && ie(M, F, B, g, A);
    ((Y = B.onVnodeUpdated) || V) && Ne(() => {
      Y && ot(Y, g, f, c), V && Mt(f, c, g, "updated");
    }, w);
  }, U = (c, f, g, w, A, P, N) => {
    for (let M = 0; M < f.length; M++) {
      const O = c[M], C = f[M], V = (
        // oldVNode may be an errored async setup() component inside Suspense
        // which will not have a mounted element
        O.el && // - In the case of a Fragment, we need to provide the actual parent
        // of the Fragment itself so it can move its children.
        (O.type === be || // - In the case of different nodes, there is going to be a replacement
        // which also requires the correct parent container
        !en(O, C) || // - In the case of a component, it could contain anything.
        O.shapeFlag & 198) ? h(O.el) : (
          // In other cases, the parent container is not actually used so we
          // just pass the block element here to avoid a DOM parentNode call.
          g
        )
      );
      y(
        O,
        C,
        V,
        null,
        w,
        A,
        P,
        N,
        !0
      );
    }
  }, ie = (c, f, g, w, A) => {
    if (f !== g) {
      if (f !== ge)
        for (const P in f)
          !sn(P) && !(P in g) && i(
            c,
            P,
            f[P],
            null,
            A,
            w
          );
      for (const P in g) {
        if (sn(P)) continue;
        const N = g[P], M = f[P];
        N !== M && P !== "value" && i(c, P, M, N, A, w);
      }
      "value" in g && i(c, "value", f.value, g.value, A);
    }
  }, ne = (c, f, g, w, A, P, N, M, O) => {
    const C = f.el = c ? c.el : a(""), V = f.anchor = c ? c.anchor : a("");
    let { patchFlag: F, dynamicChildren: B, slotScopeIds: Y } = f;
    Y && (M = M ? M.concat(Y) : Y), c == null ? (s(C, g, w), s(V, g, w), H(
      // #10007
      // such fragment like `<></>` will be compiled into
      // a fragment which doesn't have a children.
      // In this case fallback to an empty array
      f.children || [],
      g,
      V,
      A,
      P,
      N,
      M,
      O
    )) : F > 0 && F & 64 && B && // #2715 the previous fragment could've been a BAILed one as a result
    // of renderSlot() with no valid children
    c.dynamicChildren && c.dynamicChildren.length === B.length ? (U(
      c.dynamicChildren,
      B,
      g,
      A,
      P,
      N,
      M
    ), // #2080 if the stable fragment has a key, it's a <template v-for> that may
    //  get moved around. Make sure all root level vnodes inherit el.
    // #2134 or if it's a component root, it may also get moved around
    // as the component is being moved.
    (f.key != null || A && f === A.subTree) && zi(
      c,
      f,
      !0
      /* shallow */
    )) : se(
      c,
      f,
      g,
      V,
      A,
      P,
      N,
      M,
      O
    );
  }, he = (c, f, g, w, A, P, N, M, O) => {
    f.slotScopeIds = M, c == null ? f.shapeFlag & 512 ? A.ctx.activate(
      f,
      g,
      w,
      N,
      O
    ) : te(
      f,
      g,
      w,
      A,
      P,
      N,
      O
    ) : re(c, f, O);
  }, te = (c, f, g, w, A, P, N) => {
    const M = c.component = dl(
      c,
      w,
      A
    );
    if (Ti(c) && (M.ctx.renderer = b), pl(M, !1, N), M.asyncDep) {
      if (A && A.registerDep(M, ue, N), !c.el) {
        const O = M.subTree = Pe(xt);
        J(null, O, f, g), c.placeholder = O.el;
      }
    } else
      ue(
        M,
        c,
        f,
        g,
        A,
        P,
        N
      );
  }, re = (c, f, g) => {
    const w = f.component = c.component;
    if (Ga(c, f, g))
      if (w.asyncDep && !w.asyncResolved) {
        oe(w, f, g);
        return;
      } else
        w.next = f, w.update();
    else
      f.el = c.el, w.vnode = f;
  }, ue = (c, f, g, w, A, P, N) => {
    const M = () => {
      if (c.isMounted) {
        let { next: F, bu: B, u: Y, parent: ae, vnode: pe } = c;
        {
          const rt = Ji(c);
          if (rt) {
            F && (F.el = pe.el, oe(c, F, N)), rt.asyncDep.then(() => {
              Ne(() => {
                c.isUnmounted || C();
              }, A);
            });
            return;
          }
        }
        let me = F, Ie;
        Ot(c, !1), F ? (F.el = pe.el, oe(c, F, N)) : F = pe, B && En(B), (Ie = F.props && F.props.onVnodeBeforeUpdate) && ot(Ie, ae, F, pe), Ot(c, !0);
        const ke = vr(c), st = c.subTree;
        c.subTree = ke, y(
          st,
          ke,
          // parent may have changed if it's in a teleport
          h(st.el),
          // anchor may have changed if it's in a fragment
          v(st),
          c,
          A,
          P
        ), F.el = ke.el, me === null && Ya(c, ke.el), Y && Ne(Y, A), (Ie = F.props && F.props.onVnodeUpdated) && Ne(
          () => ot(Ie, ae, F, pe),
          A
        );
      } else {
        let F;
        const { el: B, props: Y } = f, { bm: ae, m: pe, parent: me, root: Ie, type: ke } = c, st = zt(f);
        Ot(c, !1), ae && En(ae), !st && (F = Y && Y.onVnodeBeforeMount) && ot(F, me, f), Ot(c, !0);
        {
          Ie.ce && Ie.ce._hasShadowRoot() && Ie.ce._injectChildStyle(
            ke,
            c.parent ? c.parent.type : void 0
          );
          const rt = c.subTree = vr(c);
          y(
            null,
            rt,
            g,
            w,
            c,
            A,
            P
          ), f.el = rt.el;
        }
        if (pe && Ne(pe, A), !st && (F = Y && Y.onVnodeMounted)) {
          const rt = f;
          Ne(
            () => ot(F, me, rt),
            A
          );
        }
        (f.shapeFlag & 256 || me && zt(me.vnode) && me.vnode.shapeFlag & 256) && c.a && Ne(c.a, A), c.isMounted = !0, f = g = w = null;
      }
    };
    c.scope.on();
    const O = c.effect = new oi(M);
    c.scope.off();
    const C = c.update = O.run.bind(O), V = c.job = O.runIfDirty.bind(O);
    V.i = c, V.id = c.uid, O.scheduler = () => Vs(V), Ot(c, !0), C();
  }, oe = (c, f, g) => {
    f.component = c;
    const w = c.vnode.props;
    c.vnode = f, c.next = null, Qa(c, f.props, w, g), nl(c, f.children, g), wt(), dr(c), It();
  }, se = (c, f, g, w, A, P, N, M, O = !1) => {
    const C = c && c.children, V = c ? c.shapeFlag : 0, F = f.children, { patchFlag: B, shapeFlag: Y } = f;
    if (B > 0) {
      if (B & 128) {
        Je(
          C,
          F,
          g,
          w,
          A,
          P,
          N,
          M,
          O
        );
        return;
      } else if (B & 256) {
        Ce(
          C,
          F,
          g,
          w,
          A,
          P,
          N,
          M,
          O
        );
        return;
      }
    }
    Y & 8 ? (V & 16 && Q(C, A, P), F !== C && u(g, F)) : V & 16 ? Y & 16 ? Je(
      C,
      F,
      g,
      w,
      A,
      P,
      N,
      M,
      O
    ) : Q(C, A, P, !0) : (V & 8 && u(g, ""), Y & 16 && H(
      F,
      g,
      w,
      A,
      P,
      N,
      M,
      O
    ));
  }, Ce = (c, f, g, w, A, P, N, M, O) => {
    c = c || Ht, f = f || Ht;
    const C = c.length, V = f.length, F = Math.min(C, V);
    let B;
    for (B = 0; B < F; B++) {
      const Y = f[B] = O ? yt(f[B]) : ct(f[B]);
      y(
        c[B],
        Y,
        g,
        null,
        A,
        P,
        N,
        M,
        O
      );
    }
    C > V ? Q(
      c,
      A,
      P,
      !0,
      !1,
      F
    ) : H(
      f,
      g,
      w,
      A,
      P,
      N,
      M,
      O,
      F
    );
  }, Je = (c, f, g, w, A, P, N, M, O) => {
    let C = 0;
    const V = f.length;
    let F = c.length - 1, B = V - 1;
    for (; C <= F && C <= B; ) {
      const Y = c[C], ae = f[C] = O ? yt(f[C]) : ct(f[C]);
      if (en(Y, ae))
        y(
          Y,
          ae,
          g,
          null,
          A,
          P,
          N,
          M,
          O
        );
      else
        break;
      C++;
    }
    for (; C <= F && C <= B; ) {
      const Y = c[F], ae = f[B] = O ? yt(f[B]) : ct(f[B]);
      if (en(Y, ae))
        y(
          Y,
          ae,
          g,
          null,
          A,
          P,
          N,
          M,
          O
        );
      else
        break;
      F--, B--;
    }
    if (C > F) {
      if (C <= B) {
        const Y = B + 1, ae = Y < V ? f[Y].el : w;
        for (; C <= B; )
          y(
            null,
            f[C] = O ? yt(f[C]) : ct(f[C]),
            g,
            ae,
            A,
            P,
            N,
            M,
            O
          ), C++;
      }
    } else if (C > B)
      for (; C <= F; )
        _e(c[C], A, P, !0), C++;
    else {
      const Y = C, ae = C, pe = /* @__PURE__ */ new Map();
      for (C = ae; C <= B; C++) {
        const Ue = f[C] = O ? yt(f[C]) : ct(f[C]);
        Ue.key != null && pe.set(Ue.key, C);
      }
      let me, Ie = 0;
      const ke = B - ae + 1;
      let st = !1, rt = 0;
      const Qt = new Array(ke);
      for (C = 0; C < ke; C++) Qt[C] = 0;
      for (C = Y; C <= F; C++) {
        const Ue = c[C];
        if (Ie >= ke) {
          _e(Ue, A, P, !0);
          continue;
        }
        let it;
        if (Ue.key != null)
          it = pe.get(Ue.key);
        else
          for (me = ae; me <= B; me++)
            if (Qt[me - ae] === 0 && en(Ue, f[me])) {
              it = me;
              break;
            }
        it === void 0 ? _e(Ue, A, P, !0) : (Qt[it - ae] = C + 1, it >= rt ? rt = it : st = !0, y(
          Ue,
          f[it],
          g,
          null,
          A,
          P,
          N,
          M,
          O
        ), Ie++);
      }
      const rr = st ? ol(Qt) : Ht;
      for (me = rr.length - 1, C = ke - 1; C >= 0; C--) {
        const Ue = ae + C, it = f[Ue], ir = f[Ue + 1], or = Ue + 1 < V ? (
          // #13559, #14173 fallback to el placeholder for unresolved async component
          ir.el || Gi(ir)
        ) : w;
        Qt[C] === 0 ? y(
          null,
          it,
          g,
          or,
          A,
          P,
          N,
          M,
          O
        ) : st && (me < 0 || C !== rr[me] ? Le(it, g, or, 2) : me--);
      }
    }
  }, Le = (c, f, g, w, A = null) => {
    const { el: P, type: N, transition: M, children: O, shapeFlag: C } = c;
    if (C & 6) {
      Le(c.component.subTree, f, g, w);
      return;
    }
    if (C & 128) {
      c.suspense.move(f, g, w);
      return;
    }
    if (C & 64) {
      N.move(c, f, g, b);
      return;
    }
    if (N === be) {
      s(P, f, g);
      for (let F = 0; F < O.length; F++)
        Le(O[F], f, g, w);
      s(c.anchor, f, g);
      return;
    }
    if (N === ls) {
      j(c, f, g);
      return;
    }
    if (w !== 2 && C & 1 && M)
      if (w === 0)
        M.beforeEnter(P), s(P, f, g), Ne(() => M.enter(P), A);
      else {
        const { leave: F, delayLeave: B, afterLeave: Y } = M, ae = () => {
          c.ctx.isUnmounted ? r(P) : s(P, f, g);
        }, pe = () => {
          P._isLeaving && P[Sa](
            !0
            /* cancelled */
          ), F(P, () => {
            ae(), Y && Y();
          });
        };
        B ? B(P, ae, pe) : pe();
      }
    else
      s(P, f, g);
  }, _e = (c, f, g, w = !1, A = !1) => {
    const {
      type: P,
      props: N,
      ref: M,
      children: O,
      dynamicChildren: C,
      shapeFlag: V,
      patchFlag: F,
      dirs: B,
      cacheIndex: Y,
      memo: ae
    } = c;
    if (F === -2 && (A = !1), M != null && (wt(), an(M, null, g, c, !0), It()), Y != null && (f.renderCache[Y] = void 0), V & 256) {
      f.ctx.deactivate(c);
      return;
    }
    const pe = V & 1 && B, me = !zt(c);
    let Ie;
    if (me && (Ie = N && N.onVnodeBeforeUnmount) && ot(Ie, f, c), V & 6)
      q(c.component, g, w);
    else {
      if (V & 128) {
        c.suspense.unmount(g, w);
        return;
      }
      pe && Mt(c, null, f, "beforeUnmount"), V & 64 ? c.type.remove(
        c,
        f,
        g,
        b,
        w
      ) : C && // #5154
      // when v-once is used inside a block, setBlockTracking(-1) marks the
      // parent block with hasOnce: true
      // so that it doesn't take the fast path during unmount - otherwise
      // components nested in v-once are never unmounted.
      !C.hasOnce && // #1153: fast path should not be taken for non-stable (v-for) fragments
      (P !== be || F > 0 && F & 64) ? Q(
        C,
        f,
        g,
        !1,
        !0
      ) : (P === be && F & 384 || !A && V & 16) && Q(O, f, g), w && nt(c);
    }
    const ke = ae != null && Y == null;
    (me && (Ie = N && N.onVnodeUnmounted) || pe || ke) && Ne(() => {
      Ie && ot(Ie, f, c), pe && Mt(c, null, f, "unmounted"), ke && (c.el = null);
    }, g);
  }, nt = (c) => {
    const { type: f, el: g, anchor: w, transition: A } = c;
    if (f === be) {
      kt(g, w);
      return;
    }
    if (f === ls) {
      R(c);
      return;
    }
    const P = () => {
      r(g), A && !A.persisted && A.afterLeave && A.afterLeave();
    };
    if (c.shapeFlag & 1 && A && !A.persisted) {
      const { leave: N, delayLeave: M } = A, O = () => N(g, P);
      M ? M(c.el, P, O) : O();
    } else
      P();
  }, kt = (c, f) => {
    let g;
    for (; c !== f; )
      g = m(c), r(c), c = g;
    r(f);
  }, q = (c, f, g) => {
    const { bum: w, scope: A, job: P, subTree: N, um: M, m: O, a: C } = c;
    Ir(O), Ir(C), w && En(w), A.stop(), P && (P.flags |= 8, _e(N, c, f, g)), M && Ne(M, f), Ne(() => {
      c.isUnmounted = !0;
    }, f);
  }, Q = (c, f, g, w = !1, A = !1, P = 0) => {
    for (let N = P; N < c.length; N++)
      _e(c[N], f, g, w, A);
  }, v = (c) => {
    if (c.shapeFlag & 6)
      return v(c.component.subTree);
    if (c.shapeFlag & 128)
      return c.suspense.next();
    const f = m(c.anchor || c.el), g = f && f[_a];
    return g ? m(g) : f;
  };
  let x = !1;
  const G = (c, f, g) => {
    let w;
    c == null ? f._vnode && (_e(f._vnode, null, null, !0), w = f._vnode.component) : y(
      f._vnode || null,
      c,
      f,
      null,
      null,
      null,
      g
    ), f._vnode = c, x || (x = !0, dr(w), Ii(), x = !1);
  }, b = {
    p: y,
    um: _e,
    m: Le,
    r: nt,
    mt: te,
    mc: H,
    pc: se,
    pbc: U,
    n: v,
    o: e
  };
  return {
    render: G,
    hydrate: void 0,
    createApp: Va(G)
  };
}
function as({ type: e, props: t }, n) {
  return n === "svg" && e === "foreignObject" || n === "mathml" && e === "annotation-xml" && t && t.encoding && t.encoding.includes("html") ? void 0 : n;
}
function Ot({ effect: e, job: t }, n) {
  n ? (e.flags |= 32, t.flags |= 4) : (e.flags &= -33, t.flags &= -5);
}
function il(e, t) {
  return (!e || e && !e.pendingBranch) && t && !t.persisted;
}
function zi(e, t, n = !1) {
  const s = e.children, r = t.children;
  if (W(s) && W(r))
    for (let i = 0; i < s.length; i++) {
      const o = s[i];
      let a = r[i];
      a.shapeFlag & 1 && !a.dynamicChildren && ((a.patchFlag <= 0 || a.patchFlag === 32) && (a = r[i] = yt(r[i]), a.el = o.el), !n && a.patchFlag !== -2 && zi(o, a)), a.type === Zn && (a.patchFlag === -1 && (a = r[i] = yt(a)), a.el = o.el), a.type === xt && !a.el && (a.el = o.el);
    }
}
function ol(e) {
  const t = e.slice(), n = [0];
  let s, r, i, o, a;
  const l = e.length;
  for (s = 0; s < l; s++) {
    const d = e[s];
    if (d !== 0) {
      if (r = n[n.length - 1], e[r] < d) {
        t[s] = r, n.push(s);
        continue;
      }
      for (i = 0, o = n.length - 1; i < o; )
        a = i + o >> 1, e[n[a]] < d ? i = a + 1 : o = a;
      d < e[n[i]] && (i > 0 && (t[s] = n[i - 1]), n[i] = s);
    }
  }
  for (i = n.length, o = n[i - 1]; i-- > 0; )
    n[i] = o, o = t[o];
  return n;
}
function Ji(e) {
  const t = e.subTree.component;
  if (t)
    return t.asyncDep && !t.asyncResolved ? t : Ji(t);
}
function Ir(e) {
  if (e)
    for (let t = 0; t < e.length; t++)
      e[t].flags |= 8;
}
function Gi(e) {
  if (e.placeholder)
    return e.placeholder;
  const t = e.component;
  return t ? Gi(t.subTree) : null;
}
const Yi = (e) => e.__isSuspense;
function al(e, t) {
  t && t.pendingBranch ? W(e) ? t.effects.push(...e) : t.effects.push(e) : pa(e);
}
const be = /* @__PURE__ */ Symbol.for("v-fgt"), Zn = /* @__PURE__ */ Symbol.for("v-txt"), xt = /* @__PURE__ */ Symbol.for("v-cmt"), ls = /* @__PURE__ */ Symbol.for("v-stc"), cn = [];
let We = null;
function T(e = !1) {
  cn.push(We = e ? null : []);
}
function ll() {
  cn.pop(), We = cn[cn.length - 1] || null;
}
let pn = 1;
function Dn(e, t = !1) {
  pn += e, e < 0 && We && t && (We.hasOnce = !0);
}
function Xi(e) {
  return e.dynamicChildren = pn > 0 ? We || Ht : null, ll(), pn > 0 && We && We.push(e), e;
}
function $(e, t, n, s, r, i) {
  return Xi(
    D(
      e,
      t,
      n,
      s,
      r,
      i,
      !0
    )
  );
}
function pt(e, t, n, s, r) {
  return Xi(
    Pe(
      e,
      t,
      n,
      s,
      r,
      !0
    )
  );
}
function gn(e) {
  return e ? e.__v_isVNode === !0 : !1;
}
function en(e, t) {
  return e.type === t.type && e.key === t.key;
}
const Qi = ({ key: e }) => e ?? null, Pn = ({
  ref: e,
  ref_key: t,
  ref_for: n
}) => (typeof e == "number" && (e = "" + e), e != null ? Se(e) || /* @__PURE__ */ Oe(e) || ee(e) ? { i: Te, r: e, k: t, f: !!n } : e : null);
function D(e, t = null, n = null, s = 0, r = null, i = e === be ? 0 : 1, o = !1, a = !1) {
  const l = {
    __v_isVNode: !0,
    __v_skip: !0,
    type: e,
    props: t,
    key: t && Qi(t),
    ref: t && Pn(t),
    scopeId: xi,
    slotScopeIds: null,
    children: n,
    component: null,
    suspense: null,
    ssContent: null,
    ssFallback: null,
    dirs: null,
    transition: null,
    el: null,
    anchor: null,
    target: null,
    targetStart: null,
    targetAnchor: null,
    staticCount: 0,
    shapeFlag: i,
    patchFlag: s,
    dynamicProps: r,
    dynamicChildren: null,
    appContext: null,
    ctx: Te
  };
  return a ? (Gs(l, n), i & 128 && e.normalize(l)) : n && (l.shapeFlag |= Se(n) ? 8 : 16), pn > 0 && // avoid a block node from tracking itself
  !o && // has current parent block
  We && // presence of a patch flag indicates this node needs patching on updates.
  // component nodes also should always be patched, because even if the
  // component doesn't need to update, it needs to persist the instance on to
  // the next vnode so that it can be properly unmounted later.
  (l.patchFlag > 0 || i & 6) && // the EVENTS flag is only for hydration and if it is the only flag, the
  // vnode should not be considered dynamic due to handler caching.
  l.patchFlag !== 32 && We.push(l), l;
}
const Pe = cl;
function cl(e, t = null, n = null, s = 0, r = null, i = !1) {
  if ((!e || e === Ri) && (e = xt), gn(e)) {
    const a = Yt(
      e,
      t,
      !0
      /* mergeRef: true */
    );
    return n && Gs(a, n), pn > 0 && !i && We && (a.shapeFlag & 6 ? We[We.indexOf(e)] = a : We.push(a)), a.patchFlag = -2, a;
  }
  if (_l(e) && (e = e.__vccOpts), t) {
    t = Zi(t);
    let { class: a, style: l } = t;
    a && !Se(a) && (t.class = Ke(a)), de(l) && (/* @__PURE__ */ Ks(l) && !W(l) && (l = we({}, l)), t.style = _n(l));
  }
  const o = Se(e) ? 1 : Yi(e) ? 128 : va(e) ? 64 : de(e) ? 4 : ee(e) ? 2 : 0;
  return D(
    e,
    t,
    n,
    s,
    r,
    o,
    i,
    !0
  );
}
function Zi(e) {
  return e ? /* @__PURE__ */ Ks(e) || Li(e) ? we({}, e) : e : null;
}
function Yt(e, t, n = !1, s = !1) {
  const { props: r, ref: i, patchFlag: o, children: a, transition: l } = e, d = t ? eo(r || {}, t) : r, u = {
    __v_isVNode: !0,
    __v_skip: !0,
    type: e.type,
    props: d,
    key: d && Qi(d),
    ref: t && t.ref ? (
      // #2078 in the case of <component :is="vnode" ref="extra"/>
      // if the vnode itself already has a ref, cloneVNode will need to merge
      // the refs so the single vnode can be set on multiple refs
      n && i ? W(i) ? i.concat(Pn(t)) : [i, Pn(t)] : Pn(t)
    ) : i,
    scopeId: e.scopeId,
    slotScopeIds: e.slotScopeIds,
    children: a,
    target: e.target,
    targetStart: e.targetStart,
    targetAnchor: e.targetAnchor,
    staticCount: e.staticCount,
    shapeFlag: e.shapeFlag,
    // if the vnode is cloned with extra props, we can no longer assume its
    // existing patch flag to be reliable and need to add the FULL_PROPS flag.
    // note: preserve flag for fragments since they use the flag for children
    // fast paths only.
    patchFlag: t && e.type !== be ? o === -1 ? 16 : o | 16 : o,
    dynamicProps: e.dynamicProps,
    dynamicChildren: e.dynamicChildren,
    appContext: e.appContext,
    dirs: e.dirs,
    transition: l,
    // These should technically only be non-null on mounted VNodes. However,
    // they *should* be copied for kept-alive vnodes. So we just always copy
    // them since them being non-null during a mount doesn't affect the logic as
    // they will simply be overwritten.
    component: e.component,
    suspense: e.suspense,
    ssContent: e.ssContent && Yt(e.ssContent),
    ssFallback: e.ssFallback && Yt(e.ssFallback),
    placeholder: e.placeholder,
    el: e.el,
    anchor: e.anchor,
    ctx: e.ctx,
    ce: e.ce
  };
  return l && s && Hs(
    u,
    l.clone(u)
  ), u;
}
function mn(e = " ", t = 0) {
  return Pe(Zn, null, e, t);
}
function Z(e = "", t = !1) {
  return t ? (T(), pt(xt, null, e)) : Pe(xt, null, e);
}
function ct(e) {
  return e == null || typeof e == "boolean" ? Pe(xt) : W(e) ? Pe(
    be,
    null,
    // #3666, avoid reference pollution when reusing vnode
    e.slice()
  ) : gn(e) ? yt(e) : Pe(Zn, null, String(e));
}
function yt(e) {
  return e.el === null && e.patchFlag !== -1 || e.memo ? e : Yt(e);
}
function Gs(e, t) {
  let n = 0;
  const { shapeFlag: s } = e;
  if (t == null)
    t = null;
  else if (W(t))
    n = 16;
  else if (typeof t == "object")
    if (s & 65) {
      const r = t.default;
      r && (r._c && (r._d = !1), Gs(e, r()), r._c && (r._d = !0));
      return;
    } else {
      n = 32;
      const r = t._;
      !r && !Li(t) ? t._ctx = Te : r === 3 && Te && (Te.slots._ === 1 ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024));
    }
  else ee(t) ? (t = { default: t, _ctx: Te }, n = 32) : (t = String(t), s & 64 ? (n = 16, t = [mn(t)]) : n = 8);
  e.children = t, e.shapeFlag |= n;
}
function eo(...e) {
  const t = {};
  for (let n = 0; n < e.length; n++) {
    const s = e[n];
    for (const r in s)
      if (r === "class")
        t.class !== s.class && (t.class = Ke([t.class, s.class]));
      else if (r === "style")
        t.style = _n([t.style, s.style]);
      else if (Ln(r)) {
        const i = t[r], o = s[r];
        o && i !== o && !(W(i) && i.includes(o)) ? t[r] = i ? [].concat(i, o) : o : o == null && i == null && // mergeProps({ 'onUpdate:modelValue': undefined }) should not retain
        // the model listener.
        !Un(r) && (t[r] = o);
      } else r !== "" && (t[r] = s[r]);
  }
  return t;
}
function ot(e, t, n, s = null) {
  dt(e, t, 7, [
    n,
    s
  ]);
}
const ul = ji();
let fl = 0;
function dl(e, t, n) {
  const s = e.type, r = (t ? t.appContext : e.appContext) || ul, i = {
    uid: fl++,
    vnode: e,
    type: s,
    parent: t,
    appContext: r,
    root: null,
    // to be immediately set
    next: null,
    subTree: null,
    // will be set synchronously right after creation
    effect: null,
    update: null,
    // will be set synchronously right after creation
    job: null,
    scope: new No(
      !0
      /* detached */
    ),
    render: null,
    proxy: null,
    exposed: null,
    exposeProxy: null,
    withProxy: null,
    provides: t ? t.provides : Object.create(r.provides),
    ids: t ? t.ids : ["", 0, 0],
    accessCache: null,
    renderCache: [],
    // local resolved assets
    components: null,
    directives: null,
    // resolved props and emits options
    propsOptions: Vi(s, r),
    emitsOptions: Ni(s, r),
    // emit
    emit: null,
    // to be set immediately
    emitted: null,
    // props default value
    propsDefaults: ge,
    // inheritAttrs
    inheritAttrs: s.inheritAttrs,
    // state
    ctx: ge,
    data: ge,
    props: ge,
    attrs: ge,
    slots: ge,
    refs: ge,
    setupState: ge,
    setupContext: null,
    // suspense related
    suspense: n,
    suspenseId: n ? n.pendingId : 0,
    asyncDep: null,
    asyncResolved: !1,
    // lifecycle hooks
    // not using enums here because it results in computed properties
    isMounted: !1,
    isUnmounted: !1,
    isDeactivated: !1,
    bc: null,
    c: null,
    bm: null,
    m: null,
    bu: null,
    u: null,
    um: null,
    bum: null,
    da: null,
    a: null,
    rtg: null,
    rtc: null,
    ec: null,
    sp: null
  };
  return i.ctx = { _: i }, i.root = t ? t.root : i, i.emit = Ba.bind(null, i), e.ce && e.ce(i), i;
}
let Me = null;
const hl = () => Me || Te;
let Fn, xs;
{
  const e = zn(), t = (n, s) => {
    let r;
    return (r = e[n]) || (r = e[n] = []), r.push(s), (i) => {
      r.length > 1 ? r.forEach((o) => o(i)) : r[0](i);
    };
  };
  Fn = t(
    "__VUE_INSTANCE_SETTERS__",
    (n) => Me = n
  ), xs = t(
    "__VUE_SSR_SETTERS__",
    (n) => yn = n
  );
}
const Sn = (e) => {
  const t = Me;
  return Fn(e), e.scope.on(), () => {
    e.scope.off(), Fn(t);
  };
}, Ar = () => {
  Me && Me.scope.off(), Fn(null);
};
function to(e) {
  return e.vnode.shapeFlag & 4;
}
let yn = !1;
function pl(e, t = !1, n = !1) {
  t && xs(t);
  const { props: s, children: r } = e.vnode, i = to(e);
  Xa(e, s, i, t), tl(e, r, n || t);
  const o = i ? gl(e, t) : void 0;
  return t && xs(!1), o;
}
function gl(e, t) {
  const n = e.type;
  e.accessCache = /* @__PURE__ */ Object.create(null), e.proxy = new Proxy(e.ctx, ja);
  const { setup: s } = n;
  if (s) {
    wt();
    const r = e.setupContext = s.length > 1 ? yl(e) : null, i = Sn(e), o = vn(
      s,
      e,
      0,
      [
        e.props,
        r
      ]
    ), a = Zr(o);
    if (It(), i(), (a || e.sp) && !zt(e) && Ei(e), a) {
      if (o.then(Ar, Ar), t)
        return o.then((l) => {
          xr(e, l);
        }).catch((l) => {
          Yn(l, e, 0);
        });
      e.asyncDep = o;
    } else
      xr(e, o);
  } else
    no(e);
}
function xr(e, t, n) {
  ee(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : de(t) && (e.setupState = vi(t)), no(e);
}
function no(e, t, n) {
  const s = e.type;
  e.render || (e.render = s.render || ft);
  {
    const r = Sn(e);
    wt();
    try {
      Na(e);
    } finally {
      It(), r();
    }
  }
}
const ml = {
  get(e, t) {
    return $e(e, "get", ""), e[t];
  }
};
function yl(e) {
  const t = (n) => {
    e.exposed = n || {};
  };
  return {
    attrs: new Proxy(e.attrs, ml),
    slots: e.slots,
    emit: e.emit,
    expose: t
  };
}
function es(e) {
  return e.exposed ? e.exposeProxy || (e.exposeProxy = new Proxy(vi(ra(e.exposed)), {
    get(t, n) {
      if (n in t)
        return t[n];
      if (n in ln)
        return ln[n](e);
    },
    has(t, n) {
      return n in t || n in ln;
    }
  })) : e.proxy;
}
function bl(e, t = !0) {
  return ee(e) ? e.displayName || e.name : e.name || t && e.__name;
}
function _l(e) {
  return ee(e) && "__vccOpts" in e;
}
const le = (e, t) => /* @__PURE__ */ ca(e, t, yn);
function vl(e, t, n) {
  try {
    Dn(-1);
    const s = arguments.length;
    return s === 2 ? de(t) && !W(t) ? gn(t) ? Pe(e, null, [t]) : Pe(e, t) : Pe(e, null, t) : (s > 3 ? n = Array.prototype.slice.call(arguments, 2) : s === 3 && gn(n) && (n = [n]), Pe(e, t, n));
  } finally {
    Dn(1);
  }
}
const Sl = "3.5.31";
/**
* @vue/runtime-dom v3.5.31
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
let Cs;
const Cr = typeof window < "u" && window.trustedTypes;
if (Cr)
  try {
    Cs = /* @__PURE__ */ Cr.createPolicy("vue", {
      createHTML: (e) => e
    });
  } catch {
  }
const so = Cs ? (e) => Cs.createHTML(e) : (e) => e, wl = "http://www.w3.org/2000/svg", Il = "http://www.w3.org/1998/Math/MathML", mt = typeof document < "u" ? document : null, kr = mt && /* @__PURE__ */ mt.createElement("template"), Al = {
  insert: (e, t, n) => {
    t.insertBefore(e, n || null);
  },
  remove: (e) => {
    const t = e.parentNode;
    t && t.removeChild(e);
  },
  createElement: (e, t, n, s) => {
    const r = t === "svg" ? mt.createElementNS(wl, e) : t === "mathml" ? mt.createElementNS(Il, e) : n ? mt.createElement(e, { is: n }) : mt.createElement(e);
    return e === "select" && s && s.multiple != null && r.setAttribute("multiple", s.multiple), r;
  },
  createText: (e) => mt.createTextNode(e),
  createComment: (e) => mt.createComment(e),
  setText: (e, t) => {
    e.nodeValue = t;
  },
  setElementText: (e, t) => {
    e.textContent = t;
  },
  parentNode: (e) => e.parentNode,
  nextSibling: (e) => e.nextSibling,
  querySelector: (e) => mt.querySelector(e),
  setScopeId(e, t) {
    e.setAttribute(t, "");
  },
  // __UNSAFE__
  // Reason: innerHTML.
  // Static content here can only come from compiled templates.
  // As long as the user only uses trusted templates, this is safe.
  insertStaticContent(e, t, n, s, r, i) {
    const o = n ? n.previousSibling : t.lastChild;
    if (r && (r === i || r.nextSibling))
      for (; t.insertBefore(r.cloneNode(!0), n), !(r === i || !(r = r.nextSibling)); )
        ;
    else {
      kr.innerHTML = so(
        s === "svg" ? `<svg>${e}</svg>` : s === "mathml" ? `<math>${e}</math>` : e
      );
      const a = kr.content;
      if (s === "svg" || s === "mathml") {
        const l = a.firstChild;
        for (; l.firstChild; )
          a.appendChild(l.firstChild);
        a.removeChild(l);
      }
      t.insertBefore(a, n);
    }
    return [
      // first
      o ? o.nextSibling : t.firstChild,
      // last
      n ? n.previousSibling : t.lastChild
    ];
  }
}, xl = /* @__PURE__ */ Symbol("_vtc");
function Cl(e, t, n) {
  const s = e[xl];
  s && (t = (t ? [t, ...s] : [...s]).join(" ")), t == null ? e.removeAttribute("class") : n ? e.setAttribute("class", t) : e.className = t;
}
const Er = /* @__PURE__ */ Symbol("_vod"), kl = /* @__PURE__ */ Symbol("_vsh"), El = /* @__PURE__ */ Symbol(""), Tl = /(?:^|;)\s*display\s*:/;
function Pl(e, t, n) {
  const s = e.style, r = Se(n);
  let i = !1;
  if (n && !r) {
    if (t)
      if (Se(t))
        for (const o of t.split(";")) {
          const a = o.slice(0, o.indexOf(":")).trim();
          n[a] == null && Rn(s, a, "");
        }
      else
        for (const o in t)
          n[o] == null && Rn(s, o, "");
    for (const o in n)
      o === "display" && (i = !0), Rn(s, o, n[o]);
  } else if (r) {
    if (t !== n) {
      const o = s[El];
      o && (n += ";" + o), s.cssText = n, i = Tl.test(n);
    }
  } else t && e.removeAttribute("style");
  Er in e && (e[Er] = i ? s.display : "", e[kl] && (s.display = "none"));
}
const Tr = /\s*!important$/;
function Rn(e, t, n) {
  if (W(n))
    n.forEach((s) => Rn(e, t, s));
  else if (n == null && (n = ""), t.startsWith("--"))
    e.setProperty(t, n);
  else {
    const s = Rl(e, t);
    Tr.test(n) ? e.setProperty(
      Xe(s),
      n.replace(Tr, ""),
      "important"
    ) : e[s] = n;
  }
}
const Pr = ["Webkit", "Moz", "ms"], cs = {};
function Rl(e, t) {
  const n = cs[t];
  if (n)
    return n;
  let s = xe(t);
  if (s !== "filter" && s in e)
    return cs[t] = s;
  s = Wn(s);
  for (let r = 0; r < Pr.length; r++) {
    const i = Pr[r] + s;
    if (i in e)
      return cs[t] = i;
  }
  return t;
}
const Rr = "http://www.w3.org/1999/xlink";
function $r(e, t, n, s, r, i = qo(t)) {
  s && t.startsWith("xlink:") ? n == null ? e.removeAttributeNS(Rr, t.slice(6, t.length)) : e.setAttributeNS(Rr, t, n) : n == null || i && !ni(n) ? e.removeAttribute(t) : e.setAttribute(
    t,
    i ? "" : et(n) ? String(n) : n
  );
}
function Mr(e, t, n, s, r) {
  if (t === "innerHTML" || t === "textContent") {
    n != null && (e[t] = t === "innerHTML" ? so(n) : n);
    return;
  }
  const i = e.tagName;
  if (t === "value" && i !== "PROGRESS" && // custom elements may use _value internally
  !i.includes("-")) {
    const a = i === "OPTION" ? e.getAttribute("value") || "" : e.value, l = n == null ? (
      // #11647: value should be set as empty string for null and undefined,
      // but <input type="checkbox"> should be set as 'on'.
      e.type === "checkbox" ? "on" : ""
    ) : String(n);
    (a !== l || !("_value" in e)) && (e.value = l), n == null && e.removeAttribute(t), e._value = n;
    return;
  }
  let o = !1;
  if (n === "" || n == null) {
    const a = typeof e[t];
    a === "boolean" ? n = ni(n) : n == null && a === "string" ? (n = "", o = !0) : a === "number" && (n = 0, o = !0);
  }
  try {
    e[t] = n;
  } catch {
  }
  o && e.removeAttribute(r || t);
}
function Rt(e, t, n, s) {
  e.addEventListener(t, n, s);
}
function $l(e, t, n, s) {
  e.removeEventListener(t, n, s);
}
const Or = /* @__PURE__ */ Symbol("_vei");
function Ml(e, t, n, s, r = null) {
  const i = e[Or] || (e[Or] = {}), o = i[t];
  if (s && o)
    o.value = s;
  else {
    const [a, l] = Ol(t);
    if (s) {
      const d = i[t] = Nl(
        s,
        r
      );
      Rt(e, a, d, l);
    } else o && ($l(e, a, o, l), i[t] = void 0);
  }
}
const qr = /(?:Once|Passive|Capture)$/;
function Ol(e) {
  let t;
  if (qr.test(e)) {
    t = {};
    let s;
    for (; s = e.match(qr); )
      e = e.slice(0, e.length - s[0].length), t[s[0].toLowerCase()] = !0;
  }
  return [e[2] === ":" ? e.slice(3) : Xe(e.slice(2)), t];
}
let us = 0;
const ql = /* @__PURE__ */ Promise.resolve(), jl = () => us || (ql.then(() => us = 0), us = Date.now());
function Nl(e, t) {
  const n = (s) => {
    if (!s._vts)
      s._vts = Date.now();
    else if (s._vts <= n.attached)
      return;
    dt(
      Dl(s, n.value),
      t,
      5,
      [s]
    );
  };
  return n.value = e, n.attached = jl(), n;
}
function Dl(e, t) {
  if (W(t)) {
    const n = e.stopImmediatePropagation;
    return e.stopImmediatePropagation = () => {
      n.call(e), e._stopped = !0;
    }, t.map(
      (s) => (r) => !r._stopped && s && s(r)
    );
  } else
    return t;
}
const jr = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && // lowercase letter
e.charCodeAt(2) > 96 && e.charCodeAt(2) < 123, Fl = (e, t, n, s, r, i) => {
  const o = r === "svg";
  t === "class" ? Cl(e, s, o) : t === "style" ? Pl(e, n, s) : Ln(t) ? Un(t) || Ml(e, t, n, s, i) : (t[0] === "." ? (t = t.slice(1), !0) : t[0] === "^" ? (t = t.slice(1), !1) : Kl(e, t, s, o)) ? (Mr(e, t, s), !e.tagName.includes("-") && (t === "value" || t === "checked" || t === "selected") && $r(e, t, s, o, i, t !== "value")) : /* #11081 force set props for possible async custom element */ e._isVueCE && // #12408 check if it's declared prop or it's async custom element
  (Ll(e, t) || // @ts-expect-error _def is private
  e._def.__asyncLoader && (/[A-Z]/.test(t) || !Se(s))) ? Mr(e, xe(t), s, i, t) : (t === "true-value" ? e._trueValue = s : t === "false-value" && (e._falseValue = s), $r(e, t, s, o));
};
function Kl(e, t, n, s) {
  if (s)
    return !!(t === "innerHTML" || t === "textContent" || t in e && jr(t) && ee(n));
  if (t === "spellcheck" || t === "draggable" || t === "translate" || t === "autocorrect" || t === "sandbox" && e.tagName === "IFRAME" || t === "form" || t === "list" && e.tagName === "INPUT" || t === "type" && e.tagName === "TEXTAREA")
    return !1;
  if (t === "width" || t === "height") {
    const r = e.tagName;
    if (r === "IMG" || r === "VIDEO" || r === "CANVAS" || r === "SOURCE")
      return !1;
  }
  return jr(t) && Se(n) ? !1 : t in e;
}
function Ll(e, t) {
  const n = (
    // @ts-expect-error _def is private
    e._def.props
  );
  if (!n)
    return !1;
  const s = xe(t);
  return Array.isArray(n) ? n.some((r) => xe(r) === s) : Object.keys(n).some((r) => xe(r) === s);
}
const Nr = {};
// @__NO_SIDE_EFFECTS__
function Ul(e, t, n) {
  let s = /* @__PURE__ */ ht(e, t);
  Hn(s) && (s = we({}, s, t));
  class r extends Ys {
    constructor(o) {
      super(s, o, n);
    }
  }
  return r.def = s, r;
}
const Vl = typeof HTMLElement < "u" ? HTMLElement : class {
};
class Ys extends Vl {
  constructor(t, n = {}, s = Es) {
    super(), this._def = t, this._props = n, this._createApp = s, this._isVueCE = !0, this._instance = null, this._app = null, this._nonce = this._def.nonce, this._connected = !1, this._resolved = !1, this._patching = !1, this._dirty = !1, this._numberProps = null, this._styleChildren = /* @__PURE__ */ new WeakSet(), this._styleAnchors = /* @__PURE__ */ new WeakMap(), this._ob = null, this.shadowRoot && s !== Es ? this._root = this.shadowRoot : t.shadowRoot !== !1 ? (this.attachShadow(
      we({}, t.shadowRootOptions, {
        mode: "open"
      })
    ), this._root = this.shadowRoot) : this._root = this;
  }
  connectedCallback() {
    if (!this.isConnected) return;
    !this.shadowRoot && !this._resolved && this._parseSlots(), this._connected = !0;
    let t = this;
    for (; t = t && // #12479 should check assignedSlot first to get correct parent
    (t.assignedSlot || t.parentNode || t.host); )
      if (t instanceof Ys) {
        this._parent = t;
        break;
      }
    this._instance || (this._resolved ? this._mount(this._def) : t && t._pendingResolve ? this._pendingResolve = t._pendingResolve.then(() => {
      this._pendingResolve = void 0, this._resolveDef();
    }) : this._resolveDef());
  }
  _setParent(t = this._parent) {
    t && (this._instance.parent = t._instance, this._inheritParentContext(t));
  }
  _inheritParentContext(t = this._parent) {
    t && this._app && Object.setPrototypeOf(
      this._app._context.provides,
      t._instance.provides
    );
  }
  disconnectedCallback() {
    this._connected = !1, Us(() => {
      this._connected || (this._ob && (this._ob.disconnect(), this._ob = null), this._app && this._app.unmount(), this._instance && (this._instance.ce = void 0), this._app = this._instance = null, this._teleportTargets && (this._teleportTargets.clear(), this._teleportTargets = void 0));
    });
  }
  _processMutations(t) {
    for (const n of t)
      this._setAttr(n.attributeName);
  }
  /**
   * resolve inner component definition (handle possible async component)
   */
  _resolveDef() {
    if (this._pendingResolve)
      return;
    for (let s = 0; s < this.attributes.length; s++)
      this._setAttr(this.attributes[s].name);
    this._ob = new MutationObserver(this._processMutations.bind(this)), this._ob.observe(this, { attributes: !0 });
    const t = (s, r = !1) => {
      this._resolved = !0, this._pendingResolve = void 0;
      const { props: i, styles: o } = s;
      let a;
      if (i && !W(i))
        for (const l in i) {
          const d = i[l];
          (d === Number || d && d.type === Number) && (l in this._props && (this._props[l] = lr(this._props[l])), (a || (a = /* @__PURE__ */ Object.create(null)))[xe(l)] = !0);
        }
      this._numberProps = a, this._resolveProps(s), this.shadowRoot && this._applyStyles(o), this._mount(s);
    }, n = this._def.__asyncLoader;
    n ? this._pendingResolve = n().then((s) => {
      s.configureApp = this._def.configureApp, t(this._def = s, !0);
    }) : t(this._def);
  }
  _mount(t) {
    this._app = this._createApp(t), this._inheritParentContext(), t.configureApp && t.configureApp(this._app), this._app._ceVNode = this._createVNode(), this._app.mount(this._root);
    const n = this._instance && this._instance.exposed;
    if (n)
      for (const s in n)
        ce(this, s) || Object.defineProperty(this, s, {
          // unwrap ref to be consistent with public instance behavior
          get: () => Ls(n[s])
        });
  }
  _resolveProps(t) {
    const { props: n } = t, s = W(n) ? n : Object.keys(n || {});
    for (const r of Object.keys(this))
      r[0] !== "_" && s.includes(r) && this._setProp(r, this[r]);
    for (const r of s.map(xe))
      Object.defineProperty(this, r, {
        get() {
          return this._getProp(r);
        },
        set(i) {
          this._setProp(r, i, !0, !this._patching);
        }
      });
  }
  _setAttr(t) {
    if (t.startsWith("data-v-")) return;
    const n = this.hasAttribute(t);
    let s = n ? this.getAttribute(t) : Nr;
    const r = xe(t);
    n && this._numberProps && this._numberProps[r] && (s = lr(s)), this._setProp(r, s, !1, !0);
  }
  /**
   * @internal
   */
  _getProp(t) {
    return this._props[t];
  }
  /**
   * @internal
   */
  _setProp(t, n, s = !0, r = !1) {
    if (n !== this._props[t] && (this._dirty = !0, n === Nr ? delete this._props[t] : (this._props[t] = n, t === "key" && this._app && (this._app._ceVNode.key = n)), r && this._instance && this._update(), s)) {
      const i = this._ob;
      i && (this._processMutations(i.takeRecords()), i.disconnect()), n === !0 ? this.setAttribute(Xe(t), "") : typeof n == "string" || typeof n == "number" ? this.setAttribute(Xe(t), n + "") : n || this.removeAttribute(Xe(t)), i && i.observe(this, { attributes: !0 });
    }
  }
  _update() {
    const t = this._createVNode();
    this._app && (t.appContext = this._app._context), Gl(t, this._root);
  }
  _createVNode() {
    const t = {};
    this.shadowRoot || (t.onVnodeMounted = t.onVnodeUpdated = this._renderSlots.bind(this));
    const n = Pe(this._def, we(t, this._props));
    return this._instance || (n.ce = (s) => {
      this._instance = s, s.ce = this, s.isCE = !0;
      const r = (i, o) => {
        this.dispatchEvent(
          new CustomEvent(
            i,
            Hn(o[0]) ? we({ detail: o }, o[0]) : { detail: o }
          )
        );
      };
      s.emit = (i, ...o) => {
        r(i, o), Xe(i) !== i && r(Xe(i), o);
      }, this._setParent();
    }), n;
  }
  _applyStyles(t, n, s) {
    if (!t) return;
    if (n) {
      if (n === this._def || this._styleChildren.has(n))
        return;
      this._styleChildren.add(n);
    }
    const r = this._nonce, i = this.shadowRoot, o = s ? this._getStyleAnchor(s) || this._getStyleAnchor(this._def) : this._getRootStyleInsertionAnchor(i);
    let a = null;
    for (let l = t.length - 1; l >= 0; l--) {
      const d = document.createElement("style");
      r && d.setAttribute("nonce", r), d.textContent = t[l], i.insertBefore(d, a || o), a = d, l === 0 && (s || this._styleAnchors.set(this._def, d), n && this._styleAnchors.set(n, d));
    }
  }
  _getStyleAnchor(t) {
    if (!t)
      return null;
    const n = this._styleAnchors.get(t);
    return n && n.parentNode === this.shadowRoot ? n : (n && this._styleAnchors.delete(t), null);
  }
  _getRootStyleInsertionAnchor(t) {
    for (let n = 0; n < t.childNodes.length; n++) {
      const s = t.childNodes[n];
      if (!(s instanceof HTMLStyleElement))
        return s;
    }
    return null;
  }
  /**
   * Only called when shadowRoot is false
   */
  _parseSlots() {
    const t = this._slots = {};
    let n;
    for (; n = this.firstChild; ) {
      const s = n.nodeType === 1 && n.getAttribute("slot") || "default";
      (t[s] || (t[s] = [])).push(n), this.removeChild(n);
    }
  }
  /**
   * Only called when shadowRoot is false
   */
  _renderSlots() {
    const t = this._getSlots(), n = this._instance.type.__scopeId;
    for (let s = 0; s < t.length; s++) {
      const r = t[s], i = r.getAttribute("name") || "default", o = this._slots[i], a = r.parentNode;
      if (o)
        for (const l of o) {
          if (n && l.nodeType === 1) {
            const d = n + "-s", u = document.createTreeWalker(l, 1);
            l.setAttribute(d, "");
            let h;
            for (; h = u.nextNode(); )
              h.setAttribute(d, "");
          }
          a.insertBefore(l, r);
        }
      else
        for (; r.firstChild; ) a.insertBefore(r.firstChild, r);
      a.removeChild(r);
    }
  }
  /**
   * @internal
   */
  _getSlots() {
    const t = [this];
    this._teleportTargets && t.push(...this._teleportTargets);
    const n = /* @__PURE__ */ new Set();
    for (const s of t) {
      const r = s.querySelectorAll("slot");
      for (let i = 0; i < r.length; i++)
        n.add(r[i]);
    }
    return Array.from(n);
  }
  /**
   * @internal
   */
  _injectChildStyle(t, n) {
    this._applyStyles(t.styles, t, n);
  }
  /**
   * @internal
   */
  _beginPatch() {
    this._patching = !0, this._dirty = !1;
  }
  /**
   * @internal
   */
  _endPatch() {
    this._patching = !1, this._dirty && this._instance && this._update();
  }
  /**
   * @internal
   */
  _hasShadowRoot() {
    return this._def.shadowRoot !== !1;
  }
  /**
   * @internal
   */
  _removeChildStyle(t) {
  }
}
const Xt = (e) => {
  const t = e.props["onUpdate:modelValue"] || !1;
  return W(t) ? (n) => En(t, n) : t;
};
function Hl(e) {
  e.target.composing = !0;
}
function Dr(e) {
  const t = e.target;
  t.composing && (t.composing = !1, t.dispatchEvent(new Event("input")));
}
const vt = /* @__PURE__ */ Symbol("_assign");
function Fr(e, t, n) {
  return t && (e = e.trim()), n && (e = Ms(e)), e;
}
const ks = {
  created(e, { modifiers: { lazy: t, trim: n, number: s } }, r) {
    e[vt] = Xt(r);
    const i = s || r.props && r.props.type === "number";
    Rt(e, t ? "change" : "input", (o) => {
      o.target.composing || e[vt](Fr(e.value, n, i));
    }), (n || i) && Rt(e, "change", () => {
      e.value = Fr(e.value, n, i);
    }), t || (Rt(e, "compositionstart", Hl), Rt(e, "compositionend", Dr), Rt(e, "change", Dr));
  },
  // set value on mounted so it's after min/max for type="range"
  mounted(e, { value: t }) {
    e.value = t ?? "";
  },
  beforeUpdate(e, { value: t, oldValue: n, modifiers: { lazy: s, trim: r, number: i } }, o) {
    if (e[vt] = Xt(o), e.composing) return;
    const a = (i || e.type === "number") && !/^0\d/.test(e.value) ? Ms(e.value) : e.value, l = t ?? "";
    if (a === l)
      return;
    const d = e.getRootNode();
    (d instanceof Document || d instanceof ShadowRoot) && d.activeElement === e && e.type !== "range" && (s && t === n || r && e.value.trim() === l) || (e.value = l);
  }
}, Kr = {
  // #4096 array checkboxes need to be deep traversed
  deep: !0,
  created(e, t, n) {
    e[vt] = Xt(n), Rt(e, "change", () => {
      const s = e._modelValue, r = ro(e), i = e.checked, o = e[vt];
      if (W(s)) {
        const a = si(s, r), l = a !== -1;
        if (i && !l)
          o(s.concat(r));
        else if (!i && l) {
          const d = [...s];
          d.splice(a, 1), o(d);
        }
      } else if (Vn(s)) {
        const a = new Set(s);
        i ? a.add(r) : a.delete(r), o(a);
      } else
        o(io(e, i));
    });
  },
  // set initial checked on mount to wait for true-value/false-value
  mounted: Lr,
  beforeUpdate(e, t, n) {
    e[vt] = Xt(n), Lr(e, t, n);
  }
};
function Lr(e, { value: t, oldValue: n }, s) {
  e._modelValue = t;
  let r;
  if (W(t))
    r = si(t, s.props.value) > -1;
  else if (Vn(t))
    r = t.has(s.props.value);
  else {
    if (t === n) return;
    r = Ft(t, io(e, !0));
  }
  e.checked !== r && (e.checked = r);
}
const Bl = {
  created(e, { value: t }, n) {
    e.checked = Ft(t, n.props.value), e[vt] = Xt(n), Rt(e, "change", () => {
      e[vt](ro(e));
    });
  },
  beforeUpdate(e, { value: t, oldValue: n }, s) {
    e[vt] = Xt(s), t !== n && (e.checked = Ft(t, s.props.value));
  }
};
function ro(e) {
  return "_value" in e ? e._value : e.value;
}
function io(e, t) {
  const n = t ? "_trueValue" : "_falseValue";
  return n in e ? e[n] : t;
}
const Wl = ["ctrl", "shift", "alt", "meta"], zl = {
  stop: (e) => e.stopPropagation(),
  prevent: (e) => e.preventDefault(),
  self: (e) => e.target !== e.currentTarget,
  ctrl: (e) => !e.ctrlKey,
  shift: (e) => !e.shiftKey,
  alt: (e) => !e.altKey,
  meta: (e) => !e.metaKey,
  left: (e) => "button" in e && e.button !== 0,
  middle: (e) => "button" in e && e.button !== 1,
  right: (e) => "button" in e && e.button !== 2,
  exact: (e, t) => Wl.some((n) => e[`${n}Key`] && !t.includes(n))
}, oo = (e, t) => {
  if (!e) return e;
  const n = e._withMods || (e._withMods = {}), s = t.join(".");
  return n[s] || (n[s] = ((r, ...i) => {
    for (let o = 0; o < t.length; o++) {
      const a = zl[t[o]];
      if (a && a(r, t)) return;
    }
    return e(r, ...i);
  }));
}, Jl = /* @__PURE__ */ we({ patchProp: Fl }, Al);
let Ur;
function ao() {
  return Ur || (Ur = sl(Jl));
}
const Gl = ((...e) => {
  ao().render(...e);
}), Es = ((...e) => {
  const t = ao().createApp(...e), { mount: n } = t;
  return t.mount = (s) => {
    const r = Xl(s);
    if (!r) return;
    const i = t._component;
    !ee(i) && !i.render && !i.template && (i.template = r.innerHTML), r.nodeType === 1 && (r.textContent = "");
    const o = n(r, !1, Yl(r));
    return r instanceof Element && (r.removeAttribute("v-cloak"), r.setAttribute("data-v-app", "")), o;
  }, t;
});
function Yl(e) {
  if (e instanceof SVGElement)
    return "svg";
  if (typeof MathMLElement == "function" && e instanceof MathMLElement)
    return "mathml";
}
function Xl(e) {
  return Se(e) ? document.querySelector(e) : e;
}
let Vr = 0;
function He(e = "c") {
  Vr += 1;
  const t = Math.random().toString(36).slice(2, 8);
  return `${e}_${Date.now().toString(36)}_${Vr}_${t}`;
}
function Ye() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
function Xs(e) {
  return {
    sessionId: e,
    turnStatus: "idle",
    messages: [],
    error: null
  };
}
function Ql(e) {
  return e.blocks.filter((t) => t.type === "text").map((t) => t.text).join("");
}
function Zl(e) {
  return e.startsWith("debug.");
}
function ve(e, t, n = {}) {
  return {
    protocolVersion: "1.0",
    type: e,
    timestamp: Ye(),
    data: t,
    ...n
  };
}
const ec = {
  form: "form",
  text_question: "text_question",
  textquestion: "text_question",
  select: "select",
  choice: "choice",
  multi_select: "multi_select",
  multiselect: "multi_select",
  confirm: "confirm",
  table: "table",
  detail: "detail",
  card: "card",
  report: "report",
  summary_card: "summary_card",
  summarycard: "summary_card",
  list_card: "list_card",
  listcard: "list_card",
  output_card: "output_card",
  outputcard: "output_card",
  page_action: "page_action",
  pageaction: "page_action",
  custom: "custom"
}, tc = /* @__PURE__ */ new Set([
  "table",
  "detail",
  "card",
  "report",
  "summary_card",
  "list_card",
  "output_card"
]);
function Ve(e) {
  return !e || typeof e != "object" || Array.isArray(e) ? null : e;
}
function Be(e) {
  if (e == null) return;
  const t = String(e).trim();
  return t || void 0;
}
function nc(e) {
  var n;
  const t = ((n = Be(e)) == null ? void 0 : n.toLowerCase().replace(/[\s-]+/g, "_")) || "custom";
  return ec[t] || t;
}
function sc(e) {
  if (!Array.isArray(e)) return;
  const t = [];
  for (const n of e) {
    const s = Ve(n);
    if (!s) continue;
    const r = Be(s.key) || Be(s.name) || Be(s.id);
    if (!r) continue;
    const i = Array.isArray(s.options) ? s.options.map((o) => {
      const a = Ve(o);
      return a ? {
        value: a.value ?? a.id ?? "",
        label: String(a.label ?? a.name ?? a.value ?? "")
      } : null;
    }).filter((o) => !!o) : void 0;
    t.push({
      key: r,
      name: Be(s.name),
      label: String(s.label ?? s.name ?? r),
      type: String(s.type ?? "string"),
      required: s.required === !0,
      targetPath: Be(s.targetPath),
      options: i,
      placeholder: Be(s.placeholder),
      source: Ve(s.source) || void 0
    });
  }
  return t.length ? t : void 0;
}
function rc(e) {
  if (!Array.isArray(e)) return;
  const t = [];
  for (const n of e) {
    const s = Ve(n);
    s && t.push({ ...s });
  }
  return t.length ? t : void 0;
}
function ic(e, t, n) {
  const s = `${e}|${t || ""}|${n || ""}`.slice(0, 80);
  let r = 0;
  for (let i = 0; i < s.length; i += 1)
    r = (r << 5) - r + s.charCodeAt(i) | 0;
  return `local:readonly:${e}:${Math.abs(r).toString(36)}`;
}
function oc(e) {
  const t = Ve(e);
  if (!t) return null;
  const n = nc(t.component ?? t.type), s = Be(t.title), r = Be(t.message);
  let i = Be(t.interactionId);
  i || (tc.has(n) ? i = ic(n, s, r) : i = He("interaction"));
  const o = Ve(t.extension) || void 0, a = Ve(t.schema) || Ve(t.renderSchema) || Ve(o == null ? void 0 : o.renderSchema) || void 0;
  return {
    schemaVersion: "1.0",
    interactionId: i,
    traceId: Be(t.traceId),
    type: Be(t.type),
    component: n,
    title: s,
    message: r,
    ttlSeconds: typeof t.ttlSeconds == "number" ? t.ttlSeconds : void 0,
    expiresAt: Be(t.expiresAt),
    fields: sc(t.fields),
    prefilled: Ve(t.prefilled) || void 0,
    missing: Array.isArray(t.missing) ? t.missing.map(String) : void 0,
    summary: Ve(t.summary) || void 0,
    data: t.data,
    schema: a,
    actions: rc(t.actions),
    datasources: Ve(t.datasources) || void 0,
    behavior: Ve(t.behavior) || void 0,
    extension: o
  };
}
function Re(e) {
  return {
    ...e,
    messages: e.messages.map((t) => ({
      ...t,
      blocks: t.blocks.map((n) => ({ ...n })),
      metadata: t.metadata ? { ...t.metadata } : void 0,
      completion: t.completion ? { ...t.completion } : void 0
    })),
    metadata: e.metadata ? { ...e.metadata } : void 0
  };
}
function ac(e, t) {
  return e.id === t || e.transportMessageId === t;
}
function Qs(e) {
  for (let t = e.messages.length - 1; t >= 0; t -= 1) {
    const n = e.messages[t];
    if (n.role === "assistant" && (n.status === "streaming" || n.status === "pending"))
      return n;
  }
}
function Hr(e, t) {
  return Qs(e);
}
function lc(e) {
  for (let t = e.messages.length - 1; t >= 0; t -= 1)
    if (e.messages[t].role === "assistant") return e.messages[t];
}
function Et(e, t, n, s = {}) {
  if (t) {
    const o = e.messages.find((a) => ac(a, t));
    if (o && (o.status === "pending" || o.status === "streaming" || s.reuseCompleted))
      return n && (o.metadata = { ...o.metadata || {}, ...n }), o;
  }
  const r = Qs(e);
  if (r)
    return t && r.transportMessageId !== t && (r.transportMessageId = t), n && (r.metadata = { ...r.metadata || {}, ...n }), r;
  if (s.reuseCompleted) {
    const o = lc(e);
    if (o)
      return n && (o.metadata = { ...o.metadata || {}, ...n }), o;
  }
  const i = {
    id: He("msg"),
    role: "assistant",
    status: "streaming",
    blocks: [],
    createdAt: Ye(),
    metadata: n,
    transportMessageId: t
  };
  return e.messages.push(i), i;
}
function lo(e, t) {
  return e.blocks.find(
    (n) => n.type === "interaction" && n.request.interactionId === t
  );
}
function Br(e, t) {
  if (!t) return;
  const n = e.blocks[e.blocks.length - 1];
  if (n && n.type === "text" && n.status !== "completed")
    n.text += t, n.status = "streaming";
  else {
    const s = {
      id: He("blk"),
      type: "text",
      text: t,
      status: "streaming"
    };
    e.blocks.push(s);
  }
  e.status = "streaming", e.updatedAt = Ye();
}
function Wr(e, t, n = "waiting") {
  const s = oc(t);
  if (!s) return;
  const r = lo(e, s.interactionId);
  if (r) {
    r.request = s, (r.state === "waiting" || r.state === "failed") && (r.state = n), e.updatedAt = Ye();
    return;
  }
  e.blocks.push({
    id: He("blk"),
    type: "interaction",
    request: s,
    state: n
  }), e.updatedAt = Ye();
}
function fs(e) {
  for (const t of e.blocks)
    t.type === "text" && t.status === "streaming" && (t.status = "completed");
}
function Ge(e, t) {
  switch (t.type) {
    case "reset":
      return Xs(t.sessionId);
    case "restore":
      return Re(t.snapshot);
    case "set_session": {
      const n = Re(e);
      return n.sessionId = t.sessionId, n;
    }
    case "set_error": {
      const n = Re(e);
      return n.error = t.error, n;
    }
    case "append_user_message": {
      const n = Re(e);
      return n.messages.push({
        id: t.id || He("msg"),
        role: "user",
        status: "completed",
        blocks: [{ id: He("blk"), type: "text", text: t.text, status: "completed" }],
        createdAt: Ye(),
        metadata: t.metadata
      }), n.error = null, n;
    }
    case "begin_assistant_placeholder": {
      const n = Re(e), s = Qs(n);
      return s && (!t.turnId || !s.turnId || s.turnId === t.turnId) ? (t.turnId && (s.turnId = t.turnId, n.turnId = t.turnId), n) : (n.messages.push({
        id: He("msg"),
        role: "assistant",
        status: "pending",
        blocks: [],
        createdAt: Ye(),
        turnId: t.turnId,
        localPlaceholder: !0
      }), t.turnId && (n.turnId = t.turnId), n.error = null, n);
    }
    case "start_assistant_message": {
      const n = Re(e), s = Et(n, t.id, t.metadata);
      return s.status === "pending" && (s.status = "streaming"), s.updatedAt = Ye(), n.turnStatus = n.turnStatus === "waiting" ? "waiting" : "streaming", n.error = null, n;
    }
    case "append_text_delta": {
      const n = Re(e), s = Et(n, t.messageId);
      return Br(s, t.text), (n.turnStatus === "idle" || n.turnStatus === "sending") && (n.turnStatus = "streaming"), n;
    }
    case "add_interaction": {
      const n = Re(e), s = Et(n, t.messageId);
      return Wr(s, t.request, t.state || "waiting"), (n.turnStatus === "idle" || n.turnStatus === "sending") && (n.turnStatus = "streaming"), n;
    }
    case "update_interaction_state": {
      const n = Re(e);
      for (const s of n.messages) {
        const r = lo(s, t.interactionId);
        if (r) {
          r.state = t.state, t.result && (r.result = t.result), t.errorMessage !== void 0 && (r.errorMessage = t.errorMessage), s.updatedAt = Ye();
          break;
        }
      }
      return n;
    }
    case "add_notice": {
      const n = Re(e);
      return Et(n, t.messageId).blocks.push({
        id: He("blk"),
        type: "notice",
        level: t.level || "info",
        text: t.text
      }), n;
    }
    case "add_error_block": {
      const n = Re(e), s = Et(n, t.messageId);
      return s.blocks.push({
        id: He("blk"),
        type: "error",
        text: t.text,
        retryable: t.retryable
      }), s.status = "failed", n;
    }
    case "add_page_action": {
      const n = Re(e), s = Et(n, t.messageId);
      return s.blocks.some(
        (i) => i.type === "page_action" && i.requestId === t.requestId
      ) || !t.requestId || s.blocks.push({
        id: He("blk"),
        type: "page_action",
        requestId: t.requestId,
        actionKey: t.actionKey,
        title: t.title,
        args: t.args,
        status: "pending"
      }), n;
    }
    case "set_turn_status": {
      const n = Re(e);
      return n.turnStatus = t.status, n;
    }
    case "complete_turn": {
      const n = Re(e);
      t.sessionId && (n.sessionId = t.sessionId);
      const s = Et(n, void 0, void 0, { reuseCompleted: !0 });
      t.answer && (s.blocks.some((o) => o.type === "text" && o.text) || Br(s, t.answer)), t.uiRequest && Wr(s, t.uiRequest, "waiting"), fs(s);
      const r = s.blocks.some(
        (i) => i.type === "interaction" && i.state === "waiting"
      );
      return s.status = "completed", s.updatedAt = Ye(), t.metadata && (s.metadata = { ...s.metadata || {}, ...t.metadata }, n.metadata = { ...n.metadata || {}, ...t.metadata }), t.completion && (s.completion = {
        ...s.completion || {},
        ...t.completion
      }), n.turnStatus = r ? "waiting" : "completed", n.error = null, n;
    }
    case "fail_turn": {
      const n = Re(e), s = Hr(n) || Et(n);
      return fs(s), s.status = "failed", s.blocks.push({
        id: He("blk"),
        type: "error",
        text: t.message,
        retryable: !0
      }), t.metadata && (s.metadata = { ...s.metadata || {}, ...t.metadata }, n.metadata = { ...n.metadata || {}, ...t.metadata }), s.updatedAt = Ye(), n.turnStatus = "failed", n.error = t.message, n;
    }
    case "cancel_turn": {
      const n = Re(e), s = Hr(n);
      return s && (fs(s), s.status = "cancelled", s.updatedAt = Ye()), n.turnStatus = "cancelled", n.error = null, n;
    }
    case "apply_event":
      return cc(e, t.event);
    default:
      return e;
  }
}
function cc(e, t) {
  const n = t.type, s = t.data && typeof t.data == "object" ? t.data : {}, r = t.turnId && e.turnId !== t.turnId ? { ...e, turnId: t.turnId } : e;
  switch (n) {
    case "session.created":
    case "session.restored":
      return n === "session.restored" && t.data && typeof t.data == "object" && "messages" in t.data ? Ge(r, { type: "restore", snapshot: t.data }) : Ge(r, { type: "set_session", sessionId: t.sessionId || Ae(s.sessionId) });
    case "turn.started":
      return Ge(r, { type: "set_turn_status", status: "sending" });
    case "message.started":
      return Ge(r, {
        type: "start_assistant_message",
        id: Ae(s.messageId)
      });
    case "message.delta": {
      const i = typeof s.text == "string" ? s.text : typeof t.data == "string" ? t.data : "";
      return Ge(r, {
        type: "append_text_delta",
        text: i,
        messageId: Ae(s.messageId)
      });
    }
    case "ui.requested":
      return Ge(r, {
        type: "add_interaction",
        request: s.uiRequest ?? t.data,
        messageId: Ae(s.messageId)
      });
    case "page.action.requested":
      return Ge(r, {
        type: "add_page_action",
        requestId: String(s.requestId || ""),
        actionKey: String(s.actionKey || ""),
        title: Ae(s.title),
        args: s.args || void 0,
        messageId: Ae(s.messageId)
      });
    case "turn.waiting":
      return Ge(r, {
        type: "complete_turn",
        answer: Ae(s.answer),
        uiRequest: s.uiRequest,
        sessionId: t.sessionId || Ae(s.sessionId),
        metadata: ds(s.metadata, s.result),
        completion: {
          intentType: s.intentType,
          toolCalls: s.toolCalls,
          result: s.result
        }
      });
    case "turn.completed":
      return Ge(r, {
        type: "complete_turn",
        answer: Ae(s.answer),
        uiRequest: s.uiRequest,
        sessionId: t.sessionId || Ae(s.sessionId),
        metadata: {
          ...ds(s.metadata, s.result),
          ...t.traceId ? { traceId: t.traceId } : {},
          ...s.traceId ? { traceId: s.traceId } : {}
        },
        completion: {
          intentType: s.intentType,
          toolCalls: s.toolCalls,
          result: s.result
        }
      });
    case "turn.cancelled":
      return Ge(r, { type: "cancel_turn" });
    case "turn.failed": {
      const i = ds(s.metadata, s.result), o = t.traceId || Ae(s.traceId) || Ae(i.traceId), a = Ae(s.code) || Ae(i.code);
      return Ge(r, {
        type: "fail_turn",
        message: Ae(s.message) || Ae(s.error) || "对话失败",
        metadata: {
          ...i,
          success: !1,
          ...a ? { code: a } : {},
          ...o ? { traceId: o } : {},
          ...t.sessionId || Ae(s.sessionId) ? { sessionId: t.sessionId || Ae(s.sessionId) } : {}
        }
      });
    }
    default:
      return r;
  }
}
function Ae(e) {
  if (e == null) return;
  const t = String(e);
  return t || void 0;
}
function ds(e, t) {
  if (e && typeof e == "object" && !Array.isArray(e)) {
    const n = e;
    if (n.metadata && typeof n.metadata == "object" && !Array.isArray(n.metadata) && ("answer" in n || "uiRequest" in n || "sessionId" in n)) {
      const r = { ...n.metadata };
      return "success" in n && (r.success = n.success), n.code != null && (r.code = n.code), n.traceId != null && (r.traceId = n.traceId), r;
    }
    if (!("answer" in n) && !("uiRequest" in n))
      return { ...n };
    const s = {};
    if ("success" in n && (s.success = n.success), n.code != null && (s.code = n.code), n.traceId != null && (s.traceId = n.traceId), t && typeof t == "object" && !Array.isArray(t)) {
      const r = t.metadata;
      if (r && typeof r == "object" && !Array.isArray(r))
        return { ...r, ...s };
    }
    return s;
  }
  if (t && typeof t == "object" && !Array.isArray(t)) {
    const n = t, s = n.metadata, r = {};
    return "success" in n && (r.success = n.success), s && typeof s == "object" && !Array.isArray(s) ? { ...s, ...r } : r;
  }
  return {};
}
function uc(e) {
  return Xs(e);
}
function fc(e) {
  const t = e.trim();
  if (!t) return "";
  try {
    return JSON.parse(t);
  } catch {
    return e;
  }
}
function co(e) {
  const n = e.replace(/\r\n/g, `
`).replace(/\r/g, `
`).split(`
`);
  let s = "message", r;
  const i = [];
  for (const a of n)
    if (!(!a || a.startsWith(":"))) {
      if (a.startsWith("event:")) {
        s = a.slice(6).trim();
        continue;
      }
      if (a.startsWith("id:")) {
        r = a.slice(3).trim();
        continue;
      }
      a.startsWith("data:") && i.push(a.slice(5).replace(/^ /, ""));
    }
  if (!i.length && s === "message") return null;
  const o = i.join(`
`);
  return {
    event: s,
    rawData: o,
    data: fc(o),
    id: r
  };
}
function dc(e) {
  const t = [];
  let n = e.replace(/\r\n/g, `
`).replace(/\r/g, `
`), s = n.indexOf(`

`);
  for (; s >= 0; ) {
    const r = n.slice(0, s);
    n = n.slice(s + 2);
    const i = co(r);
    i && t.push(i), s = n.indexOf(`

`);
  }
  return { frames: t, rest: n };
}
async function* hc(e, t = {}) {
  const n = e.getReader(), s = new TextDecoder();
  let r = "";
  const i = t.signal, o = () => {
    if (i != null && i.aborted)
      throw new DOMException("The operation was aborted.", "AbortError");
  };
  try {
    for (; ; ) {
      o();
      const { done: a, value: l } = await n.read();
      if (a) break;
      o(), r += s.decode(l, { stream: !0 });
      const d = dc(r);
      r = d.rest;
      for (const u of d.frames)
        yield u;
    }
    if (r += s.decode(), r.trim()) {
      const a = co(r.trim());
      a && (yield a);
    }
  } finally {
    try {
      n.releaseLock();
    } catch {
    }
  }
}
function Kn(e) {
  return !e || typeof e != "object" ? !1 : e.name === "AbortError";
}
const pc = /* @__PURE__ */ new Set([
  "message.delta",
  "ui.requested",
  "page.action.requested",
  "turn.started",
  "turn.waiting",
  "turn.completed",
  "turn.failed",
  "turn.cancelled",
  "interaction.submitted",
  "interaction.cancelled"
]);
function gc(e) {
  const { transport: t, onDebugEvent: n, onPublicEvent: s } = e;
  let r = uc(e.initialSessionId);
  const i = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Set();
  let a = !1, l = null, d = 0, u;
  const h = /* @__PURE__ */ new Set(), m = /* @__PURE__ */ new Set(), k = /* @__PURE__ */ new Set();
  function I() {
    var _;
    (_ = e.onChange) == null || _.call(e, r);
    for (const E of i) E(r);
  }
  function y(_) {
    r = Ge(r, _), I();
  }
  function z(_) {
    return _.turnId || !u ? _ : { ..._, turnId: u };
  }
  function J(_) {
    if (!pc.has(_.type)) return !1;
    const E = _.data && typeof _.data == "object" ? _.data : {}, H = _.turnId || u || "";
    if (_.type === "message.delta")
      return !0;
    if (_.type === "page.action.requested") {
      const L = String(E.requestId || "");
      if (!L) return !0;
      const U = `page.action.requested:${L}`;
      return k.has(U) ? !1 : (k.add(U), !0);
    }
    if (_.type === "ui.requested") {
      const L = E.uiRequest, U = `ui.requested:${H}:${(L == null ? void 0 : L.interactionId) || JSON.stringify(E.uiRequest || "")}`;
      return m.has(U) ? !1 : (m.add(U), !0);
    }
    if (_.type === "turn.completed" || _.type === "turn.waiting" || _.type === "turn.failed" || _.type === "turn.cancelled") {
      const L = _.sessionId || (E.sessionId != null ? String(E.sessionId) : "") || r.sessionId || "", U = `${_.type}:${L}:${H}`;
      return h.has(U) ? !1 : (h.add(U), !0);
    }
    if (_.type === "interaction.submitted" || _.type === "interaction.cancelled") {
      const L = `${_.type}:${H}:${String(E.interactionId || "")}:${String(E.action || "")}`;
      return h.has(L) ? !1 : (h.add(L), !0);
    }
    return !0;
  }
  function S(_) {
    const E = z(_);
    J(E) && (s == null || s(E));
  }
  function j(_) {
    const E = z(_);
    if (Zl(E.type)) {
      n == null || n(E);
      return;
    }
    if (E.type === "page.action.requested") {
      const H = E.data && typeof E.data == "object" ? E.data : {}, L = String(H.requestId || "");
      if (L) {
        const U = `page.action.requested:${L}`;
        if (k.has(U))
          return;
      }
    }
    S(E), y({ type: "apply_event", event: E });
  }
  async function R(_, E) {
    for await (const H of _) {
      if (a || E !== d) break;
      j(H);
    }
  }
  async function K(_, E) {
    var ie, ne, he, te;
    if (a) return;
    const H = ++d;
    u = He("turn"), E === "start" || ((ie = _.uiSubmit) == null ? void 0 : ie.action) !== "cancel" ? (l == null || l.abort(), l = new AbortController()) : (!l || l.signal.aborted) && (l = new AbortController());
    const L = l.signal;
    y({ type: "set_turn_status", status: "sending" }), y({ type: "set_error", error: null }), E === "start" && _.message && y({ type: "append_user_message", text: _.message }), (E === "start" || ((ne = _.uiSubmit) == null ? void 0 : ne.action) !== "cancel") && y({ type: "begin_assistant_placeholder", turnId: u });
    try {
      const re = E === "resume" && t.resumeInteraction && _.interactionId ? t.resumeInteraction(
        _.interactionId,
        ((he = _.uiSubmit) == null ? void 0 : he.action) || "submit",
        ((te = _.uiSubmit) == null ? void 0 : te.values) || _.values || {},
        L
      ) : t.startTurn(_, L);
      if (await R(re, H), H !== d) return;
      (r.turnStatus === "sending" || r.turnStatus === "streaming") && y({ type: "set_turn_status", status: "completed" });
    } catch (re) {
      if (H !== d) return;
      if (Kn(re) || L.aborted) {
        y({ type: "cancel_turn" }), S(ve("turn.cancelled", {}, { sessionId: r.sessionId, turnId: u }));
        return;
      }
      const ue = re instanceof Error ? re.message : String(re);
      y({ type: "fail_turn", message: ue }), S(ve("turn.failed", { message: ue, error: ue }, {
        sessionId: r.sessionId,
        turnId: u
      }));
    }
  }
  return {
    getState() {
      return r;
    },
    subscribe(_) {
      return i.add(_), _(r), () => i.delete(_);
    },
    async send(_) {
      const E = typeof _ == "string" ? { message: _ } : _;
      !E.message && !E.values && !E.uiSubmit || await K(E, "start");
    },
    async submitInteraction(_, E, H = {}) {
      if (!_ || o.has(_)) return;
      o.add(_);
      const L = E === "cancel";
      y({
        type: "update_interaction_state",
        interactionId: _,
        state: "submitting",
        result: { action: E, values: H }
      });
      try {
        await K(
          {
            interactionId: _,
            uiSubmit: { action: E, values: H },
            values: H,
            message: void 0
          },
          "resume"
        ), L && r.turnStatus === "cancelled" ? (y({
          type: "update_interaction_state",
          interactionId: _,
          state: "cancelled",
          result: { action: E, values: H }
        }), S(ve(
          "interaction.cancelled",
          { interactionId: _, action: E, values: H },
          { sessionId: r.sessionId, turnId: u }
        ))) : r.turnStatus === "failed" ? y({
          type: "update_interaction_state",
          interactionId: _,
          state: "failed",
          errorMessage: r.error || "提交失败"
        }) : L ? (y({
          type: "update_interaction_state",
          interactionId: _,
          state: "cancelled",
          result: { action: E, values: H }
        }), S(ve(
          "interaction.cancelled",
          { interactionId: _, action: E, values: H },
          { sessionId: r.sessionId, turnId: u }
        ))) : r.turnStatus === "cancelled" ? y({
          type: "update_interaction_state",
          interactionId: _,
          state: "cancelled",
          result: { action: E, values: H }
        }) : (y({
          type: "update_interaction_state",
          interactionId: _,
          state: "resolved",
          result: { action: E, values: H }
        }), S(ve(
          "interaction.submitted",
          { interactionId: _, action: E, values: H },
          { sessionId: r.sessionId, turnId: u }
        )));
      } catch (U) {
        Kn(U) || r.turnStatus === "cancelled" ? y({
          type: "update_interaction_state",
          interactionId: _,
          state: "failed",
          errorMessage: "交互提交被中断"
        }) : y({
          type: "update_interaction_state",
          interactionId: _,
          state: "failed",
          errorMessage: U instanceof Error ? U.message : String(U)
        });
      } finally {
        o.delete(_);
      }
    },
    async cancel() {
      var _;
      d += 1, u = He("turn"), l == null || l.abort(), l = null;
      try {
        await ((_ = t.cancelTurn) == null ? void 0 : _.call(t));
      } catch {
      }
      y({ type: "cancel_turn" }), S(ve("turn.cancelled", {}, { sessionId: r.sessionId, turnId: u }));
    },
    async clearSession() {
      var _;
      d += 1, u = void 0, l == null || l.abort(), l = null, await ((_ = t.clearSession) == null ? void 0 : _.call(t)), h.clear(), m.clear(), k.clear(), y({ type: "reset", sessionId: void 0 });
    },
    async restore() {
      var E;
      const _ = await ((E = t.restoreSession) == null ? void 0 : E.call(t));
      return _ ? (y({ type: "restore", snapshot: _ }), _) : null;
    },
    dispose() {
      a = !0, d += 1, u = void 0, l == null || l.abort(), l = null, i.clear(), h.clear(), m.clear(), k.clear(), t.dispose();
    }
  };
}
function Zs(e) {
  return !e || typeof e != "object" || Array.isArray(e) ? null : e;
}
function mc(e) {
  const t = Zs(e);
  return t && "text" in t ? String(t.text ?? "") : typeof e == "string" ? e : "";
}
function uo(e) {
  if (!e) return;
  const t = Zs(e.metadata);
  if (t) return { ...t };
  if (!("answer" in e) && !("uiRequest" in e) && !("sessionId" in e) && !("toolCalls" in e))
    return { ...e };
}
function yc(e, t, n, s) {
  const r = uo(e || void 0);
  return {
    answer: s,
    sessionId: n,
    result: t,
    metadata: r,
    intentType: e == null ? void 0 : e.intentType,
    toolCalls: e == null ? void 0 : e.toolCalls,
    uiRequest: e == null ? void 0 : e.uiRequest
  };
}
function fo(e, t, n = {}) {
  const s = Zs(t), r = n.sessionId || (s != null && s.sessionId ? String(s.sessionId) : void 0);
  switch (e) {
    case "message.delta": {
      const i = mc(t);
      return i ? ve("message.delta", { text: i }, { sessionId: r }) : null;
    }
    case "ui.requested":
      return ve("ui.requested", {
        uiRequest: (s == null ? void 0 : s.uiRequest) ?? t
      }, { sessionId: r });
    case "page.action.requested":
      return ve("page.action.requested", t, { sessionId: r });
    case "message.completed": {
      const i = (s == null ? void 0 : s.answer) != null ? String(s.answer) : void 0, o = s == null ? void 0 : s.uiRequest, a = yc(s, t, r, i);
      return o ? [
        ve("ui.requested", { uiRequest: o }, { sessionId: r }),
        ve("turn.waiting", a, { sessionId: r })
      ] : ve("turn.completed", a, { sessionId: r });
    }
    case "error":
    case "execution.error": {
      const i = (s == null ? void 0 : s.message) != null ? String(s.message) : typeof t == "string" ? t : "Embed 对话失败";
      return ve("turn.failed", { message: i, error: i }, { sessionId: r });
    }
    case "execution.started":
      return ve("turn.started", s || {}, { sessionId: r });
    case "execution.completed":
      return fo("message.completed", t, n);
    case "supervisor.step":
    case "reasoning.delta":
      return null;
    default:
      return null;
  }
}
function* bc(e) {
  if (e) {
    if (Array.isArray(e)) {
      for (const t of e) yield t;
      return;
    }
    yield e;
  }
}
function _c(e, t) {
  const n = typeof crypto < "u" && typeof crypto.randomUUID == "function" ? crypto.randomUUID().replace(/-/g, "") : `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`;
  return `${e}-${t}-${n}`;
}
function vc(e) {
  return e === 404 || e === 405 || e === 415 || e === 501;
}
function Sc(e) {
  return !e || typeof e != "object" ? !1 : e.name === "AbortError";
}
function hs(e) {
  return e.aborted || Sc(e.error) || e.bytesOrEventsConsumed || e.status == null ? !1 : vc(e.status);
}
function wc(e) {
  const t = e.fetchImpl || fetch, n = e.preferStream !== !1;
  let s = !1;
  const r = /* @__PURE__ */ new Set();
  let i = null;
  function o(S) {
    const j = e.apiBase.replace(/\/$/, "");
    return S.startsWith("http") ? S : `${j}${S.startsWith("/") ? S : `/${S}`}`;
  }
  async function a(S, j, R) {
    const K = {
      "Content-Type": "application/json",
      ...j.headers
    }, _ = e.tokenProvider();
    _ && (K.Authorization = `Bearer ${_}`);
    let E = await t(S, { ...j, headers: K, signal: R });
    if (E.status === 401 && e.onUnauthorized) {
      const H = await e.onUnauthorized();
      if (typeof H == "string" && H)
        K.Authorization = `Bearer ${H}`;
      else {
        const L = e.tokenProvider();
        L && (K.Authorization = `Bearer ${L}`);
      }
      E = await t(S, { ...j, headers: K, signal: R });
    }
    return E;
  }
  function l(S, j) {
    const R = new Error(`${S}: HTTP ${j}`);
    return R.status = j, R;
  }
  async function d(S) {
    if (s) throw new Error("Embed transport disposed");
    const j = e.getSessionId();
    return j || (i || (i = (async () => {
      var L, U;
      const R = e.sessionsPath || "/chat/sessions", K = await a(o(R), {
        method: "POST",
        body: JSON.stringify(((L = e.createSessionPayload) == null ? void 0 : L.call(e)) || { context: (U = e.getContext) == null ? void 0 : U.call(e) })
      }, S);
      if (!K.ok)
        throw l("Embed session create failed", K.status);
      const _ = await K.json().catch(() => ({})), E = _.data && typeof _.data == "object" ? _.data : _, H = E.sessionId ? String(E.sessionId) : E.id ? String(E.id) : void 0;
      if (!H) throw new Error("Embed session create returned no sessionId");
      return e.setSessionId(H), H;
    })().finally(() => {
      i = null;
    })), i);
  }
  async function u(S) {
    return e.setSessionId(void 0), d(S);
  }
  async function* h(S, j, R) {
    if (!S.body) throw new Error("Embed stream has no body");
    for await (const K of hc(S.body, { signal: R })) {
      const _ = fo(K.event, K.data, { sessionId: j });
      for (const E of bc(_))
        yield E;
    }
  }
  function* m(S, j) {
    yield ve("turn.started", {}, { sessionId: j }), S.answer && (yield ve("message.delta", { text: String(S.answer) }, { sessionId: j }));
    const R = S.metadata && typeof S.metadata == "object" && !Array.isArray(S.metadata) ? { ...S.metadata } : void 0;
    S.uiRequest ? (yield ve("ui.requested", { uiRequest: S.uiRequest }, { sessionId: j }), yield ve("turn.waiting", {
      answer: S.answer,
      uiRequest: S.uiRequest,
      sessionId: j,
      result: S,
      metadata: R,
      intentType: S.intentType,
      toolCalls: S.toolCalls
    }, { sessionId: j })) : yield ve("turn.completed", {
      answer: S.answer,
      sessionId: j,
      result: S,
      metadata: R,
      intentType: S.intentType,
      toolCalls: S.toolCalls
    }, { sessionId: j });
  }
  async function* k(S, j, R, K = !0) {
    var U, ie;
    const _ = ((U = e.messagesJsonPath) == null ? void 0 : U.call(e, S)) || `/chat/sessions/${encodeURIComponent(S)}/messages`, E = await a(o(_), {
      method: "POST",
      body: JSON.stringify({
        message: j.message,
        context: (ie = e.getContext) == null ? void 0 : ie.call(e),
        interactionId: j.interactionId,
        uiSubmit: j.uiSubmit
      })
    }, R);
    if (E.status === 401 && K) {
      const ne = await u(R);
      yield* k(ne, j, R, !1);
      return;
    }
    if (!E.ok)
      throw l("Embed message failed", E.status);
    const H = await E.json().catch(() => ({})), L = H.data && typeof H.data == "object" ? H.data : H;
    yield* m(L, S);
  }
  async function* I(S, j, R, K = !0) {
    var L, U;
    const _ = ((L = e.messagesPath) == null ? void 0 : L.call(e, S)) || `/chat/sessions/${encodeURIComponent(S)}/messages/stream`, E = await a(o(_), {
      method: "POST",
      headers: { Accept: "text/event-stream" },
      body: JSON.stringify({
        message: j.message,
        context: (U = e.getContext) == null ? void 0 : U.call(e),
        interactionId: j.interactionId,
        uiSubmit: j.uiSubmit
      })
    }, R);
    if (E.status === 401 && K) {
      const ie = await u(R);
      yield* I(ie, j, R, !1);
      return;
    }
    const H = E.headers.get("content-type") || "";
    if (!E.ok || !E.body || !H.includes("text/event-stream")) {
      if (hs({
        status: E.status,
        bytesOrEventsConsumed: !1,
        aborted: R == null ? void 0 : R.aborted
      })) {
        yield* k(S, j, R, K);
        return;
      }
      throw l("Embed stream failed", E.status);
    }
    yield ve("turn.started", {}, { sessionId: S }), yield* h(E, S, R);
  }
  async function* y(S, j) {
    if (s) return;
    const R = new AbortController();
    r.add(R);
    const K = () => R.abort();
    j == null || j.addEventListener("abort", K);
    try {
      const _ = await d(R.signal);
      if (!n) {
        yield* k(_, S, R.signal);
        return;
      }
      yield* I(_, S, R.signal);
    } catch (_) {
      if (Kn(_) || R.signal.aborted) {
        yield ve("turn.cancelled", {}, { sessionId: e.getSessionId() });
        return;
      }
      throw _;
    } finally {
      j == null || j.removeEventListener("abort", K), r.delete(R);
    }
  }
  async function* z(S, j, R, K, _, E) {
    var ne, he;
    const H = ((ne = e.interactionSubmitPath) == null ? void 0 : ne.call(e, S, j)) || `/chat/sessions/${encodeURIComponent(S)}/interactions/${encodeURIComponent(j)}/submit`, L = await a(o(H), {
      method: "POST",
      body: JSON.stringify({
        action: R,
        values: K,
        idempotencyKey: _,
        context: (he = e.getContext) == null ? void 0 : he.call(e)
      })
    }, E);
    if (!L.ok)
      throw l("Embed interaction submit failed", L.status);
    const U = await L.json().catch(() => ({})), ie = U.data && typeof U.data == "object" ? U.data : U;
    yield* m(ie, S);
  }
  async function* J(S, j, R, K) {
    var U, ie;
    if (s) return;
    const _ = e.getSessionId();
    if (!_) throw new Error("No embed session");
    const E = _c("embed", S);
    if (!n) {
      yield* z(_, S, j, R, E, K);
      return;
    }
    const H = ((U = e.interactionSubmitStreamPath) == null ? void 0 : U.call(e, _, S)) || `/chat/sessions/${encodeURIComponent(_)}/interactions/${encodeURIComponent(S)}/submit/stream`;
    let L = !1;
    try {
      const ne = await a(o(H), {
        method: "POST",
        headers: { Accept: "text/event-stream" },
        body: JSON.stringify({
          action: j,
          values: R,
          idempotencyKey: E,
          context: (ie = e.getContext) == null ? void 0 : ie.call(e)
        })
      }, K), he = ne.headers.get("content-type") || "";
      if (ne.ok && ne.body && he.includes("text/event-stream")) {
        yield ve("turn.started", {}, { sessionId: _ }), L = !0, yield* h(ne, _, K);
        return;
      }
      if (hs({
        status: ne.status,
        bytesOrEventsConsumed: !1,
        aborted: K == null ? void 0 : K.aborted
      })) {
        yield* z(_, S, j, R, E, K);
        return;
      }
      throw l("Embed interaction stream failed", ne.status);
    } catch (ne) {
      if (Kn(ne) || K != null && K.aborted) {
        yield ve("turn.cancelled", {}, { sessionId: _ });
        return;
      }
      if (hs({
        status: ne == null ? void 0 : ne.status,
        bytesOrEventsConsumed: L,
        aborted: K == null ? void 0 : K.aborted,
        error: ne
      })) {
        yield* z(_, S, j, R, E, K);
        return;
      }
      throw ne;
    }
  }
  return {
    kind: "embed",
    capabilities: {
      eventStreaming: n,
      tokenStreaming: !0,
      abort: !0,
      restore: !1,
      structuredInitialInput: !1,
      pageActions: !0
    },
    startTurn: y,
    resumeInteraction: J,
    /** 供 facade / 测试显式预热会话（带去重） */
    ensureSession: d,
    async cancelTurn() {
      for (const S of r) S.abort();
      r.clear();
    },
    dispose() {
      s = !0, i = null;
      for (const S of r) S.abort();
      r.clear();
    }
  };
}
const Ic = /* @__PURE__ */ new Map(), Ac = {
  form: "form",
  text_question: "form",
  select: "select",
  choice: "select",
  multi_select: "select",
  confirm: "confirm",
  table: "table",
  detail: "detail",
  card: "output_card",
  report: "output_card",
  summary_card: "summary_card",
  list_card: "list_card",
  output_card: "output_card",
  page_action: "page_action",
  custom: "custom"
};
function xc(e) {
  const t = String(e || "custom").toLowerCase();
  return Ac[t] || "custom";
}
function Cc(e) {
  if (e)
    return Ic.get(e);
}
const kc = /* @__PURE__ */ new Set(["__proto__", "prototype", "constructor"]), Ec = /* @__PURE__ */ new Set(["neutral", "success", "warning", "danger", "info"]);
function $t(e) {
  return !e || typeof e != "object" || Array.isArray(e) ? null : e;
}
function ze(e) {
  return e == null ? void 0 : String(e).trim() || void 0;
}
function ho(e, t, n, s) {
  const r = typeof e == "number" ? e : Number(e);
  return Number.isFinite(r) ? Math.min(s, Math.max(n, Math.floor(r))) : t;
}
function Tc(e) {
  const t = e.trim().replace(/^\$\.?/, "").replace(/\[\s*["']?([^\]"']+)["']?\s*\]/g, ".$1").replace(/^\./, "");
  if (!t) return [];
  const n = t.split(".").filter(Boolean);
  return n.some((s) => kc.has(s)) ? [] : n;
}
function St(e, t) {
  if (!(t != null && t.trim())) return e;
  const n = Tc(t);
  if (!n.length) return;
  let s = e;
  for (const r of n) {
    if (Array.isArray(s)) {
      const o = Number(r);
      if (!Number.isInteger(o) || o < 0 || o >= s.length) return;
      s = s[o];
      continue;
    }
    const i = $t(s);
    if (!i || !Object.prototype.hasOwnProperty.call(i, r)) return;
    s = i[r];
  }
  return s;
}
function Pc(e) {
  var n;
  const t = $t(e.schema);
  return t || $t((n = e.extension) == null ? void 0 : n.renderSchema) || {};
}
function Rc(e, t) {
  const n = ze(t.itemsPath ?? t.dataPath), s = n ? St(e, n) : void 0, r = Array.isArray(s) ? s : Array.isArray(e) ? e : [
    "records",
    "items",
    "rows",
    "list",
    "data.records",
    "data.items",
    "data.rows",
    "data.list",
    "data"
  ].map((o) => St(e, o)).find(Array.isArray);
  if (Array.isArray(r))
    return r.map((o) => $t(o) || { value: o });
  const i = $t(e);
  return i ? [i] : [];
}
function $c(e, t, n) {
  const s = ze(t.totalPath ?? t.totalField), r = s ? [St(e, s)] : ["total", "totalCount", "data.total", "data.totalCount", "pagination.total"].map((i) => St(e, i));
  for (const i of r) {
    const o = Number(i);
    if (Number.isFinite(o) && o >= 0) return Math.floor(o);
  }
  return n;
}
function er(e) {
  const t = $t(e);
  return t ? Object.fromEntries(
    Object.entries(t).filter(([, n]) => n != null).map(([n, s]) => [n, String(s)])
  ) : {};
}
function Mc(e) {
  const t = er(e);
  return Object.fromEntries(
    Object.entries(t).map(([n, s]) => [n, s.toLowerCase()]).filter((n) => Ec.has(n[1]))
  );
}
function Oc(e) {
  return Array.isArray(e.fields) ? e.fields.flatMap((t) => {
    if (typeof t == "string" && t.trim())
      return [{
        key: t.trim(),
        label: t.trim(),
        valueMap: {},
        separator: "、",
        hideWhenEmpty: !1
      }];
    const n = $t(t), s = ze((n == null ? void 0 : n.key) ?? (n == null ? void 0 : n.field) ?? (n == null ? void 0 : n.name));
    return !n || !s || n.hidden === !0 ? [] : [{
      key: s,
      label: ze(n.label ?? n.title) || s,
      valueMap: er(n.valueMap ?? n.labels),
      maxItems: n.maxItems == null ? void 0 : ho(n.maxItems, 3, 1, 20),
      separator: ze(n.separator) || "、",
      hideWhenEmpty: n.hideWhenEmpty === !0
    }];
  }) : [];
}
function qc(e) {
  const t = $t(e.status) || {}, n = ze(t.field ?? e.statusField ?? e.badgeField);
  return n ? {
    field: n,
    valueMap: er(t.valueMap ?? t.labels ?? e.statusMap),
    toneMap: Mc(t.toneMap ?? t.tones ?? e.statusToneMap)
  } : null;
}
function po(e, t) {
  const n = String(e);
  return t[n] ?? t[n.toLowerCase()];
}
function un(e, t) {
  if (e == null || e === "") return "-";
  const n = po(e, (t == null ? void 0 : t.valueMap) || {});
  if (n != null) return n;
  if (Array.isArray(e)) {
    const s = (t == null ? void 0 : t.maxItems) ?? e.length, r = e.slice(0, s).map((o) => un(o)), i = e.length - r.length;
    return `${r.join((t == null ? void 0 : t.separator) || "、")}${i > 0 ? `… +${i}` : ""}`;
  }
  if (typeof e == "object")
    try {
      return JSON.stringify(e);
    } catch {
      return String(e);
    }
  return String(e);
}
function jc(e) {
  for (const n of ["title", "name", "displayName", "label"])
    if (ze(e[n])) return n;
  const t = Object.keys(e).find((n) => /(?:name|title|label)$/i.test(n) && ze(e[n]));
  return t || Object.keys(e).find((n) => typeof e[n] == "string" && ze(e[n]));
}
function Nc(e, t) {
  return Object.keys(e).filter((n) => !t.has(n)).slice(0, 4).map((n) => ({
    key: n,
    label: n,
    valueMap: {},
    separator: "、",
    hideWhenEmpty: !1
  }));
}
function Dc(e, t, n) {
  const s = t ? St(e, t) : e.id ?? e.key ?? e.code;
  return s == null || s === "" ? `list-item-${n}` : String(s);
}
function Fc(e, t) {
  if (!t) return;
  const n = St(e, t.field);
  if (!(n == null || n === ""))
    return {
      label: po(n, t.valueMap) || un(n),
      tone: t.toneMap[String(n)] ?? t.toneMap[String(n).toLowerCase()] ?? "neutral"
    };
}
function Kc(e) {
  const t = Pc(e), n = Rc(e.data, t), s = Oc(t), r = qc(t), i = ze(t.titleField), o = ze(t.subtitleField), a = ze(t.itemKey ?? t.rowKey), l = n.map((d, u) => {
    const h = i || jc(d), m = new Set(
      [h, o, r == null ? void 0 : r.field, a].filter((I) => !!I)
    ), k = s.length ? s : Nc(d, m);
    return {
      key: Dc(d, a, u),
      title: h ? un(St(d, h)) : `#${u + 1}`,
      subtitle: o ? un(St(d, o)) : void 0,
      status: Fc(d, r),
      fields: k.flatMap((I) => {
        const y = St(d, I.key);
        return I.hideWhenEmpty && (y == null || y === "") ? [] : [{ key: I.key, label: I.label, value: un(y, I) }];
      })
    };
  });
  return {
    items: l,
    total: $c(e.data, t, l.length),
    initialVisibleCount: ho(t.initialVisibleCount, 5, 1, 50),
    showCount: t.showCount !== !1,
    emptyText: ze(t.emptyText) || "暂无数据"
  };
}
const Lc = ["aria-label"], Uc = {
  key: 0,
  class: "reachai-interaction__header"
}, Vc = { key: 0 }, Hc = {
  key: 1,
  class: "reachai-interaction__badge"
}, Bc = {
  key: 1,
  class: "reachai-interaction__message"
}, Wc = {
  key: 2,
  class: "reachai-interaction__state",
  "aria-live": "polite"
}, zc = { key: 0 }, Jc = ["onUpdate:modelValue", "disabled"], Gc = ["onUpdate:modelValue", "disabled", "placeholder"], Yc = ["value", "multiple", "disabled", "onChange"], Xc = ["value"], Qc = ["onUpdate:modelValue", "disabled"], Zc = ["value", "disabled", "placeholder", "onInput"], eu = ["value", "disabled", "placeholder", "onInput"], tu = {
  key: 0,
  class: "reachai-interaction__actions"
}, nu = ["disabled"], su = ["disabled"], ru = {
  key: 5,
  class: "reachai-interaction__confirm"
}, iu = {
  key: 0,
  class: "reachai-interaction__actions"
}, ou = ["disabled"], au = ["disabled"], lu = ["disabled"], cu = {
  key: 6,
  class: "reachai-interaction__choice"
}, uu = ["value", "disabled"], fu = ["name", "value", "disabled"], du = {
  key: 0,
  class: "reachai-interaction__actions"
}, hu = ["disabled"], pu = ["disabled"], gu = {
  key: 7,
  class: "reachai-interaction__table-wrap"
}, mu = { class: "reachai-interaction__table" }, yu = {
  key: 8,
  class: "reachai-interaction__detail"
}, bu = {
  key: 0,
  class: "reachai-interaction__actions"
}, _u = ["disabled", "onClick"], vu = {
  key: 9,
  class: "reachai-interaction__list"
}, Su = {
  key: 0,
  class: "reachai-interaction__list-summary"
}, wu = {
  key: 1,
  class: "reachai-interaction__empty"
}, Iu = { class: "reachai-interaction__list-item-header" }, Au = { class: "reachai-interaction__list-title" }, xu = { key: 0 }, Cu = {
  key: 0,
  class: "reachai-interaction__list-fields"
}, ku = ["aria-expanded"], Eu = {
  key: 10,
  class: "reachai-interaction__page-action"
}, Tu = { class: "reachai-interaction__actions" }, Pu = ["disabled"], Ru = ["disabled"], $u = {
  key: 11,
  class: "reachai-interaction__custom"
}, Mu = { class: "reachai-interaction__warn" }, Ou = { class: "reachai-interaction__actions" }, qu = ["disabled"], ju = ["disabled"], Nu = {
  key: 12,
  class: "reachai-interaction__error",
  role: "alert"
}, Du = {
  key: 13,
  class: "reachai-interaction__actions"
}, Fu = /* @__PURE__ */ ht({
  __name: "UnifiedInteractionRenderer",
  props: {
    request: {},
    state: {},
    errorMessage: {},
    disabled: { type: Boolean }
  },
  emits: ["submit", "cancel", "action"],
  setup(e, { emit: t }) {
    const n = e, s = t, r = le(() => xc(n.request.component)), i = le(() => n.state || "waiting"), o = le(
      () => n.disabled || i.value === "submitting" || i.value === "resolved" || i.value === "expired" || i.value === "cancelled"
    ), a = le(() => `reachai-choice-${n.request.interactionId || "default"}`), l = /* @__PURE__ */ Ee(""), d = /* @__PURE__ */ Ee(!1), u = le(() => n.request.actions || []), h = le(() => {
      var x;
      return ((x = n.request.behavior) == null ? void 0 : x.readonly) === !0 ? !0 : (/* @__PURE__ */ new Set(["table", "detail", "summary_card", "list_card", "output_card", "card", "report"])).has(r.value) && !u.value.length;
    }), m = le(() => !h.value), k = le(() => {
      switch (i.value) {
        case "submitting":
          return "提交中…";
        case "resolved":
          return "已提交";
        case "failed":
          return "提交失败";
        case "expired":
          return "已过期";
        case "cancelled":
          return "已取消";
        default:
          return "";
      }
    }), I = /* @__PURE__ */ Gn({}), y = /* @__PURE__ */ Ee(null), z = /* @__PURE__ */ Ee([]), J = /* @__PURE__ */ Ee(null);
    function S(v, x) {
      return v == null ? x.type === "boolean" ? !1 : x.type === "multi_select" ? [] : "" : typeof v == "string" || typeof v == "number" || typeof v == "boolean" ? v : Array.isArray(v) ? v.map(String) : String(v);
    }
    Dt(
      () => n.request,
      (v) => {
        var p, c, f, g;
        l.value = "", d.value = !1, Object.keys(I).forEach((w) => delete I[w]);
        for (const w of v.fields || []) {
          const A = (p = v.prefilled) == null ? void 0 : p[w.key];
          I[w.key] = S(A, w);
        }
        const x = (c = v.fields) == null ? void 0 : c[0], G = x == null ? void 0 : x.key, b = G && ((f = v.prefilled) == null ? void 0 : f[G]) !== void 0 ? v.prefilled[G] : (g = v.prefilled) == null ? void 0 : g.value;
        if (v.component === "multi_select") {
          Array.isArray(b) ? z.value = [...b] : b == null ? z.value = [] : z.value = [b], y.value = null;
          return;
        }
        b !== void 0 && (typeof b == "string" || typeof b == "number" || typeof b == "boolean" ? y.value = b : b == null ? y.value = null : y.value = String(b));
      },
      { immediate: !0, deep: !0 }
    );
    function j(v) {
      var x;
      return v.type === "select" || v.type === "multi_select" || !!((x = v.options) != null && x.length);
    }
    function R(v) {
      const x = I[v.key];
      return v.type === "multi_select" ? Array.isArray(x) ? x.map(String) : [] : typeof x == "string" || typeof x == "number" ? x : x == null ? void 0 : String(x);
    }
    function K(v, x) {
      const G = x.target;
      v.type === "multi_select" ? I[v.key] = Array.from(G.selectedOptions).map((b) => b.value) : I[v.key] = G.value;
    }
    const _ = le(() => {
      var G, b;
      const v = (G = n.request.fields) == null ? void 0 : G[0];
      if ((b = v == null ? void 0 : v.options) != null && b.length) return v.options;
      const x = n.request.data;
      return Array.isArray(x) ? x.map((p, c) => {
        if (p && typeof p == "object") {
          const f = p;
          return { value: f.value ?? f.id ?? c, label: String(f.label ?? f.name ?? f.value ?? c) };
        }
        return { value: p, label: String(p) };
      }) : [];
    }), E = le(() => {
      const v = n.request.data;
      return Array.isArray(v) ? v.map((x) => x && typeof x == "object" ? x : { value: x }) : v && typeof v == "object" ? [v] : n.request.summary ? [n.request.summary] : [];
    }), H = le(() => {
      const v = ie(n.request);
      if (v.length) return v;
      const x = E.value[0];
      return x ? Object.keys(x).map((G) => ({ key: G, label: G })) : [];
    }), L = le(() => Kc(n.request)), U = le(() => d.value ? L.value.items : L.value.items.slice(0, L.value.initialVisibleCount));
    function ie(v) {
      var G, b;
      const x = [
        (G = v.schema) == null ? void 0 : G.columns,
        (b = v.extension) == null ? void 0 : b.columns,
        v.data && typeof v.data == "object" && !Array.isArray(v.data) ? v.data.columns : void 0
      ];
      for (const p of x)
        if (!(!Array.isArray(p) || !p.length))
          return p.map((c, f) => {
            if (typeof c == "string") return { key: c, label: c };
            if (c && typeof c == "object") {
              const g = c, w = String(g.key ?? g.field ?? g.name ?? f);
              return { key: w, label: String(g.label ?? g.title ?? w) };
            }
            return { key: String(f), label: String(c) };
          });
      return [];
    }
    const ne = le(() => {
      const v = n.request.summary || n.request.data || {};
      return Array.isArray(v) ? v.map((x, G) => ({
        key: String(G),
        label: `#${G + 1}`,
        value: x
      })) : Object.entries(v || {}).map(([x, G]) => ({ key: x, label: x, value: G }));
    }), he = le(() => {
      var x;
      const v = (x = n.request.extension) == null ? void 0 : x.pageActionRequest;
      return v && typeof v == "object" ? v : n.request.data && typeof n.request.data == "object" ? n.request.data : {};
    }), te = le(
      () => String(he.value.title || n.request.title || "页面动作")
    ), re = le(
      () => {
        var v;
        return (v = n.request.extension) != null && v.rendererKey ? String(n.request.extension.rendererKey) : "";
      }
    ), ue = le(() => {
      const v = re.value;
      if (!v) return null;
      const x = Cc(v);
      if (!x) return null;
      const G = x({
        request: n.request,
        state: i.value,
        disabled: o.value,
        onSubmit: (b, p) => _e(b, p),
        onCancel: () => q()
      });
      return G ? /* @__PURE__ */ ht({
        name: `ReachAiCustomInteraction_${v}`,
        setup() {
          return () => vl(G);
        }
      }) : null;
    });
    function oe(v) {
      if (v == null) return "-";
      if (typeof v == "string") return v;
      try {
        return JSON.stringify(v);
      } catch {
        return String(v);
      }
    }
    function se(v) {
      return String(v.key || v.action || "submit");
    }
    function Ce(v) {
      return String(v.label || v.key || v.action || "提交");
    }
    function Je(v) {
      return v.values && typeof v.values == "object" ? v.values : { ...v };
    }
    function Le(v) {
      return v.type === "primary" || se(v) === "confirm" || se(v) === "submit";
    }
    function _e(v, x) {
      o.value && i.value !== "failed" || (J.value = { action: v, values: x }, s("submit", v, x), s("action", v, x));
    }
    function nt(v) {
      for (const x of n.request.fields || [])
        if (x.required) {
          const G = I[x.key];
          if (G === "" || G == null || Array.isArray(G) && !G.length) {
            l.value = `请填写必填项：${x.label || x.key}`;
            return;
          }
        }
      l.value = "", _e(v, { ...I });
    }
    function kt() {
      var v, x;
      if (n.request.component === "multi_select") {
        if (!z.value.length && ((v = n.request.fields) != null && v.some((G) => G.required))) {
          l.value = "请至少选择一项";
          return;
        }
        l.value = "", _e("choose", { value: [...z.value] });
      } else {
        if ((y.value === null || y.value === "") && ((x = n.request.fields) != null && x.some((G) => G.required))) {
          l.value = "请选择一项";
          return;
        }
        l.value = "", _e("choose", { value: y.value });
      }
    }
    function q() {
      o.value || (s("cancel"), s("action", "cancel", {}));
    }
    function Q() {
      J.value && (s("submit", J.value.action, J.value.values), s("action", J.value.action, J.value.values));
    }
    return (v, x) => {
      var G, b;
      return T(), $("div", {
        class: Ke(["reachai-interaction", [
          `reachai-interaction--${r.value}`,
          `reachai-interaction--${i.value}`,
          { "is-disabled": o.value }
        ]]),
        role: "region",
        "aria-label": e.request.title || e.request.component || "interaction"
      }, [
        e.request.title || (G = e.request.missing) != null && G.length ? (T(), $("header", Uc, [
          e.request.title ? (T(), $("strong", Vc, X(e.request.title), 1)) : Z("", !0),
          (b = e.request.missing) != null && b.length ? (T(), $("span", Hc, "待补充 " + X(e.request.missing.length) + " 项", 1)) : Z("", !0)
        ])) : Z("", !0),
        e.request.message && r.value !== "form" ? (T(), $("p", Bc, X(e.request.message), 1)) : Z("", !0),
        k.value ? (T(), $("div", Wc, X(k.value), 1)) : Z("", !0),
        ue.value ? (T(), pt(Oa(ue.value), {
          key: 3,
          class: "reachai-interaction__custom-host"
        })) : r.value === "form" ? (T(), $("form", {
          key: 4,
          class: "reachai-interaction__form",
          onSubmit: x[0] || (x[0] = oo((p) => nt("submit"), ["prevent"]))
        }, [
          (T(!0), $(be, null, Fe(e.request.fields || [], (p) => (T(), $("label", {
            key: p.key,
            class: "reachai-interaction__field"
          }, [
            D("span", null, [
              mn(X(p.label), 1),
              p.required ? (T(), $("em", zc, "*")) : Z("", !0)
            ]),
            p.type === "boolean" ? Vt((T(), $("input", {
              key: 0,
              "onUpdate:modelValue": (c) => I[p.key] = c,
              type: "checkbox",
              disabled: o.value
            }, null, 8, Jc)), [
              [Kr, I[p.key]]
            ]) : p.type === "number" || p.type === "integer" ? Vt((T(), $("input", {
              key: 1,
              "onUpdate:modelValue": (c) => I[p.key] = c,
              type: "number",
              disabled: o.value,
              placeholder: p.placeholder
            }, null, 8, Gc)), [
              [
                ks,
                I[p.key],
                void 0,
                { number: !0 }
              ]
            ]) : j(p) ? (T(), $("select", {
              key: 2,
              value: R(p),
              multiple: p.type === "multi_select",
              disabled: o.value,
              onChange: (c) => K(p, c)
            }, [
              (T(!0), $(be, null, Fe(p.options || [], (c) => (T(), $("option", {
                key: String(c.value),
                value: c.value
              }, X(c.label), 9, Xc))), 128))
            ], 40, Yc)) : p.type === "date" ? Vt((T(), $("input", {
              key: 3,
              "onUpdate:modelValue": (c) => I[p.key] = c,
              type: "date",
              disabled: o.value
            }, null, 8, Qc)), [
              [ks, I[p.key]]
            ]) : p.type === "textarea" || p.type === "object" || p.type === "array" ? (T(), $("textarea", {
              key: 4,
              value: String(I[p.key] ?? ""),
              rows: "3",
              disabled: o.value,
              placeholder: p.placeholder,
              onInput: (c) => I[p.key] = c.target.value
            }, null, 40, Zc)) : (T(), $("input", {
              key: 5,
              value: String(I[p.key] ?? ""),
              type: "text",
              disabled: o.value,
              placeholder: p.placeholder,
              onInput: (c) => I[p.key] = c.target.value
            }, null, 40, eu))
          ]))), 128)),
          m.value ? (T(), $("div", tu, [
            D("button", {
              type: "button",
              disabled: o.value,
              onClick: q
            }, "取消", 8, nu),
            D("button", {
              type: "submit",
              class: "is-primary",
              disabled: o.value
            }, "提交", 8, su)
          ])) : Z("", !0)
        ], 32)) : r.value === "confirm" ? (T(), $("div", ru, [
          D("p", null, X(e.request.message || "请确认是否继续。"), 1),
          m.value ? (T(), $("div", iu, [
            D("button", {
              type: "button",
              disabled: o.value,
              onClick: q
            }, "取消", 8, ou),
            D("button", {
              type: "button",
              disabled: o.value,
              onClick: x[1] || (x[1] = (p) => _e("reject", { confirm: !1 }))
            }, "拒绝", 8, au),
            D("button", {
              type: "button",
              class: "is-primary",
              disabled: o.value,
              onClick: x[2] || (x[2] = (p) => _e("confirm", { confirm: !0 }))
            }, "确认", 8, lu)
          ])) : Z("", !0)
        ])) : r.value === "select" ? (T(), $("div", cu, [
          (T(!0), $(be, null, Fe(_.value, (p) => (T(), $("label", {
            key: String(p.value),
            class: "reachai-interaction__option"
          }, [
            e.request.component === "multi_select" ? Vt((T(), $("input", {
              key: 0,
              "onUpdate:modelValue": x[3] || (x[3] = (c) => z.value = c),
              type: "checkbox",
              value: p.value,
              disabled: o.value
            }, null, 8, uu)), [
              [Kr, z.value]
            ]) : Vt((T(), $("input", {
              key: 1,
              "onUpdate:modelValue": x[4] || (x[4] = (c) => y.value = c),
              type: "radio",
              name: a.value,
              value: p.value,
              disabled: o.value
            }, null, 8, fu)), [
              [Bl, y.value]
            ]),
            D("span", null, X(p.label), 1)
          ]))), 128)),
          m.value ? (T(), $("div", du, [
            D("button", {
              type: "button",
              disabled: o.value,
              onClick: q
            }, "取消", 8, hu),
            D("button", {
              type: "button",
              class: "is-primary",
              disabled: o.value,
              onClick: kt
            }, "选择", 8, pu)
          ])) : Z("", !0)
        ])) : r.value === "table" ? (T(), $("div", gu, [
          D("table", mu, [
            D("thead", null, [
              D("tr", null, [
                (T(!0), $(be, null, Fe(H.value, (p) => (T(), $("th", {
                  key: p.key
                }, X(p.label), 1))), 128))
              ])
            ]),
            D("tbody", null, [
              (T(!0), $(be, null, Fe(E.value, (p, c) => (T(), $("tr", { key: c }, [
                (T(!0), $(be, null, Fe(H.value, (f) => (T(), $("td", {
                  key: f.key
                }, X(oe(p[f.key])), 1))), 128))
              ]))), 128))
            ])
          ])
        ])) : r.value === "detail" || r.value === "summary_card" || r.value === "output_card" ? (T(), $("div", yu, [
          D("dl", null, [
            (T(!0), $(be, null, Fe(ne.value, (p) => (T(), $("div", {
              key: p.key
            }, [
              D("dt", null, X(p.label), 1),
              D("dd", null, X(oe(p.value)), 1)
            ]))), 128))
          ]),
          m.value && u.value.length ? (T(), $("div", bu, [
            (T(!0), $(be, null, Fe(u.value, (p) => (T(), $("button", {
              key: se(p),
              type: "button",
              class: Ke({ "is-primary": Le(p) }),
              disabled: o.value,
              onClick: (c) => _e(se(p), Je(p))
            }, X(Ce(p)), 11, _u))), 128))
          ])) : Z("", !0)
        ])) : r.value === "list_card" ? (T(), $("div", vu, [
          L.value.showCount ? (T(), $("div", Su, " 共 " + X(L.value.total) + " 条 ", 1)) : Z("", !0),
          L.value.items.length ? Z("", !0) : (T(), $("p", wu, X(L.value.emptyText), 1)),
          (T(!0), $(be, null, Fe(U.value, (p) => (T(), $("article", {
            key: p.key,
            class: "reachai-interaction__list-item"
          }, [
            D("header", Iu, [
              D("div", Au, [
                D("strong", null, X(p.title), 1),
                p.subtitle ? (T(), $("span", xu, X(p.subtitle), 1)) : Z("", !0)
              ]),
              p.status ? (T(), $("span", {
                key: 0,
                class: Ke(["reachai-interaction__status-chip", `is-${p.status.tone}`])
              }, X(p.status.label), 3)) : Z("", !0)
            ]),
            p.fields.length ? (T(), $("dl", Cu, [
              (T(!0), $(be, null, Fe(p.fields, (c) => (T(), $("div", {
                key: c.key
              }, [
                D("dt", null, X(c.label), 1),
                D("dd", null, X(c.value), 1)
              ]))), 128))
            ])) : Z("", !0)
          ]))), 128)),
          L.value.items.length > L.value.initialVisibleCount ? (T(), $("button", {
            key: 2,
            type: "button",
            class: "reachai-interaction__list-toggle",
            "aria-expanded": d.value,
            onClick: x[5] || (x[5] = (p) => d.value = !d.value)
          }, X(d.value ? "收起" : `展开剩余 ${L.value.items.length - L.value.initialVisibleCount} 条`), 9, ku)) : Z("", !0)
        ])) : r.value === "page_action" ? (T(), $("div", Eu, [
          D("p", null, X(te.value), 1),
          D("dl", null, [
            D("div", null, [
              x[8] || (x[8] = D("dt", null, "actionKey", -1)),
              D("dd", null, X(he.value.actionKey || "-"), 1)
            ]),
            D("div", null, [
              x[9] || (x[9] = D("dt", null, "requestId", -1)),
              D("dd", null, X(he.value.requestId || e.request.interactionId || "-"), 1)
            ]),
            D("div", null, [
              x[10] || (x[10] = D("dt", null, "args", -1)),
              D("dd", null, X(oe(he.value.args || {})), 1)
            ])
          ]),
          D("div", Tu, [
            he.value.confirm ? (T(), $("button", {
              key: 0,
              type: "button",
              disabled: o.value,
              onClick: q
            }, "取消", 8, Pu)) : Z("", !0),
            D("button", {
              type: "button",
              class: "is-primary",
              disabled: o.value,
              onClick: x[6] || (x[6] = (p) => _e("page_action_ack", { requestId: he.value.requestId, actionKey: he.value.actionKey }))
            }, " 已收到 ", 8, Ru)
          ])
        ])) : (T(), $("div", $u, [
          D("p", Mu, X(re.value ? `自定义渲染器未在宿主注册：${re.value}` : `未注册的交互组件：${e.request.component || "unknown"}`), 1),
          D("pre", null, X(oe(e.request.data ?? e.request.summary ?? {})), 1),
          D("div", Ou, [
            D("button", {
              type: "button",
              disabled: o.value,
              onClick: q
            }, "取消", 8, qu),
            D("button", {
              type: "button",
              class: "is-primary",
              disabled: o.value,
              onClick: x[7] || (x[7] = (p) => _e("submit", {}))
            }, "按原始值提交", 8, ju)
          ])
        ])),
        l.value || e.errorMessage ? (T(), $("p", Nu, X(l.value || e.errorMessage), 1)) : Z("", !0),
        i.value === "failed" ? (T(), $("div", Du, [
          D("button", {
            type: "button",
            class: "is-primary",
            onClick: Q
          }, "重试")
        ])) : Z("", !0)
      ], 10, Lc);
    };
  }
}), Kt = (e, t) => {
  const n = e.__vccOpts || e;
  for (const [s, r] of t)
    n[s] = r;
  return n;
}, Ku = /* @__PURE__ */ Kt(Fu, [["__scopeId", "data-v-2a5d0f29"]]), Lu = ["data-type"], Uu = {
  key: 0,
  class: "reachai-block__caret",
  "aria-hidden": "true"
}, Vu = {
  key: 2,
  class: "reachai-block__page-action"
}, Hu = { key: 0 }, Bu = ["data-level"], Wu = {
  key: 4,
  class: "reachai-block__error",
  role: "alert"
}, zu = /* @__PURE__ */ ht({
  __name: "ConversationBlockRenderer",
  props: {
    block: {}
  },
  emits: ["interaction-submit", "interaction-cancel", "retry"],
  setup(e, { emit: t }) {
    const n = t;
    function s(i, o, a) {
      i.type === "interaction" && n("interaction-submit", i.request.interactionId, o, a);
    }
    function r(i) {
      i.type === "interaction" && n("interaction-cancel", i.request.interactionId);
    }
    return (i, o) => (T(), $("div", {
      class: "reachai-block",
      "data-type": e.block.type
    }, [
      e.block.type === "text" ? (T(), $("div", {
        key: 0,
        class: Ke(["reachai-block__text", { "is-streaming": e.block.status === "streaming" }])
      }, [
        mn(X(e.block.text) + " ", 1),
        e.block.status === "streaming" ? (T(), $("span", Uu)) : Z("", !0)
      ], 2)) : e.block.type === "interaction" ? (T(), pt(Ku, {
        key: 1,
        request: e.block.request,
        state: e.block.state,
        "error-message": e.block.errorMessage,
        onSubmit: o[0] || (o[0] = (a, l) => s(e.block, a, l)),
        onCancel: o[1] || (o[1] = (a) => r(e.block))
      }, null, 8, ["request", "state", "error-message"])) : e.block.type === "page_action" ? (T(), $("div", Vu, [
        D("strong", null, X(e.block.title || e.block.actionKey), 1),
        D("span", null, X(e.block.status), 1),
        e.block.message ? (T(), $("p", Hu, X(e.block.message), 1)) : Z("", !0)
      ])) : e.block.type === "notice" ? (T(), $("div", {
        key: 3,
        class: "reachai-block__notice",
        "data-level": e.block.level || "info"
      }, X(e.block.text), 9, Bu)) : e.block.type === "error" ? (T(), $("div", Wu, [
        mn(X(e.block.text) + " ", 1),
        e.block.retryable ? (T(), $("button", {
          key: 0,
          type: "button",
          onClick: o[2] || (o[2] = (a) => i.$emit("retry"))
        }, "重试")) : Z("", !0)
      ])) : Z("", !0)
    ], 8, Lu));
  }
}), zr = /* @__PURE__ */ Kt(zu, [["__scopeId", "data-v-775b19fc"]]), Ju = ["data-message-id", "data-role", "data-status"], Gu = {
  key: 0,
  class: "reachai-message__user-row"
}, Yu = { class: "reachai-message__user-bubble" }, Xu = {
  key: 0,
  class: "reachai-message__user-avatar",
  "aria-hidden": "true"
}, Qu = {
  key: 1,
  class: "reachai-message__assistant-row"
}, Zu = {
  key: 0,
  class: "reachai-message__prism-avatar",
  "aria-hidden": "true"
}, ef = {
  key: 0,
  class: "reachai-message__card-heading"
}, tf = {
  key: 0,
  class: "reachai-message__thinking-title"
}, nf = {
  key: 1,
  class: "reachai-message__weak-label"
}, sf = {
  key: 2,
  class: "reachai-message__heading-spacer",
  "aria-hidden": "true"
}, rf = ["data-tone"], of = {
  key: 1,
  class: "reachai-message__status-hint"
}, af = {
  key: 2,
  class: "reachai-message__thinking-details"
}, lf = ["aria-expanded"], cf = {
  class: "reachai-message__thinking-chevron",
  "aria-hidden": "true"
}, uf = {
  key: 0,
  class: "reachai-message__thinking-steps"
}, ff = ["data-state"], df = { class: "reachai-message__thinking-step-body" }, hf = { key: 0 }, pf = { class: "reachai-message__body" }, gf = {
  key: 0,
  class: "reachai-message__loading"
}, mf = {
  key: 3,
  class: "reachai-message__meta"
}, yf = /* @__PURE__ */ ht({
  __name: "ConversationMessageItem",
  props: {
    message: {},
    assistantLabel: { default: "" },
    statusHint: { default: "" },
    thinkingPresentation: { default: null },
    showAvatars: { type: Boolean, default: !0 },
    surface: { default: "admin" }
  },
  emits: ["interaction-submit", "interaction-cancel", "retry"],
  setup(e) {
    const t = e, n = /* @__PURE__ */ Ee(!1), s = le(
      () => t.message.role !== "user" && (t.message.status === "pending" || t.message.status === "streaming")
    ), r = le(() => s.value), i = le(() => {
      var h;
      return ((h = t.thinkingPresentation) == null ? void 0 : h.steps) || [];
    });
    Dt(
      () => t.message.id,
      () => {
        n.value = !1;
      }
    ), Dt(s, (h) => {
      h || (n.value = !1);
    });
    const o = le(
      () => !s.value && !!t.assistantLabel && t.message.role === "assistant" && t.surface === "admin"
    ), a = le(() => [
      `reachai-message--${t.message.role}`,
      `reachai-message--${t.message.status}`,
      {
        "reachai-message--thinking": s.value,
        "reachai-message--prism": t.message.role !== "user"
      }
    ]), l = le(() => ({
      "reachai-message__card-shell--thinking": s.value,
      "reachai-message__card-shell--response": !s.value,
      "reachai-message__card-shell--failed": t.message.status === "failed",
      "reachai-message__card-shell--cancelled": t.message.status === "cancelled"
    })), d = le(() => ({
      "reachai-message__card--thinking": s.value,
      "reachai-message__card--response": !s.value,
      [`reachai-message__card--${t.message.status}`]: !0
    })), u = le(() => s.value ? null : t.message.status === "failed" ? { label: "失败", tone: "danger" } : t.message.status === "cancelled" ? { label: "已取消", tone: "warning" } : null);
    return (h, m) => {
      var k;
      return T(), $("article", {
        class: Ke(["reachai-message", a.value]),
        "data-message-id": e.message.id,
        "data-role": e.message.role,
        "data-status": e.message.status
      }, [
        e.message.role === "user" ? (T(), $("div", Gu, [
          D("div", Yu, [
            (T(!0), $(be, null, Fe(e.message.blocks, (I) => (T(), pt(zr, {
              key: I.id,
              block: I,
              onInteractionSubmit: m[0] || (m[0] = (...y) => h.$emit("interaction-submit", ...y)),
              onInteractionCancel: m[1] || (m[1] = (y) => h.$emit("interaction-cancel", y)),
              onRetry: m[2] || (m[2] = (y) => h.$emit("retry"))
            }, null, 8, ["block"]))), 128))
          ]),
          e.showAvatars ? (T(), $("div", Xu, [...m[7] || (m[7] = [
            D("svg", {
              viewBox: "0 0 24 24",
              width: "18",
              height: "18",
              fill: "none",
              stroke: "currentColor",
              "stroke-width": "1.8"
            }, [
              D("circle", {
                cx: "12",
                cy: "8",
                r: "3.5"
              }),
              D("path", {
                d: "M5 19.5c1.2-3.2 3.6-4.8 7-4.8s5.8 1.6 7 4.8",
                "stroke-linecap": "round"
              })
            ], -1)
          ])])) : Z("", !0)
        ])) : (T(), $("div", Qu, [
          e.showAvatars ? (T(), $("div", Zu, [...m[8] || (m[8] = [
            D("span", { class: "reachai-message__prism-avatar-img" }, null, -1)
          ])])) : Z("", !0),
          D("div", {
            class: Ke(["reachai-message__card-shell", l.value])
          }, [
            D("div", {
              class: Ke(["reachai-message__card", d.value])
            }, [
              r.value || o.value || u.value ? (T(), $("header", ef, [
                r.value ? (T(), $("div", tf, [...m[9] || (m[9] = [
                  D("span", {
                    class: "reachai-message__spark",
                    "aria-hidden": "true"
                  }, "✦", -1),
                  D("strong", null, "思考中…", -1),
                  D("span", {
                    class: "reachai-message__thinking-dots",
                    "aria-hidden": "true"
                  }, [
                    D("i"),
                    D("i"),
                    D("i")
                  ], -1)
                ])])) : o.value ? (T(), $("div", nf, X(e.assistantLabel), 1)) : (T(), $("span", sf)),
                u.value ? (T(), $("span", {
                  key: 3,
                  class: "reachai-message__status-capsule",
                  "data-tone": u.value.tone
                }, X(u.value.label), 9, rf)) : Z("", !0)
              ])) : Z("", !0),
              r.value && e.statusHint ? (T(), $("p", of, X(e.statusHint), 1)) : Z("", !0),
              r.value && ((k = e.thinkingPresentation) != null && k.label) ? (T(), $("div", af, [
                D("button", {
                  type: "button",
                  class: "reachai-message__thinking-toggle",
                  "aria-expanded": n.value,
                  onClick: m[3] || (m[3] = (I) => n.value = !n.value)
                }, [
                  D("span", null, X(e.thinkingPresentation.label), 1),
                  D("span", cf, X(n.value ? "▴" : "▾"), 1)
                ], 8, lf),
                n.value && i.value.length ? (T(), $("ul", uf, [
                  (T(!0), $(be, null, Fe(i.value, (I) => (T(), $("li", {
                    key: I.id,
                    class: "reachai-message__thinking-step",
                    "data-state": I.state
                  }, [
                    m[10] || (m[10] = D("span", {
                      class: "reachai-message__thinking-step-mark",
                      "aria-hidden": "true"
                    }, null, -1)),
                    D("div", df, [
                      D("strong", null, X(I.title), 1),
                      I.detail ? (T(), $("p", hf, X(I.detail), 1)) : Z("", !0)
                    ])
                  ], 8, ff))), 128))
                ])) : Z("", !0)
              ])) : Z("", !0),
              D("div", pf, [
                (T(!0), $(be, null, Fe(e.message.blocks, (I) => (T(), pt(zr, {
                  key: I.id,
                  block: I,
                  onInteractionSubmit: m[4] || (m[4] = (...y) => h.$emit("interaction-submit", ...y)),
                  onInteractionCancel: m[5] || (m[5] = (y) => h.$emit("interaction-cancel", y)),
                  onRetry: m[6] || (m[6] = (y) => h.$emit("retry"))
                }, null, 8, ["block"]))), 128)),
                !e.message.blocks.length && s.value && !e.statusHint ? (T(), $("div", gf, " 正在处理 ")) : Z("", !0)
              ]),
              h.$slots.meta ? (T(), $("footer", mf, [
                Pt(h.$slots, "meta", { message: e.message }, void 0)
              ])) : Z("", !0)
            ], 2)
          ], 2)
        ]))
      ], 10, Ju);
    };
  }
}), bf = /* @__PURE__ */ Kt(yf, [["__scopeId", "data-v-05a4c2be"]]), _f = {
  key: 0,
  class: "reachai-message-list__empty"
}, vf = /* @__PURE__ */ ht({
  __name: "ConversationMessageList",
  props: {
    messages: {},
    autoFollow: { type: Boolean, default: !0 },
    assistantLabel: { default: "" },
    resolveStatusHint: {},
    resolveThinkingPresentation: {},
    showAvatars: { type: Boolean, default: !0 },
    surface: { default: "admin" }
  },
  emits: ["interaction-submit", "interaction-cancel", "retry"],
  setup(e, { expose: t }) {
    const n = e, s = /* @__PURE__ */ Ee(null), r = /* @__PURE__ */ Ee(!0), i = /* @__PURE__ */ Ee(!1);
    function o(u) {
      var h;
      return ((h = n.resolveStatusHint) == null ? void 0 : h.call(n, u)) || "";
    }
    function a(u) {
      var h;
      return ((h = n.resolveThinkingPresentation) == null ? void 0 : h.call(n, u)) || null;
    }
    function l() {
      const u = s.value;
      if (!u) return;
      const h = u.scrollHeight - u.scrollTop - u.clientHeight;
      r.value = h < 48, i.value = !r.value;
    }
    function d(u = !1) {
      const h = s.value;
      h && (!u && !r.value || (h.scrollTop = h.scrollHeight, i.value = !1, r.value = !0));
    }
    return Dt(
      () => n.messages,
      async () => {
        n.autoFollow !== !1 && (await Us(), d());
      },
      { deep: !0 }
    ), Bs(() => d(!0)), t({ scrollToBottom: d }), (u, h) => (T(), $("div", {
      ref_key: "listEl",
      ref: s,
      class: "reachai-message-list",
      role: "log",
      "aria-live": "polite",
      onScroll: l
    }, [
      e.messages.length ? Z("", !0) : (T(), $("div", _f, [
        Pt(u.$slots, "empty", {}, () => [
          h[4] || (h[4] = mn("开始对话吧", -1))
        ])
      ])),
      (T(!0), $(be, null, Fe(e.messages, (m) => (T(), pt(bf, {
        key: m.id,
        message: m,
        "assistant-label": e.assistantLabel,
        "status-hint": o(m),
        "thinking-presentation": a(m),
        "show-avatars": e.showAvatars,
        surface: e.surface,
        onInteractionSubmit: h[0] || (h[0] = (...k) => u.$emit("interaction-submit", ...k)),
        onInteractionCancel: h[1] || (h[1] = (k) => u.$emit("interaction-cancel", k)),
        onRetry: h[2] || (h[2] = (k) => u.$emit("retry"))
      }, $i({ _: 2 }, [
        u.$slots["message-meta"] ? {
          name: "meta",
          fn: qn((k) => [
            Pt(u.$slots, "message-meta", eo({ ref_for: !0 }, k), void 0, !0)
          ]),
          key: "0"
        } : void 0
      ]), 1032, ["message", "assistant-label", "status-hint", "thinking-presentation", "show-avatars", "surface"]))), 128)),
      i.value ? (T(), $("button", {
        key: 1,
        type: "button",
        class: "reachai-message-list__jump",
        onClick: h[3] || (h[3] = (m) => d(!0))
      }, " 回到底部 ")) : Z("", !0)
    ], 544));
  }
}), Sf = /* @__PURE__ */ Kt(vf, [["__scopeId", "data-v-3cddb8bb"]]), wf = ["placeholder", "disabled", "aria-label"], If = { class: "reachai-composer__actions" }, Af = { class: "reachai-composer__buttons" }, xf = ["disabled"], Cf = /* @__PURE__ */ ht({
  __name: "ConversationComposer",
  props: {
    placeholder: { default: "输入消息" },
    disabled: { type: Boolean, default: !1 },
    showStop: { type: Boolean, default: !1 }
  },
  emits: ["send", "stop"],
  setup(e, { expose: t, emit: n }) {
    const s = n, r = /* @__PURE__ */ Ee(""), i = /* @__PURE__ */ Ee(null);
    function o() {
      const l = r.value.trim();
      l && (s("send", l), r.value = "");
    }
    function a(l) {
      (l.ctrlKey || l.metaKey) && l.key === "Enter" && (l.preventDefault(), o());
    }
    return t({
      focus() {
        var l;
        (l = i.value) == null || l.focus();
      },
      setValue(l) {
        r.value = l;
      }
    }), (l, d) => (T(), $("form", {
      class: "reachai-composer",
      onSubmit: oo(o, ["prevent"])
    }, [
      Vt(D("textarea", {
        ref_key: "inputEl",
        ref: i,
        "onUpdate:modelValue": d[0] || (d[0] = (u) => r.value = u),
        class: "reachai-composer__input",
        rows: "2",
        placeholder: e.placeholder,
        disabled: e.disabled,
        "aria-label": e.placeholder,
        onKeydown: a
      }, null, 40, wf), [
        [ks, r.value]
      ]),
      D("div", If, [
        d[2] || (d[2] = D("span", { class: "reachai-composer__hint" }, [
          D("kbd", null, "Ctrl"),
          D("b", null, "+"),
          D("kbd", null, "Enter"),
          D("em", null, "发送")
        ], -1)),
        D("div", Af, [
          e.showStop ? (T(), $("button", {
            key: 0,
            type: "button",
            class: "reachai-composer__stop",
            onClick: d[1] || (d[1] = (u) => l.$emit("stop"))
          }, " 停止 ")) : Z("", !0),
          D("button", {
            type: "submit",
            class: Ke(["reachai-composer__send", { "is-busy": e.showStop }]),
            disabled: e.disabled || !r.value.trim()
          }, X(e.showStop ? "思考中" : "发送"), 11, xf)
        ])
      ])
    ], 32));
  }
}), kf = /* @__PURE__ */ Kt(Cf, [["__scopeId", "data-v-fe697210"]]);
function go(e) {
  return `./${e}`;
}
const Ef = go("agent-prism.webp"), Tf = go("conversation-atmosphere.webp"), Pf = ["data-surface"], Rf = {
  key: 0,
  class: "reachai-conversation__header"
}, $f = {
  key: 1,
  class: "reachai-conversation__error",
  role: "alert"
}, Mf = {
  key: 2,
  class: "reachai-conversation__footer"
}, Of = /* @__PURE__ */ ht({
  __name: "ConversationView",
  props: {
    snapshot: {},
    density: { default: "comfortable" },
    chrome: { default: "panel" },
    placeholder: {},
    hideComposer: { type: Boolean, default: !1 },
    autoFollow: { type: Boolean, default: !0 },
    disableSendWhileBusy: { type: Boolean, default: !0 },
    forceComposerDisabled: { type: Boolean, default: !1 },
    atmosphere: { type: Boolean, default: !0 },
    assistantLabel: { default: "" },
    showAvatars: { type: Boolean, default: !0 },
    surface: { default: "admin" },
    resolveStatusHint: {},
    resolveThinkingPresentation: {}
  },
  emits: ["send", "stop", "retry", "interaction-submit", "interaction-cancel"],
  setup(e, { emit: t }) {
    const n = e, s = t, r = le(() => ({
      "--reachai-chat-atmosphere-image": `url("${Tf}")`,
      "--reachai-chat-prism-avatar": `url("${Ef}")`
    })), i = le(
      () => n.snapshot.turnStatus === "sending" || n.snapshot.turnStatus === "streaming"
    ), o = le(() => i.value), a = le(
      () => n.forceComposerDisabled || n.disableSendWhileBusy && (i.value || n.snapshot.turnStatus === "waiting")
    );
    function l(h) {
      s("send", h);
    }
    function d(h, m, k) {
      s("interaction-submit", h, m, k);
    }
    function u(h) {
      s("interaction-cancel", h);
    }
    return (h, m) => (T(), $("div", {
      class: Ke(["reachai-conversation", [
        `reachai-conversation--${e.density}`,
        `reachai-conversation--${e.chrome}`,
        {
          "reachai-conversation--atmosphere": e.atmosphere,
          "is-busy": i.value
        }
      ]]),
      "data-surface": e.surface,
      style: _n(r.value)
    }, [
      h.$slots.header ? (T(), $("header", Rf, [
        Pt(h.$slots, "header", {}, void 0)
      ])) : Z("", !0),
      Pe(Sf, {
        messages: e.snapshot.messages,
        "auto-follow": e.autoFollow,
        "assistant-label": e.assistantLabel,
        "resolve-status-hint": e.resolveStatusHint,
        "resolve-thinking-presentation": e.resolveThinkingPresentation,
        "show-avatars": e.showAvatars,
        surface: e.surface,
        onInteractionSubmit: d,
        onInteractionCancel: u,
        onRetry: m[0] || (m[0] = (k) => h.$emit("retry"))
      }, $i({ _: 2 }, [
        h.$slots.empty ? {
          name: "empty",
          fn: qn(() => [
            Pt(h.$slots, "empty", {}, void 0, !0)
          ]),
          key: "0"
        } : void 0,
        h.$slots["message-meta"] ? {
          name: "message-meta",
          fn: qn((k) => [
            Pt(h.$slots, "message-meta", Mo(Zi(k)), void 0, !0)
          ]),
          key: "1"
        } : void 0
      ]), 1032, ["messages", "auto-follow", "assistant-label", "resolve-status-hint", "resolve-thinking-presentation", "show-avatars", "surface"]),
      e.snapshot.error ? (T(), $("div", $f, [
        D("span", null, X(e.snapshot.error), 1),
        D("button", {
          type: "button",
          onClick: m[1] || (m[1] = (k) => h.$emit("retry"))
        }, "重试")
      ])) : Z("", !0),
      Pt(h.$slots, "composer", {}, () => [
        e.hideComposer ? Z("", !0) : (T(), pt(kf, {
          key: 0,
          disabled: a.value,
          "show-stop": o.value,
          placeholder: e.placeholder,
          onSend: l,
          onStop: m[2] || (m[2] = (k) => h.$emit("stop"))
        }, null, 8, ["disabled", "show-stop", "placeholder"]))
      ]),
      h.$slots.footer ? (T(), $("footer", Mf, [
        Pt(h.$slots, "footer", {}, void 0)
      ])) : Z("", !0)
    ], 14, Pf));
  }
}), qf = /* @__PURE__ */ Kt(Of, [["__scopeId", "data-v-f1db5347"]]), jf = "1.0.0-SNAPSHOT";
function Nf(e, t) {
  return {
    pageKey: t == null ? void 0 : t.pageKey,
    pageInstanceId: e.pageInstanceId,
    route: e.route || (typeof location < "u" ? location.pathname : "/"),
    bridgeActions: e.registeredActions,
    sdkVersion: jf
  };
}
const Df = { class: "eaf-chat-host" }, Ff = ["role"], Kf = /* @__PURE__ */ ht({
  __name: "EmbedChatHost",
  props: {
    apiBase: {},
    tokenProvider: {},
    tokenTimeoutMs: { default: 1e4 },
    bridge: {},
    page: {},
    context: { default: () => ({}) },
    placeholder: { default: "输入消息" },
    locale: { default: "zh-CN" },
    preferStream: { type: Boolean, default: !0 },
    onEvent: {},
    onError: {},
    onAuthStateChange: {},
    onTokenChanged: {},
    onSessionChanged: {},
    onUnauthorized: {}
  },
  setup(e, { expose: t }) {
    const n = e, s = /* @__PURE__ */ Ee(Xs()), r = /* @__PURE__ */ Ee({
      phase: "token",
      status: "loading",
      reason: "initial",
      attempt: 0,
      message: n.locale === "en-US" ? "Connecting to ReachAI…" : "正在连接 ReachAI…"
    });
    let i = "", o = { ...n.context }, a = "", l = 0, d = !1, u = 0, h = null, m = null, k = "", I = null;
    function y(b) {
      var p;
      r.value = b, (p = n.onAuthStateChange) == null || p.call(n, b);
    }
    function z(b) {
      const p = typeof b == "string" ? b : b == null ? void 0 : b.token, c = typeof b == "object" && b ? Number(b.expiresAt || 0) : 0, f = typeof b == "object" && b ? Number(b.expiresIn || 0) : 0;
      return {
        token: String(p || "").trim(),
        expiresAt: c > 0 ? c : f > 0 ? Date.now() + f * 1e3 : 0
      };
    }
    function J(b) {
      if (!b || typeof b != "object") return;
      const p = b.httpStatus ?? b.status, c = Number(p);
      return Number.isFinite(c) && c > 0 ? c : void 0;
    }
    function S(b, p, c, f) {
      const g = new Error(p);
      return g.name = "EafChatTokenError", g.code = b, g.phase = "token", g.retryable = f !== 403, g.httpStatus = f, g.cause = c, g;
    }
    function j(b) {
      if (b && typeof b == "object" && b.code)
        return b;
      const p = J(b);
      return p === 401 ? S(
        "TOKEN_PROVIDER_UNAUTHORIZED",
        n.locale === "en-US" ? "Authentication expired. Sign in again and retry." : "身份认证已失效，请重新登录后重试",
        b,
        p
      ) : p != null && p >= 500 ? S(
        "TOKEN_PROVIDER_UNAVAILABLE",
        n.locale === "en-US" ? "ReachAI is temporarily unavailable. Retry later." : "ReachAI 暂时不可用，请稍后重试",
        b,
        p
      ) : b instanceof TypeError ? S(
        "TOKEN_PROVIDER_NETWORK_ERROR",
        n.locale === "en-US" ? "Network connection failed. Check your network and retry." : "网络连接失败，请检查网络后重试",
        b,
        p
      ) : S(
        "TOKEN_PROVIDER_FAILED",
        n.locale === "en-US" ? "Unable to connect to ReachAI. Retry later." : "暂时无法连接 ReachAI，请稍后重试",
        b,
        p
      );
    }
    function R(b) {
      return {
        message: b.message,
        code: b.code,
        phase: b.phase,
        httpStatus: b.httpStatus,
        retryable: b.retryable
      };
    }
    async function K(b, p = !1) {
      if (d) throw new DOMException("The operation was aborted.", "AbortError");
      const c = l > 0 && Date.now() + 3e4 >= l;
      if (a && !p && !c) return a;
      if (h) return h;
      const f = c && b === "send" ? "expiring" : b, g = ++u, w = new AbortController();
      m = w, y({
        phase: "token",
        status: "loading",
        reason: f,
        attempt: g,
        message: n.locale === "en-US" ? "Connecting to ReachAI…" : "正在连接 ReachAI…"
      });
      let A;
      const P = Number.isFinite(n.tokenTimeoutMs) && n.tokenTimeoutMs > 0 ? n.tokenTimeoutMs : 1e4, N = {
        reason: f,
        signal: w.signal,
        attempt: g,
        sessionId: i || void 0
      }, M = Promise.resolve().then(async () => {
        if (b === "unauthorized" && n.onUnauthorized) {
          const C = await n.onUnauthorized();
          if (C) return C;
        }
        return n.tokenProvider(N);
      }), O = new Promise((C, V) => {
        A = setTimeout(() => {
          w.abort(), V(S(
            "TOKEN_PROVIDER_TIMEOUT",
            n.locale === "en-US" ? "Connection timed out. Retry." : "连接超时，请重试"
          ));
        }, P);
      });
      return h = Promise.race([M, O]).then((C) => {
        var F;
        if (d) throw new DOMException("The operation was aborted.", "AbortError");
        const V = z(C);
        if (!V.token)
          throw S(
            "TOKEN_PROVIDER_EMPTY",
            n.locale === "en-US" ? "Authentication token is unavailable. Retry." : "登录凭证不可用，请重试"
          );
        return a = V.token, l = V.expiresAt, (F = n.onTokenChanged) == null || F.call(n, V.token), y({
          phase: "token",
          status: "ready",
          reason: f,
          attempt: g
        }), V.token;
      }).catch((C) => {
        var F;
        if (C instanceof DOMException && C.name === "AbortError" && d) throw C;
        const V = j(C);
        throw a = "", l = 0, (F = n.onTokenChanged) == null || F.call(n, ""), y({
          phase: "token",
          status: "error",
          reason: f,
          attempt: g,
          message: V.message,
          error: R(V)
        }), V;
      }).finally(() => {
        A !== void 0 && clearTimeout(A), m === w && (m = null), h = null;
      }), h;
    }
    async function _(b = "unauthorized") {
      var p;
      return a = "", l = 0, (p = n.onTokenChanged) == null || p.call(n, ""), K(b, !0);
    }
    function E() {
      return _("retry");
    }
    function H(b) {
      var f;
      const p = String(b || ""), c = p !== i;
      i = p, c && p && ((f = n.onSessionChanged) == null || f.call(n, p));
    }
    const L = wc({
      apiBase: n.apiBase,
      tokenProvider: () => a,
      getSessionId: () => i || void 0,
      setSessionId: H,
      getContext: () => o,
      createSessionPayload: () => ({
        ...Nf(n.bridge, n.page)
      }),
      preferStream: n.preferStream,
      onUnauthorized: () => _("unauthorized")
    }), U = L, ie = gc({
      transport: L,
      onPublicEvent: ne,
      onChange(b) {
        s.value = b, b.sessionId && H(b.sessionId), te(b);
      }
    });
    K("initial").catch((b) => {
      d || x(b);
    });
    function ne(b) {
      var f, g, w, A, P, N, M;
      const p = b.data, c = {
        sessionId: b.sessionId || i || void 0,
        turnId: b.turnId
      };
      switch (b.type) {
        case "message.delta":
          (f = n.onEvent) == null || f.call(n, { type: "message.delta", data: p, ...c });
          return;
        case "ui.requested":
          (g = n.onEvent) == null || g.call(n, { type: "ui.requested", data: p, ...c });
          return;
        case "page.action.requested":
          (w = n.onEvent) == null || w.call(n, { type: "page.action.requested", data: p, ...c });
          return;
        case "turn.completed":
        case "turn.waiting":
          (A = n.onEvent) == null || A.call(n, {
            type: "message.completed",
            data: he(b),
            ...c
          });
          return;
        case "turn.failed":
          (P = n.onEvent) == null || P.call(n, { type: "error", data: p, ...c });
          return;
        case "interaction.submitted":
          (N = n.onEvent) == null || N.call(n, { type: "interaction.submitted", data: p, ...c });
          return;
        case "interaction.cancelled":
          (M = n.onEvent) == null || M.call(n, { type: "interaction.cancelled", data: p, ...c });
          return;
        default:
          return;
      }
    }
    function he(b) {
      const p = b.data && typeof b.data == "object" ? b.data : {}, c = uo(p) || (p.metadata && typeof p.metadata == "object" && !Array.isArray(p.metadata) ? { ...p.metadata } : void 0);
      return {
        answer: p.answer != null ? String(p.answer) : void 0,
        sessionId: b.sessionId || (p.sessionId != null ? String(p.sessionId) : i) || void 0,
        uiRequest: p.uiRequest,
        metadata: c,
        intentType: p.intentType,
        toolCalls: p.toolCalls,
        turnId: b.turnId
      };
    }
    function te(b) {
      if (!I) return;
      const p = b.turnStatus;
      if (p === "sending" || p === "streaming") {
        I.armed = !0;
        return;
      }
      if (!I.armed || p !== "completed" && p !== "waiting" && p !== "failed" && p !== "cancelled")
        return;
      const c = I;
      if (I = null, p === "failed") {
        c.reject(new Error(b.error || "Message failed"));
        return;
      }
      if (p === "cancelled") {
        c.reject(new DOMException("The operation was aborted.", "AbortError"));
        return;
      }
      c.resolve(re(b));
    }
    function re(b) {
      var A, P;
      let p = "", c, f, g, w;
      for (let N = b.messages.length - 1; N >= 0; N -= 1) {
        const M = b.messages[N];
        if (M.role === "assistant") {
          p = Ql(M);
          for (const O of M.blocks)
            O.type === "interaction" && (O.state === "waiting" || O.state === "submitting") && (c = O.request);
          f = M.metadata ? { ...M.metadata } : void 0, f && "metadata" in f && typeof f.metadata == "object" && (f = { ...f.metadata }), g = (A = M.completion) == null ? void 0 : A.intentType, w = (P = M.completion) == null ? void 0 : P.toolCalls;
          break;
        }
      }
      return f && (delete f.result, delete f.answer, delete f.uiRequest, delete f.sessionId, delete f.intentType, delete f.toolCalls), {
        answer: p,
        sessionId: b.sessionId || i || void 0,
        uiRequest: c,
        metadata: f && Object.keys(f).length ? f : void 0,
        intentType: g,
        toolCalls: w,
        turnId: b.turnId
      };
    }
    async function ue(b) {
      if (d)
        throw new DOMException("The operation was aborted.", "AbortError");
      const p = b.trim();
      if (!p) return {};
      if (I)
        throw new Error("Another message is still in flight");
      return k = p, await K("send"), new Promise((c, f) => {
        I = { resolve: c, reject: f, armed: !1 }, ie.send(p).catch((g) => {
          I && (I = null, f(g));
        });
      });
    }
    function oe(b) {
      o = { ...o, ...b };
    }
    function se() {
      return i || null;
    }
    function Ce() {
      return i || null;
    }
    async function Je() {
      if (d) throw new DOMException("The operation was aborted.", "AbortError");
      if (await K("send"), i) return i;
      if (typeof U.ensureSession == "function")
        return U.ensureSession();
      throw new Error("Embed transport cannot ensure session");
    }
    function Le(b) {
      return b.role !== "assistant" || b.status !== "pending" && b.status !== "streaming" ? void 0 : b.blocks.some((c) => c.type === "text" && c.text) ? "正在生成回答" : "正在处理";
    }
    function _e(b) {
      ue(b).catch(x);
    }
    function nt() {
      E().catch(x);
    }
    function kt() {
      if (r.value.status === "error") {
        nt();
        return;
      }
      !k || I || ue(k).catch(x);
    }
    function q() {
      ie.cancel().then(() => {
        if (I) {
          const b = I;
          I = null, b.reject(new DOMException("The operation was aborted.", "AbortError"));
        }
      });
    }
    function Q(b, p, c) {
      ie.submitInteraction(b, p, c).catch(x);
    }
    function v(b) {
      ie.submitInteraction(b, "cancel", {}).catch(x);
    }
    function x(b) {
      var f;
      const p = b && typeof b == "object" ? b : void 0, c = {
        message: (p == null ? void 0 : p.message) || (b instanceof Error ? b.message : String(b)),
        cause: (p == null ? void 0 : p.cause) ?? b,
        code: p == null ? void 0 : p.code,
        phase: p == null ? void 0 : p.phase,
        httpStatus: (p == null ? void 0 : p.httpStatus) ?? J(b),
        retryable: p == null ? void 0 : p.retryable
      };
      try {
        (f = n.onError) == null || f.call(n, c);
      } catch {
      }
    }
    function G() {
      if (d = !0, m == null || m.abort(), m = null, I) {
        const b = I;
        I = null, b.reject(new DOMException("The operation was aborted.", "AbortError"));
      }
      ie.dispose();
    }
    return Ws(() => {
      G();
    }), t({
      sendMessage: ue,
      retryAuthentication: E,
      refreshToken: _,
      setContext: oe,
      getSessionId: se,
      getExistingSessionId: Ce,
      ensureHostSession: Je,
      disposeHost: G
    }), (b, p) => (T(), $("div", Df, [
      r.value.status !== "ready" ? (T(), $("div", {
        key: 0,
        class: Ke(["eaf-chat-auth", `is-${r.value.status}`]),
        role: r.value.status === "error" ? "alert" : "status",
        "aria-live": "polite"
      }, [
        D("span", null, X(r.value.message), 1),
        r.value.status === "error" ? (T(), $("button", {
          key: 0,
          type: "button",
          onClick: nt
        }, X(e.locale === "en-US" ? "Retry" : "重试"), 1)) : Z("", !0)
      ], 10, Ff)) : Z("", !0),
      Pe(Ls(qf), {
        class: "eaf-chat__conversation",
        chrome: "inline",
        density: "compact",
        surface: "embed",
        atmosphere: "",
        snapshot: s.value,
        placeholder: e.placeholder,
        "force-composer-disabled": r.value.status !== "ready",
        "resolve-status-hint": Le,
        onSend: _e,
        onStop: q,
        onRetry: kt,
        onInteractionSubmit: Q,
        onInteractionCancel: v
      }, null, 8, ["snapshot", "placeholder", "force-composer-disabled"])
    ]));
  }
}), mo = /* @__PURE__ */ Kt(Kf, [["__scopeId", "data-v-b24b9e02"]]);
function Ts(e) {
  var s;
  const t = (s = e.metadata) == null ? void 0 : s.pageActionQueue;
  if (!Array.isArray(t)) return [];
  const n = nr(e.metadata);
  return t.map((r) => yo(r, n)).filter((r) => !!r);
}
function yo(e, t) {
  if (!e || typeof e != "object") return null;
  const n = e;
  if (n.type !== "page.action.requested" || typeof n.requestId != "string" || typeof n.actionKey != "string") return null;
  const s = n.metadata && typeof n.metadata == "object" ? { ...n.metadata } : {}, r = typeof n.pageKey == "string" ? n.pageKey : t;
  return r && !s.pageKey && (s.pageKey = r), {
    type: "page.action.requested",
    protocolVersion: typeof n.protocolVersion == "string" ? n.protocolVersion : void 0,
    requestId: n.requestId,
    actionKey: n.actionKey,
    title: typeof n.title == "string" ? n.title : void 0,
    args: n.args && typeof n.args == "object" ? n.args : void 0,
    target: n.target && typeof n.target == "object" ? n.target : void 0,
    confirm: n.confirm === !0,
    metadata: s
  };
}
async function tr(e) {
  const t = yo(e.request, nr(e.responseMetadata));
  if (!(t != null && t.requestId)) return;
  const n = t.requestId;
  if (e.handledPageActions.has(n)) return;
  const s = e.inFlightPageActions.get(n);
  if (s) {
    await s;
    return;
  }
  const r = (async () => {
    var i, o, a;
    if (!e.handledPageActions.has(n)) {
      e.handledPageActions.add(n), (i = e.onRequested) == null || i.call(e, t);
      try {
        const l = await Lf(
          t,
          e.bridge,
          e.responseMetadata,
          /* @__PURE__ */ new Set()
          // 已认领，内部不再二次 gated
        );
        if (!l) return;
        (l.status === "FAILED" || l.status === "TIMEOUT") && ((o = e.onError) == null || o.call(e, new Error(l.error || `Page action ${l.status}: ${t.actionKey}`)));
        let d = e.token;
        try {
          await Jr(
            e.apiBase,
            e.sessionId,
            d,
            l,
            e.fetchImpl
          );
        } catch (u) {
          if (!_o(u) || !e.refreshToken) throw u;
          d = await e.refreshToken(), await Jr(
            e.apiBase,
            e.sessionId,
            d,
            l,
            e.fetchImpl
          );
        }
      } catch (l) {
        (a = e.onError) == null || a.call(e, l);
      }
    }
  })();
  e.inFlightPageActions.set(n, r);
  try {
    await r;
  } finally {
    e.inFlightPageActions.delete(n);
  }
}
async function Lf(e, t, n, s) {
  const r = await t.handleEvent(e);
  if (r && r.status !== "ACTION_NOT_FOUND")
    return s.add(e.requestId), r;
  const i = await Vf(e, n);
  return i ? (i.status !== "ACTION_NOT_FOUND" && s.add(e.requestId), i) : (r && s.add(e.requestId), r);
}
async function Uf(e) {
  const t = Ts(e.response);
  for (const n of t)
    await tr({
      request: n,
      bridge: e.bridge,
      sessionId: e.sessionId,
      apiBase: e.apiBase,
      token: e.token,
      handledPageActions: e.handledPageActions,
      inFlightPageActions: e.inFlightPageActions,
      responseMetadata: e.response.metadata,
      onRequested: e.onRequested,
      onError: e.onError,
      refreshToken: e.refreshToken,
      fetchImpl: e.fetchImpl
    });
}
async function Vf(e, t) {
  const n = typeof window < "u" ? window.__REACHAI_PAGE_BRIDGE__ : void 0;
  if (!n || typeof n.execute != "function") return null;
  const s = Hf(e) || nr(t);
  if (!s)
    return {
      protocolVersion: e.protocolVersion || "1.0",
      type: "page.action.result",
      requestId: e.requestId,
      actionKey: e.actionKey,
      status: "ACTION_NOT_FOUND",
      error: "Page action pageKey is missing for window.__REACHAI_PAGE_BRIDGE__ fallback"
    };
  try {
    const r = await n.execute(s, e.actionKey, e.args || {}, {
      confirmed: !0,
      requestId: e.requestId
    }), i = r && typeof r == "object" ? r : { data: r }, o = String(i.status || "SUCCESS").toUpperCase(), a = o === "SUCCESS", l = i.error && typeof i.error == "object" ? String(i.error.message || i.message || "") : String(i.message || "");
    return {
      protocolVersion: e.protocolVersion || "1.0",
      type: "page.action.result",
      requestId: e.requestId,
      actionKey: e.actionKey,
      status: a ? "SUCCESS" : "FAILED",
      data: i.data ?? r,
      error: a ? void 0 : l || `Page action returned ${o}`
    };
  } catch (r) {
    return {
      protocolVersion: e.protocolVersion || "1.0",
      type: "page.action.result",
      requestId: e.requestId,
      actionKey: e.actionKey,
      status: "FAILED",
      error: r instanceof Error ? r.message : String(r)
    };
  }
}
function Hf(e) {
  var n;
  const t = (n = e.metadata) == null ? void 0 : n.pageKey;
  return typeof t == "string" && t.trim() ? t.trim() : void 0;
}
function nr(e) {
  const t = e == null ? void 0 : e.pageKey;
  return typeof t == "string" && t.trim() ? t.trim() : void 0;
}
async function Jr(e, t, n, s, r = fetch) {
  await Wf(
    `${e}/chat/sessions/${encodeURIComponent(t)}/page-actions/${encodeURIComponent(s.requestId)}/result`,
    s,
    n,
    r
  );
}
async function Bf(e) {
  const t = e.fetchImpl || fetch, n = e.inFlightPageActions || /* @__PURE__ */ new Map(), s = `${e.apiBase}/chat/sessions/${encodeURIComponent(e.sessionId)}/page-actions/pending?limit=10`;
  let r;
  try {
    r = await Gr(s, e.token, t);
  } catch (i) {
    if (!_o(i) || !e.refreshToken) throw i;
    const o = await e.refreshToken();
    r = await Gr(s, o, t);
  }
  for (const i of r)
    i != null && i.requestId && await tr({
      request: i,
      bridge: e.bridge,
      sessionId: e.sessionId,
      apiBase: e.apiBase,
      token: e.token,
      handledPageActions: e.handledPageActions,
      inFlightPageActions: n,
      responseMetadata: e.context,
      onRequested: (o) => {
        var a;
        return (a = e.onEvent) == null ? void 0 : a.call(e, { type: "page.action.requested", data: o });
      },
      onError: e.onError,
      refreshToken: e.refreshToken,
      fetchImpl: t
    });
}
async function Wf(e, t, n, s) {
  const r = await s(e, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${n}`
    },
    body: JSON.stringify(t)
  }), i = await r.json().catch(() => ({}));
  if (!r.ok || i.code && i.code !== 200 && i.code !== 0)
    throw bo(i.message || `Request failed: ${r.status}`, r.status);
  return i.data ?? i;
}
async function Gr(e, t, n) {
  const s = await n(e, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${t}`
    }
  }), r = await s.json().catch(() => ({}));
  if (!s.ok || r.code && r.code !== 200 && r.code !== 0)
    throw bo(r.message || `Request failed: ${s.status}`, s.status);
  return r.data ?? r;
}
function bo(e, t) {
  const n = new Error(e);
  return n.status = t, n;
}
function _o(e) {
  return !!(e && typeof e == "object" && e.status === 401);
}
const kn = {
  activeWindowMs: 5e3,
  activeIntervalMs: 1e3,
  idleIntervalMs: 1e4,
  /** 第 1..n 次连续失败后的等待间隔（ms），封顶取最后一项 */
  backoffMs: [5e3, 1e4, 2e4, 4e4, 6e4]
};
function zf(e) {
  var U, ie, ne, he;
  const t = {
    activeWindowMs: ((U = e.timings) == null ? void 0 : U.activeWindowMs) ?? kn.activeWindowMs,
    activeIntervalMs: ((ie = e.timings) == null ? void 0 : ie.activeIntervalMs) ?? kn.activeIntervalMs,
    idleIntervalMs: ((ne = e.timings) == null ? void 0 : ne.idleIntervalMs) ?? kn.idleIntervalMs,
    backoffMs: ((he = e.timings) == null ? void 0 : he.backoffMs) ?? kn.backoffMs
  }, n = e.now || (() => Date.now()), s = e.setTimeoutFn || ((te, re) => window.setTimeout(te, re)), r = e.clearTimeoutFn || ((te) => window.clearTimeout(te)), i = e.isDocumentHidden || (() => typeof document > "u" ? !1 : document.visibilityState === "hidden");
  let o = !1, a, l = !1, d = !1, u = !1, h = 0, m = 0, k = 0, I = 0, y;
  function z() {
    return !(o || e.isDestroyed() || !e.getSessionId() || !e.hasRegisteredActions() || i());
  }
  function J() {
    a !== void 0 && (r(a), a = void 0);
  }
  function S() {
    if (k <= 0) return 0;
    const te = Math.min(k - 1, t.backoffMs.length - 1);
    return t.backoffMs[te];
  }
  function j(te) {
    if (I > te)
      return I - te;
    if (u) {
      if (m > 0) {
        const re = te - m;
        if (re < t.activeIntervalMs)
          return t.activeIntervalMs - re;
      }
      return 0;
    }
    if (te < h) {
      if (m > 0) {
        const re = te - m;
        if (re < t.activeIntervalMs)
          return t.activeIntervalMs - re;
      }
      return 0;
    }
    if (m > 0) {
      const re = te - m;
      if (re < t.idleIntervalMs)
        return t.idleIntervalMs - re;
    }
    return t.idleIntervalMs;
  }
  function R() {
    if (J(), o || e.isDestroyed() || !z()) return;
    if (l) {
      d = !0;
      return;
    }
    const te = n(), re = j(te);
    a = s(() => {
      a = void 0, K();
    }, Math.max(0, re));
  }
  async function K() {
    var te;
    if (!(o || e.isDestroyed()) && z()) {
      if (l) {
        d = !0;
        return;
      }
      l = !0, u = !1, m = n();
      try {
        await e.poll(), k = 0, I = 0;
      } catch (re) {
        k += 1;
        const ue = S();
        I = n() + ue, (te = e.onError) == null || te.call(e, re);
      } finally {
        l = !1, d && (d = !1, u = !0), R();
      }
    }
  }
  function _() {
    if (o || e.isDestroyed()) return;
    const te = n();
    if (h = Math.max(h, te + t.activeWindowMs), u = !0, l) {
      d = !0;
      return;
    }
    R();
  }
  function E(te, re) {
    if (!(o || e.isDestroyed())) {
      if (te <= 0 && re > 0) {
        e.getSessionId() && _();
        return;
      }
      te > 0 && re <= 0 && (J(), u = !1, d = !1);
    }
  }
  function H() {
    if (!(o || e.isDestroyed())) {
      if (i()) {
        J();
        return;
      }
      _();
    }
  }
  return y = (e.addVisibilityListener || ((te) => typeof document > "u" ? () => {
  } : (document.addEventListener("visibilitychange", te), () => document.removeEventListener("visibilitychange", te))))(H), {
    notifyActivity: _,
    notifyActionsChanged: E,
    destroy() {
      o = !0, J(), u = !1, d = !1, y == null || y(), y = void 0;
    },
    isInFlight() {
      return l;
    }
  };
}
const nn = {
  "tech-purple": { primary: "#6366f1", rgb: "99 102 241" },
  "metro-green": { primary: "#0b7a59", rgb: "11 122 89" },
  "aurora-cyan": { primary: "#0891b2", rgb: "8 145 178" },
  "nebula-violet": { primary: "#7c3aed", rgb: "124 58 237" },
  "coral-rose": { primary: "#db2777", rgb: "219 39 119" },
  "solar-gold": { primary: "#b45309", rgb: "180 83 9" },
  "deep-ocean": { primary: "#1d4ed8", rgb: "29 78 216" }
}, Yr = "tech-purple";
function Jf(e) {
  const t = String((e == null ? void 0 : e.primaryColor) || "").trim();
  if (t)
    return {
      primary: t,
      rgb: Gf(t) || nn[Yr].rgb,
      source: "primaryColor"
    };
  const n = String((e == null ? void 0 : e.preset) || "").trim();
  if (n && n in nn) {
    const r = nn[n];
    return { primary: r.primary, rgb: r.rgb, source: "preset" };
  }
  const s = nn[Yr];
  return { primary: s.primary, rgb: s.rgb, source: "default" };
}
function Gf(e) {
  const t = e.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);
  if (t) {
    const s = t[1];
    return s.length === 3 ? [
      parseInt(s[0] + s[0], 16),
      parseInt(s[1] + s[1], 16),
      parseInt(s[2] + s[2], 16)
    ].join(" ") : [
      parseInt(s.slice(0, 2), 16),
      parseInt(s.slice(2, 4), 16),
      parseInt(s.slice(4, 6), 16)
    ].join(" ");
  }
  const n = e.match(/^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
  return n ? `${Number(n[1])} ${Number(n[2])} ${Number(n[3])}` : null;
}
function Yf(e, t) {
  const n = Jf({
    preset: t == null ? void 0 : t.preset,
    primaryColor: t == null ? void 0 : t.primaryColor
  });
  e.style.setProperty("--reachai-chat-primary", n.primary), e.style.setProperty("--reachai-chat-spectrum-anchor", n.primary), e.style.setProperty("--reachai-chat-primary-rgb", n.rgb), t != null && t.preset && t.preset in nn ? e.dataset.chatPreset = t.preset : n.source === "default" ? e.dataset.chatPreset = "tech-purple" : delete e.dataset.chatPreset;
}
async function ld(e) {
  var nt, kt;
  if (!e.agentId) throw new Error("agentId is required");
  const t = typeof e.mount == "string" ? document.querySelector(e.mount) : e.mount;
  if (!t) throw new Error("mount element not found");
  const n = e.bridge || gs({ route: location.pathname }), s = rd(e.apiBase, e.embedPathPrefix), r = id(e.apiBase), i = e.locale || "zh-CN";
  let o = "", a = { ...e.context || {} };
  const l = /* @__PURE__ */ new Set(), d = /* @__PURE__ */ new Set(), u = /* @__PURE__ */ new Map(), h = /* @__PURE__ */ new Set();
  let m, k = !1, I = null, y = null, z = !1, J = n.registeredActions.length;
  function S(q, Q = {}) {
    var G;
    const x = String((q && typeof q == "object" ? q : {}).requestId || "");
    if (x) {
      if (h.has(x)) return !1;
      h.add(x);
    }
    return (G = e.onEvent) == null || G.call(e, {
      type: "page.action.requested",
      data: q,
      sessionId: Q.sessionId,
      turnId: Q.turnId
    }), !0;
  }
  function j(q, Q, v) {
    if (!k) {
      if (!Q) {
        E(new Error("Page action requires an active embed session; no sessionId available"));
        return;
      }
      tr({
        request: q,
        bridge: n,
        sessionId: Q,
        apiBase: s,
        token: o,
        handledPageActions: d,
        inFlightPageActions: u,
        responseMetadata: v,
        onRequested: (x) => S(x, { sessionId: Q }),
        onError: E,
        refreshToken: async () => (await Je(), o)
      }).catch(E);
    }
  }
  function R(q) {
    if (q.sessionId) return q.sessionId;
    const Q = q.data && typeof q.data == "object" ? q.data : {};
    return Q.sessionId != null && String(Q.sessionId) ? String(Q.sessionId) : (y == null ? void 0 : y.getExistingSessionId()) || (y == null ? void 0 : y.getSessionId()) || void 0;
  }
  function K(q) {
    var Q, v;
    if (q.type === "page.action.requested") {
      const x = S(q.data, {
        sessionId: q.sessionId,
        turnId: q.turnId
      });
      j(
        q.data,
        R(q),
        q.data && typeof q.data == "object" ? q.data.metadata : void 0
      ), x && L.notifyActivity();
      return;
    }
    if (q.type === "message.completed") {
      const x = q.data;
      for (const G of Ts(x))
        S(G, { sessionId: x.sessionId, turnId: x.turnId });
      (Q = e.onEvent) == null || Q.call(e, q), _(x).catch(E), L.notifyActivity();
      return;
    }
    (v = e.onEvent) == null || v.call(e, q);
  }
  async function _(q) {
    if (!q || k) return;
    const Q = q.sessionId || (y == null ? void 0 : y.getExistingSessionId()) || (y == null ? void 0 : y.getSessionId()), v = Ts(q);
    if (!Q) {
      v.length > 0 && E(new Error("Page action requires an active embed session; no sessionId available"));
      return;
    }
    await Uf({
      response: q,
      bridge: n,
      sessionId: Q,
      apiBase: s,
      token: o,
      handledPageActions: d,
      inFlightPageActions: u,
      onRequested: (x) => S(x, { sessionId: Q }),
      onError: E,
      refreshToken: async () => (await Je(), o)
    });
  }
  function E(q) {
    var v;
    const Q = { message: q instanceof Error ? q.message : String(q), cause: q };
    (v = e.onError) == null || v.call(e, Q);
  }
  async function H() {
    if (k) return;
    const q = y == null ? void 0 : y.getExistingSessionId();
    q && await Bf({
      apiBase: s,
      token: o,
      sessionId: q,
      bridge: n,
      handledPageActions: d,
      pendingPageActions: l,
      inFlightPageActions: u,
      context: a,
      // poll 自己已 dispatch；此处只 publish，禁止再走 emitPublicEvent→dispatch 递归
      onEvent: (Q) => {
        Q.type === "page.action.requested" && S(Q.data, { sessionId: q });
      },
      onError: E,
      refreshToken: async () => (await Je(), o)
    });
  }
  const L = zf({
    getSessionId: () => (y == null ? void 0 : y.getExistingSessionId()) || null,
    hasRegisteredActions: () => n.registeredActions.length > 0,
    isDestroyed: () => k,
    poll: H,
    onError: E
  }), U = document.createElement("div");
  U.className = "eaf-chat", e.position && e.position !== "inline" && U.classList.add(`eaf-chat--${e.position}`), e.initialOpen === !1 && U.classList.add("eaf-chat--closed"), Yf(U, e.theme), U.innerHTML = `
    <div class="eaf-chat__header">
      <div class="eaf-chat__brand">${sd(((nt = e.theme) == null ? void 0 : nt.brandName) || "ReachAI")}</div>
      <div class="eaf-chat__header-actions">
        <span class="eaf-chat__connection-status" role="status" aria-live="polite">${i === "en-US" ? "Connecting" : "正在连接"}</span>
        <button class="eaf-chat__toggle" type="button" aria-expanded="${e.initialOpen === !1 ? "false" : "true"}">
          ${e.initialOpen === !1 ? "+" : "-"}
        </button>
      </div>
    </div>
    <div class="eaf-chat__body"></div>
  `, t.appendChild(U);
  const ie = U.querySelector(".eaf-chat__toggle"), ne = U.querySelector(".eaf-chat__connection-status"), he = U.querySelector(".eaf-chat__body");
  function te(q) {
    var Q, v;
    U.dataset.authState = q.status, ne.hidden = q.status === "ready", ne.classList.toggle("is-error", q.status === "error"), ne.textContent = q.status === "loading" ? i === "en-US" ? "Connecting" : "正在连接" : q.status === "error" ? i === "en-US" ? "Connection failed" : "连接失败" : "";
    try {
      (Q = e.onStateChange) == null || Q.call(e, q);
    } catch (x) {
      try {
        (v = e.onError) == null || v.call(e, {
          message: "ReachAI state callback failed",
          cause: x,
          code: "STATE_CALLBACK_FAILED",
          phase: "token",
          retryable: !1
        });
      } catch {
      }
    }
  }
  I = Es(mo, {
    apiBase: s,
    tokenProvider: e.tokenProvider,
    tokenTimeoutMs: e.tokenTimeoutMs,
    bridge: n,
    page: e.page,
    context: a,
    locale: i,
    placeholder: i === "zh-CN" ? "输入消息" : "Type a message",
    preferStream: e.stream !== !1,
    onEvent: K,
    onError: (q) => {
      var Q;
      return (Q = e.onError) == null ? void 0 : Q.call(e, q);
    },
    onAuthStateChange: te,
    onTokenChanged: (q) => {
      o = q;
    },
    onSessionChanged: () => {
      L.notifyActivity();
    }
  }), y = I.mount(he);
  const re = n.onActionDefinitionsChange(() => {
    oe();
    const q = n.registeredActions.length;
    L.notifyActionsChanged(J, q), J = q;
  });
  oe(0);
  function ue(q) {
    var v;
    const Q = { message: q instanceof Error ? q.message : String(q), cause: q };
    (v = e.onError) == null || v.call(e, Q);
  }
  function oe(q = 250) {
    !e.pageRegistry || e.pageRegistry.registerOnStart === !1 || !e.page || (m && window.clearTimeout(m), m = window.setTimeout(() => {
      m = void 0, se().catch(ue);
    }, q));
  }
  async function se() {
    k || await Xf(r, e, n);
  }
  function Ce() {
    const q = !U.classList.contains("eaf-chat--closed");
    ie.textContent = q ? "-" : "+", ie.setAttribute("aria-expanded", q ? "true" : "false");
  }
  async function Je() {
    if (!y) throw new Error("Embed chat host is not ready");
    o = await y.refreshToken("page-action");
  }
  async function Le(q) {
    const Q = q.trim();
    if (!Q || !y || k) return {};
    if (z) throw new Error("Another message is still in flight");
    z = !0, L.notifyActivity();
    try {
      const v = await y.sendMessage(Q);
      return await _(v), L.notifyActivity(), v;
    } catch (v) {
      throw E(v), v;
    } finally {
      z = !1;
    }
  }
  ie.addEventListener("click", () => {
    const q = U.classList.contains("eaf-chat--closed");
    U.classList.toggle("eaf-chat--closed"), Ce(), q && !U.classList.contains("eaf-chat--closed") && L.notifyActivity();
  }), Ce();
  const _e = {
    bridge: n,
    get sessionId() {
      return (y == null ? void 0 : y.getSessionId()) || null;
    },
    open() {
      U.classList.remove("eaf-chat--closed"), Ce(), L.notifyActivity();
    },
    close() {
      U.classList.add("eaf-chat--closed"), Ce();
    },
    toggle() {
      const q = U.classList.contains("eaf-chat--closed");
      U.classList.toggle("eaf-chat--closed"), Ce(), q && !U.classList.contains("eaf-chat--closed") && L.notifyActivity();
    },
    send: Le,
    async retry() {
      !y || k || (o = await y.retryAuthentication());
    },
    registerPageCatalog: se,
    setContext(q) {
      a = { ...a, ...q || {} }, y == null || y.setContext(q || {});
    },
    destroy() {
      k = !0, L.destroy(), re(), m && window.clearTimeout(m), y == null || y.disposeHost(), I == null || I.unmount(), I = null, y = null, U.remove();
    }
  };
  return typeof process < "u" && ((kt = process.env) != null && kt.VITEST) && Object.assign(_e, {
    __emitPublicEventForTests: K
  }), _e;
}
async function Xf(e, t, n) {
  const s = t.pageRegistry, r = t.page;
  !s || s.registerOnStart === !1 || !r || !s.projectCode || !s.appKey || !s.appSecret || await Zf(
    `${e}/api/registry/projects/${encodeURIComponent(s.projectCode)}/pages/register`,
    {
      pageKey: r.pageKey,
      name: r.name || r.pageKey,
      routePattern: r.routePattern || n.route || location.pathname,
      origin: r.origin || location.origin,
      pageInstanceId: n.pageInstanceId,
      replaceActions: !0,
      actions: n.actionDefinitions.map(Qf),
      metadata: r.metadata || {}
    },
    s
  );
}
function Qf(e) {
  return {
    actionKey: e.actionKey,
    title: e.title || e.actionKey,
    description: e.description || "",
    confirmRequired: e.confirmRequired === !0,
    inputSchema: e.inputSchema || {},
    outputSchema: e.outputSchema || {},
    sampleArgs: e.sampleArgs || {},
    allowedAgentIds: e.allowedAgentIds || [],
    metadata: e.metadata || {}
  };
}
async function Zf(e, t, n) {
  const s = String(Date.now()), r = td(), i = await ed(n.appSecret, `${n.projectCode}
${s}
${r}`), o = await fetch(e, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-ReachAI-App-Key": n.appKey,
      "X-ReachAI-Timestamp": s,
      "X-ReachAI-Nonce": r,
      "X-ReachAI-Signature": i
    },
    body: JSON.stringify(t)
  }), a = await o.json().catch(() => ({}));
  if (!o.ok || a.code && a.code !== 200 && a.code !== 0)
    throw nd(a.message || `Page catalog registration failed: ${o.status}`, o.status);
  return a.data ?? a;
}
async function ed(e, t) {
  if (!(crypto != null && crypto.subtle))
    throw new Error("Web Crypto API is required for ReachAI page catalog registration");
  const n = new TextEncoder(), s = await crypto.subtle.importKey(
    "raw",
    n.encode(e),
    { name: "HMAC", hash: "SHA-256" },
    !1,
    ["sign"]
  ), r = await crypto.subtle.sign("HMAC", s, n.encode(t));
  return Array.from(new Uint8Array(r)).map((i) => i.toString(16).padStart(2, "0")).join("");
}
function td() {
  return typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}
function nd(e, t) {
  const n = new Error(e);
  return n.status = t, n;
}
function sd(e) {
  return e.replace(/[<>&"']/g, (t) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", '"': "&quot;", "'": "&#39;" })[t] || t);
}
function rd(e, t) {
  const n = wn((e || "").trim());
  if (t !== void 0) {
    const s = sr(t || "/api/embed");
    return Xr(od(n, s), s);
  }
  return vo(n) ? n : Xr(n, "/api/embed");
}
function id(e) {
  const t = wn((e || "").trim());
  return t ? vo(t) ? t.replace(/\/api\/(?:reachai\/)?embed$/i, "") : t : "";
}
function Xr(e, t) {
  const n = wn(e), s = sr(t);
  return n ? s ? `${n}${s}` : n : s || "";
}
function od(e, t) {
  const n = sr(t);
  return !e || !n ? e : e.toLowerCase().endsWith(n.toLowerCase()) ? wn(e.slice(0, -n.length)) : e;
}
function sr(e) {
  const t = wn((e || "").trim());
  return t ? t.startsWith("/") ? t : `/${t}` : "";
}
function vo(e) {
  return /\/api\/(?:reachai\/)?embed$/i.test(e);
}
function wn(e) {
  return e.endsWith("/") ? e.slice(0, -1) : e;
}
const ad = /* @__PURE__ */ ht({
  __name: "ReachAiChatElement.ce",
  props: {
    apiBase: { default: "/api/embed", type: String },
    token: { default: "", type: String },
    pageKey: { type: String },
    route: { type: String },
    placeholder: { default: "输入消息", type: String }
  },
  setup(e) {
    const t = e, n = /* @__PURE__ */ Ee(!1), s = /* @__PURE__ */ Ee(gs()), r = /* @__PURE__ */ Ee(void 0), i = /* @__PURE__ */ Ee({});
    function o() {
      return t.token;
    }
    async function a() {
      return t.token;
    }
    return Bs(() => {
      s.value = gs({
        route: t.route || (typeof location < "u" ? location.pathname : "/")
      }), t.pageKey && (r.value = { pageKey: t.pageKey }), n.value = !0;
    }), (l, d) => n.value ? (T(), pt(mo, {
      key: 0,
      "api-base": e.apiBase,
      "token-provider": o,
      bridge: s.value,
      page: r.value,
      context: i.value,
      placeholder: e.placeholder,
      "on-unauthorized": a
    }, null, 8, ["api-base", "bridge", "page", "context", "placeholder"])) : Z("", !0);
  }
});
let ps = !1;
function cd(e = "reachai-chat") {
  if (!(ps || typeof customElements > "u")) {
    if (customElements.get(e)) {
      ps = !0;
      return;
    }
    customElements.define(e, /* @__PURE__ */ Ul(ad)), ps = !0;
  }
}
export {
  nn as EAF_CHAT_THEME_PRESETS,
  Nf as buildEafChatSessionPayload,
  ld as createEafChat,
  gs as createEafPageBridge,
  cd as defineReachAiChatElement,
  rd as resolveEafChatEmbedApiRoot,
  id as resolveEafChatPlatformBase,
  Jf as resolveEafChatThemePrimary
};
