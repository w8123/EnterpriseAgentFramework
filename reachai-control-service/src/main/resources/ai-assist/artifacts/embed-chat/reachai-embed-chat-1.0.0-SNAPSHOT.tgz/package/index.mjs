function un(e = {}) {
  const t = e.pageInstanceId || go(), s = Math.max(1e3, e.actionTimeoutMs || 15e3), n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Set();
  function a() {
    return Array.from(n.keys()).map((c) => ({
      actionKey: c,
      ...r.get(c) || {}
    }));
  }
  function l(c) {
    i.forEach((d) => d(c));
  }
  function f() {
    const c = a();
    o.forEach((d) => d(c));
  }
  return {
    pageInstanceId: t,
    route: e.route,
    get registeredActions() {
      return Array.from(n.keys());
    },
    get actionDefinitions() {
      return a();
    },
    registerAction(c, d, g = {}) {
      return n.set(c, d), r.set(c, g), f(), () => {
        n.delete(c), r.delete(c), f();
      };
    },
    async handleEvent(c) {
      var _;
      if (!po(c)) return null;
      const d = (_ = c.target) == null ? void 0 : _.pageInstanceId;
      if (d && d !== t) return null;
      const g = n.get(c.actionKey);
      if (!g) {
        const v = ys(c, "ACTION_NOT_FOUND", void 0, `Action is not registered: ${c.actionKey}`);
        return l(v), v;
      }
      if (!await fo(c, e.confirmAction)) {
        const v = ys(c, "CANCELLED", void 0, `Action was cancelled: ${c.actionKey}`);
        return l(v), v;
      }
      try {
        const v = await ho(g(c.args || {}, c), s), p = ys(c, "SUCCESS", v);
        return l(p), p;
      } catch (v) {
        const p = v instanceof Error ? v.message : String(v), M = ys(c, p === "Page action timed out" ? "TIMEOUT" : "FAILED", void 0, p);
        return l(M), M;
      }
    },
    onResult(c) {
      return i.add(c), () => i.delete(c);
    },
    onActionDefinitionsChange(c) {
      return o.add(c), () => o.delete(c);
    }
  };
}
async function fo(e, t) {
  return e.confirm ? t ? await t(e) : typeof window < "u" && typeof window.confirm == "function" ? window.confirm(e.title || `Run page action: ${e.actionKey}`) : !1 : !0;
}
function ys(e, t, s, n) {
  return {
    protocolVersion: e.protocolVersion || "1.0",
    type: "page.action.result",
    requestId: e.requestId,
    actionKey: e.actionKey,
    status: t,
    data: s,
    error: n
  };
}
async function ho(e, t) {
  let s;
  try {
    return await Promise.race([
      Promise.resolve(e),
      new Promise((n, r) => {
        s = setTimeout(() => r(new Error("Page action timed out")), t);
      })
    ]);
  } catch (n) {
    throw n instanceof Error && n.message === "Page action timed out", n;
  } finally {
    s && clearTimeout(s);
  }
}
function po(e) {
  if (!e || typeof e != "object") return !1;
  const t = e;
  return t.type === "page.action.requested" && typeof t.requestId == "string" && typeof t.actionKey == "string";
}
function go() {
  return typeof crypto < "u" && "randomUUID" in crypto ? `page-${crypto.randomUUID()}` : `page-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}
/**
* @vue/shared v3.5.31
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
// @__NO_SIDE_EFFECTS__
function An(e) {
  const t = /* @__PURE__ */ Object.create(null);
  for (const s of e.split(",")) t[s] = 1;
  return (s) => s in t;
}
const pe = {}, Lt = [], ft = () => {
}, Hr = () => !1, qs = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && // uppercase letter
(e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97), js = (e) => e.startsWith("onUpdate:"), we = Object.assign, Cn = (e, t) => {
  const s = e.indexOf(t);
  s > -1 && e.splice(s, 1);
}, mo = Object.prototype.hasOwnProperty, ce = (e, t) => mo.call(e, t), Y = Array.isArray, Ut = (e) => ds(e) === "[object Map]", Ds = (e) => ds(e) === "[object Set]", tr = (e) => ds(e) === "[object Date]", ee = (e) => typeof e == "function", ve = (e) => typeof e == "string", et = (e) => typeof e == "symbol", de = (e) => e !== null && typeof e == "object", Wr = (e) => (de(e) || ee(e)) && ee(e.then) && ee(e.catch), zr = Object.prototype.toString, ds = (e) => zr.call(e), yo = (e) => ds(e).slice(8, -1), Fs = (e) => ds(e) === "[object Object]", kn = (e) => ve(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e, Zt = /* @__PURE__ */ An(
  // the leading comma is intentional so empty string "" is also included
  ",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"
), Ns = (e) => {
  const t = /* @__PURE__ */ Object.create(null);
  return ((s) => t[s] || (t[s] = e(s)));
}, bo = /-\w/g, Ee = Ns(
  (e) => e.replace(bo, (t) => t.slice(1).toUpperCase())
), _o = /\B([A-Z])/g, Ge = Ns(
  (e) => e.replace(_o, "-$1").toLowerCase()
), Ks = Ns((e) => e.charAt(0).toUpperCase() + e.slice(1)), Gs = Ns(
  (e) => e ? `on${Ks(e)}` : ""
), ut = (e, t) => !Object.is(e, t), Ss = (e, ...t) => {
  for (let s = 0; s < e.length; s++)
    e[s](...t);
}, Jr = (e, t, s, n = !1) => {
  Object.defineProperty(e, t, {
    configurable: !0,
    enumerable: !1,
    writable: n,
    value: s
  });
}, En = (e) => {
  const t = parseFloat(e);
  return isNaN(t) ? e : t;
}, sr = (e) => {
  const t = ve(e) ? Number(e) : NaN;
  return isNaN(t) ? e : t;
};
let nr;
const Ls = () => nr || (nr = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {});
function hs(e) {
  if (Y(e)) {
    const t = {};
    for (let s = 0; s < e.length; s++) {
      const n = e[s], r = ve(n) ? Io(n) : hs(n);
      if (r)
        for (const i in r)
          t[i] = r[i];
    }
    return t;
  } else if (ve(e) || de(e))
    return e;
}
const vo = /;(?![^(]*\))/g, wo = /:([^]+)/, So = /\/\*[^]*?\*\//g;
function Io(e) {
  const t = {};
  return e.replace(So, "").split(vo).forEach((s) => {
    if (s) {
      const n = s.split(wo);
      n.length > 1 && (t[n[0].trim()] = n[1].trim());
    }
  }), t;
}
function Ye(e) {
  let t = "";
  if (ve(e))
    t = e;
  else if (Y(e))
    for (let s = 0; s < e.length; s++) {
      const n = Ye(e[s]);
      n && (t += n + " ");
    }
  else if (de(e))
    for (const s in e)
      e[s] && (t += s + " ");
  return t.trim();
}
function xo(e) {
  if (!e) return null;
  let { class: t, style: s } = e;
  return t && !ve(t) && (e.class = Ye(t)), s && (e.style = hs(s)), e;
}
const Ao = "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly", Co = /* @__PURE__ */ An(Ao);
function Gr(e) {
  return !!e || e === "";
}
function ko(e, t) {
  if (e.length !== t.length) return !1;
  let s = !0;
  for (let n = 0; s && n < e.length; n++)
    s = jt(e[n], t[n]);
  return s;
}
function jt(e, t) {
  if (e === t) return !0;
  let s = tr(e), n = tr(t);
  if (s || n)
    return s && n ? e.getTime() === t.getTime() : !1;
  if (s = et(e), n = et(t), s || n)
    return e === t;
  if (s = Y(e), n = Y(t), s || n)
    return s && n ? ko(e, t) : !1;
  if (s = de(e), n = de(t), s || n) {
    if (!s || !n)
      return !1;
    const r = Object.keys(e).length, i = Object.keys(t).length;
    if (r !== i)
      return !1;
    for (const o in e) {
      const a = e.hasOwnProperty(o), l = t.hasOwnProperty(o);
      if (a && !l || !a && l || !jt(e[o], t[o]))
        return !1;
    }
  }
  return String(e) === String(t);
}
function Yr(e, t) {
  return e.findIndex((s) => jt(s, t));
}
const Xr = (e) => !!(e && e.__v_isRef === !0), ne = (e) => ve(e) ? e : e == null ? "" : Y(e) || de(e) && (e.toString === zr || !ee(e.toString)) ? Xr(e) ? ne(e.value) : JSON.stringify(e, Qr, 2) : String(e), Qr = (e, t) => Xr(t) ? Qr(e, t.value) : Ut(t) ? {
  [`Map(${t.size})`]: [...t.entries()].reduce(
    (s, [n, r], i) => (s[Ys(n, i) + " =>"] = r, s),
    {}
  )
} : Ds(t) ? {
  [`Set(${t.size})`]: [...t.values()].map((s) => Ys(s))
} : et(t) ? Ys(t) : de(t) && !Y(t) && !Fs(t) ? String(t) : t, Ys = (e, t = "") => {
  var s;
  return (
    // Symbol.description in es2019+ so we need to cast here to pass
    // the lib: es2016 check
    et(e) ? `Symbol(${(s = e.description) != null ? s : t})` : e
  );
};
/**
* @vue/reactivity v3.5.31
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
let Le;
class Eo {
  // TODO isolatedDeclarations "__v_skip"
  constructor(t = !1) {
    this.detached = t, this._active = !0, this._on = 0, this.effects = [], this.cleanups = [], this._isPaused = !1, this.__v_skip = !0, this.parent = Le, !t && Le && (this.index = (Le.scopes || (Le.scopes = [])).push(
      this
    ) - 1);
  }
  get active() {
    return this._active;
  }
  pause() {
    if (this._active) {
      this._isPaused = !0;
      let t, s;
      if (this.scopes)
        for (t = 0, s = this.scopes.length; t < s; t++)
          this.scopes[t].pause();
      for (t = 0, s = this.effects.length; t < s; t++)
        this.effects[t].pause();
    }
  }
  /**
   * Resumes the effect scope, including all child scopes and effects.
   */
  resume() {
    if (this._active && this._isPaused) {
      this._isPaused = !1;
      let t, s;
      if (this.scopes)
        for (t = 0, s = this.scopes.length; t < s; t++)
          this.scopes[t].resume();
      for (t = 0, s = this.effects.length; t < s; t++)
        this.effects[t].resume();
    }
  }
  run(t) {
    if (this._active) {
      const s = Le;
      try {
        return Le = this, t();
      } finally {
        Le = s;
      }
    }
  }
  /**
   * This should only be called on non-detached scopes
   * @internal
   */
  on() {
    ++this._on === 1 && (this.prevScope = Le, Le = this);
  }
  /**
   * This should only be called on non-detached scopes
   * @internal
   */
  off() {
    this._on > 0 && --this._on === 0 && (Le = this.prevScope, this.prevScope = void 0);
  }
  stop(t) {
    if (this._active) {
      this._active = !1;
      let s, n;
      for (s = 0, n = this.effects.length; s < n; s++)
        this.effects[s].stop();
      for (this.effects.length = 0, s = 0, n = this.cleanups.length; s < n; s++)
        this.cleanups[s]();
      if (this.cleanups.length = 0, this.scopes) {
        for (s = 0, n = this.scopes.length; s < n; s++)
          this.scopes[s].stop(!0);
        this.scopes.length = 0;
      }
      if (!this.detached && this.parent && !t) {
        const r = this.parent.scopes.pop();
        r && r !== this && (this.parent.scopes[this.index] = r, r.index = this.index);
      }
      this.parent = void 0;
    }
  }
}
function To() {
  return Le;
}
let ye;
const Xs = /* @__PURE__ */ new WeakSet();
class Zr {
  constructor(t) {
    this.fn = t, this.deps = void 0, this.depsTail = void 0, this.flags = 5, this.next = void 0, this.cleanup = void 0, this.scheduler = void 0, Le && Le.active && Le.effects.push(this);
  }
  pause() {
    this.flags |= 64;
  }
  resume() {
    this.flags & 64 && (this.flags &= -65, Xs.has(this) && (Xs.delete(this), this.trigger()));
  }
  /**
   * @internal
   */
  notify() {
    this.flags & 2 && !(this.flags & 32) || this.flags & 8 || ti(this);
  }
  run() {
    if (!(this.flags & 1))
      return this.fn();
    this.flags |= 2, rr(this), si(this);
    const t = ye, s = Ze;
    ye = this, Ze = !0;
    try {
      return this.fn();
    } finally {
      ni(this), ye = t, Ze = s, this.flags &= -3;
    }
  }
  stop() {
    if (this.flags & 1) {
      for (let t = this.deps; t; t = t.nextDep)
        $n(t);
      this.deps = this.depsTail = void 0, rr(this), this.onStop && this.onStop(), this.flags &= -2;
    }
  }
  trigger() {
    this.flags & 64 ? Xs.add(this) : this.scheduler ? this.scheduler() : this.runIfDirty();
  }
  /**
   * @internal
   */
  runIfDirty() {
    fn(this) && this.run();
  }
  get dirty() {
    return fn(this);
  }
}
let ei = 0, es, ts;
function ti(e, t = !1) {
  if (e.flags |= 8, t) {
    e.next = ts, ts = e;
    return;
  }
  e.next = es, es = e;
}
function Tn() {
  ei++;
}
function Pn() {
  if (--ei > 0)
    return;
  if (ts) {
    let t = ts;
    for (ts = void 0; t; ) {
      const s = t.next;
      t.next = void 0, t.flags &= -9, t = s;
    }
  }
  let e;
  for (; es; ) {
    let t = es;
    for (es = void 0; t; ) {
      const s = t.next;
      if (t.next = void 0, t.flags &= -9, t.flags & 1)
        try {
          t.trigger();
        } catch (n) {
          e || (e = n);
        }
      t = s;
    }
  }
  if (e) throw e;
}
function si(e) {
  for (let t = e.deps; t; t = t.nextDep)
    t.version = -1, t.prevActiveLink = t.dep.activeLink, t.dep.activeLink = t;
}
function ni(e) {
  let t, s = e.depsTail, n = s;
  for (; n; ) {
    const r = n.prevDep;
    n.version === -1 ? (n === s && (s = r), $n(n), Po(n)) : t = n, n.dep.activeLink = n.prevActiveLink, n.prevActiveLink = void 0, n = r;
  }
  e.deps = t, e.depsTail = s;
}
function fn(e) {
  for (let t = e.deps; t; t = t.nextDep)
    if (t.dep.version !== t.version || t.dep.computed && (ri(t.dep.computed) || t.dep.version !== t.version))
      return !0;
  return !!e._dirty;
}
function ri(e) {
  if (e.flags & 4 && !(e.flags & 16) || (e.flags &= -17, e.globalVersion === is) || (e.globalVersion = is, !e.isSSR && e.flags & 128 && (!e.deps && !e._dirty || !fn(e))))
    return;
  e.flags |= 2;
  const t = e.dep, s = ye, n = Ze;
  ye = e, Ze = !0;
  try {
    si(e);
    const r = e.fn(e._value);
    (t.version === 0 || ut(r, e._value)) && (e.flags |= 128, e._value = r, t.version++);
  } catch (r) {
    throw t.version++, r;
  } finally {
    ye = s, Ze = n, ni(e), e.flags &= -3;
  }
}
function $n(e, t = !1) {
  const { dep: s, prevSub: n, nextSub: r } = e;
  if (n && (n.nextSub = r, e.prevSub = void 0), r && (r.prevSub = n, e.nextSub = void 0), s.subs === e && (s.subs = n, !n && s.computed)) {
    s.computed.flags &= -5;
    for (let i = s.computed.deps; i; i = i.nextDep)
      $n(i, !0);
  }
  !t && !--s.sc && s.map && s.map.delete(s.key);
}
function Po(e) {
  const { prevDep: t, nextDep: s } = e;
  t && (t.nextDep = s, e.prevDep = void 0), s && (s.prevDep = t, e.nextDep = void 0);
}
let Ze = !0;
const ii = [];
function wt() {
  ii.push(Ze), Ze = !1;
}
function St() {
  const e = ii.pop();
  Ze = e === void 0 ? !0 : e;
}
function rr(e) {
  const { cleanup: t } = e;
  if (e.cleanup = void 0, t) {
    const s = ye;
    ye = void 0;
    try {
      t();
    } finally {
      ye = s;
    }
  }
}
let is = 0;
class $o {
  constructor(t, s) {
    this.sub = t, this.dep = s, this.version = s.version, this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0;
  }
}
class Rn {
  // TODO isolatedDeclarations "__v_skip"
  constructor(t) {
    this.computed = t, this.version = 0, this.activeLink = void 0, this.subs = void 0, this.map = void 0, this.key = void 0, this.sc = 0, this.__v_skip = !0;
  }
  track(t) {
    if (!ye || !Ze || ye === this.computed)
      return;
    let s = this.activeLink;
    if (s === void 0 || s.sub !== ye)
      s = this.activeLink = new $o(ye, this), ye.deps ? (s.prevDep = ye.depsTail, ye.depsTail.nextDep = s, ye.depsTail = s) : ye.deps = ye.depsTail = s, oi(s);
    else if (s.version === -1 && (s.version = this.version, s.nextDep)) {
      const n = s.nextDep;
      n.prevDep = s.prevDep, s.prevDep && (s.prevDep.nextDep = n), s.prevDep = ye.depsTail, s.nextDep = void 0, ye.depsTail.nextDep = s, ye.depsTail = s, ye.deps === s && (ye.deps = n);
    }
    return s;
  }
  trigger(t) {
    this.version++, is++, this.notify(t);
  }
  notify(t) {
    Tn();
    try {
      for (let s = this.subs; s; s = s.prevSub)
        s.sub.notify() && s.sub.dep.notify();
    } finally {
      Pn();
    }
  }
}
function oi(e) {
  if (e.dep.sc++, e.sub.flags & 4) {
    const t = e.dep.computed;
    if (t && !e.dep.subs) {
      t.flags |= 20;
      for (let n = t.deps; n; n = n.nextDep)
        oi(n);
    }
    const s = e.dep.subs;
    s !== e && (e.prevSub = s, s && (s.nextSub = e)), e.dep.subs = e;
  }
}
const dn = /* @__PURE__ */ new WeakMap(), Mt = /* @__PURE__ */ Symbol(
  ""
), hn = /* @__PURE__ */ Symbol(
  ""
), os = /* @__PURE__ */ Symbol(
  ""
);
function Re(e, t, s) {
  if (Ze && ye) {
    let n = dn.get(e);
    n || dn.set(e, n = /* @__PURE__ */ new Map());
    let r = n.get(s);
    r || (n.set(s, r = new Rn()), r.map = n, r.key = s), r.track();
  }
}
function bt(e, t, s, n, r, i) {
  const o = dn.get(e);
  if (!o) {
    is++;
    return;
  }
  const a = (l) => {
    l && l.trigger();
  };
  if (Tn(), t === "clear")
    o.forEach(a);
  else {
    const l = Y(e), f = l && kn(s);
    if (l && s === "length") {
      const c = Number(n);
      o.forEach((d, g) => {
        (g === "length" || g === os || !et(g) && g >= c) && a(d);
      });
    } else
      switch ((s !== void 0 || o.has(void 0)) && a(o.get(s)), f && a(o.get(os)), t) {
        case "add":
          l ? f && a(o.get("length")) : (a(o.get(Mt)), Ut(e) && a(o.get(hn)));
          break;
        case "delete":
          l || (a(o.get(Mt)), Ut(e) && a(o.get(hn)));
          break;
        case "set":
          Ut(e) && a(o.get(Mt));
          break;
      }
  }
  Pn();
}
function Ft(e) {
  const t = /* @__PURE__ */ ue(e);
  return t === e ? t : (Re(t, "iterate", os), /* @__PURE__ */ Xe(e) ? t : t.map(tt));
}
function Us(e) {
  return Re(e = /* @__PURE__ */ ue(e), "iterate", os), e;
}
function lt(e, t) {
  return /* @__PURE__ */ It(e) ? Wt(/* @__PURE__ */ Ot(e) ? tt(t) : t) : tt(t);
}
const Ro = {
  __proto__: null,
  [Symbol.iterator]() {
    return Qs(this, Symbol.iterator, (e) => lt(this, e));
  },
  concat(...e) {
    return Ft(this).concat(
      ...e.map((t) => Y(t) ? Ft(t) : t)
    );
  },
  entries() {
    return Qs(this, "entries", (e) => (e[1] = lt(this, e[1]), e));
  },
  every(e, t) {
    return gt(this, "every", e, t, void 0, arguments);
  },
  filter(e, t) {
    return gt(
      this,
      "filter",
      e,
      t,
      (s) => s.map((n) => lt(this, n)),
      arguments
    );
  },
  find(e, t) {
    return gt(
      this,
      "find",
      e,
      t,
      (s) => lt(this, s),
      arguments
    );
  },
  findIndex(e, t) {
    return gt(this, "findIndex", e, t, void 0, arguments);
  },
  findLast(e, t) {
    return gt(
      this,
      "findLast",
      e,
      t,
      (s) => lt(this, s),
      arguments
    );
  },
  findLastIndex(e, t) {
    return gt(this, "findLastIndex", e, t, void 0, arguments);
  },
  // flat, flatMap could benefit from ARRAY_ITERATE but are not straight-forward to implement
  forEach(e, t) {
    return gt(this, "forEach", e, t, void 0, arguments);
  },
  includes(...e) {
    return Zs(this, "includes", e);
  },
  indexOf(...e) {
    return Zs(this, "indexOf", e);
  },
  join(e) {
    return Ft(this).join(e);
  },
  // keys() iterator only reads `length`, no optimization required
  lastIndexOf(...e) {
    return Zs(this, "lastIndexOf", e);
  },
  map(e, t) {
    return gt(this, "map", e, t, void 0, arguments);
  },
  pop() {
    return Yt(this, "pop");
  },
  push(...e) {
    return Yt(this, "push", e);
  },
  reduce(e, ...t) {
    return ir(this, "reduce", e, t);
  },
  reduceRight(e, ...t) {
    return ir(this, "reduceRight", e, t);
  },
  shift() {
    return Yt(this, "shift");
  },
  // slice could use ARRAY_ITERATE but also seems to beg for range tracking
  some(e, t) {
    return gt(this, "some", e, t, void 0, arguments);
  },
  splice(...e) {
    return Yt(this, "splice", e);
  },
  toReversed() {
    return Ft(this).toReversed();
  },
  toSorted(e) {
    return Ft(this).toSorted(e);
  },
  toSpliced(...e) {
    return Ft(this).toSpliced(...e);
  },
  unshift(...e) {
    return Yt(this, "unshift", e);
  },
  values() {
    return Qs(this, "values", (e) => lt(this, e));
  }
};
function Qs(e, t, s) {
  const n = Us(e), r = n[t]();
  return n !== e && !/* @__PURE__ */ Xe(e) && (r._next = r.next, r.next = () => {
    const i = r._next();
    return i.done || (i.value = s(i.value)), i;
  }), r;
}
const Mo = Array.prototype;
function gt(e, t, s, n, r, i) {
  const o = Us(e), a = o !== e && !/* @__PURE__ */ Xe(e), l = o[t];
  if (l !== Mo[t]) {
    const d = l.apply(e, i);
    return a ? tt(d) : d;
  }
  let f = s;
  o !== e && (a ? f = function(d, g) {
    return s.call(this, lt(e, d), g, e);
  } : s.length > 2 && (f = function(d, g) {
    return s.call(this, d, g, e);
  }));
  const c = l.call(o, f, n);
  return a && r ? r(c) : c;
}
function ir(e, t, s, n) {
  const r = Us(e), i = r !== e && !/* @__PURE__ */ Xe(e);
  let o = s, a = !1;
  r !== e && (i ? (a = n.length === 0, o = function(f, c, d) {
    return a && (a = !1, f = lt(e, f)), s.call(this, f, lt(e, c), d, e);
  }) : s.length > 3 && (o = function(f, c, d) {
    return s.call(this, f, c, d, e);
  }));
  const l = r[t](o, ...n);
  return a ? lt(e, l) : l;
}
function Zs(e, t, s) {
  const n = /* @__PURE__ */ ue(e);
  Re(n, "iterate", os);
  const r = n[t](...s);
  return (r === -1 || r === !1) && /* @__PURE__ */ qn(s[0]) ? (s[0] = /* @__PURE__ */ ue(s[0]), n[t](...s)) : r;
}
function Yt(e, t, s = []) {
  wt(), Tn();
  const n = (/* @__PURE__ */ ue(e))[t].apply(e, s);
  return Pn(), St(), n;
}
const Oo = /* @__PURE__ */ An("__proto__,__v_isRef,__isVue"), ai = new Set(
  /* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((e) => e !== "arguments" && e !== "caller").map((e) => Symbol[e]).filter(et)
);
function qo(e) {
  et(e) || (e = String(e));
  const t = /* @__PURE__ */ ue(this);
  return Re(t, "has", e), t.hasOwnProperty(e);
}
class li {
  constructor(t = !1, s = !1) {
    this._isReadonly = t, this._isShallow = s;
  }
  get(t, s, n) {
    if (s === "__v_skip") return t.__v_skip;
    const r = this._isReadonly, i = this._isShallow;
    if (s === "__v_isReactive")
      return !r;
    if (s === "__v_isReadonly")
      return r;
    if (s === "__v_isShallow")
      return i;
    if (s === "__v_raw")
      return n === (r ? i ? Ho : di : i ? fi : ui).get(t) || // receiver is not the reactive proxy, but has the same prototype
      // this means the receiver is a user proxy of the reactive proxy
      Object.getPrototypeOf(t) === Object.getPrototypeOf(n) ? t : void 0;
    const o = Y(t);
    if (!r) {
      let l;
      if (o && (l = Ro[s]))
        return l;
      if (s === "hasOwnProperty")
        return qo;
    }
    const a = Reflect.get(
      t,
      s,
      // if this is a proxy wrapping a ref, return methods using the raw ref
      // as receiver so that we don't have to call `toRaw` on the ref in all
      // its class methods
      /* @__PURE__ */ qe(t) ? t : n
    );
    if ((et(s) ? ai.has(s) : Oo(s)) || (r || Re(t, "get", s), i))
      return a;
    if (/* @__PURE__ */ qe(a)) {
      const l = o && kn(s) ? a : a.value;
      return r && de(l) ? /* @__PURE__ */ gn(l) : l;
    }
    return de(a) ? r ? /* @__PURE__ */ gn(a) : /* @__PURE__ */ Vs(a) : a;
  }
}
class ci extends li {
  constructor(t = !1) {
    super(!1, t);
  }
  set(t, s, n, r) {
    let i = t[s];
    const o = Y(t) && kn(s);
    if (!this._isShallow) {
      const f = /* @__PURE__ */ It(i);
      if (!/* @__PURE__ */ Xe(n) && !/* @__PURE__ */ It(n) && (i = /* @__PURE__ */ ue(i), n = /* @__PURE__ */ ue(n)), !o && /* @__PURE__ */ qe(i) && !/* @__PURE__ */ qe(n))
        return f || (i.value = n), !0;
    }
    const a = o ? Number(s) < t.length : ce(t, s), l = Reflect.set(
      t,
      s,
      n,
      /* @__PURE__ */ qe(t) ? t : r
    );
    return t === /* @__PURE__ */ ue(r) && (a ? ut(n, i) && bt(t, "set", s, n) : bt(t, "add", s, n)), l;
  }
  deleteProperty(t, s) {
    const n = ce(t, s);
    t[s];
    const r = Reflect.deleteProperty(t, s);
    return r && n && bt(t, "delete", s, void 0), r;
  }
  has(t, s) {
    const n = Reflect.has(t, s);
    return (!et(s) || !ai.has(s)) && Re(t, "has", s), n;
  }
  ownKeys(t) {
    return Re(
      t,
      "iterate",
      Y(t) ? "length" : Mt
    ), Reflect.ownKeys(t);
  }
}
class jo extends li {
  constructor(t = !1) {
    super(!0, t);
  }
  set(t, s) {
    return !0;
  }
  deleteProperty(t, s) {
    return !0;
  }
}
const Do = /* @__PURE__ */ new ci(), Fo = /* @__PURE__ */ new jo(), No = /* @__PURE__ */ new ci(!0);
const pn = (e) => e, bs = (e) => Reflect.getPrototypeOf(e);
function Ko(e, t, s) {
  return function(...n) {
    const r = this.__v_raw, i = /* @__PURE__ */ ue(r), o = Ut(i), a = e === "entries" || e === Symbol.iterator && o, l = e === "keys" && o, f = r[e](...n), c = s ? pn : t ? Wt : tt;
    return !t && Re(
      i,
      "iterate",
      l ? hn : Mt
    ), we(
      // inheriting all iterator properties
      Object.create(f),
      {
        // iterator protocol
        next() {
          const { value: d, done: g } = f.next();
          return g ? { value: d, done: g } : {
            value: a ? [c(d[0]), c(d[1])] : c(d),
            done: g
          };
        }
      }
    );
  };
}
function _s(e) {
  return function(...t) {
    return e === "delete" ? !1 : e === "clear" ? void 0 : this;
  };
}
function Lo(e, t) {
  const s = {
    get(r) {
      const i = this.__v_raw, o = /* @__PURE__ */ ue(i), a = /* @__PURE__ */ ue(r);
      e || (ut(r, a) && Re(o, "get", r), Re(o, "get", a));
      const { has: l } = bs(o), f = t ? pn : e ? Wt : tt;
      if (l.call(o, r))
        return f(i.get(r));
      if (l.call(o, a))
        return f(i.get(a));
      i !== o && i.get(r);
    },
    get size() {
      const r = this.__v_raw;
      return !e && Re(/* @__PURE__ */ ue(r), "iterate", Mt), r.size;
    },
    has(r) {
      const i = this.__v_raw, o = /* @__PURE__ */ ue(i), a = /* @__PURE__ */ ue(r);
      return e || (ut(r, a) && Re(o, "has", r), Re(o, "has", a)), r === a ? i.has(r) : i.has(r) || i.has(a);
    },
    forEach(r, i) {
      const o = this, a = o.__v_raw, l = /* @__PURE__ */ ue(a), f = t ? pn : e ? Wt : tt;
      return !e && Re(l, "iterate", Mt), a.forEach((c, d) => r.call(i, f(c), f(d), o));
    }
  };
  return we(
    s,
    e ? {
      add: _s("add"),
      set: _s("set"),
      delete: _s("delete"),
      clear: _s("clear")
    } : {
      add(r) {
        const i = /* @__PURE__ */ ue(this), o = bs(i), a = /* @__PURE__ */ ue(r), l = !t && !/* @__PURE__ */ Xe(r) && !/* @__PURE__ */ It(r) ? a : r;
        return o.has.call(i, l) || ut(r, l) && o.has.call(i, r) || ut(a, l) && o.has.call(i, a) || (i.add(l), bt(i, "add", l, l)), this;
      },
      set(r, i) {
        !t && !/* @__PURE__ */ Xe(i) && !/* @__PURE__ */ It(i) && (i = /* @__PURE__ */ ue(i));
        const o = /* @__PURE__ */ ue(this), { has: a, get: l } = bs(o);
        let f = a.call(o, r);
        f || (r = /* @__PURE__ */ ue(r), f = a.call(o, r));
        const c = l.call(o, r);
        return o.set(r, i), f ? ut(i, c) && bt(o, "set", r, i) : bt(o, "add", r, i), this;
      },
      delete(r) {
        const i = /* @__PURE__ */ ue(this), { has: o, get: a } = bs(i);
        let l = o.call(i, r);
        l || (r = /* @__PURE__ */ ue(r), l = o.call(i, r)), a && a.call(i, r);
        const f = i.delete(r);
        return l && bt(i, "delete", r, void 0), f;
      },
      clear() {
        const r = /* @__PURE__ */ ue(this), i = r.size !== 0, o = r.clear();
        return i && bt(
          r,
          "clear",
          void 0,
          void 0
        ), o;
      }
    }
  ), [
    "keys",
    "values",
    "entries",
    Symbol.iterator
  ].forEach((r) => {
    s[r] = Ko(r, e, t);
  }), s;
}
function Mn(e, t) {
  const s = Lo(e, t);
  return (n, r, i) => r === "__v_isReactive" ? !e : r === "__v_isReadonly" ? e : r === "__v_raw" ? n : Reflect.get(
    ce(s, r) && r in n ? s : n,
    r,
    i
  );
}
const Uo = {
  get: /* @__PURE__ */ Mn(!1, !1)
}, Vo = {
  get: /* @__PURE__ */ Mn(!1, !0)
}, Bo = {
  get: /* @__PURE__ */ Mn(!0, !1)
};
const ui = /* @__PURE__ */ new WeakMap(), fi = /* @__PURE__ */ new WeakMap(), di = /* @__PURE__ */ new WeakMap(), Ho = /* @__PURE__ */ new WeakMap();
function Wo(e) {
  switch (e) {
    case "Object":
    case "Array":
      return 1;
    case "Map":
    case "Set":
    case "WeakMap":
    case "WeakSet":
      return 2;
    default:
      return 0;
  }
}
function zo(e) {
  return e.__v_skip || !Object.isExtensible(e) ? 0 : Wo(yo(e));
}
// @__NO_SIDE_EFFECTS__
function Vs(e) {
  return /* @__PURE__ */ It(e) ? e : On(
    e,
    !1,
    Do,
    Uo,
    ui
  );
}
// @__NO_SIDE_EFFECTS__
function Jo(e) {
  return On(
    e,
    !1,
    No,
    Vo,
    fi
  );
}
// @__NO_SIDE_EFFECTS__
function gn(e) {
  return On(
    e,
    !0,
    Fo,
    Bo,
    di
  );
}
function On(e, t, s, n, r) {
  if (!de(e) || e.__v_raw && !(t && e.__v_isReactive))
    return e;
  const i = zo(e);
  if (i === 0)
    return e;
  const o = r.get(e);
  if (o)
    return o;
  const a = new Proxy(
    e,
    i === 2 ? n : s
  );
  return r.set(e, a), a;
}
// @__NO_SIDE_EFFECTS__
function Ot(e) {
  return /* @__PURE__ */ It(e) ? /* @__PURE__ */ Ot(e.__v_raw) : !!(e && e.__v_isReactive);
}
// @__NO_SIDE_EFFECTS__
function It(e) {
  return !!(e && e.__v_isReadonly);
}
// @__NO_SIDE_EFFECTS__
function Xe(e) {
  return !!(e && e.__v_isShallow);
}
// @__NO_SIDE_EFFECTS__
function qn(e) {
  return e ? !!e.__v_raw : !1;
}
// @__NO_SIDE_EFFECTS__
function ue(e) {
  const t = e && e.__v_raw;
  return t ? /* @__PURE__ */ ue(t) : e;
}
function Go(e) {
  return !ce(e, "__v_skip") && Object.isExtensible(e) && Jr(e, "__v_skip", !0), e;
}
const tt = (e) => de(e) ? /* @__PURE__ */ Vs(e) : e, Wt = (e) => de(e) ? /* @__PURE__ */ gn(e) : e;
// @__NO_SIDE_EFFECTS__
function qe(e) {
  return e ? e.__v_isRef === !0 : !1;
}
// @__NO_SIDE_EFFECTS__
function Ne(e) {
  return Yo(e, !1);
}
function Yo(e, t) {
  return /* @__PURE__ */ qe(e) ? e : new Xo(e, t);
}
class Xo {
  constructor(t, s) {
    this.dep = new Rn(), this.__v_isRef = !0, this.__v_isShallow = !1, this._rawValue = s ? t : /* @__PURE__ */ ue(t), this._value = s ? t : tt(t), this.__v_isShallow = s;
  }
  get value() {
    return this.dep.track(), this._value;
  }
  set value(t) {
    const s = this._rawValue, n = this.__v_isShallow || /* @__PURE__ */ Xe(t) || /* @__PURE__ */ It(t);
    t = n ? t : /* @__PURE__ */ ue(t), ut(t, s) && (this._rawValue = t, this._value = n ? t : tt(t), this.dep.trigger());
  }
}
function jn(e) {
  return /* @__PURE__ */ qe(e) ? e.value : e;
}
const Qo = {
  get: (e, t, s) => t === "__v_raw" ? e : jn(Reflect.get(e, t, s)),
  set: (e, t, s, n) => {
    const r = e[t];
    return /* @__PURE__ */ qe(r) && !/* @__PURE__ */ qe(s) ? (r.value = s, !0) : Reflect.set(e, t, s, n);
  }
};
function hi(e) {
  return /* @__PURE__ */ Ot(e) ? e : new Proxy(e, Qo);
}
class Zo {
  constructor(t, s, n) {
    this.fn = t, this.setter = s, this._value = void 0, this.dep = new Rn(this), this.__v_isRef = !0, this.deps = void 0, this.depsTail = void 0, this.flags = 16, this.globalVersion = is - 1, this.next = void 0, this.effect = this, this.__v_isReadonly = !s, this.isSSR = n;
  }
  /**
   * @internal
   */
  notify() {
    if (this.flags |= 16, !(this.flags & 8) && // avoid infinite self recursion
    ye !== this)
      return ti(this, !0), !0;
  }
  get value() {
    const t = this.dep.track();
    return ri(this), t && (t.version = this.dep.version), this._value;
  }
  set value(t) {
    this.setter && this.setter(t);
  }
}
// @__NO_SIDE_EFFECTS__
function ea(e, t, s = !1) {
  let n, r;
  return ee(e) ? n = e : (n = e.get, r = e.set), new Zo(n, r, s);
}
const vs = {}, Cs = /* @__PURE__ */ new WeakMap();
let Rt;
function ta(e, t = !1, s = Rt) {
  if (s) {
    let n = Cs.get(s);
    n || Cs.set(s, n = []), n.push(e);
  }
}
function sa(e, t, s = pe) {
  const { immediate: n, deep: r, once: i, scheduler: o, augmentJob: a, call: l } = s, f = ($) => r ? $ : /* @__PURE__ */ Xe($) || r === !1 || r === 0 ? _t($, 1) : _t($);
  let c, d, g, _, v = !1, p = !1;
  if (/* @__PURE__ */ qe(e) ? (d = () => e.value, v = /* @__PURE__ */ Xe(e)) : /* @__PURE__ */ Ot(e) ? (d = () => f(e), v = !0) : Y(e) ? (p = !0, v = e.some(($) => /* @__PURE__ */ Ot($) || /* @__PURE__ */ Xe($)), d = () => e.map(($) => {
    if (/* @__PURE__ */ qe($))
      return $.value;
    if (/* @__PURE__ */ Ot($))
      return f($);
    if (ee($))
      return l ? l($, 2) : $();
  })) : ee(e) ? t ? d = l ? () => l(e, 2) : e : d = () => {
    if (g) {
      wt();
      try {
        g();
      } finally {
        St();
      }
    }
    const $ = Rt;
    Rt = c;
    try {
      return l ? l(e, 3, [_]) : e(_);
    } finally {
      Rt = $;
    }
  } : d = ft, t && r) {
    const $ = d, W = r === !0 ? 1 / 0 : r;
    d = () => _t($(), W);
  }
  const M = To(), K = () => {
    c.stop(), M && M.active && Cn(M.effects, c);
  };
  if (i && t) {
    const $ = t;
    t = (...W) => {
      $(...W), K();
    };
  }
  let P = p ? new Array(e.length).fill(vs) : vs;
  const V = ($) => {
    if (!(!(c.flags & 1) || !c.dirty && !$))
      if (t) {
        const W = c.run();
        if (r || v || (p ? W.some((y, k) => ut(y, P[k])) : ut(W, P))) {
          g && g();
          const y = Rt;
          Rt = c;
          try {
            const k = [
              W,
              // pass undefined as the old value when it's changed for the first time
              P === vs ? void 0 : p && P[0] === vs ? [] : P,
              _
            ];
            P = W, l ? l(t, 3, k) : (
              // @ts-expect-error
              t(...k)
            );
          } finally {
            Rt = y;
          }
        }
      } else
        c.run();
  };
  return a && a(V), c = new Zr(d), c.scheduler = o ? () => o(V, !1) : V, _ = ($) => ta($, !1, c), g = c.onStop = () => {
    const $ = Cs.get(c);
    if ($) {
      if (l)
        l($, 4);
      else
        for (const W of $) W();
      Cs.delete(c);
    }
  }, t ? n ? V(!0) : P = c.run() : o ? o(V.bind(null, !0), !0) : c.run(), K.pause = c.pause.bind(c), K.resume = c.resume.bind(c), K.stop = K, K;
}
function _t(e, t = 1 / 0, s) {
  if (t <= 0 || !de(e) || e.__v_skip || (s = s || /* @__PURE__ */ new Map(), (s.get(e) || 0) >= t))
    return e;
  if (s.set(e, t), t--, /* @__PURE__ */ qe(e))
    _t(e.value, t, s);
  else if (Y(e))
    for (let n = 0; n < e.length; n++)
      _t(e[n], t, s);
  else if (Ds(e) || Ut(e))
    e.forEach((n) => {
      _t(n, t, s);
    });
  else if (Fs(e)) {
    for (const n in e)
      _t(e[n], t, s);
    for (const n of Object.getOwnPropertySymbols(e))
      Object.prototype.propertyIsEnumerable.call(e, n) && _t(e[n], t, s);
  }
  return e;
}
/**
* @vue/runtime-core v3.5.31
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
function ps(e, t, s, n) {
  try {
    return n ? e(...n) : e();
  } catch (r) {
    Bs(r, t, s);
  }
}
function dt(e, t, s, n) {
  if (ee(e)) {
    const r = ps(e, t, s, n);
    return r && Wr(r) && r.catch((i) => {
      Bs(i, t, s);
    }), r;
  }
  if (Y(e)) {
    const r = [];
    for (let i = 0; i < e.length; i++)
      r.push(dt(e[i], t, s, n));
    return r;
  }
}
function Bs(e, t, s, n = !0) {
  const r = t ? t.vnode : null, { errorHandler: i, throwUnhandledErrorInProduction: o } = t && t.appContext.config || pe;
  if (t) {
    let a = t.parent;
    const l = t.proxy, f = `https://vuejs.org/error-reference/#runtime-${s}`;
    for (; a; ) {
      const c = a.ec;
      if (c) {
        for (let d = 0; d < c.length; d++)
          if (c[d](e, l, f) === !1)
            return;
      }
      a = a.parent;
    }
    if (i) {
      wt(), ps(i, null, 10, [
        e,
        l,
        f
      ]), St();
      return;
    }
  }
  na(e, s, r, n, o);
}
function na(e, t, s, n = !0, r = !1) {
  if (r)
    throw e;
  console.error(e);
}
const Fe = [];
let at = -1;
const Vt = [];
let kt = null, Nt = 0;
const pi = /* @__PURE__ */ Promise.resolve();
let ks = null;
function Dn(e) {
  const t = ks || pi;
  return e ? t.then(this ? e.bind(this) : e) : t;
}
function ra(e) {
  let t = at + 1, s = Fe.length;
  for (; t < s; ) {
    const n = t + s >>> 1, r = Fe[n], i = as(r);
    i < e || i === e && r.flags & 2 ? t = n + 1 : s = n;
  }
  return t;
}
function Fn(e) {
  if (!(e.flags & 1)) {
    const t = as(e), s = Fe[Fe.length - 1];
    !s || // fast path when the job id is larger than the tail
    !(e.flags & 2) && t >= as(s) ? Fe.push(e) : Fe.splice(ra(t), 0, e), e.flags |= 1, gi();
  }
}
function gi() {
  ks || (ks = pi.then(yi));
}
function ia(e) {
  Y(e) ? Vt.push(...e) : kt && e.id === -1 ? kt.splice(Nt + 1, 0, e) : e.flags & 1 || (Vt.push(e), e.flags |= 1), gi();
}
function or(e, t, s = at + 1) {
  for (; s < Fe.length; s++) {
    const n = Fe[s];
    if (n && n.flags & 2) {
      if (e && n.id !== e.uid)
        continue;
      Fe.splice(s, 1), s--, n.flags & 4 && (n.flags &= -2), n(), n.flags & 4 || (n.flags &= -2);
    }
  }
}
function mi(e) {
  if (Vt.length) {
    const t = [...new Set(Vt)].sort(
      (s, n) => as(s) - as(n)
    );
    if (Vt.length = 0, kt) {
      kt.push(...t);
      return;
    }
    for (kt = t, Nt = 0; Nt < kt.length; Nt++) {
      const s = kt[Nt];
      s.flags & 4 && (s.flags &= -2), s.flags & 8 || s(), s.flags &= -2;
    }
    kt = null, Nt = 0;
  }
}
const as = (e) => e.id == null ? e.flags & 2 ? -1 : 1 / 0 : e.id;
function yi(e) {
  try {
    for (at = 0; at < Fe.length; at++) {
      const t = Fe[at];
      t && !(t.flags & 8) && (t.flags & 4 && (t.flags &= -2), ps(
        t,
        t.i,
        t.i ? 15 : 14
      ), t.flags & 4 || (t.flags &= -2));
    }
  } finally {
    for (; at < Fe.length; at++) {
      const t = Fe[at];
      t && (t.flags &= -2);
    }
    at = -1, Fe.length = 0, mi(), ks = null, (Fe.length || Vt.length) && yi();
  }
}
let Pe = null, bi = null;
function Es(e) {
  const t = Pe;
  return Pe = e, bi = e && e.type.__scopeId || null, t;
}
function Ts(e, t = Pe, s) {
  if (!t || e._n)
    return e;
  const n = (...r) => {
    n._d && Rs(-1);
    const i = Es(t);
    let o;
    try {
      o = e(...r);
    } finally {
      Es(i), n._d && Rs(1);
    }
    return o;
  };
  return n._n = !0, n._c = !0, n._d = !0, n;
}
function Kt(e, t) {
  if (Pe === null)
    return e;
  const s = Js(Pe), n = e.dirs || (e.dirs = []);
  for (let r = 0; r < t.length; r++) {
    let [i, o, a, l = pe] = t[r];
    i && (ee(i) && (i = {
      mounted: i,
      updated: i
    }), i.deep && _t(o), n.push({
      dir: i,
      instance: s,
      value: o,
      oldValue: void 0,
      arg: a,
      modifiers: l
    }));
  }
  return e;
}
function Pt(e, t, s, n) {
  const r = e.dirs, i = t && t.dirs;
  for (let o = 0; o < r.length; o++) {
    const a = r[o];
    i && (a.oldValue = i[o].value);
    let l = a.dir[n];
    l && (wt(), dt(l, s, 8, [
      e.el,
      a,
      e,
      t
    ]), St());
  }
}
function oa(e, t) {
  if (Me) {
    let s = Me.provides;
    const n = Me.parent && Me.parent.provides;
    n === s && (s = Me.provides = Object.create(n)), s[e] = t;
  }
}
function Is(e, t, s = !1) {
  const n = rl();
  if (n || Ht) {
    let r = Ht ? Ht._context.provides : n ? n.parent == null || n.ce ? n.vnode.appContext && n.vnode.appContext.provides : n.parent.provides : void 0;
    if (r && e in r)
      return r[e];
    if (arguments.length > 1)
      return s && ee(t) ? t.call(n && n.proxy) : t;
  }
}
const aa = /* @__PURE__ */ Symbol.for("v-scx"), la = () => Is(aa);
function qt(e, t, s) {
  return _i(e, t, s);
}
function _i(e, t, s = pe) {
  const { immediate: n, deep: r, flush: i, once: o } = s, a = we({}, s), l = t && n || !t && i !== "post";
  let f;
  if (fs) {
    if (i === "sync") {
      const _ = la();
      f = _.__watcherHandles || (_.__watcherHandles = []);
    } else if (!l) {
      const _ = () => {
      };
      return _.stop = ft, _.resume = ft, _.pause = ft, _;
    }
  }
  const c = Me;
  a.call = (_, v, p) => dt(_, c, v, p);
  let d = !1;
  i === "post" ? a.scheduler = (_) => {
    Ke(_, c && c.suspense);
  } : i !== "sync" && (d = !0, a.scheduler = (_, v) => {
    v ? _() : Fn(_);
  }), a.augmentJob = (_) => {
    t && (_.flags |= 4), d && (_.flags |= 2, c && (_.id = c.uid, _.i = c));
  };
  const g = sa(e, t, a);
  return fs && (f ? f.push(g) : l && g()), g;
}
function ca(e, t, s) {
  const n = this.proxy, r = ve(e) ? e.includes(".") ? vi(n, e) : () => n[e] : e.bind(n, n);
  let i;
  ee(t) ? i = t : (i = t.handler, s = t);
  const o = gs(this), a = _i(r, i.bind(n), s);
  return o(), a;
}
function vi(e, t) {
  const s = t.split(".");
  return () => {
    let n = e;
    for (let r = 0; r < s.length && n; r++)
      n = n[s[r]];
    return n;
  };
}
const ua = /* @__PURE__ */ Symbol("_vte"), fa = (e) => e.__isTeleport, da = /* @__PURE__ */ Symbol("_leaveCb");
function Nn(e, t) {
  e.shapeFlag & 6 && e.component ? (e.transition = t, Nn(e.component.subTree, t)) : e.shapeFlag & 128 ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t;
}
// @__NO_SIDE_EFFECTS__
function ht(e, t) {
  return ee(e) ? (
    // #8236: extend call and options.name access are considered side-effects
    // by Rollup, so we have to wrap it in a pure-annotated IIFE.
    we({ name: e.name }, t, { setup: e })
  ) : e;
}
function wi(e) {
  e.ids = [e.ids[0] + e.ids[2]++ + "-", 0, 0];
}
function ar(e, t) {
  let s;
  return !!((s = Object.getOwnPropertyDescriptor(e, t)) && !s.configurable);
}
const Ps = /* @__PURE__ */ new WeakMap();
function ss(e, t, s, n, r = !1) {
  if (Y(e)) {
    e.forEach(
      (p, M) => ss(
        p,
        t && (Y(t) ? t[M] : t),
        s,
        n,
        r
      )
    );
    return;
  }
  if (Bt(n) && !r) {
    n.shapeFlag & 512 && n.type.__asyncResolved && n.component.subTree.component && ss(e, t, s, n.component.subTree);
    return;
  }
  const i = n.shapeFlag & 4 ? Js(n.component) : n.el, o = r ? null : i, { i: a, r: l } = e, f = t && t.r, c = a.refs === pe ? a.refs = {} : a.refs, d = a.setupState, g = /* @__PURE__ */ ue(d), _ = d === pe ? Hr : (p) => ar(c, p) ? !1 : ce(g, p), v = (p, M) => !(M && ar(c, M));
  if (f != null && f !== l) {
    if (lr(t), ve(f))
      c[f] = null, _(f) && (d[f] = null);
    else if (/* @__PURE__ */ qe(f)) {
      const p = t;
      v(f, p.k) && (f.value = null), p.k && (c[p.k] = null);
    }
  }
  if (ee(l))
    ps(l, a, 12, [o, c]);
  else {
    const p = ve(l), M = /* @__PURE__ */ qe(l);
    if (p || M) {
      const K = () => {
        if (e.f) {
          const P = p ? _(l) ? d[l] : c[l] : v() || !e.k ? l.value : c[e.k];
          if (r)
            Y(P) && Cn(P, i);
          else if (Y(P))
            P.includes(i) || P.push(i);
          else if (p)
            c[l] = [i], _(l) && (d[l] = c[l]);
          else {
            const V = [i];
            v(l, e.k) && (l.value = V), e.k && (c[e.k] = V);
          }
        } else p ? (c[l] = o, _(l) && (d[l] = o)) : M && (v(l, e.k) && (l.value = o), e.k && (c[e.k] = o));
      };
      if (o) {
        const P = () => {
          K(), Ps.delete(e);
        };
        P.id = -1, Ps.set(e, P), Ke(P, s);
      } else
        lr(e), K();
    }
  }
}
function lr(e) {
  const t = Ps.get(e);
  t && (t.flags |= 8, Ps.delete(e));
}
Ls().requestIdleCallback;
Ls().cancelIdleCallback;
const Bt = (e) => !!e.type.__asyncLoader, Si = (e) => e.type.__isKeepAlive;
function ha(e, t) {
  Ii(e, "a", t);
}
function pa(e, t) {
  Ii(e, "da", t);
}
function Ii(e, t, s = Me) {
  const n = e.__wdc || (e.__wdc = () => {
    let r = s;
    for (; r; ) {
      if (r.isDeactivated)
        return;
      r = r.parent;
    }
    return e();
  });
  if (Hs(t, n, s), s) {
    let r = s.parent;
    for (; r && r.parent; )
      Si(r.parent.vnode) && ga(n, t, s, r), r = r.parent;
  }
}
function ga(e, t, s, n) {
  const r = Hs(
    t,
    e,
    n,
    !0
    /* prepend */
  );
  Ln(() => {
    Cn(n[t], r);
  }, s);
}
function Hs(e, t, s = Me, n = !1) {
  if (s) {
    const r = s[e] || (s[e] = []), i = t.__weh || (t.__weh = (...o) => {
      wt();
      const a = gs(s), l = dt(t, s, e, o);
      return a(), St(), l;
    });
    return n ? r.unshift(i) : r.push(i), i;
  }
}
const At = (e) => (t, s = Me) => {
  (!fs || e === "sp") && Hs(e, (...n) => t(...n), s);
}, ma = At("bm"), Kn = At("m"), ya = At(
  "bu"
), ba = At("u"), _a = At(
  "bum"
), Ln = At("um"), va = At(
  "sp"
), wa = At("rtg"), Sa = At("rtc");
function Ia(e, t = Me) {
  Hs("ec", e, t);
}
const xa = "components", xi = /* @__PURE__ */ Symbol.for("v-ndc");
function Aa(e) {
  return ve(e) ? Ca(xa, e, !1) || e : e || xi;
}
function Ca(e, t, s = !0, n = !1) {
  const r = Pe || Me;
  if (r) {
    const i = r.type;
    {
      const a = cl(
        i,
        !1
      );
      if (a && (a === t || a === Ee(t) || a === Ks(Ee(t))))
        return i;
    }
    const o = (
      // local registration
      // check instance[type] first which is resolved for options API
      cr(r[e] || i[e], t) || // global registration
      cr(r.appContext[e], t)
    );
    return !o && n ? i : o;
  }
}
function cr(e, t) {
  return e && (e[t] || e[Ee(t)] || e[Ks(Ee(t))]);
}
function Ve(e, t, s, n) {
  let r;
  const i = s, o = Y(e);
  if (o || ve(e)) {
    const a = o && /* @__PURE__ */ Ot(e);
    let l = !1, f = !1;
    a && (l = !/* @__PURE__ */ Xe(e), f = /* @__PURE__ */ It(e), e = Us(e)), r = new Array(e.length);
    for (let c = 0, d = e.length; c < d; c++)
      r[c] = t(
        l ? f ? Wt(tt(e[c])) : tt(e[c]) : e[c],
        c,
        void 0,
        i
      );
  } else if (typeof e == "number") {
    r = new Array(e);
    for (let a = 0; a < e; a++)
      r[a] = t(a + 1, a, void 0, i);
  } else if (de(e))
    if (e[Symbol.iterator])
      r = Array.from(
        e,
        (a, l) => t(a, l, void 0, i)
      );
    else {
      const a = Object.keys(e);
      r = new Array(a.length);
      for (let l = 0, f = a.length; l < f; l++) {
        const c = a[l];
        r[l] = t(e[c], c, l, i);
      }
    }
  else
    r = [];
  return r;
}
function Ai(e, t) {
  for (let s = 0; s < t.length; s++) {
    const n = t[s];
    if (Y(n))
      for (let r = 0; r < n.length; r++)
        e[n[r].name] = n[r].fn;
    else n && (e[n.name] = n.key ? (...r) => {
      const i = n.fn(...r);
      return i && (i.key = n.key), i;
    } : n.fn);
  }
  return e;
}
function Et(e, t, s = {}, n, r) {
  if (Pe.ce || Pe.parent && Bt(Pe.parent) && Pe.parent.ce) {
    const f = Object.keys(s).length > 0;
    return t !== "default" && (s.name = t), A(), st(
      be,
      null,
      [Oe("slot", s, n && n())],
      f ? -2 : 64
    );
  }
  let i = e[t];
  i && i._c && (i._d = !1), A();
  const o = i && Ci(i(s)), a = s.key || // slot content array of a dynamic conditional slot may have a branch
  // key attached in the `createSlots` helper, respect that
  o && o.key, l = st(
    be,
    {
      key: (a && !et(a) ? a : `_${t}`) + // #7256 force differentiate fallback content from actual content
      (!o && n ? "_fb" : "")
    },
    o || (n ? n() : []),
    o && e._ === 1 ? 64 : -2
  );
  return i && i._c && (i._d = !0), l;
}
function Ci(e) {
  return e.some((t) => cs(t) ? !(t.type === xt || t.type === be && !Ci(t.children)) : !0) ? e : null;
}
const mn = (e) => e ? Ji(e) ? Js(e) : mn(e.parent) : null, ns = (
  // Move PURE marker to new line to workaround compiler discarding it
  // due to type annotation
  /* @__PURE__ */ we(/* @__PURE__ */ Object.create(null), {
    $: (e) => e,
    $el: (e) => e.vnode.el,
    $data: (e) => e.data,
    $props: (e) => e.props,
    $attrs: (e) => e.attrs,
    $slots: (e) => e.slots,
    $refs: (e) => e.refs,
    $parent: (e) => mn(e.parent),
    $root: (e) => mn(e.root),
    $host: (e) => e.ce,
    $emit: (e) => e.emit,
    $options: (e) => Ei(e),
    $forceUpdate: (e) => e.f || (e.f = () => {
      Fn(e.update);
    }),
    $nextTick: (e) => e.n || (e.n = Dn.bind(e.proxy)),
    $watch: (e) => ca.bind(e)
  })
), en = (e, t) => e !== pe && !e.__isScriptSetup && ce(e, t), ka = {
  get({ _: e }, t) {
    if (t === "__v_skip")
      return !0;
    const { ctx: s, setupState: n, data: r, props: i, accessCache: o, type: a, appContext: l } = e;
    if (t[0] !== "$") {
      const g = o[t];
      if (g !== void 0)
        switch (g) {
          case 1:
            return n[t];
          case 2:
            return r[t];
          case 4:
            return s[t];
          case 3:
            return i[t];
        }
      else {
        if (en(n, t))
          return o[t] = 1, n[t];
        if (r !== pe && ce(r, t))
          return o[t] = 2, r[t];
        if (ce(i, t))
          return o[t] = 3, i[t];
        if (s !== pe && ce(s, t))
          return o[t] = 4, s[t];
        yn && (o[t] = 0);
      }
    }
    const f = ns[t];
    let c, d;
    if (f)
      return t === "$attrs" && Re(e.attrs, "get", ""), f(e);
    if (
      // css module (injected by vue-loader)
      (c = a.__cssModules) && (c = c[t])
    )
      return c;
    if (s !== pe && ce(s, t))
      return o[t] = 4, s[t];
    if (
      // global properties
      d = l.config.globalProperties, ce(d, t)
    )
      return d[t];
  },
  set({ _: e }, t, s) {
    const { data: n, setupState: r, ctx: i } = e;
    return en(r, t) ? (r[t] = s, !0) : n !== pe && ce(n, t) ? (n[t] = s, !0) : ce(e.props, t) || t[0] === "$" && t.slice(1) in e ? !1 : (i[t] = s, !0);
  },
  has({
    _: { data: e, setupState: t, accessCache: s, ctx: n, appContext: r, props: i, type: o }
  }, a) {
    let l;
    return !!(s[a] || e !== pe && a[0] !== "$" && ce(e, a) || en(t, a) || ce(i, a) || ce(n, a) || ce(ns, a) || ce(r.config.globalProperties, a) || (l = o.__cssModules) && l[a]);
  },
  defineProperty(e, t, s) {
    return s.get != null ? e._.accessCache[t] = 0 : ce(s, "value") && this.set(e, t, s.value, null), Reflect.defineProperty(e, t, s);
  }
};
function ur(e) {
  return Y(e) ? e.reduce(
    (t, s) => (t[s] = null, t),
    {}
  ) : e;
}
let yn = !0;
function Ea(e) {
  const t = Ei(e), s = e.proxy, n = e.ctx;
  yn = !1, t.beforeCreate && fr(t.beforeCreate, e, "bc");
  const {
    // state
    data: r,
    computed: i,
    methods: o,
    watch: a,
    provide: l,
    inject: f,
    // lifecycle
    created: c,
    beforeMount: d,
    mounted: g,
    beforeUpdate: _,
    updated: v,
    activated: p,
    deactivated: M,
    beforeDestroy: K,
    beforeUnmount: P,
    destroyed: V,
    unmounted: $,
    render: W,
    renderTracked: y,
    renderTriggered: k,
    errorCaptured: z,
    serverPrefetch: U,
    // public API
    expose: Q,
    inheritAttrs: xe,
    // assets
    components: Ae,
    directives: j,
    filters: T
  } = t;
  if (f && Ta(f, n, null), o)
    for (const se in o) {
      const re = o[se];
      ee(re) && (n[se] = re.bind(s));
    }
  if (r) {
    const se = r.call(s, s);
    de(se) && (e.data = /* @__PURE__ */ Vs(se));
  }
  if (yn = !0, i)
    for (const se in i) {
      const re = i[se], ge = ee(re) ? re.bind(s, s) : ee(re.get) ? re.get.bind(s, s) : ft, je = !ee(re) && ee(re.set) ? re.set.bind(s) : ft, Ce = fe({
        get: ge,
        set: je
      });
      Object.defineProperty(n, se, {
        enumerable: !0,
        configurable: !0,
        get: () => Ce.value,
        set: (le) => Ce.value = le
      });
    }
  if (a)
    for (const se in a)
      ki(a[se], n, s, se);
  if (l) {
    const se = ee(l) ? l.call(s) : l;
    Reflect.ownKeys(se).forEach((re) => {
      oa(re, se[re]);
    });
  }
  c && fr(c, e, "c");
  function G(se, re) {
    Y(re) ? re.forEach((ge) => se(ge.bind(s))) : re && se(re.bind(s));
  }
  if (G(ma, d), G(Kn, g), G(ya, _), G(ba, v), G(ha, p), G(pa, M), G(Ia, z), G(Sa, y), G(wa, k), G(_a, P), G(Ln, $), G(va, U), Y(Q))
    if (Q.length) {
      const se = e.exposed || (e.exposed = {});
      Q.forEach((re) => {
        Object.defineProperty(se, re, {
          get: () => s[re],
          set: (ge) => s[re] = ge,
          enumerable: !0
        });
      });
    } else e.exposed || (e.exposed = {});
  W && e.render === ft && (e.render = W), xe != null && (e.inheritAttrs = xe), Ae && (e.components = Ae), j && (e.directives = j), U && wi(e);
}
function Ta(e, t, s = ft) {
  Y(e) && (e = bn(e));
  for (const n in e) {
    const r = e[n];
    let i;
    de(r) ? "default" in r ? i = Is(
      r.from || n,
      r.default,
      !0
    ) : i = Is(r.from || n) : i = Is(r), /* @__PURE__ */ qe(i) ? Object.defineProperty(t, n, {
      enumerable: !0,
      configurable: !0,
      get: () => i.value,
      set: (o) => i.value = o
    }) : t[n] = i;
  }
}
function fr(e, t, s) {
  dt(
    Y(e) ? e.map((n) => n.bind(t.proxy)) : e.bind(t.proxy),
    t,
    s
  );
}
function ki(e, t, s, n) {
  let r = n.includes(".") ? vi(s, n) : () => s[n];
  if (ve(e)) {
    const i = t[e];
    ee(i) && qt(r, i);
  } else if (ee(e))
    qt(r, e.bind(s));
  else if (de(e))
    if (Y(e))
      e.forEach((i) => ki(i, t, s, n));
    else {
      const i = ee(e.handler) ? e.handler.bind(s) : t[e.handler];
      ee(i) && qt(r, i, e);
    }
}
function Ei(e) {
  const t = e.type, { mixins: s, extends: n } = t, {
    mixins: r,
    optionsCache: i,
    config: { optionMergeStrategies: o }
  } = e.appContext, a = i.get(t);
  let l;
  return a ? l = a : !r.length && !s && !n ? l = t : (l = {}, r.length && r.forEach(
    (f) => $s(l, f, o, !0)
  ), $s(l, t, o)), de(t) && i.set(t, l), l;
}
function $s(e, t, s, n = !1) {
  const { mixins: r, extends: i } = t;
  i && $s(e, i, s, !0), r && r.forEach(
    (o) => $s(e, o, s, !0)
  );
  for (const o in t)
    if (!(n && o === "expose")) {
      const a = Pa[o] || s && s[o];
      e[o] = a ? a(e[o], t[o]) : t[o];
    }
  return e;
}
const Pa = {
  data: dr,
  props: hr,
  emits: hr,
  // objects
  methods: Qt,
  computed: Qt,
  // lifecycle
  beforeCreate: De,
  created: De,
  beforeMount: De,
  mounted: De,
  beforeUpdate: De,
  updated: De,
  beforeDestroy: De,
  beforeUnmount: De,
  destroyed: De,
  unmounted: De,
  activated: De,
  deactivated: De,
  errorCaptured: De,
  serverPrefetch: De,
  // assets
  components: Qt,
  directives: Qt,
  // watch
  watch: Ra,
  // provide / inject
  provide: dr,
  inject: $a
};
function dr(e, t) {
  return t ? e ? function() {
    return we(
      ee(e) ? e.call(this, this) : e,
      ee(t) ? t.call(this, this) : t
    );
  } : t : e;
}
function $a(e, t) {
  return Qt(bn(e), bn(t));
}
function bn(e) {
  if (Y(e)) {
    const t = {};
    for (let s = 0; s < e.length; s++)
      t[e[s]] = e[s];
    return t;
  }
  return e;
}
function De(e, t) {
  return e ? [...new Set([].concat(e, t))] : t;
}
function Qt(e, t) {
  return e ? we(/* @__PURE__ */ Object.create(null), e, t) : t;
}
function hr(e, t) {
  return e ? Y(e) && Y(t) ? [.../* @__PURE__ */ new Set([...e, ...t])] : we(
    /* @__PURE__ */ Object.create(null),
    ur(e),
    ur(t ?? {})
  ) : t;
}
function Ra(e, t) {
  if (!e) return t;
  if (!t) return e;
  const s = we(/* @__PURE__ */ Object.create(null), e);
  for (const n in t)
    s[n] = De(e[n], t[n]);
  return s;
}
function Ti() {
  return {
    app: null,
    config: {
      isNativeTag: Hr,
      performance: !1,
      globalProperties: {},
      optionMergeStrategies: {},
      errorHandler: void 0,
      warnHandler: void 0,
      compilerOptions: {}
    },
    mixins: [],
    components: {},
    directives: {},
    provides: /* @__PURE__ */ Object.create(null),
    optionsCache: /* @__PURE__ */ new WeakMap(),
    propsCache: /* @__PURE__ */ new WeakMap(),
    emitsCache: /* @__PURE__ */ new WeakMap()
  };
}
let Ma = 0;
function Oa(e, t) {
  return function(n, r = null) {
    ee(n) || (n = we({}, n)), r != null && !de(r) && (r = null);
    const i = Ti(), o = /* @__PURE__ */ new WeakSet(), a = [];
    let l = !1;
    const f = i.app = {
      _uid: Ma++,
      _component: n,
      _props: r,
      _container: null,
      _context: i,
      _instance: null,
      version: dl,
      get config() {
        return i.config;
      },
      set config(c) {
      },
      use(c, ...d) {
        return o.has(c) || (c && ee(c.install) ? (o.add(c), c.install(f, ...d)) : ee(c) && (o.add(c), c(f, ...d))), f;
      },
      mixin(c) {
        return i.mixins.includes(c) || i.mixins.push(c), f;
      },
      component(c, d) {
        return d ? (i.components[c] = d, f) : i.components[c];
      },
      directive(c, d) {
        return d ? (i.directives[c] = d, f) : i.directives[c];
      },
      mount(c, d, g) {
        if (!l) {
          const _ = f._ceVNode || Oe(n, r);
          return _.appContext = i, g === !0 ? g = "svg" : g === !1 && (g = void 0), e(_, c, g), l = !0, f._container = c, c.__vue_app__ = f, Js(_.component);
        }
      },
      onUnmount(c) {
        a.push(c);
      },
      unmount() {
        l && (dt(
          a,
          f._instance,
          16
        ), e(null, f._container), delete f._container.__vue_app__);
      },
      provide(c, d) {
        return i.provides[c] = d, f;
      },
      runWithContext(c) {
        const d = Ht;
        Ht = f;
        try {
          return c();
        } finally {
          Ht = d;
        }
      }
    };
    return f;
  };
}
let Ht = null;
const qa = (e, t) => t === "modelValue" || t === "model-value" ? e.modelModifiers : e[`${t}Modifiers`] || e[`${Ee(t)}Modifiers`] || e[`${Ge(t)}Modifiers`];
function ja(e, t, ...s) {
  if (e.isUnmounted) return;
  const n = e.vnode.props || pe;
  let r = s;
  const i = t.startsWith("update:"), o = i && qa(n, t.slice(7));
  o && (o.trim && (r = s.map((c) => ve(c) ? c.trim() : c)), o.number && (r = s.map(En)));
  let a, l = n[a = Gs(t)] || // also try camelCase event handler (#2249)
  n[a = Gs(Ee(t))];
  !l && i && (l = n[a = Gs(Ge(t))]), l && dt(
    l,
    e,
    6,
    r
  );
  const f = n[a + "Once"];
  if (f) {
    if (!e.emitted)
      e.emitted = {};
    else if (e.emitted[a])
      return;
    e.emitted[a] = !0, dt(
      f,
      e,
      6,
      r
    );
  }
}
const Da = /* @__PURE__ */ new WeakMap();
function Pi(e, t, s = !1) {
  const n = s ? Da : t.emitsCache, r = n.get(e);
  if (r !== void 0)
    return r;
  const i = e.emits;
  let o = {}, a = !1;
  if (!ee(e)) {
    const l = (f) => {
      const c = Pi(f, t, !0);
      c && (a = !0, we(o, c));
    };
    !s && t.mixins.length && t.mixins.forEach(l), e.extends && l(e.extends), e.mixins && e.mixins.forEach(l);
  }
  return !i && !a ? (de(e) && n.set(e, null), null) : (Y(i) ? i.forEach((l) => o[l] = null) : we(o, i), de(e) && n.set(e, o), o);
}
function Ws(e, t) {
  return !e || !qs(t) ? !1 : (t = t.slice(2).replace(/Once$/, ""), ce(e, t[0].toLowerCase() + t.slice(1)) || ce(e, Ge(t)) || ce(e, t));
}
function pr(e) {
  const {
    type: t,
    vnode: s,
    proxy: n,
    withProxy: r,
    propsOptions: [i],
    slots: o,
    attrs: a,
    emit: l,
    render: f,
    renderCache: c,
    props: d,
    data: g,
    setupState: _,
    ctx: v,
    inheritAttrs: p
  } = e, M = Es(e);
  let K, P;
  try {
    if (s.shapeFlag & 4) {
      const $ = r || n, W = $;
      K = ct(
        f.call(
          W,
          $,
          c,
          d,
          _,
          g,
          v
        )
      ), P = a;
    } else {
      const $ = t;
      K = ct(
        $.length > 1 ? $(
          d,
          { attrs: a, slots: o, emit: l }
        ) : $(
          d,
          null
        )
      ), P = t.props ? a : Fa(a);
    }
  } catch ($) {
    rs.length = 0, Bs($, e, 1), K = Oe(xt);
  }
  let V = K;
  if (P && p !== !1) {
    const $ = Object.keys(P), { shapeFlag: W } = V;
    $.length && W & 7 && (i && $.some(js) && (P = Na(
      P,
      i
    )), V = zt(V, P, !1, !0));
  }
  return s.dirs && (V = zt(V, null, !1, !0), V.dirs = V.dirs ? V.dirs.concat(s.dirs) : s.dirs), s.transition && Nn(V, s.transition), K = V, Es(M), K;
}
const Fa = (e) => {
  let t;
  for (const s in e)
    (s === "class" || s === "style" || qs(s)) && ((t || (t = {}))[s] = e[s]);
  return t;
}, Na = (e, t) => {
  const s = {};
  for (const n in e)
    (!js(n) || !(n.slice(9) in t)) && (s[n] = e[n]);
  return s;
};
function Ka(e, t, s) {
  const { props: n, children: r, component: i } = e, { props: o, children: a, patchFlag: l } = t, f = i.emitsOptions;
  if (t.dirs || t.transition)
    return !0;
  if (s && l >= 0) {
    if (l & 1024)
      return !0;
    if (l & 16)
      return n ? gr(n, o, f) : !!o;
    if (l & 8) {
      const c = t.dynamicProps;
      for (let d = 0; d < c.length; d++) {
        const g = c[d];
        if ($i(o, n, g) && !Ws(f, g))
          return !0;
      }
    }
  } else
    return (r || a) && (!a || !a.$stable) ? !0 : n === o ? !1 : n ? o ? gr(n, o, f) : !0 : !!o;
  return !1;
}
function gr(e, t, s) {
  const n = Object.keys(t);
  if (n.length !== Object.keys(e).length)
    return !0;
  for (let r = 0; r < n.length; r++) {
    const i = n[r];
    if ($i(t, e, i) && !Ws(s, i))
      return !0;
  }
  return !1;
}
function $i(e, t, s) {
  const n = e[s], r = t[s];
  return s === "style" && de(n) && de(r) ? !jt(n, r) : n !== r;
}
function La({ vnode: e, parent: t, suspense: s }, n) {
  for (; t; ) {
    const r = t.subTree;
    if (r.suspense && r.suspense.activeBranch === e && (r.suspense.vnode.el = r.el = n, e = r), r === e)
      (e = t.vnode).el = n, t = t.parent;
    else
      break;
  }
  s && s.activeBranch === e && (s.vnode.el = n);
}
const Ri = {}, Mi = () => Object.create(Ri), Oi = (e) => Object.getPrototypeOf(e) === Ri;
function Ua(e, t, s, n = !1) {
  const r = {}, i = Mi();
  e.propsDefaults = /* @__PURE__ */ Object.create(null), qi(e, t, r, i);
  for (const o in e.propsOptions[0])
    o in r || (r[o] = void 0);
  s ? e.props = n ? r : /* @__PURE__ */ Jo(r) : e.type.props ? e.props = r : e.props = i, e.attrs = i;
}
function Va(e, t, s, n) {
  const {
    props: r,
    attrs: i,
    vnode: { patchFlag: o }
  } = e, a = /* @__PURE__ */ ue(r), [l] = e.propsOptions;
  let f = !1;
  if (
    // always force full diff in dev
    // - #1942 if hmr is enabled with sfc component
    // - vite#872 non-sfc component used by sfc component
    (n || o > 0) && !(o & 16)
  ) {
    if (o & 8) {
      const c = e.vnode.dynamicProps;
      for (let d = 0; d < c.length; d++) {
        let g = c[d];
        if (Ws(e.emitsOptions, g))
          continue;
        const _ = t[g];
        if (l)
          if (ce(i, g))
            _ !== i[g] && (i[g] = _, f = !0);
          else {
            const v = Ee(g);
            r[v] = _n(
              l,
              a,
              v,
              _,
              e,
              !1
            );
          }
        else
          _ !== i[g] && (i[g] = _, f = !0);
      }
    }
  } else {
    qi(e, t, r, i) && (f = !0);
    let c;
    for (const d in a)
      (!t || // for camelCase
      !ce(t, d) && // it's possible the original props was passed in as kebab-case
      // and converted to camelCase (#955)
      ((c = Ge(d)) === d || !ce(t, c))) && (l ? s && // for camelCase
      (s[d] !== void 0 || // for kebab-case
      s[c] !== void 0) && (r[d] = _n(
        l,
        a,
        d,
        void 0,
        e,
        !0
      )) : delete r[d]);
    if (i !== a)
      for (const d in i)
        (!t || !ce(t, d)) && (delete i[d], f = !0);
  }
  f && bt(e.attrs, "set", "");
}
function qi(e, t, s, n) {
  const [r, i] = e.propsOptions;
  let o = !1, a;
  if (t)
    for (let l in t) {
      if (Zt(l))
        continue;
      const f = t[l];
      let c;
      r && ce(r, c = Ee(l)) ? !i || !i.includes(c) ? s[c] = f : (a || (a = {}))[c] = f : Ws(e.emitsOptions, l) || (!(l in n) || f !== n[l]) && (n[l] = f, o = !0);
    }
  if (i) {
    const l = /* @__PURE__ */ ue(s), f = a || pe;
    for (let c = 0; c < i.length; c++) {
      const d = i[c];
      s[d] = _n(
        r,
        l,
        d,
        f[d],
        e,
        !ce(f, d)
      );
    }
  }
  return o;
}
function _n(e, t, s, n, r, i) {
  const o = e[s];
  if (o != null) {
    const a = ce(o, "default");
    if (a && n === void 0) {
      const l = o.default;
      if (o.type !== Function && !o.skipFactory && ee(l)) {
        const { propsDefaults: f } = r;
        if (s in f)
          n = f[s];
        else {
          const c = gs(r);
          n = f[s] = l.call(
            null,
            t
          ), c();
        }
      } else
        n = l;
      r.ce && r.ce._setProp(s, n);
    }
    o[
      0
      /* shouldCast */
    ] && (i && !a ? n = !1 : o[
      1
      /* shouldCastTrue */
    ] && (n === "" || n === Ge(s)) && (n = !0));
  }
  return n;
}
const Ba = /* @__PURE__ */ new WeakMap();
function ji(e, t, s = !1) {
  const n = s ? Ba : t.propsCache, r = n.get(e);
  if (r)
    return r;
  const i = e.props, o = {}, a = [];
  let l = !1;
  if (!ee(e)) {
    const c = (d) => {
      l = !0;
      const [g, _] = ji(d, t, !0);
      we(o, g), _ && a.push(..._);
    };
    !s && t.mixins.length && t.mixins.forEach(c), e.extends && c(e.extends), e.mixins && e.mixins.forEach(c);
  }
  if (!i && !l)
    return de(e) && n.set(e, Lt), Lt;
  if (Y(i))
    for (let c = 0; c < i.length; c++) {
      const d = Ee(i[c]);
      mr(d) && (o[d] = pe);
    }
  else if (i)
    for (const c in i) {
      const d = Ee(c);
      if (mr(d)) {
        const g = i[c], _ = o[d] = Y(g) || ee(g) ? { type: g } : we({}, g), v = _.type;
        let p = !1, M = !0;
        if (Y(v))
          for (let K = 0; K < v.length; ++K) {
            const P = v[K], V = ee(P) && P.name;
            if (V === "Boolean") {
              p = !0;
              break;
            } else V === "String" && (M = !1);
          }
        else
          p = ee(v) && v.name === "Boolean";
        _[
          0
          /* shouldCast */
        ] = p, _[
          1
          /* shouldCastTrue */
        ] = M, (p || ce(_, "default")) && a.push(d);
      }
    }
  const f = [o, a];
  return de(e) && n.set(e, f), f;
}
function mr(e) {
  return e[0] !== "$" && !Zt(e);
}
const Un = (e) => e === "_" || e === "_ctx" || e === "$stable", Vn = (e) => Y(e) ? e.map(ct) : [ct(e)], Ha = (e, t, s) => {
  if (t._n)
    return t;
  const n = Ts((...r) => Vn(t(...r)), s);
  return n._c = !1, n;
}, Di = (e, t, s) => {
  const n = e._ctx;
  for (const r in e) {
    if (Un(r)) continue;
    const i = e[r];
    if (ee(i))
      t[r] = Ha(r, i, n);
    else if (i != null) {
      const o = Vn(i);
      t[r] = () => o;
    }
  }
}, Fi = (e, t) => {
  const s = Vn(t);
  e.slots.default = () => s;
}, Ni = (e, t, s) => {
  for (const n in t)
    (s || !Un(n)) && (e[n] = t[n]);
}, Wa = (e, t, s) => {
  const n = e.slots = Mi();
  if (e.vnode.shapeFlag & 32) {
    const r = t._;
    r ? (Ni(n, t, s), s && Jr(n, "_", r, !0)) : Di(t, n);
  } else t && Fi(e, t);
}, za = (e, t, s) => {
  const { vnode: n, slots: r } = e;
  let i = !0, o = pe;
  if (n.shapeFlag & 32) {
    const a = t._;
    a ? s && a === 1 ? i = !1 : Ni(r, t, s) : (i = !t.$stable, Di(t, r)), o = t;
  } else t && (Fi(e, t), o = { default: 1 });
  if (i)
    for (const a in r)
      !Un(a) && o[a] == null && delete r[a];
}, Ke = Qa;
function Ja(e) {
  return Ga(e);
}
function Ga(e, t) {
  const s = Ls();
  s.__VUE__ = !0;
  const {
    insert: n,
    remove: r,
    patchProp: i,
    createElement: o,
    createText: a,
    createComment: l,
    setText: f,
    setElementText: c,
    parentNode: d,
    nextSibling: g,
    setScopeId: _ = ft,
    insertStaticContent: v
  } = e, p = (u, h, b, C = null, S = null, I = null, F = void 0, q = null, R = !!h.dynamicChildren) => {
    if (u === h)
      return;
    u && !Xt(u, h) && (C = oe(u), le(u, S, I, !0), u = null), h.patchFlag === -2 && (R = !1, h.dynamicChildren = null);
    const { type: x, ref: X, shapeFlag: L } = h;
    switch (x) {
      case zs:
        M(u, h, b, C);
        break;
      case xt:
        K(u, h, b, C);
        break;
      case sn:
        u == null && P(h, b, C, F);
        break;
      case be:
        Ae(
          u,
          h,
          b,
          C,
          S,
          I,
          F,
          q,
          R
        );
        break;
      default:
        L & 1 ? W(
          u,
          h,
          b,
          C,
          S,
          I,
          F,
          q,
          R
        ) : L & 6 ? j(
          u,
          h,
          b,
          C,
          S,
          I,
          F,
          q,
          R
        ) : (L & 64 || L & 128) && x.process(
          u,
          h,
          b,
          C,
          S,
          I,
          F,
          q,
          R,
          Se
        );
    }
    X != null && S ? ss(X, u && u.ref, I, h || u, !h) : X == null && u && u.ref != null && ss(u.ref, null, I, u, !0);
  }, M = (u, h, b, C) => {
    if (u == null)
      n(
        h.el = a(h.children),
        b,
        C
      );
    else {
      const S = h.el = u.el;
      h.children !== u.children && f(S, h.children);
    }
  }, K = (u, h, b, C) => {
    u == null ? n(
      h.el = l(h.children || ""),
      b,
      C
    ) : h.el = u.el;
  }, P = (u, h, b, C) => {
    [u.el, u.anchor] = v(
      u.children,
      h,
      b,
      C,
      u.el,
      u.anchor
    );
  }, V = ({ el: u, anchor: h }, b, C) => {
    let S;
    for (; u && u !== h; )
      S = g(u), n(u, b, C), u = S;
    n(h, b, C);
  }, $ = ({ el: u, anchor: h }) => {
    let b;
    for (; u && u !== h; )
      b = g(u), r(u), u = b;
    r(h);
  }, W = (u, h, b, C, S, I, F, q, R) => {
    if (h.type === "svg" ? F = "svg" : h.type === "math" && (F = "mathml"), u == null)
      y(
        h,
        b,
        C,
        S,
        I,
        F,
        q,
        R
      );
    else {
      const x = u.el && u.el._isVueCE ? u.el : null;
      try {
        x && x._beginPatch(), U(
          u,
          h,
          S,
          I,
          F,
          q,
          R
        );
      } finally {
        x && x._endPatch();
      }
    }
  }, y = (u, h, b, C, S, I, F, q) => {
    let R, x;
    const { props: X, shapeFlag: L, transition: J, dirs: Z } = u;
    if (R = u.el = o(
      u.type,
      I,
      X && X.is,
      X
    ), L & 8 ? c(R, u.children) : L & 16 && z(
      u.children,
      R,
      null,
      C,
      S,
      tn(u, I),
      F,
      q
    ), Z && Pt(u, null, C, "created"), k(R, u, u.scopeId, F, C), X) {
      for (const he in X)
        he !== "value" && !Zt(he) && i(R, he, null, X[he], I, C);
      "value" in X && i(R, "value", null, X.value, I), (x = X.onVnodeBeforeMount) && ot(x, C, u);
    }
    Z && Pt(u, null, C, "beforeMount");
    const ae = Ya(S, J);
    ae && J.beforeEnter(R), n(R, h, b), ((x = X && X.onVnodeMounted) || ae || Z) && Ke(() => {
      try {
        x && ot(x, C, u), ae && J.enter(R), Z && Pt(u, null, C, "mounted");
      } finally {
      }
    }, S);
  }, k = (u, h, b, C, S) => {
    if (b && _(u, b), C)
      for (let I = 0; I < C.length; I++)
        _(u, C[I]);
    if (S) {
      let I = S.subTree;
      if (h === I || Vi(I.type) && (I.ssContent === h || I.ssFallback === h)) {
        const F = S.vnode;
        k(
          u,
          F,
          F.scopeId,
          F.slotScopeIds,
          S.parent
        );
      }
    }
  }, z = (u, h, b, C, S, I, F, q, R = 0) => {
    for (let x = R; x < u.length; x++) {
      const X = u[x] = q ? yt(u[x]) : ct(u[x]);
      p(
        null,
        X,
        h,
        b,
        C,
        S,
        I,
        F,
        q
      );
    }
  }, U = (u, h, b, C, S, I, F) => {
    const q = h.el = u.el;
    let { patchFlag: R, dynamicChildren: x, dirs: X } = h;
    R |= u.patchFlag & 16;
    const L = u.props || pe, J = h.props || pe;
    let Z;
    if (b && $t(b, !1), (Z = J.onVnodeBeforeUpdate) && ot(Z, b, h, u), X && Pt(h, u, b, "beforeUpdate"), b && $t(b, !0), (L.innerHTML && J.innerHTML == null || L.textContent && J.textContent == null) && c(q, ""), x ? Q(
      u.dynamicChildren,
      x,
      q,
      b,
      C,
      tn(h, S),
      I
    ) : F || re(
      u,
      h,
      q,
      null,
      b,
      C,
      tn(h, S),
      I,
      !1
    ), R > 0) {
      if (R & 16)
        xe(q, L, J, b, S);
      else if (R & 2 && L.class !== J.class && i(q, "class", null, J.class, S), R & 4 && i(q, "style", L.style, J.style, S), R & 8) {
        const ae = h.dynamicProps;
        for (let he = 0; he < ae.length; he++) {
          const me = ae[he], Ie = L[me], Te = J[me];
          (Te !== Ie || me === "value") && i(q, me, Ie, Te, S, b);
        }
      }
      R & 1 && u.children !== h.children && c(q, h.children);
    } else !F && x == null && xe(q, L, J, b, S);
    ((Z = J.onVnodeUpdated) || X) && Ke(() => {
      Z && ot(Z, b, h, u), X && Pt(h, u, b, "updated");
    }, C);
  }, Q = (u, h, b, C, S, I, F) => {
    for (let q = 0; q < h.length; q++) {
      const R = u[q], x = h[q], X = (
        // oldVNode may be an errored async setup() component inside Suspense
        // which will not have a mounted element
        R.el && // - In the case of a Fragment, we need to provide the actual parent
        // of the Fragment itself so it can move its children.
        (R.type === be || // - In the case of different nodes, there is going to be a replacement
        // which also requires the correct parent container
        !Xt(R, x) || // - In the case of a component, it could contain anything.
        R.shapeFlag & 198) ? d(R.el) : (
          // In other cases, the parent container is not actually used so we
          // just pass the block element here to avoid a DOM parentNode call.
          b
        )
      );
      p(
        R,
        x,
        X,
        null,
        C,
        S,
        I,
        F,
        !0
      );
    }
  }, xe = (u, h, b, C, S) => {
    if (h !== b) {
      if (h !== pe)
        for (const I in h)
          !Zt(I) && !(I in b) && i(
            u,
            I,
            h[I],
            null,
            S,
            C
          );
      for (const I in b) {
        if (Zt(I)) continue;
        const F = b[I], q = h[I];
        F !== q && I !== "value" && i(u, I, q, F, S, C);
      }
      "value" in b && i(u, "value", h.value, b.value, S);
    }
  }, Ae = (u, h, b, C, S, I, F, q, R) => {
    const x = h.el = u ? u.el : a(""), X = h.anchor = u ? u.anchor : a("");
    let { patchFlag: L, dynamicChildren: J, slotScopeIds: Z } = h;
    Z && (q = q ? q.concat(Z) : Z), u == null ? (n(x, b, C), n(X, b, C), z(
      // #10007
      // such fragment like `<></>` will be compiled into
      // a fragment which doesn't have a children.
      // In this case fallback to an empty array
      h.children || [],
      b,
      X,
      S,
      I,
      F,
      q,
      R
    )) : L > 0 && L & 64 && J && // #2715 the previous fragment could've been a BAILed one as a result
    // of renderSlot() with no valid children
    u.dynamicChildren && u.dynamicChildren.length === J.length ? (Q(
      u.dynamicChildren,
      J,
      b,
      S,
      I,
      F,
      q
    ), // #2080 if the stable fragment has a key, it's a <template v-for> that may
    //  get moved around. Make sure all root level vnodes inherit el.
    // #2134 or if it's a component root, it may also get moved around
    // as the component is being moved.
    (h.key != null || S && h === S.subTree) && Ki(
      u,
      h,
      !0
      /* shallow */
    )) : re(
      u,
      h,
      b,
      X,
      S,
      I,
      F,
      q,
      R
    );
  }, j = (u, h, b, C, S, I, F, q, R) => {
    h.slotScopeIds = q, u == null ? h.shapeFlag & 512 ? S.ctx.activate(
      h,
      b,
      C,
      F,
      R
    ) : T(
      h,
      b,
      C,
      S,
      I,
      F,
      R
    ) : B(u, h, R);
  }, T = (u, h, b, C, S, I, F) => {
    const q = u.component = nl(
      u,
      C,
      S
    );
    if (Si(u) && (q.ctx.renderer = Se), il(q, !1, F), q.asyncDep) {
      if (S && S.registerDep(q, G, F), !u.el) {
        const R = q.subTree = Oe(xt);
        K(null, R, h, b), u.placeholder = R.el;
      }
    } else
      G(
        q,
        u,
        h,
        b,
        S,
        I,
        F
      );
  }, B = (u, h, b) => {
    const C = h.component = u.component;
    if (Ka(u, h, b))
      if (C.asyncDep && !C.asyncResolved) {
        se(C, h, b);
        return;
      } else
        C.next = h, C.update();
    else
      h.el = u.el, C.vnode = h;
  }, G = (u, h, b, C, S, I, F) => {
    const q = () => {
      if (u.isMounted) {
        let { next: L, bu: J, u: Z, parent: ae, vnode: he } = u;
        {
          const rt = Li(u);
          if (rt) {
            L && (L.el = he.el, se(u, L, F)), rt.asyncDep.then(() => {
              Ke(() => {
                u.isUnmounted || x();
              }, S);
            });
            return;
          }
        }
        let me = L, Ie;
        $t(u, !1), L ? (L.el = he.el, se(u, L, F)) : L = he, J && Ss(J), (Ie = L.props && L.props.onVnodeBeforeUpdate) && ot(Ie, ae, L, he), $t(u, !0);
        const Te = pr(u), nt = u.subTree;
        u.subTree = Te, p(
          nt,
          Te,
          // parent may have changed if it's in a teleport
          d(nt.el),
          // anchor may have changed if it's in a fragment
          oe(nt),
          u,
          S,
          I
        ), L.el = Te.el, me === null && La(u, Te.el), Z && Ke(Z, S), (Ie = L.props && L.props.onVnodeUpdated) && Ke(
          () => ot(Ie, ae, L, he),
          S
        );
      } else {
        let L;
        const { el: J, props: Z } = h, { bm: ae, m: he, parent: me, root: Ie, type: Te } = u, nt = Bt(h);
        $t(u, !1), ae && Ss(ae), !nt && (L = Z && Z.onVnodeBeforeMount) && ot(L, me, h), $t(u, !0);
        {
          Ie.ce && Ie.ce._hasShadowRoot() && Ie.ce._injectChildStyle(
            Te,
            u.parent ? u.parent.type : void 0
          );
          const rt = u.subTree = pr(u);
          p(
            null,
            rt,
            b,
            C,
            u,
            S,
            I
          ), h.el = rt.el;
        }
        if (he && Ke(he, S), !nt && (L = Z && Z.onVnodeMounted)) {
          const rt = h;
          Ke(
            () => ot(L, me, rt),
            S
          );
        }
        (h.shapeFlag & 256 || me && Bt(me.vnode) && me.vnode.shapeFlag & 256) && u.a && Ke(u.a, S), u.isMounted = !0, h = b = C = null;
      }
    };
    u.scope.on();
    const R = u.effect = new Zr(q);
    u.scope.off();
    const x = u.update = R.run.bind(R), X = u.job = R.runIfDirty.bind(R);
    X.i = u, X.id = u.uid, R.scheduler = () => Fn(X), $t(u, !0), x();
  }, se = (u, h, b) => {
    h.component = u;
    const C = u.vnode.props;
    u.vnode = h, u.next = null, Va(u, h.props, C, b), za(u, h.children, b), wt(), or(u), St();
  }, re = (u, h, b, C, S, I, F, q, R = !1) => {
    const x = u && u.children, X = u ? u.shapeFlag : 0, L = h.children, { patchFlag: J, shapeFlag: Z } = h;
    if (J > 0) {
      if (J & 128) {
        je(
          x,
          L,
          b,
          C,
          S,
          I,
          F,
          q,
          R
        );
        return;
      } else if (J & 256) {
        ge(
          x,
          L,
          b,
          C,
          S,
          I,
          F,
          q,
          R
        );
        return;
      }
    }
    Z & 8 ? (X & 16 && H(x, S, I), L !== x && c(b, L)) : X & 16 ? Z & 16 ? je(
      x,
      L,
      b,
      C,
      S,
      I,
      F,
      q,
      R
    ) : H(x, S, I, !0) : (X & 8 && c(b, ""), Z & 16 && z(
      L,
      b,
      C,
      S,
      I,
      F,
      q,
      R
    ));
  }, ge = (u, h, b, C, S, I, F, q, R) => {
    u = u || Lt, h = h || Lt;
    const x = u.length, X = h.length, L = Math.min(x, X);
    let J;
    for (J = 0; J < L; J++) {
      const Z = h[J] = R ? yt(h[J]) : ct(h[J]);
      p(
        u[J],
        Z,
        b,
        null,
        S,
        I,
        F,
        q,
        R
      );
    }
    x > X ? H(
      u,
      S,
      I,
      !0,
      !1,
      L
    ) : z(
      h,
      b,
      C,
      S,
      I,
      F,
      q,
      R,
      L
    );
  }, je = (u, h, b, C, S, I, F, q, R) => {
    let x = 0;
    const X = h.length;
    let L = u.length - 1, J = X - 1;
    for (; x <= L && x <= J; ) {
      const Z = u[x], ae = h[x] = R ? yt(h[x]) : ct(h[x]);
      if (Xt(Z, ae))
        p(
          Z,
          ae,
          b,
          null,
          S,
          I,
          F,
          q,
          R
        );
      else
        break;
      x++;
    }
    for (; x <= L && x <= J; ) {
      const Z = u[L], ae = h[J] = R ? yt(h[J]) : ct(h[J]);
      if (Xt(Z, ae))
        p(
          Z,
          ae,
          b,
          null,
          S,
          I,
          F,
          q,
          R
        );
      else
        break;
      L--, J--;
    }
    if (x > L) {
      if (x <= J) {
        const Z = J + 1, ae = Z < X ? h[Z].el : C;
        for (; x <= J; )
          p(
            null,
            h[x] = R ? yt(h[x]) : ct(h[x]),
            b,
            ae,
            S,
            I,
            F,
            q,
            R
          ), x++;
      }
    } else if (x > J)
      for (; x <= L; )
        le(u[x], S, I, !0), x++;
    else {
      const Z = x, ae = x, he = /* @__PURE__ */ new Map();
      for (x = ae; x <= J; x++) {
        const Ue = h[x] = R ? yt(h[x]) : ct(h[x]);
        Ue.key != null && he.set(Ue.key, x);
      }
      let me, Ie = 0;
      const Te = J - ae + 1;
      let nt = !1, rt = 0;
      const Gt = new Array(Te);
      for (x = 0; x < Te; x++) Gt[x] = 0;
      for (x = Z; x <= L; x++) {
        const Ue = u[x];
        if (Ie >= Te) {
          le(Ue, S, I, !0);
          continue;
        }
        let it;
        if (Ue.key != null)
          it = he.get(Ue.key);
        else
          for (me = ae; me <= J; me++)
            if (Gt[me - ae] === 0 && Xt(Ue, h[me])) {
              it = me;
              break;
            }
        it === void 0 ? le(Ue, S, I, !0) : (Gt[it - ae] = x + 1, it >= rt ? rt = it : nt = !0, p(
          Ue,
          h[it],
          b,
          null,
          S,
          I,
          F,
          q,
          R
        ), Ie++);
      }
      const Qn = nt ? Xa(Gt) : Lt;
      for (me = Qn.length - 1, x = Te - 1; x >= 0; x--) {
        const Ue = ae + x, it = h[Ue], Zn = h[Ue + 1], er = Ue + 1 < X ? (
          // #13559, #14173 fallback to el placeholder for unresolved async component
          Zn.el || Ui(Zn)
        ) : C;
        Gt[x] === 0 ? p(
          null,
          it,
          b,
          er,
          S,
          I,
          F,
          q,
          R
        ) : nt && (me < 0 || x !== Qn[me] ? Ce(it, b, er, 2) : me--);
      }
    }
  }, Ce = (u, h, b, C, S = null) => {
    const { el: I, type: F, transition: q, children: R, shapeFlag: x } = u;
    if (x & 6) {
      Ce(u.component.subTree, h, b, C);
      return;
    }
    if (x & 128) {
      u.suspense.move(h, b, C);
      return;
    }
    if (x & 64) {
      F.move(u, h, b, Se);
      return;
    }
    if (F === be) {
      n(I, h, b);
      for (let L = 0; L < R.length; L++)
        Ce(R[L], h, b, C);
      n(u.anchor, h, b);
      return;
    }
    if (F === sn) {
      V(u, h, b);
      return;
    }
    if (C !== 2 && x & 1 && q)
      if (C === 0)
        q.beforeEnter(I), n(I, h, b), Ke(() => q.enter(I), S);
      else {
        const { leave: L, delayLeave: J, afterLeave: Z } = q, ae = () => {
          u.ctx.isUnmounted ? r(I) : n(I, h, b);
        }, he = () => {
          I._isLeaving && I[da](
            !0
            /* cancelled */
          ), L(I, () => {
            ae(), Z && Z();
          });
        };
        J ? J(I, ae, he) : he();
      }
    else
      n(I, h, b);
  }, le = (u, h, b, C = !1, S = !1) => {
    const {
      type: I,
      props: F,
      ref: q,
      children: R,
      dynamicChildren: x,
      shapeFlag: X,
      patchFlag: L,
      dirs: J,
      cacheIndex: Z,
      memo: ae
    } = u;
    if (L === -2 && (S = !1), q != null && (wt(), ss(q, null, b, u, !0), St()), Z != null && (h.renderCache[Z] = void 0), X & 256) {
      h.ctx.deactivate(u);
      return;
    }
    const he = X & 1 && J, me = !Bt(u);
    let Ie;
    if (me && (Ie = F && F.onVnodeBeforeUnmount) && ot(Ie, h, u), X & 6)
      w(u.component, b, C);
    else {
      if (X & 128) {
        u.suspense.unmount(b, C);
        return;
      }
      he && Pt(u, null, h, "beforeUnmount"), X & 64 ? u.type.remove(
        u,
        h,
        b,
        Se,
        C
      ) : x && // #5154
      // when v-once is used inside a block, setBlockTracking(-1) marks the
      // parent block with hasOnce: true
      // so that it doesn't take the fast path during unmount - otherwise
      // components nested in v-once are never unmounted.
      !x.hasOnce && // #1153: fast path should not be taken for non-stable (v-for) fragments
      (I !== be || L > 0 && L & 64) ? H(
        x,
        h,
        b,
        !1,
        !0
      ) : (I === be && L & 384 || !S && X & 16) && H(R, h, b), C && D(u);
    }
    const Te = ae != null && Z == null;
    (me && (Ie = F && F.onVnodeUnmounted) || he || Te) && Ke(() => {
      Ie && ot(Ie, h, u), he && Pt(u, null, h, "unmounted"), Te && (u.el = null);
    }, b);
  }, D = (u) => {
    const { type: h, el: b, anchor: C, transition: S } = u;
    if (h === be) {
      m(b, C);
      return;
    }
    if (h === sn) {
      $(u);
      return;
    }
    const I = () => {
      r(b), S && !S.persisted && S.afterLeave && S.afterLeave();
    };
    if (u.shapeFlag & 1 && S && !S.persisted) {
      const { leave: F, delayLeave: q } = S, R = () => F(b, I);
      q ? q(u.el, I, R) : R();
    } else
      I();
  }, m = (u, h) => {
    let b;
    for (; u !== h; )
      b = g(u), r(u), u = b;
    r(h);
  }, w = (u, h, b) => {
    const { bum: C, scope: S, job: I, subTree: F, um: q, m: R, a: x } = u;
    yr(R), yr(x), C && Ss(C), S.stop(), I && (I.flags |= 8, le(F, u, h, b)), q && Ke(q, h), Ke(() => {
      u.isUnmounted = !0;
    }, h);
  }, H = (u, h, b, C = !1, S = !1, I = 0) => {
    for (let F = I; F < u.length; F++)
      le(u[F], h, b, C, S);
  }, oe = (u) => {
    if (u.shapeFlag & 6)
      return oe(u.component.subTree);
    if (u.shapeFlag & 128)
      return u.suspense.next();
    const h = g(u.anchor || u.el), b = h && h[ua];
    return b ? g(b) : h;
  };
  let O = !1;
  const te = (u, h, b) => {
    let C;
    u == null ? h._vnode && (le(h._vnode, null, null, !0), C = h._vnode.component) : p(
      h._vnode || null,
      u,
      h,
      null,
      null,
      null,
      b
    ), h._vnode = u, O || (O = !0, or(C), mi(), O = !1);
  }, Se = {
    p,
    um: le,
    m: Ce,
    r: D,
    mt: T,
    mc: z,
    pc: re,
    pbc: Q,
    n: oe,
    o: e
  };
  return {
    render: te,
    hydrate: void 0,
    createApp: Oa(te)
  };
}
function tn({ type: e, props: t }, s) {
  return s === "svg" && e === "foreignObject" || s === "mathml" && e === "annotation-xml" && t && t.encoding && t.encoding.includes("html") ? void 0 : s;
}
function $t({ effect: e, job: t }, s) {
  s ? (e.flags |= 32, t.flags |= 4) : (e.flags &= -33, t.flags &= -5);
}
function Ya(e, t) {
  return (!e || e && !e.pendingBranch) && t && !t.persisted;
}
function Ki(e, t, s = !1) {
  const n = e.children, r = t.children;
  if (Y(n) && Y(r))
    for (let i = 0; i < n.length; i++) {
      const o = n[i];
      let a = r[i];
      a.shapeFlag & 1 && !a.dynamicChildren && ((a.patchFlag <= 0 || a.patchFlag === 32) && (a = r[i] = yt(r[i]), a.el = o.el), !s && a.patchFlag !== -2 && Ki(o, a)), a.type === zs && (a.patchFlag === -1 && (a = r[i] = yt(a)), a.el = o.el), a.type === xt && !a.el && (a.el = o.el);
    }
}
function Xa(e) {
  const t = e.slice(), s = [0];
  let n, r, i, o, a;
  const l = e.length;
  for (n = 0; n < l; n++) {
    const f = e[n];
    if (f !== 0) {
      if (r = s[s.length - 1], e[r] < f) {
        t[n] = r, s.push(n);
        continue;
      }
      for (i = 0, o = s.length - 1; i < o; )
        a = i + o >> 1, e[s[a]] < f ? i = a + 1 : o = a;
      f < e[s[i]] && (i > 0 && (t[n] = s[i - 1]), s[i] = n);
    }
  }
  for (i = s.length, o = s[i - 1]; i-- > 0; )
    s[i] = o, o = t[o];
  return s;
}
function Li(e) {
  const t = e.subTree.component;
  if (t)
    return t.asyncDep && !t.asyncResolved ? t : Li(t);
}
function yr(e) {
  if (e)
    for (let t = 0; t < e.length; t++)
      e[t].flags |= 8;
}
function Ui(e) {
  if (e.placeholder)
    return e.placeholder;
  const t = e.component;
  return t ? Ui(t.subTree) : null;
}
const Vi = (e) => e.__isSuspense;
function Qa(e, t) {
  t && t.pendingBranch ? Y(e) ? t.effects.push(...e) : t.effects.push(e) : ia(e);
}
const be = /* @__PURE__ */ Symbol.for("v-fgt"), zs = /* @__PURE__ */ Symbol.for("v-txt"), xt = /* @__PURE__ */ Symbol.for("v-cmt"), sn = /* @__PURE__ */ Symbol.for("v-stc"), rs = [];
let We = null;
function A(e = !1) {
  rs.push(We = e ? null : []);
}
function Za() {
  rs.pop(), We = rs[rs.length - 1] || null;
}
let ls = 1;
function Rs(e, t = !1) {
  ls += e, e < 0 && We && t && (We.hasOnce = !0);
}
function Bi(e) {
  return e.dynamicChildren = ls > 0 ? We || Lt : null, Za(), ls > 0 && We && We.push(e), e;
}
function E(e, t, s, n, r, i) {
  return Bi(
    N(
      e,
      t,
      s,
      n,
      r,
      i,
      !0
    )
  );
}
function st(e, t, s, n, r) {
  return Bi(
    Oe(
      e,
      t,
      s,
      n,
      r,
      !0
    )
  );
}
function cs(e) {
  return e ? e.__v_isVNode === !0 : !1;
}
function Xt(e, t) {
  return e.type === t.type && e.key === t.key;
}
const Hi = ({ key: e }) => e ?? null, xs = ({
  ref: e,
  ref_key: t,
  ref_for: s
}) => (typeof e == "number" && (e = "" + e), e != null ? ve(e) || /* @__PURE__ */ qe(e) || ee(e) ? { i: Pe, r: e, k: t, f: !!s } : e : null);
function N(e, t = null, s = null, n = 0, r = null, i = e === be ? 0 : 1, o = !1, a = !1) {
  const l = {
    __v_isVNode: !0,
    __v_skip: !0,
    type: e,
    props: t,
    key: t && Hi(t),
    ref: t && xs(t),
    scopeId: bi,
    slotScopeIds: null,
    children: s,
    component: null,
    suspense: null,
    ssContent: null,
    ssFallback: null,
    dirs: null,
    transition: null,
    el: null,
    anchor: null,
    target: null,
    targetStart: null,
    targetAnchor: null,
    staticCount: 0,
    shapeFlag: i,
    patchFlag: n,
    dynamicProps: r,
    dynamicChildren: null,
    appContext: null,
    ctx: Pe
  };
  return a ? (Bn(l, s), i & 128 && e.normalize(l)) : s && (l.shapeFlag |= ve(s) ? 8 : 16), ls > 0 && // avoid a block node from tracking itself
  !o && // has current parent block
  We && // presence of a patch flag indicates this node needs patching on updates.
  // component nodes also should always be patched, because even if the
  // component doesn't need to update, it needs to persist the instance on to
  // the next vnode so that it can be properly unmounted later.
  (l.patchFlag > 0 || i & 6) && // the EVENTS flag is only for hydration and if it is the only flag, the
  // vnode should not be considered dynamic due to handler caching.
  l.patchFlag !== 32 && We.push(l), l;
}
const Oe = el;
function el(e, t = null, s = null, n = 0, r = null, i = !1) {
  if ((!e || e === xi) && (e = xt), cs(e)) {
    const a = zt(
      e,
      t,
      !0
      /* mergeRef: true */
    );
    return s && Bn(a, s), ls > 0 && !i && We && (a.shapeFlag & 6 ? We[We.indexOf(e)] = a : We.push(a)), a.patchFlag = -2, a;
  }
  if (ul(e) && (e = e.__vccOpts), t) {
    t = Wi(t);
    let { class: a, style: l } = t;
    a && !ve(a) && (t.class = Ye(a)), de(l) && (/* @__PURE__ */ qn(l) && !Y(l) && (l = we({}, l)), t.style = hs(l));
  }
  const o = ve(e) ? 1 : Vi(e) ? 128 : fa(e) ? 64 : de(e) ? 4 : ee(e) ? 2 : 0;
  return N(
    e,
    t,
    s,
    n,
    r,
    o,
    i,
    !0
  );
}
function Wi(e) {
  return e ? /* @__PURE__ */ qn(e) || Oi(e) ? we({}, e) : e : null;
}
function zt(e, t, s = !1, n = !1) {
  const { props: r, ref: i, patchFlag: o, children: a, transition: l } = e, f = t ? zi(r || {}, t) : r, c = {
    __v_isVNode: !0,
    __v_skip: !0,
    type: e.type,
    props: f,
    key: f && Hi(f),
    ref: t && t.ref ? (
      // #2078 in the case of <component :is="vnode" ref="extra"/>
      // if the vnode itself already has a ref, cloneVNode will need to merge
      // the refs so the single vnode can be set on multiple refs
      s && i ? Y(i) ? i.concat(xs(t)) : [i, xs(t)] : xs(t)
    ) : i,
    scopeId: e.scopeId,
    slotScopeIds: e.slotScopeIds,
    children: a,
    target: e.target,
    targetStart: e.targetStart,
    targetAnchor: e.targetAnchor,
    staticCount: e.staticCount,
    shapeFlag: e.shapeFlag,
    // if the vnode is cloned with extra props, we can no longer assume its
    // existing patch flag to be reliable and need to add the FULL_PROPS flag.
    // note: preserve flag for fragments since they use the flag for children
    // fast paths only.
    patchFlag: t && e.type !== be ? o === -1 ? 16 : o | 16 : o,
    dynamicProps: e.dynamicProps,
    dynamicChildren: e.dynamicChildren,
    appContext: e.appContext,
    dirs: e.dirs,
    transition: l,
    // These should technically only be non-null on mounted VNodes. However,
    // they *should* be copied for kept-alive vnodes. So we just always copy
    // them since them being non-null during a mount doesn't affect the logic as
    // they will simply be overwritten.
    component: e.component,
    suspense: e.suspense,
    ssContent: e.ssContent && zt(e.ssContent),
    ssFallback: e.ssFallback && zt(e.ssFallback),
    placeholder: e.placeholder,
    el: e.el,
    anchor: e.anchor,
    ctx: e.ctx,
    ce: e.ce
  };
  return l && n && Nn(
    c,
    l.clone(c)
  ), c;
}
function us(e = " ", t = 0) {
  return Oe(zs, null, e, t);
}
function ie(e = "", t = !1) {
  return t ? (A(), st(xt, null, e)) : Oe(xt, null, e);
}
function ct(e) {
  return e == null || typeof e == "boolean" ? Oe(xt) : Y(e) ? Oe(
    be,
    null,
    // #3666, avoid reference pollution when reusing vnode
    e.slice()
  ) : cs(e) ? yt(e) : Oe(zs, null, String(e));
}
function yt(e) {
  return e.el === null && e.patchFlag !== -1 || e.memo ? e : zt(e);
}
function Bn(e, t) {
  let s = 0;
  const { shapeFlag: n } = e;
  if (t == null)
    t = null;
  else if (Y(t))
    s = 16;
  else if (typeof t == "object")
    if (n & 65) {
      const r = t.default;
      r && (r._c && (r._d = !1), Bn(e, r()), r._c && (r._d = !0));
      return;
    } else {
      s = 32;
      const r = t._;
      !r && !Oi(t) ? t._ctx = Pe : r === 3 && Pe && (Pe.slots._ === 1 ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024));
    }
  else ee(t) ? (t = { default: t, _ctx: Pe }, s = 32) : (t = String(t), n & 64 ? (s = 16, t = [us(t)]) : s = 8);
  e.children = t, e.shapeFlag |= s;
}
function zi(...e) {
  const t = {};
  for (let s = 0; s < e.length; s++) {
    const n = e[s];
    for (const r in n)
      if (r === "class")
        t.class !== n.class && (t.class = Ye([t.class, n.class]));
      else if (r === "style")
        t.style = hs([t.style, n.style]);
      else if (qs(r)) {
        const i = t[r], o = n[r];
        o && i !== o && !(Y(i) && i.includes(o)) ? t[r] = i ? [].concat(i, o) : o : o == null && i == null && // mergeProps({ 'onUpdate:modelValue': undefined }) should not retain
        // the model listener.
        !js(r) && (t[r] = o);
      } else r !== "" && (t[r] = n[r]);
  }
  return t;
}
function ot(e, t, s, n = null) {
  dt(e, t, 7, [
    s,
    n
  ]);
}
const tl = Ti();
let sl = 0;
function nl(e, t, s) {
  const n = e.type, r = (t ? t.appContext : e.appContext) || tl, i = {
    uid: sl++,
    vnode: e,
    type: n,
    parent: t,
    appContext: r,
    root: null,
    // to be immediately set
    next: null,
    subTree: null,
    // will be set synchronously right after creation
    effect: null,
    update: null,
    // will be set synchronously right after creation
    job: null,
    scope: new Eo(
      !0
      /* detached */
    ),
    render: null,
    proxy: null,
    exposed: null,
    exposeProxy: null,
    withProxy: null,
    provides: t ? t.provides : Object.create(r.provides),
    ids: t ? t.ids : ["", 0, 0],
    accessCache: null,
    renderCache: [],
    // local resolved assets
    components: null,
    directives: null,
    // resolved props and emits options
    propsOptions: ji(n, r),
    emitsOptions: Pi(n, r),
    // emit
    emit: null,
    // to be set immediately
    emitted: null,
    // props default value
    propsDefaults: pe,
    // inheritAttrs
    inheritAttrs: n.inheritAttrs,
    // state
    ctx: pe,
    data: pe,
    props: pe,
    attrs: pe,
    slots: pe,
    refs: pe,
    setupState: pe,
    setupContext: null,
    // suspense related
    suspense: s,
    suspenseId: s ? s.pendingId : 0,
    asyncDep: null,
    asyncResolved: !1,
    // lifecycle hooks
    // not using enums here because it results in computed properties
    isMounted: !1,
    isUnmounted: !1,
    isDeactivated: !1,
    bc: null,
    c: null,
    bm: null,
    m: null,
    bu: null,
    u: null,
    um: null,
    bum: null,
    da: null,
    a: null,
    rtg: null,
    rtc: null,
    ec: null,
    sp: null
  };
  return i.ctx = { _: i }, i.root = t ? t.root : i, i.emit = ja.bind(null, i), e.ce && e.ce(i), i;
}
let Me = null;
const rl = () => Me || Pe;
let Ms, vn;
{
  const e = Ls(), t = (s, n) => {
    let r;
    return (r = e[s]) || (r = e[s] = []), r.push(n), (i) => {
      r.length > 1 ? r.forEach((o) => o(i)) : r[0](i);
    };
  };
  Ms = t(
    "__VUE_INSTANCE_SETTERS__",
    (s) => Me = s
  ), vn = t(
    "__VUE_SSR_SETTERS__",
    (s) => fs = s
  );
}
const gs = (e) => {
  const t = Me;
  return Ms(e), e.scope.on(), () => {
    e.scope.off(), Ms(t);
  };
}, br = () => {
  Me && Me.scope.off(), Ms(null);
};
function Ji(e) {
  return e.vnode.shapeFlag & 4;
}
let fs = !1;
function il(e, t = !1, s = !1) {
  t && vn(t);
  const { props: n, children: r } = e.vnode, i = Ji(e);
  Ua(e, n, i, t), Wa(e, r, s || t);
  const o = i ? ol(e, t) : void 0;
  return t && vn(!1), o;
}
function ol(e, t) {
  const s = e.type;
  e.accessCache = /* @__PURE__ */ Object.create(null), e.proxy = new Proxy(e.ctx, ka);
  const { setup: n } = s;
  if (n) {
    wt();
    const r = e.setupContext = n.length > 1 ? ll(e) : null, i = gs(e), o = ps(
      n,
      e,
      0,
      [
        e.props,
        r
      ]
    ), a = Wr(o);
    if (St(), i(), (a || e.sp) && !Bt(e) && wi(e), a) {
      if (o.then(br, br), t)
        return o.then((l) => {
          _r(e, l);
        }).catch((l) => {
          Bs(l, e, 0);
        });
      e.asyncDep = o;
    } else
      _r(e, o);
  } else
    Gi(e);
}
function _r(e, t, s) {
  ee(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : de(t) && (e.setupState = hi(t)), Gi(e);
}
function Gi(e, t, s) {
  const n = e.type;
  e.render || (e.render = n.render || ft);
  {
    const r = gs(e);
    wt();
    try {
      Ea(e);
    } finally {
      St(), r();
    }
  }
}
const al = {
  get(e, t) {
    return Re(e, "get", ""), e[t];
  }
};
function ll(e) {
  const t = (s) => {
    e.exposed = s || {};
  };
  return {
    attrs: new Proxy(e.attrs, al),
    slots: e.slots,
    emit: e.emit,
    expose: t
  };
}
function Js(e) {
  return e.exposed ? e.exposeProxy || (e.exposeProxy = new Proxy(hi(Go(e.exposed)), {
    get(t, s) {
      if (s in t)
        return t[s];
      if (s in ns)
        return ns[s](e);
    },
    has(t, s) {
      return s in t || s in ns;
    }
  })) : e.proxy;
}
function cl(e, t = !0) {
  return ee(e) ? e.displayName || e.name : e.name || t && e.__name;
}
function ul(e) {
  return ee(e) && "__vccOpts" in e;
}
const fe = (e, t) => /* @__PURE__ */ ea(e, t, fs);
function fl(e, t, s) {
  try {
    Rs(-1);
    const n = arguments.length;
    return n === 2 ? de(t) && !Y(t) ? cs(t) ? Oe(e, null, [t]) : Oe(e, t) : Oe(e, null, t) : (n > 3 ? s = Array.prototype.slice.call(arguments, 2) : n === 3 && cs(s) && (s = [s]), Oe(e, t, s));
  } finally {
    Rs(1);
  }
}
const dl = "3.5.31";
/**
* @vue/runtime-dom v3.5.31
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
let wn;
const vr = typeof window < "u" && window.trustedTypes;
if (vr)
  try {
    wn = /* @__PURE__ */ vr.createPolicy("vue", {
      createHTML: (e) => e
    });
  } catch {
  }
const Yi = wn ? (e) => wn.createHTML(e) : (e) => e, hl = "http://www.w3.org/2000/svg", pl = "http://www.w3.org/1998/Math/MathML", mt = typeof document < "u" ? document : null, wr = mt && /* @__PURE__ */ mt.createElement("template"), gl = {
  insert: (e, t, s) => {
    t.insertBefore(e, s || null);
  },
  remove: (e) => {
    const t = e.parentNode;
    t && t.removeChild(e);
  },
  createElement: (e, t, s, n) => {
    const r = t === "svg" ? mt.createElementNS(hl, e) : t === "mathml" ? mt.createElementNS(pl, e) : s ? mt.createElement(e, { is: s }) : mt.createElement(e);
    return e === "select" && n && n.multiple != null && r.setAttribute("multiple", n.multiple), r;
  },
  createText: (e) => mt.createTextNode(e),
  createComment: (e) => mt.createComment(e),
  setText: (e, t) => {
    e.nodeValue = t;
  },
  setElementText: (e, t) => {
    e.textContent = t;
  },
  parentNode: (e) => e.parentNode,
  nextSibling: (e) => e.nextSibling,
  querySelector: (e) => mt.querySelector(e),
  setScopeId(e, t) {
    e.setAttribute(t, "");
  },
  // __UNSAFE__
  // Reason: innerHTML.
  // Static content here can only come from compiled templates.
  // As long as the user only uses trusted templates, this is safe.
  insertStaticContent(e, t, s, n, r, i) {
    const o = s ? s.previousSibling : t.lastChild;
    if (r && (r === i || r.nextSibling))
      for (; t.insertBefore(r.cloneNode(!0), s), !(r === i || !(r = r.nextSibling)); )
        ;
    else {
      wr.innerHTML = Yi(
        n === "svg" ? `<svg>${e}</svg>` : n === "mathml" ? `<math>${e}</math>` : e
      );
      const a = wr.content;
      if (n === "svg" || n === "mathml") {
        const l = a.firstChild;
        for (; l.firstChild; )
          a.appendChild(l.firstChild);
        a.removeChild(l);
      }
      t.insertBefore(a, s);
    }
    return [
      // first
      o ? o.nextSibling : t.firstChild,
      // last
      s ? s.previousSibling : t.lastChild
    ];
  }
}, ml = /* @__PURE__ */ Symbol("_vtc");
function yl(e, t, s) {
  const n = e[ml];
  n && (t = (t ? [t, ...n] : [...n]).join(" ")), t == null ? e.removeAttribute("class") : s ? e.setAttribute("class", t) : e.className = t;
}
const Sr = /* @__PURE__ */ Symbol("_vod"), bl = /* @__PURE__ */ Symbol("_vsh"), _l = /* @__PURE__ */ Symbol(""), vl = /(?:^|;)\s*display\s*:/;
function wl(e, t, s) {
  const n = e.style, r = ve(s);
  let i = !1;
  if (s && !r) {
    if (t)
      if (ve(t))
        for (const o of t.split(";")) {
          const a = o.slice(0, o.indexOf(":")).trim();
          s[a] == null && As(n, a, "");
        }
      else
        for (const o in t)
          s[o] == null && As(n, o, "");
    for (const o in s)
      o === "display" && (i = !0), As(n, o, s[o]);
  } else if (r) {
    if (t !== s) {
      const o = n[_l];
      o && (s += ";" + o), n.cssText = s, i = vl.test(s);
    }
  } else t && e.removeAttribute("style");
  Sr in e && (e[Sr] = i ? n.display : "", e[bl] && (n.display = "none"));
}
const Ir = /\s*!important$/;
function As(e, t, s) {
  if (Y(s))
    s.forEach((n) => As(e, t, n));
  else if (s == null && (s = ""), t.startsWith("--"))
    e.setProperty(t, s);
  else {
    const n = Sl(e, t);
    Ir.test(s) ? e.setProperty(
      Ge(n),
      s.replace(Ir, ""),
      "important"
    ) : e[n] = s;
  }
}
const xr = ["Webkit", "Moz", "ms"], nn = {};
function Sl(e, t) {
  const s = nn[t];
  if (s)
    return s;
  let n = Ee(t);
  if (n !== "filter" && n in e)
    return nn[t] = n;
  n = Ks(n);
  for (let r = 0; r < xr.length; r++) {
    const i = xr[r] + n;
    if (i in e)
      return nn[t] = i;
  }
  return t;
}
const Ar = "http://www.w3.org/1999/xlink";
function Cr(e, t, s, n, r, i = Co(t)) {
  n && t.startsWith("xlink:") ? s == null ? e.removeAttributeNS(Ar, t.slice(6, t.length)) : e.setAttributeNS(Ar, t, s) : s == null || i && !Gr(s) ? e.removeAttribute(t) : e.setAttribute(
    t,
    i ? "" : et(s) ? String(s) : s
  );
}
function kr(e, t, s, n, r) {
  if (t === "innerHTML" || t === "textContent") {
    s != null && (e[t] = t === "innerHTML" ? Yi(s) : s);
    return;
  }
  const i = e.tagName;
  if (t === "value" && i !== "PROGRESS" && // custom elements may use _value internally
  !i.includes("-")) {
    const a = i === "OPTION" ? e.getAttribute("value") || "" : e.value, l = s == null ? (
      // #11647: value should be set as empty string for null and undefined,
      // but <input type="checkbox"> should be set as 'on'.
      e.type === "checkbox" ? "on" : ""
    ) : String(s);
    (a !== l || !("_value" in e)) && (e.value = l), s == null && e.removeAttribute(t), e._value = s;
    return;
  }
  let o = !1;
  if (s === "" || s == null) {
    const a = typeof e[t];
    a === "boolean" ? s = Gr(s) : s == null && a === "string" ? (s = "", o = !0) : a === "number" && (s = 0, o = !0);
  }
  try {
    e[t] = s;
  } catch {
  }
  o && e.removeAttribute(r || t);
}
function Tt(e, t, s, n) {
  e.addEventListener(t, s, n);
}
function Il(e, t, s, n) {
  e.removeEventListener(t, s, n);
}
const Er = /* @__PURE__ */ Symbol("_vei");
function xl(e, t, s, n, r = null) {
  const i = e[Er] || (e[Er] = {}), o = i[t];
  if (n && o)
    o.value = n;
  else {
    const [a, l] = Al(t);
    if (n) {
      const f = i[t] = El(
        n,
        r
      );
      Tt(e, a, f, l);
    } else o && (Il(e, a, o, l), i[t] = void 0);
  }
}
const Tr = /(?:Once|Passive|Capture)$/;
function Al(e) {
  let t;
  if (Tr.test(e)) {
    t = {};
    let n;
    for (; n = e.match(Tr); )
      e = e.slice(0, e.length - n[0].length), t[n[0].toLowerCase()] = !0;
  }
  return [e[2] === ":" ? e.slice(3) : Ge(e.slice(2)), t];
}
let rn = 0;
const Cl = /* @__PURE__ */ Promise.resolve(), kl = () => rn || (Cl.then(() => rn = 0), rn = Date.now());
function El(e, t) {
  const s = (n) => {
    if (!n._vts)
      n._vts = Date.now();
    else if (n._vts <= s.attached)
      return;
    dt(
      Tl(n, s.value),
      t,
      5,
      [n]
    );
  };
  return s.value = e, s.attached = kl(), s;
}
function Tl(e, t) {
  if (Y(t)) {
    const s = e.stopImmediatePropagation;
    return e.stopImmediatePropagation = () => {
      s.call(e), e._stopped = !0;
    }, t.map(
      (n) => (r) => !r._stopped && n && n(r)
    );
  } else
    return t;
}
const Pr = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && // lowercase letter
e.charCodeAt(2) > 96 && e.charCodeAt(2) < 123, Pl = (e, t, s, n, r, i) => {
  const o = r === "svg";
  t === "class" ? yl(e, n, o) : t === "style" ? wl(e, s, n) : qs(t) ? js(t) || xl(e, t, s, n, i) : (t[0] === "." ? (t = t.slice(1), !0) : t[0] === "^" ? (t = t.slice(1), !1) : $l(e, t, n, o)) ? (kr(e, t, n), !e.tagName.includes("-") && (t === "value" || t === "checked" || t === "selected") && Cr(e, t, n, o, i, t !== "value")) : /* #11081 force set props for possible async custom element */ e._isVueCE && // #12408 check if it's declared prop or it's async custom element
  (Rl(e, t) || // @ts-expect-error _def is private
  e._def.__asyncLoader && (/[A-Z]/.test(t) || !ve(n))) ? kr(e, Ee(t), n, i, t) : (t === "true-value" ? e._trueValue = n : t === "false-value" && (e._falseValue = n), Cr(e, t, n, o));
};
function $l(e, t, s, n) {
  if (n)
    return !!(t === "innerHTML" || t === "textContent" || t in e && Pr(t) && ee(s));
  if (t === "spellcheck" || t === "draggable" || t === "translate" || t === "autocorrect" || t === "sandbox" && e.tagName === "IFRAME" || t === "form" || t === "list" && e.tagName === "INPUT" || t === "type" && e.tagName === "TEXTAREA")
    return !1;
  if (t === "width" || t === "height") {
    const r = e.tagName;
    if (r === "IMG" || r === "VIDEO" || r === "CANVAS" || r === "SOURCE")
      return !1;
  }
  return Pr(t) && ve(s) ? !1 : t in e;
}
function Rl(e, t) {
  const s = (
    // @ts-expect-error _def is private
    e._def.props
  );
  if (!s)
    return !1;
  const n = Ee(t);
  return Array.isArray(s) ? s.some((r) => Ee(r) === n) : Object.keys(s).some((r) => Ee(r) === n);
}
const $r = {};
// @__NO_SIDE_EFFECTS__
function Ml(e, t, s) {
  let n = /* @__PURE__ */ ht(e, t);
  Fs(n) && (n = we({}, n, t));
  class r extends Hn {
    constructor(o) {
      super(n, o, s);
    }
  }
  return r.def = n, r;
}
const Ol = typeof HTMLElement < "u" ? HTMLElement : class {
};
class Hn extends Ol {
  constructor(t, s = {}, n = In) {
    super(), this._def = t, this._props = s, this._createApp = n, this._isVueCE = !0, this._instance = null, this._app = null, this._nonce = this._def.nonce, this._connected = !1, this._resolved = !1, this._patching = !1, this._dirty = !1, this._numberProps = null, this._styleChildren = /* @__PURE__ */ new WeakSet(), this._styleAnchors = /* @__PURE__ */ new WeakMap(), this._ob = null, this.shadowRoot && n !== In ? this._root = this.shadowRoot : t.shadowRoot !== !1 ? (this.attachShadow(
      we({}, t.shadowRootOptions, {
        mode: "open"
      })
    ), this._root = this.shadowRoot) : this._root = this;
  }
  connectedCallback() {
    if (!this.isConnected) return;
    !this.shadowRoot && !this._resolved && this._parseSlots(), this._connected = !0;
    let t = this;
    for (; t = t && // #12479 should check assignedSlot first to get correct parent
    (t.assignedSlot || t.parentNode || t.host); )
      if (t instanceof Hn) {
        this._parent = t;
        break;
      }
    this._instance || (this._resolved ? this._mount(this._def) : t && t._pendingResolve ? this._pendingResolve = t._pendingResolve.then(() => {
      this._pendingResolve = void 0, this._resolveDef();
    }) : this._resolveDef());
  }
  _setParent(t = this._parent) {
    t && (this._instance.parent = t._instance, this._inheritParentContext(t));
  }
  _inheritParentContext(t = this._parent) {
    t && this._app && Object.setPrototypeOf(
      this._app._context.provides,
      t._instance.provides
    );
  }
  disconnectedCallback() {
    this._connected = !1, Dn(() => {
      this._connected || (this._ob && (this._ob.disconnect(), this._ob = null), this._app && this._app.unmount(), this._instance && (this._instance.ce = void 0), this._app = this._instance = null, this._teleportTargets && (this._teleportTargets.clear(), this._teleportTargets = void 0));
    });
  }
  _processMutations(t) {
    for (const s of t)
      this._setAttr(s.attributeName);
  }
  /**
   * resolve inner component definition (handle possible async component)
   */
  _resolveDef() {
    if (this._pendingResolve)
      return;
    for (let n = 0; n < this.attributes.length; n++)
      this._setAttr(this.attributes[n].name);
    this._ob = new MutationObserver(this._processMutations.bind(this)), this._ob.observe(this, { attributes: !0 });
    const t = (n, r = !1) => {
      this._resolved = !0, this._pendingResolve = void 0;
      const { props: i, styles: o } = n;
      let a;
      if (i && !Y(i))
        for (const l in i) {
          const f = i[l];
          (f === Number || f && f.type === Number) && (l in this._props && (this._props[l] = sr(this._props[l])), (a || (a = /* @__PURE__ */ Object.create(null)))[Ee(l)] = !0);
        }
      this._numberProps = a, this._resolveProps(n), this.shadowRoot && this._applyStyles(o), this._mount(n);
    }, s = this._def.__asyncLoader;
    s ? this._pendingResolve = s().then((n) => {
      n.configureApp = this._def.configureApp, t(this._def = n, !0);
    }) : t(this._def);
  }
  _mount(t) {
    this._app = this._createApp(t), this._inheritParentContext(), t.configureApp && t.configureApp(this._app), this._app._ceVNode = this._createVNode(), this._app.mount(this._root);
    const s = this._instance && this._instance.exposed;
    if (s)
      for (const n in s)
        ce(this, n) || Object.defineProperty(this, n, {
          // unwrap ref to be consistent with public instance behavior
          get: () => jn(s[n])
        });
  }
  _resolveProps(t) {
    const { props: s } = t, n = Y(s) ? s : Object.keys(s || {});
    for (const r of Object.keys(this))
      r[0] !== "_" && n.includes(r) && this._setProp(r, this[r]);
    for (const r of n.map(Ee))
      Object.defineProperty(this, r, {
        get() {
          return this._getProp(r);
        },
        set(i) {
          this._setProp(r, i, !0, !this._patching);
        }
      });
  }
  _setAttr(t) {
    if (t.startsWith("data-v-")) return;
    const s = this.hasAttribute(t);
    let n = s ? this.getAttribute(t) : $r;
    const r = Ee(t);
    s && this._numberProps && this._numberProps[r] && (n = sr(n)), this._setProp(r, n, !1, !0);
  }
  /**
   * @internal
   */
  _getProp(t) {
    return this._props[t];
  }
  /**
   * @internal
   */
  _setProp(t, s, n = !0, r = !1) {
    if (s !== this._props[t] && (this._dirty = !0, s === $r ? delete this._props[t] : (this._props[t] = s, t === "key" && this._app && (this._app._ceVNode.key = s)), r && this._instance && this._update(), n)) {
      const i = this._ob;
      i && (this._processMutations(i.takeRecords()), i.disconnect()), s === !0 ? this.setAttribute(Ge(t), "") : typeof s == "string" || typeof s == "number" ? this.setAttribute(Ge(t), s + "") : s || this.removeAttribute(Ge(t)), i && i.observe(this, { attributes: !0 });
    }
  }
  _update() {
    const t = this._createVNode();
    this._app && (t.appContext = this._app._context), Kl(t, this._root);
  }
  _createVNode() {
    const t = {};
    this.shadowRoot || (t.onVnodeMounted = t.onVnodeUpdated = this._renderSlots.bind(this));
    const s = Oe(this._def, we(t, this._props));
    return this._instance || (s.ce = (n) => {
      this._instance = n, n.ce = this, n.isCE = !0;
      const r = (i, o) => {
        this.dispatchEvent(
          new CustomEvent(
            i,
            Fs(o[0]) ? we({ detail: o }, o[0]) : { detail: o }
          )
        );
      };
      n.emit = (i, ...o) => {
        r(i, o), Ge(i) !== i && r(Ge(i), o);
      }, this._setParent();
    }), s;
  }
  _applyStyles(t, s, n) {
    if (!t) return;
    if (s) {
      if (s === this._def || this._styleChildren.has(s))
        return;
      this._styleChildren.add(s);
    }
    const r = this._nonce, i = this.shadowRoot, o = n ? this._getStyleAnchor(n) || this._getStyleAnchor(this._def) : this._getRootStyleInsertionAnchor(i);
    let a = null;
    for (let l = t.length - 1; l >= 0; l--) {
      const f = document.createElement("style");
      r && f.setAttribute("nonce", r), f.textContent = t[l], i.insertBefore(f, a || o), a = f, l === 0 && (n || this._styleAnchors.set(this._def, f), s && this._styleAnchors.set(s, f));
    }
  }
  _getStyleAnchor(t) {
    if (!t)
      return null;
    const s = this._styleAnchors.get(t);
    return s && s.parentNode === this.shadowRoot ? s : (s && this._styleAnchors.delete(t), null);
  }
  _getRootStyleInsertionAnchor(t) {
    for (let s = 0; s < t.childNodes.length; s++) {
      const n = t.childNodes[s];
      if (!(n instanceof HTMLStyleElement))
        return n;
    }
    return null;
  }
  /**
   * Only called when shadowRoot is false
   */
  _parseSlots() {
    const t = this._slots = {};
    let s;
    for (; s = this.firstChild; ) {
      const n = s.nodeType === 1 && s.getAttribute("slot") || "default";
      (t[n] || (t[n] = [])).push(s), this.removeChild(s);
    }
  }
  /**
   * Only called when shadowRoot is false
   */
  _renderSlots() {
    const t = this._getSlots(), s = this._instance.type.__scopeId;
    for (let n = 0; n < t.length; n++) {
      const r = t[n], i = r.getAttribute("name") || "default", o = this._slots[i], a = r.parentNode;
      if (o)
        for (const l of o) {
          if (s && l.nodeType === 1) {
            const f = s + "-s", c = document.createTreeWalker(l, 1);
            l.setAttribute(f, "");
            let d;
            for (; d = c.nextNode(); )
              d.setAttribute(f, "");
          }
          a.insertBefore(l, r);
        }
      else
        for (; r.firstChild; ) a.insertBefore(r.firstChild, r);
      a.removeChild(r);
    }
  }
  /**
   * @internal
   */
  _getSlots() {
    const t = [this];
    this._teleportTargets && t.push(...this._teleportTargets);
    const s = /* @__PURE__ */ new Set();
    for (const n of t) {
      const r = n.querySelectorAll("slot");
      for (let i = 0; i < r.length; i++)
        s.add(r[i]);
    }
    return Array.from(s);
  }
  /**
   * @internal
   */
  _injectChildStyle(t, s) {
    this._applyStyles(t.styles, t, s);
  }
  /**
   * @internal
   */
  _beginPatch() {
    this._patching = !0, this._dirty = !1;
  }
  /**
   * @internal
   */
  _endPatch() {
    this._patching = !1, this._dirty && this._instance && this._update();
  }
  /**
   * @internal
   */
  _hasShadowRoot() {
    return this._def.shadowRoot !== !1;
  }
  /**
   * @internal
   */
  _removeChildStyle(t) {
  }
}
const Jt = (e) => {
  const t = e.props["onUpdate:modelValue"] || !1;
  return Y(t) ? (s) => Ss(t, s) : t;
};
function ql(e) {
  e.target.composing = !0;
}
function Rr(e) {
  const t = e.target;
  t.composing && (t.composing = !1, t.dispatchEvent(new Event("input")));
}
const vt = /* @__PURE__ */ Symbol("_assign");
function Mr(e, t, s) {
  return t && (e = e.trim()), s && (e = En(e)), e;
}
const Sn = {
  created(e, { modifiers: { lazy: t, trim: s, number: n } }, r) {
    e[vt] = Jt(r);
    const i = n || r.props && r.props.type === "number";
    Tt(e, t ? "change" : "input", (o) => {
      o.target.composing || e[vt](Mr(e.value, s, i));
    }), (s || i) && Tt(e, "change", () => {
      e.value = Mr(e.value, s, i);
    }), t || (Tt(e, "compositionstart", ql), Tt(e, "compositionend", Rr), Tt(e, "change", Rr));
  },
  // set value on mounted so it's after min/max for type="range"
  mounted(e, { value: t }) {
    e.value = t ?? "";
  },
  beforeUpdate(e, { value: t, oldValue: s, modifiers: { lazy: n, trim: r, number: i } }, o) {
    if (e[vt] = Jt(o), e.composing) return;
    const a = (i || e.type === "number") && !/^0\d/.test(e.value) ? En(e.value) : e.value, l = t ?? "";
    if (a === l)
      return;
    const f = e.getRootNode();
    (f instanceof Document || f instanceof ShadowRoot) && f.activeElement === e && e.type !== "range" && (n && t === s || r && e.value.trim() === l) || (e.value = l);
  }
}, Or = {
  // #4096 array checkboxes need to be deep traversed
  deep: !0,
  created(e, t, s) {
    e[vt] = Jt(s), Tt(e, "change", () => {
      const n = e._modelValue, r = Xi(e), i = e.checked, o = e[vt];
      if (Y(n)) {
        const a = Yr(n, r), l = a !== -1;
        if (i && !l)
          o(n.concat(r));
        else if (!i && l) {
          const f = [...n];
          f.splice(a, 1), o(f);
        }
      } else if (Ds(n)) {
        const a = new Set(n);
        i ? a.add(r) : a.delete(r), o(a);
      } else
        o(Qi(e, i));
    });
  },
  // set initial checked on mount to wait for true-value/false-value
  mounted: qr,
  beforeUpdate(e, t, s) {
    e[vt] = Jt(s), qr(e, t, s);
  }
};
function qr(e, { value: t, oldValue: s }, n) {
  e._modelValue = t;
  let r;
  if (Y(t))
    r = Yr(t, n.props.value) > -1;
  else if (Ds(t))
    r = t.has(n.props.value);
  else {
    if (t === s) return;
    r = jt(t, Qi(e, !0));
  }
  e.checked !== r && (e.checked = r);
}
const jl = {
  created(e, { value: t }, s) {
    e.checked = jt(t, s.props.value), e[vt] = Jt(s), Tt(e, "change", () => {
      e[vt](Xi(e));
    });
  },
  beforeUpdate(e, { value: t, oldValue: s }, n) {
    e[vt] = Jt(n), t !== s && (e.checked = jt(t, n.props.value));
  }
};
function Xi(e) {
  return "_value" in e ? e._value : e.value;
}
function Qi(e, t) {
  const s = t ? "_trueValue" : "_falseValue";
  return s in e ? e[s] : t;
}
const Dl = ["ctrl", "shift", "alt", "meta"], Fl = {
  stop: (e) => e.stopPropagation(),
  prevent: (e) => e.preventDefault(),
  self: (e) => e.target !== e.currentTarget,
  ctrl: (e) => !e.ctrlKey,
  shift: (e) => !e.shiftKey,
  alt: (e) => !e.altKey,
  meta: (e) => !e.metaKey,
  left: (e) => "button" in e && e.button !== 0,
  middle: (e) => "button" in e && e.button !== 1,
  right: (e) => "button" in e && e.button !== 2,
  exact: (e, t) => Dl.some((s) => e[`${s}Key`] && !t.includes(s))
}, Zi = (e, t) => {
  if (!e) return e;
  const s = e._withMods || (e._withMods = {}), n = t.join(".");
  return s[n] || (s[n] = ((r, ...i) => {
    for (let o = 0; o < t.length; o++) {
      const a = Fl[t[o]];
      if (a && a(r, t)) return;
    }
    return e(r, ...i);
  }));
}, Nl = /* @__PURE__ */ we({ patchProp: Pl }, gl);
let jr;
function eo() {
  return jr || (jr = Ja(Nl));
}
const Kl = ((...e) => {
  eo().render(...e);
}), In = ((...e) => {
  const t = eo().createApp(...e), { mount: s } = t;
  return t.mount = (n) => {
    const r = Ul(n);
    if (!r) return;
    const i = t._component;
    !ee(i) && !i.render && !i.template && (i.template = r.innerHTML), r.nodeType === 1 && (r.textContent = "");
    const o = s(r, !1, Ll(r));
    return r instanceof Element && (r.removeAttribute("v-cloak"), r.setAttribute("data-v-app", "")), o;
  }, t;
});
function Ll(e) {
  if (e instanceof SVGElement)
    return "svg";
  if (typeof MathMLElement == "function" && e instanceof MathMLElement)
    return "mathml";
}
function Ul(e) {
  return ve(e) ? document.querySelector(e) : e;
}
let Dr = 0;
function Be(e = "c") {
  Dr += 1;
  const t = Math.random().toString(36).slice(2, 8);
  return `${e}_${Date.now().toString(36)}_${Dr}_${t}`;
}
function Je() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
function Wn(e) {
  return {
    sessionId: e,
    turnStatus: "idle",
    messages: [],
    error: null
  };
}
function Vl(e) {
  return e.blocks.filter((t) => t.type === "text").map((t) => t.text).join("");
}
function Bl(e) {
  return e.startsWith("debug.");
}
function _e(e, t, s = {}) {
  return {
    protocolVersion: "1.0",
    type: e,
    timestamp: Je(),
    data: t,
    ...s
  };
}
const Hl = {
  form: "form",
  text_question: "text_question",
  textquestion: "text_question",
  select: "select",
  choice: "choice",
  multi_select: "multi_select",
  multiselect: "multi_select",
  confirm: "confirm",
  table: "table",
  detail: "detail",
  card: "card",
  report: "report",
  summary_card: "summary_card",
  summarycard: "summary_card",
  list_card: "list_card",
  listcard: "list_card",
  output_card: "output_card",
  outputcard: "output_card",
  page_action: "page_action",
  pageaction: "page_action",
  custom: "custom"
}, Wl = /* @__PURE__ */ new Set([
  "table",
  "detail",
  "card",
  "report",
  "summary_card",
  "list_card",
  "output_card"
]);
function Qe(e) {
  return !e || typeof e != "object" || Array.isArray(e) ? null : e;
}
function He(e) {
  if (e == null) return;
  const t = String(e).trim();
  return t || void 0;
}
function zl(e) {
  var s;
  const t = ((s = He(e)) == null ? void 0 : s.toLowerCase().replace(/[\s-]+/g, "_")) || "custom";
  return Hl[t] || t;
}
function Jl(e) {
  if (!Array.isArray(e)) return;
  const t = [];
  for (const s of e) {
    const n = Qe(s);
    if (!n) continue;
    const r = He(n.key) || He(n.name) || He(n.id);
    if (!r) continue;
    const i = Array.isArray(n.options) ? n.options.map((o) => {
      const a = Qe(o);
      return a ? {
        value: a.value ?? a.id ?? "",
        label: String(a.label ?? a.name ?? a.value ?? "")
      } : null;
    }).filter((o) => !!o) : void 0;
    t.push({
      key: r,
      name: He(n.name),
      label: String(n.label ?? n.name ?? r),
      type: String(n.type ?? "string"),
      required: n.required === !0,
      targetPath: He(n.targetPath),
      options: i,
      placeholder: He(n.placeholder),
      source: Qe(n.source) || void 0
    });
  }
  return t.length ? t : void 0;
}
function Gl(e) {
  if (!Array.isArray(e)) return;
  const t = [];
  for (const s of e) {
    const n = Qe(s);
    n && t.push({ ...n });
  }
  return t.length ? t : void 0;
}
function Yl(e, t, s) {
  const n = `${e}|${t || ""}|${s || ""}`.slice(0, 80);
  let r = 0;
  for (let i = 0; i < n.length; i += 1)
    r = (r << 5) - r + n.charCodeAt(i) | 0;
  return `local:readonly:${e}:${Math.abs(r).toString(36)}`;
}
function Xl(e) {
  const t = Qe(e);
  if (!t) return null;
  const s = zl(t.component ?? t.type), n = He(t.title), r = He(t.message);
  let i = He(t.interactionId);
  i || (Wl.has(s) ? i = Yl(s, n, r) : i = Be("interaction"));
  const o = Qe(t.extension) || void 0;
  return {
    schemaVersion: "1.0",
    interactionId: i,
    traceId: He(t.traceId),
    type: He(t.type),
    component: s,
    title: n,
    message: r,
    ttlSeconds: typeof t.ttlSeconds == "number" ? t.ttlSeconds : void 0,
    expiresAt: He(t.expiresAt),
    fields: Jl(t.fields),
    prefilled: Qe(t.prefilled) || void 0,
    missing: Array.isArray(t.missing) ? t.missing.map(String) : void 0,
    summary: Qe(t.summary) || void 0,
    data: t.data,
    schema: Qe(t.schema) || void 0,
    actions: Gl(t.actions),
    datasources: Qe(t.datasources) || void 0,
    behavior: Qe(t.behavior) || void 0,
    extension: o
  };
}
function $e(e) {
  return {
    ...e,
    messages: e.messages.map((t) => ({
      ...t,
      blocks: t.blocks.map((s) => ({ ...s })),
      metadata: t.metadata ? { ...t.metadata } : void 0,
      completion: t.completion ? { ...t.completion } : void 0
    })),
    metadata: e.metadata ? { ...e.metadata } : void 0
  };
}
function Ql(e, t) {
  return e.id === t || e.transportMessageId === t;
}
function zn(e) {
  for (let t = e.messages.length - 1; t >= 0; t -= 1) {
    const s = e.messages[t];
    if (s.role === "assistant" && (s.status === "streaming" || s.status === "pending"))
      return s;
  }
}
function Fr(e, t) {
  return zn(e);
}
function Zl(e) {
  for (let t = e.messages.length - 1; t >= 0; t -= 1)
    if (e.messages[t].role === "assistant") return e.messages[t];
}
function Ct(e, t, s, n = {}) {
  if (t) {
    const o = e.messages.find((a) => Ql(a, t));
    if (o && (o.status === "pending" || o.status === "streaming" || n.reuseCompleted))
      return s && (o.metadata = { ...o.metadata || {}, ...s }), o;
  }
  const r = zn(e);
  if (r)
    return t && r.transportMessageId !== t && (r.transportMessageId = t), s && (r.metadata = { ...r.metadata || {}, ...s }), r;
  if (n.reuseCompleted) {
    const o = Zl(e);
    if (o)
      return s && (o.metadata = { ...o.metadata || {}, ...s }), o;
  }
  const i = {
    id: Be("msg"),
    role: "assistant",
    status: "streaming",
    blocks: [],
    createdAt: Je(),
    metadata: s,
    transportMessageId: t
  };
  return e.messages.push(i), i;
}
function to(e, t) {
  return e.blocks.find(
    (s) => s.type === "interaction" && s.request.interactionId === t
  );
}
function Nr(e, t) {
  if (!t) return;
  const s = e.blocks[e.blocks.length - 1];
  if (s && s.type === "text" && s.status !== "completed")
    s.text += t, s.status = "streaming";
  else {
    const n = {
      id: Be("blk"),
      type: "text",
      text: t,
      status: "streaming"
    };
    e.blocks.push(n);
  }
  e.status = "streaming", e.updatedAt = Je();
}
function Kr(e, t, s = "waiting") {
  const n = Xl(t);
  if (!n) return;
  const r = to(e, n.interactionId);
  if (r) {
    r.request = n, (r.state === "waiting" || r.state === "failed") && (r.state = s), e.updatedAt = Je();
    return;
  }
  e.blocks.push({
    id: Be("blk"),
    type: "interaction",
    request: n,
    state: s
  }), e.updatedAt = Je();
}
function on(e) {
  for (const t of e.blocks)
    t.type === "text" && t.status === "streaming" && (t.status = "completed");
}
function ze(e, t) {
  switch (t.type) {
    case "reset":
      return Wn(t.sessionId);
    case "restore":
      return $e(t.snapshot);
    case "set_session": {
      const s = $e(e);
      return s.sessionId = t.sessionId, s;
    }
    case "set_error": {
      const s = $e(e);
      return s.error = t.error, s;
    }
    case "append_user_message": {
      const s = $e(e);
      return s.messages.push({
        id: t.id || Be("msg"),
        role: "user",
        status: "completed",
        blocks: [{ id: Be("blk"), type: "text", text: t.text, status: "completed" }],
        createdAt: Je(),
        metadata: t.metadata
      }), s.error = null, s;
    }
    case "begin_assistant_placeholder": {
      const s = $e(e), n = zn(s);
      return n && (!t.turnId || !n.turnId || n.turnId === t.turnId) ? (t.turnId && (n.turnId = t.turnId, s.turnId = t.turnId), s) : (s.messages.push({
        id: Be("msg"),
        role: "assistant",
        status: "pending",
        blocks: [],
        createdAt: Je(),
        turnId: t.turnId,
        localPlaceholder: !0
      }), t.turnId && (s.turnId = t.turnId), s.error = null, s);
    }
    case "start_assistant_message": {
      const s = $e(e), n = Ct(s, t.id, t.metadata);
      return n.status === "pending" && (n.status = "streaming"), n.updatedAt = Je(), s.turnStatus = s.turnStatus === "waiting" ? "waiting" : "streaming", s.error = null, s;
    }
    case "append_text_delta": {
      const s = $e(e), n = Ct(s, t.messageId);
      return Nr(n, t.text), (s.turnStatus === "idle" || s.turnStatus === "sending") && (s.turnStatus = "streaming"), s;
    }
    case "add_interaction": {
      const s = $e(e), n = Ct(s, t.messageId);
      return Kr(n, t.request, t.state || "waiting"), (s.turnStatus === "idle" || s.turnStatus === "sending") && (s.turnStatus = "streaming"), s;
    }
    case "update_interaction_state": {
      const s = $e(e);
      for (const n of s.messages) {
        const r = to(n, t.interactionId);
        if (r) {
          r.state = t.state, t.result && (r.result = t.result), t.errorMessage !== void 0 && (r.errorMessage = t.errorMessage), n.updatedAt = Je();
          break;
        }
      }
      return s;
    }
    case "add_notice": {
      const s = $e(e);
      return Ct(s, t.messageId).blocks.push({
        id: Be("blk"),
        type: "notice",
        level: t.level || "info",
        text: t.text
      }), s;
    }
    case "add_error_block": {
      const s = $e(e), n = Ct(s, t.messageId);
      return n.blocks.push({
        id: Be("blk"),
        type: "error",
        text: t.text,
        retryable: t.retryable
      }), n.status = "failed", s;
    }
    case "add_page_action": {
      const s = $e(e), n = Ct(s, t.messageId);
      return n.blocks.some(
        (i) => i.type === "page_action" && i.requestId === t.requestId
      ) || !t.requestId || n.blocks.push({
        id: Be("blk"),
        type: "page_action",
        requestId: t.requestId,
        actionKey: t.actionKey,
        title: t.title,
        args: t.args,
        status: "pending"
      }), s;
    }
    case "set_turn_status": {
      const s = $e(e);
      return s.turnStatus = t.status, s;
    }
    case "complete_turn": {
      const s = $e(e);
      t.sessionId && (s.sessionId = t.sessionId);
      const n = Ct(s, void 0, void 0, { reuseCompleted: !0 });
      t.answer && (n.blocks.some((o) => o.type === "text" && o.text) || Nr(n, t.answer)), t.uiRequest && Kr(n, t.uiRequest, "waiting"), on(n);
      const r = n.blocks.some(
        (i) => i.type === "interaction" && i.state === "waiting"
      );
      return n.status = "completed", n.updatedAt = Je(), t.metadata && (n.metadata = { ...n.metadata || {}, ...t.metadata }, s.metadata = { ...s.metadata || {}, ...t.metadata }), t.completion && (n.completion = {
        ...n.completion || {},
        ...t.completion
      }), s.turnStatus = r ? "waiting" : "completed", s.error = null, s;
    }
    case "fail_turn": {
      const s = $e(e), n = Fr(s) || Ct(s);
      return on(n), n.status = "failed", n.blocks.push({
        id: Be("blk"),
        type: "error",
        text: t.message,
        retryable: !0
      }), t.metadata && (n.metadata = { ...n.metadata || {}, ...t.metadata }, s.metadata = { ...s.metadata || {}, ...t.metadata }), n.updatedAt = Je(), s.turnStatus = "failed", s.error = t.message, s;
    }
    case "cancel_turn": {
      const s = $e(e), n = Fr(s);
      return n && (on(n), n.status = "cancelled", n.updatedAt = Je()), s.turnStatus = "cancelled", s.error = null, s;
    }
    case "apply_event":
      return ec(e, t.event);
    default:
      return e;
  }
}
function ec(e, t) {
  const s = t.type, n = t.data && typeof t.data == "object" ? t.data : {}, r = t.turnId && e.turnId !== t.turnId ? { ...e, turnId: t.turnId } : e;
  switch (s) {
    case "session.created":
    case "session.restored":
      return s === "session.restored" && t.data && typeof t.data == "object" && "messages" in t.data ? ze(r, { type: "restore", snapshot: t.data }) : ze(r, { type: "set_session", sessionId: t.sessionId || ke(n.sessionId) });
    case "turn.started":
      return ze(r, { type: "set_turn_status", status: "sending" });
    case "message.started":
      return ze(r, {
        type: "start_assistant_message",
        id: ke(n.messageId)
      });
    case "message.delta": {
      const i = typeof n.text == "string" ? n.text : typeof t.data == "string" ? t.data : "";
      return ze(r, {
        type: "append_text_delta",
        text: i,
        messageId: ke(n.messageId)
      });
    }
    case "ui.requested":
      return ze(r, {
        type: "add_interaction",
        request: n.uiRequest ?? t.data,
        messageId: ke(n.messageId)
      });
    case "page.action.requested":
      return ze(r, {
        type: "add_page_action",
        requestId: String(n.requestId || ""),
        actionKey: String(n.actionKey || ""),
        title: ke(n.title),
        args: n.args || void 0,
        messageId: ke(n.messageId)
      });
    case "turn.waiting":
      return ze(r, {
        type: "complete_turn",
        answer: ke(n.answer),
        uiRequest: n.uiRequest,
        sessionId: t.sessionId || ke(n.sessionId),
        metadata: an(n.metadata, n.result),
        completion: {
          intentType: n.intentType,
          toolCalls: n.toolCalls,
          result: n.result
        }
      });
    case "turn.completed":
      return ze(r, {
        type: "complete_turn",
        answer: ke(n.answer),
        uiRequest: n.uiRequest,
        sessionId: t.sessionId || ke(n.sessionId),
        metadata: {
          ...an(n.metadata, n.result),
          ...t.traceId ? { traceId: t.traceId } : {},
          ...n.traceId ? { traceId: n.traceId } : {}
        },
        completion: {
          intentType: n.intentType,
          toolCalls: n.toolCalls,
          result: n.result
        }
      });
    case "turn.cancelled":
      return ze(r, { type: "cancel_turn" });
    case "turn.failed": {
      const i = an(n.metadata, n.result), o = t.traceId || ke(n.traceId) || ke(i.traceId), a = ke(n.code) || ke(i.code);
      return ze(r, {
        type: "fail_turn",
        message: ke(n.message) || ke(n.error) || "对话失败",
        metadata: {
          ...i,
          success: !1,
          ...a ? { code: a } : {},
          ...o ? { traceId: o } : {},
          ...t.sessionId || ke(n.sessionId) ? { sessionId: t.sessionId || ke(n.sessionId) } : {}
        }
      });
    }
    default:
      return r;
  }
}
function ke(e) {
  if (e == null) return;
  const t = String(e);
  return t || void 0;
}
function an(e, t) {
  if (e && typeof e == "object" && !Array.isArray(e)) {
    const s = e;
    if (s.metadata && typeof s.metadata == "object" && !Array.isArray(s.metadata) && ("answer" in s || "uiRequest" in s || "sessionId" in s)) {
      const r = { ...s.metadata };
      return "success" in s && (r.success = s.success), s.code != null && (r.code = s.code), s.traceId != null && (r.traceId = s.traceId), r;
    }
    if (!("answer" in s) && !("uiRequest" in s))
      return { ...s };
    const n = {};
    if ("success" in s && (n.success = s.success), s.code != null && (n.code = s.code), s.traceId != null && (n.traceId = s.traceId), t && typeof t == "object" && !Array.isArray(t)) {
      const r = t.metadata;
      if (r && typeof r == "object" && !Array.isArray(r))
        return { ...r, ...n };
    }
    return n;
  }
  if (t && typeof t == "object" && !Array.isArray(t)) {
    const s = t, n = s.metadata, r = {};
    return "success" in s && (r.success = s.success), n && typeof n == "object" && !Array.isArray(n) ? { ...n, ...r } : r;
  }
  return {};
}
function tc(e) {
  return Wn(e);
}
function sc(e) {
  const t = e.trim();
  if (!t) return "";
  try {
    return JSON.parse(t);
  } catch {
    return e;
  }
}
function so(e) {
  const s = e.replace(/\r\n/g, `
`).replace(/\r/g, `
`).split(`
`);
  let n = "message", r;
  const i = [];
  for (const a of s)
    if (!(!a || a.startsWith(":"))) {
      if (a.startsWith("event:")) {
        n = a.slice(6).trim();
        continue;
      }
      if (a.startsWith("id:")) {
        r = a.slice(3).trim();
        continue;
      }
      a.startsWith("data:") && i.push(a.slice(5).replace(/^ /, ""));
    }
  if (!i.length && n === "message") return null;
  const o = i.join(`
`);
  return {
    event: n,
    rawData: o,
    data: sc(o),
    id: r
  };
}
function nc(e) {
  const t = [];
  let s = e.replace(/\r\n/g, `
`).replace(/\r/g, `
`), n = s.indexOf(`

`);
  for (; n >= 0; ) {
    const r = s.slice(0, n);
    s = s.slice(n + 2);
    const i = so(r);
    i && t.push(i), n = s.indexOf(`

`);
  }
  return { frames: t, rest: s };
}
async function* rc(e, t = {}) {
  const s = e.getReader(), n = new TextDecoder();
  let r = "";
  const i = t.signal, o = () => {
    if (i != null && i.aborted)
      throw new DOMException("The operation was aborted.", "AbortError");
  };
  try {
    for (; ; ) {
      o();
      const { done: a, value: l } = await s.read();
      if (a) break;
      o(), r += n.decode(l, { stream: !0 });
      const f = nc(r);
      r = f.rest;
      for (const c of f.frames)
        yield c;
    }
    if (r += n.decode(), r.trim()) {
      const a = so(r.trim());
      a && (yield a);
    }
  } finally {
    try {
      s.releaseLock();
    } catch {
    }
  }
}
function Os(e) {
  return !e || typeof e != "object" ? !1 : e.name === "AbortError";
}
const ic = /* @__PURE__ */ new Set([
  "message.delta",
  "ui.requested",
  "page.action.requested",
  "turn.started",
  "turn.waiting",
  "turn.completed",
  "turn.failed",
  "turn.cancelled",
  "interaction.submitted",
  "interaction.cancelled"
]);
function oc(e) {
  const { transport: t, onDebugEvent: s, onPublicEvent: n } = e;
  let r = tc(e.initialSessionId);
  const i = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Set();
  let a = !1, l = null, f = 0, c;
  const d = /* @__PURE__ */ new Set(), g = /* @__PURE__ */ new Set(), _ = /* @__PURE__ */ new Set();
  function v() {
    var y;
    (y = e.onChange) == null || y.call(e, r);
    for (const k of i) k(r);
  }
  function p(y) {
    r = ze(r, y), v();
  }
  function M(y) {
    return y.turnId || !c ? y : { ...y, turnId: c };
  }
  function K(y) {
    if (!ic.has(y.type)) return !1;
    const k = y.data && typeof y.data == "object" ? y.data : {}, z = y.turnId || c || "";
    if (y.type === "message.delta")
      return !0;
    if (y.type === "page.action.requested") {
      const U = String(k.requestId || "");
      if (!U) return !0;
      const Q = `page.action.requested:${U}`;
      return _.has(Q) ? !1 : (_.add(Q), !0);
    }
    if (y.type === "ui.requested") {
      const U = k.uiRequest, Q = `ui.requested:${z}:${(U == null ? void 0 : U.interactionId) || JSON.stringify(k.uiRequest || "")}`;
      return g.has(Q) ? !1 : (g.add(Q), !0);
    }
    if (y.type === "turn.completed" || y.type === "turn.waiting" || y.type === "turn.failed" || y.type === "turn.cancelled") {
      const U = y.sessionId || (k.sessionId != null ? String(k.sessionId) : "") || r.sessionId || "", Q = `${y.type}:${U}:${z}`;
      return d.has(Q) ? !1 : (d.add(Q), !0);
    }
    if (y.type === "interaction.submitted" || y.type === "interaction.cancelled") {
      const U = `${y.type}:${z}:${String(k.interactionId || "")}:${String(k.action || "")}`;
      return d.has(U) ? !1 : (d.add(U), !0);
    }
    return !0;
  }
  function P(y) {
    const k = M(y);
    K(k) && (n == null || n(k));
  }
  function V(y) {
    const k = M(y);
    if (Bl(k.type)) {
      s == null || s(k);
      return;
    }
    if (k.type === "page.action.requested") {
      const z = k.data && typeof k.data == "object" ? k.data : {}, U = String(z.requestId || "");
      if (U) {
        const Q = `page.action.requested:${U}`;
        if (_.has(Q))
          return;
      }
    }
    P(k), p({ type: "apply_event", event: k });
  }
  async function $(y, k) {
    for await (const z of y) {
      if (a || k !== f) break;
      V(z);
    }
  }
  async function W(y, k) {
    var xe, Ae, j, T;
    if (a) return;
    const z = ++f;
    c = Be("turn"), k === "start" || ((xe = y.uiSubmit) == null ? void 0 : xe.action) !== "cancel" ? (l == null || l.abort(), l = new AbortController()) : (!l || l.signal.aborted) && (l = new AbortController());
    const U = l.signal;
    p({ type: "set_turn_status", status: "sending" }), p({ type: "set_error", error: null }), k === "start" && y.message && p({ type: "append_user_message", text: y.message }), (k === "start" || ((Ae = y.uiSubmit) == null ? void 0 : Ae.action) !== "cancel") && p({ type: "begin_assistant_placeholder", turnId: c });
    try {
      const B = k === "resume" && t.resumeInteraction && y.interactionId ? t.resumeInteraction(
        y.interactionId,
        ((j = y.uiSubmit) == null ? void 0 : j.action) || "submit",
        ((T = y.uiSubmit) == null ? void 0 : T.values) || y.values || {},
        U
      ) : t.startTurn(y, U);
      if (await $(B, z), z !== f) return;
      (r.turnStatus === "sending" || r.turnStatus === "streaming") && p({ type: "set_turn_status", status: "completed" });
    } catch (B) {
      if (z !== f) return;
      if (Os(B) || U.aborted) {
        p({ type: "cancel_turn" }), P(_e("turn.cancelled", {}, { sessionId: r.sessionId, turnId: c }));
        return;
      }
      const G = B instanceof Error ? B.message : String(B);
      p({ type: "fail_turn", message: G }), P(_e("turn.failed", { message: G, error: G }, {
        sessionId: r.sessionId,
        turnId: c
      }));
    }
  }
  return {
    getState() {
      return r;
    },
    subscribe(y) {
      return i.add(y), y(r), () => i.delete(y);
    },
    async send(y) {
      const k = typeof y == "string" ? { message: y } : y;
      !k.message && !k.values && !k.uiSubmit || await W(k, "start");
    },
    async submitInteraction(y, k, z = {}) {
      if (!y || o.has(y)) return;
      o.add(y);
      const U = k === "cancel";
      p({
        type: "update_interaction_state",
        interactionId: y,
        state: "submitting",
        result: { action: k, values: z }
      });
      try {
        await W(
          {
            interactionId: y,
            uiSubmit: { action: k, values: z },
            values: z,
            message: void 0
          },
          "resume"
        ), U && r.turnStatus === "cancelled" ? (p({
          type: "update_interaction_state",
          interactionId: y,
          state: "cancelled",
          result: { action: k, values: z }
        }), P(_e(
          "interaction.cancelled",
          { interactionId: y, action: k, values: z },
          { sessionId: r.sessionId, turnId: c }
        ))) : r.turnStatus === "failed" ? p({
          type: "update_interaction_state",
          interactionId: y,
          state: "failed",
          errorMessage: r.error || "提交失败"
        }) : U ? (p({
          type: "update_interaction_state",
          interactionId: y,
          state: "cancelled",
          result: { action: k, values: z }
        }), P(_e(
          "interaction.cancelled",
          { interactionId: y, action: k, values: z },
          { sessionId: r.sessionId, turnId: c }
        ))) : r.turnStatus === "cancelled" ? p({
          type: "update_interaction_state",
          interactionId: y,
          state: "cancelled",
          result: { action: k, values: z }
        }) : (p({
          type: "update_interaction_state",
          interactionId: y,
          state: "resolved",
          result: { action: k, values: z }
        }), P(_e(
          "interaction.submitted",
          { interactionId: y, action: k, values: z },
          { sessionId: r.sessionId, turnId: c }
        )));
      } catch (Q) {
        Os(Q) || r.turnStatus === "cancelled" ? p({
          type: "update_interaction_state",
          interactionId: y,
          state: "failed",
          errorMessage: "交互提交被中断"
        }) : p({
          type: "update_interaction_state",
          interactionId: y,
          state: "failed",
          errorMessage: Q instanceof Error ? Q.message : String(Q)
        });
      } finally {
        o.delete(y);
      }
    },
    async cancel() {
      var y;
      f += 1, c = Be("turn"), l == null || l.abort(), l = null;
      try {
        await ((y = t.cancelTurn) == null ? void 0 : y.call(t));
      } catch {
      }
      p({ type: "cancel_turn" }), P(_e("turn.cancelled", {}, { sessionId: r.sessionId, turnId: c }));
    },
    async clearSession() {
      var y;
      f += 1, c = void 0, l == null || l.abort(), l = null, await ((y = t.clearSession) == null ? void 0 : y.call(t)), d.clear(), g.clear(), _.clear(), p({ type: "reset", sessionId: void 0 });
    },
    async restore() {
      var k;
      const y = await ((k = t.restoreSession) == null ? void 0 : k.call(t));
      return y ? (p({ type: "restore", snapshot: y }), y) : null;
    },
    dispose() {
      a = !0, f += 1, c = void 0, l == null || l.abort(), l = null, i.clear(), d.clear(), g.clear(), _.clear(), t.dispose();
    }
  };
}
function Jn(e) {
  return !e || typeof e != "object" || Array.isArray(e) ? null : e;
}
function ac(e) {
  const t = Jn(e);
  return t && "text" in t ? String(t.text ?? "") : typeof e == "string" ? e : "";
}
function no(e) {
  if (!e) return;
  const t = Jn(e.metadata);
  if (t) return { ...t };
  if (!("answer" in e) && !("uiRequest" in e) && !("sessionId" in e) && !("toolCalls" in e))
    return { ...e };
}
function lc(e, t, s, n) {
  const r = no(e || void 0);
  return {
    answer: n,
    sessionId: s,
    result: t,
    metadata: r,
    intentType: e == null ? void 0 : e.intentType,
    toolCalls: e == null ? void 0 : e.toolCalls,
    uiRequest: e == null ? void 0 : e.uiRequest
  };
}
function ro(e, t, s = {}) {
  const n = Jn(t), r = s.sessionId || (n != null && n.sessionId ? String(n.sessionId) : void 0);
  switch (e) {
    case "message.delta": {
      const i = ac(t);
      return i ? _e("message.delta", { text: i }, { sessionId: r }) : null;
    }
    case "ui.requested":
      return _e("ui.requested", {
        uiRequest: (n == null ? void 0 : n.uiRequest) ?? t
      }, { sessionId: r });
    case "page.action.requested":
      return _e("page.action.requested", t, { sessionId: r });
    case "message.completed": {
      const i = (n == null ? void 0 : n.answer) != null ? String(n.answer) : void 0, o = n == null ? void 0 : n.uiRequest, a = lc(n, t, r, i);
      return o ? [
        _e("ui.requested", { uiRequest: o }, { sessionId: r }),
        _e("turn.waiting", a, { sessionId: r })
      ] : _e("turn.completed", a, { sessionId: r });
    }
    case "error":
    case "execution.error": {
      const i = (n == null ? void 0 : n.message) != null ? String(n.message) : typeof t == "string" ? t : "Embed 对话失败";
      return _e("turn.failed", { message: i, error: i }, { sessionId: r });
    }
    case "execution.started":
      return _e("turn.started", n || {}, { sessionId: r });
    case "execution.completed":
      return ro("message.completed", t, s);
    case "supervisor.step":
    case "reasoning.delta":
      return null;
    default:
      return null;
  }
}
function* cc(e) {
  if (e) {
    if (Array.isArray(e)) {
      for (const t of e) yield t;
      return;
    }
    yield e;
  }
}
function uc(e, t) {
  const s = typeof crypto < "u" && typeof crypto.randomUUID == "function" ? crypto.randomUUID().replace(/-/g, "") : `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`;
  return `${e}-${t}-${s}`;
}
function fc(e) {
  return e === 404 || e === 405 || e === 415 || e === 501;
}
function dc(e) {
  return !e || typeof e != "object" ? !1 : e.name === "AbortError";
}
function ln(e) {
  return e.aborted || dc(e.error) || e.bytesOrEventsConsumed || e.status == null ? !1 : fc(e.status);
}
function hc(e) {
  const t = e.fetchImpl || fetch, s = e.preferStream !== !1;
  let n = !1;
  const r = /* @__PURE__ */ new Set();
  let i = null;
  function o(p) {
    const M = e.apiBase.replace(/\/$/, "");
    return p.startsWith("http") ? p : `${M}${p.startsWith("/") ? p : `/${p}`}`;
  }
  async function a(p, M, K) {
    const P = {
      "Content-Type": "application/json",
      ...M.headers
    }, V = e.tokenProvider();
    V && (P.Authorization = `Bearer ${V}`);
    let $ = await t(p, { ...M, headers: P, signal: K });
    if ($.status === 401 && e.onUnauthorized) {
      const W = await e.onUnauthorized();
      if (typeof W == "string" && W)
        P.Authorization = `Bearer ${W}`;
      else {
        const y = e.tokenProvider();
        y && (P.Authorization = `Bearer ${y}`);
      }
      $ = await t(p, { ...M, headers: P, signal: K });
    }
    return $;
  }
  async function l(p) {
    if (n) throw new Error("Embed transport disposed");
    const M = e.getSessionId();
    return M || (i || (i = (async () => {
      var y, k;
      const K = e.sessionsPath || "/chat/sessions", P = await a(o(K), {
        method: "POST",
        body: JSON.stringify(((y = e.createSessionPayload) == null ? void 0 : y.call(e)) || { context: (k = e.getContext) == null ? void 0 : k.call(e) })
      }, p);
      if (!P.ok)
        throw new Error(`Embed session create failed: HTTP ${P.status}`);
      const V = await P.json().catch(() => ({})), $ = V.data && typeof V.data == "object" ? V.data : V, W = $.sessionId ? String($.sessionId) : $.id ? String($.id) : void 0;
      if (!W) throw new Error("Embed session create returned no sessionId");
      return e.setSessionId(W), W;
    })().finally(() => {
      i = null;
    })), i);
  }
  async function* f(p, M, K) {
    if (!p.body) throw new Error("Embed stream has no body");
    for await (const P of rc(p.body, { signal: K })) {
      const V = ro(P.event, P.data, { sessionId: M });
      for (const $ of cc(V))
        yield $;
    }
  }
  function* c(p, M) {
    yield _e("turn.started", {}, { sessionId: M }), p.answer && (yield _e("message.delta", { text: String(p.answer) }, { sessionId: M }));
    const K = p.metadata && typeof p.metadata == "object" && !Array.isArray(p.metadata) ? { ...p.metadata } : void 0;
    p.uiRequest ? (yield _e("ui.requested", { uiRequest: p.uiRequest }, { sessionId: M }), yield _e("turn.waiting", {
      answer: p.answer,
      uiRequest: p.uiRequest,
      sessionId: M,
      result: p,
      metadata: K,
      intentType: p.intentType,
      toolCalls: p.toolCalls
    }, { sessionId: M })) : yield _e("turn.completed", {
      answer: p.answer,
      sessionId: M,
      result: p,
      metadata: K,
      intentType: p.intentType,
      toolCalls: p.toolCalls
    }, { sessionId: M });
  }
  async function* d(p, M, K) {
    var y, k;
    const P = ((y = e.messagesJsonPath) == null ? void 0 : y.call(e, p)) || `/chat/sessions/${encodeURIComponent(p)}/messages`, V = await a(o(P), {
      method: "POST",
      body: JSON.stringify({
        message: M.message,
        context: (k = e.getContext) == null ? void 0 : k.call(e),
        interactionId: M.interactionId,
        uiSubmit: M.uiSubmit
      })
    }, K);
    if (!V.ok)
      throw new Error(`Embed message failed: HTTP ${V.status}`);
    const $ = await V.json().catch(() => ({})), W = $.data && typeof $.data == "object" ? $.data : $;
    yield* c(W, p);
  }
  async function* g(p, M) {
    var V, $;
    if (n) return;
    const K = new AbortController();
    r.add(K);
    const P = () => K.abort();
    M == null || M.addEventListener("abort", P);
    try {
      const W = await l(K.signal);
      if (!s) {
        yield* d(W, p, K.signal);
        return;
      }
      const y = ((V = e.messagesPath) == null ? void 0 : V.call(e, W)) || `/chat/sessions/${encodeURIComponent(W)}/messages/stream`, k = await a(o(y), {
        method: "POST",
        headers: { Accept: "text/event-stream" },
        body: JSON.stringify({
          message: p.message,
          context: ($ = e.getContext) == null ? void 0 : $.call(e),
          interactionId: p.interactionId,
          uiSubmit: p.uiSubmit
        })
      }, K.signal), z = k.headers.get("content-type") || "";
      if (!k.ok || !k.body || !z.includes("text/event-stream")) {
        if (ln({
          status: k.status,
          bytesOrEventsConsumed: !1,
          aborted: K.signal.aborted
        })) {
          yield* d(W, p, K.signal);
          return;
        }
        throw new Error(`Embed stream failed: HTTP ${k.status}`);
      }
      yield _e("turn.started", {}, { sessionId: W }), yield* f(k, W, K.signal);
    } catch (W) {
      if (Os(W) || K.signal.aborted) {
        yield _e("turn.cancelled", {}, { sessionId: e.getSessionId() });
        return;
      }
      throw W;
    } finally {
      M == null || M.removeEventListener("abort", P), r.delete(K);
    }
  }
  async function* _(p, M, K, P, V, $) {
    var U, Q;
    const W = ((U = e.interactionSubmitPath) == null ? void 0 : U.call(e, p, M)) || `/chat/sessions/${encodeURIComponent(p)}/interactions/${encodeURIComponent(M)}/submit`, y = await a(o(W), {
      method: "POST",
      body: JSON.stringify({
        action: K,
        values: P,
        idempotencyKey: V,
        context: (Q = e.getContext) == null ? void 0 : Q.call(e)
      })
    }, $);
    if (!y.ok)
      throw new Error(`Embed interaction submit failed: HTTP ${y.status}`);
    const k = await y.json().catch(() => ({})), z = k.data && typeof k.data == "object" ? k.data : k;
    yield* c(z, p);
  }
  async function* v(p, M, K, P) {
    var k, z;
    if (n) return;
    const V = e.getSessionId();
    if (!V) throw new Error("No embed session");
    const $ = uc("embed", p);
    if (!s) {
      yield* _(V, p, M, K, $, P);
      return;
    }
    const W = ((k = e.interactionSubmitStreamPath) == null ? void 0 : k.call(e, V, p)) || `/chat/sessions/${encodeURIComponent(V)}/interactions/${encodeURIComponent(p)}/submit/stream`;
    let y = !1;
    try {
      const U = await a(o(W), {
        method: "POST",
        headers: { Accept: "text/event-stream" },
        body: JSON.stringify({
          action: M,
          values: K,
          idempotencyKey: $,
          context: (z = e.getContext) == null ? void 0 : z.call(e)
        })
      }, P), Q = U.headers.get("content-type") || "";
      if (U.ok && U.body && Q.includes("text/event-stream")) {
        yield _e("turn.started", {}, { sessionId: V }), y = !0, yield* f(U, V, P);
        return;
      }
      if (ln({
        status: U.status,
        bytesOrEventsConsumed: !1,
        aborted: P == null ? void 0 : P.aborted
      })) {
        yield* _(V, p, M, K, $, P);
        return;
      }
      throw new Error(`Embed interaction stream failed: HTTP ${U.status}`);
    } catch (U) {
      if (Os(U) || P != null && P.aborted) {
        yield _e("turn.cancelled", {}, { sessionId: V });
        return;
      }
      if (ln({
        status: U == null ? void 0 : U.status,
        bytesOrEventsConsumed: y,
        aborted: P == null ? void 0 : P.aborted,
        error: U
      })) {
        yield* _(V, p, M, K, $, P);
        return;
      }
      throw U;
    }
  }
  return {
    kind: "embed",
    capabilities: {
      eventStreaming: s,
      tokenStreaming: !0,
      abort: !0,
      restore: !1,
      structuredInitialInput: !1,
      pageActions: !0
    },
    startTurn: g,
    resumeInteraction: v,
    /** 供 facade / 测试显式预热会话（带去重） */
    ensureSession: l,
    async cancelTurn() {
      for (const p of r) p.abort();
      r.clear();
    },
    dispose() {
      n = !0, i = null;
      for (const p of r) p.abort();
      r.clear();
    }
  };
}
const pc = /* @__PURE__ */ new Map(), gc = {
  form: "form",
  text_question: "form",
  select: "select",
  choice: "select",
  multi_select: "select",
  confirm: "confirm",
  table: "table",
  detail: "detail",
  card: "output_card",
  report: "output_card",
  summary_card: "summary_card",
  list_card: "list_card",
  output_card: "output_card",
  page_action: "page_action",
  custom: "custom"
};
function mc(e) {
  const t = String(e || "custom").toLowerCase();
  return gc[t] || "custom";
}
function yc(e) {
  if (e)
    return pc.get(e);
}
const bc = ["aria-label"], _c = {
  key: 0,
  class: "reachai-interaction__header"
}, vc = { key: 0 }, wc = {
  key: 1,
  class: "reachai-interaction__badge"
}, Sc = {
  key: 1,
  class: "reachai-interaction__message"
}, Ic = {
  key: 2,
  class: "reachai-interaction__state",
  "aria-live": "polite"
}, xc = { key: 0 }, Ac = ["onUpdate:modelValue", "disabled"], Cc = ["onUpdate:modelValue", "disabled", "placeholder"], kc = ["value", "multiple", "disabled", "onChange"], Ec = ["value"], Tc = ["onUpdate:modelValue", "disabled"], Pc = ["value", "disabled", "placeholder", "onInput"], $c = ["value", "disabled", "placeholder", "onInput"], Rc = {
  key: 0,
  class: "reachai-interaction__actions"
}, Mc = ["disabled"], Oc = ["disabled"], qc = {
  key: 5,
  class: "reachai-interaction__confirm"
}, jc = {
  key: 0,
  class: "reachai-interaction__actions"
}, Dc = ["disabled"], Fc = ["disabled"], Nc = ["disabled"], Kc = {
  key: 6,
  class: "reachai-interaction__choice"
}, Lc = ["value", "disabled"], Uc = ["name", "value", "disabled"], Vc = {
  key: 0,
  class: "reachai-interaction__actions"
}, Bc = ["disabled"], Hc = ["disabled"], Wc = {
  key: 7,
  class: "reachai-interaction__table-wrap"
}, zc = { class: "reachai-interaction__table" }, Jc = {
  key: 8,
  class: "reachai-interaction__detail"
}, Gc = {
  key: 0,
  class: "reachai-interaction__actions"
}, Yc = ["disabled", "onClick"], Xc = {
  key: 9,
  class: "reachai-interaction__list"
}, Qc = {
  key: 10,
  class: "reachai-interaction__page-action"
}, Zc = { class: "reachai-interaction__actions" }, eu = ["disabled"], tu = ["disabled"], su = {
  key: 11,
  class: "reachai-interaction__custom"
}, nu = { class: "reachai-interaction__warn" }, ru = { class: "reachai-interaction__actions" }, iu = ["disabled"], ou = ["disabled"], au = {
  key: 12,
  class: "reachai-interaction__error",
  role: "alert"
}, lu = {
  key: 13,
  class: "reachai-interaction__actions"
}, cu = /* @__PURE__ */ ht({
  __name: "UnifiedInteractionRenderer",
  props: {
    request: {},
    state: {},
    errorMessage: {},
    disabled: { type: Boolean }
  },
  emits: ["submit", "cancel", "action"],
  setup(e, { emit: t }) {
    const s = e, n = t, r = fe(() => mc(s.request.component)), i = fe(() => s.state || "waiting"), o = fe(
      () => s.disabled || i.value === "submitting" || i.value === "resolved" || i.value === "expired" || i.value === "cancelled"
    ), a = fe(() => `reachai-choice-${s.request.interactionId || "default"}`), l = /* @__PURE__ */ Ne(""), f = fe(() => s.request.actions || []), c = fe(() => {
      var w;
      return ((w = s.request.behavior) == null ? void 0 : w.readonly) === !0 ? !0 : (/* @__PURE__ */ new Set(["table", "detail", "summary_card", "list_card", "output_card", "card", "report"])).has(r.value) && !f.value.length;
    }), d = fe(() => !c.value), g = fe(() => {
      switch (i.value) {
        case "submitting":
          return "提交中…";
        case "resolved":
          return "已提交";
        case "failed":
          return "提交失败";
        case "expired":
          return "已过期";
        case "cancelled":
          return "已取消";
        default:
          return "";
      }
    }), _ = /* @__PURE__ */ Vs({}), v = /* @__PURE__ */ Ne(null), p = /* @__PURE__ */ Ne([]), M = /* @__PURE__ */ Ne(null);
    function K(m, w) {
      return m == null ? w.type === "boolean" ? !1 : w.type === "multi_select" ? [] : "" : typeof m == "string" || typeof m == "number" || typeof m == "boolean" ? m : Array.isArray(m) ? m.map(String) : String(m);
    }
    qt(
      () => s.request,
      (m) => {
        var O, te, Se, pt;
        l.value = "", Object.keys(_).forEach((u) => delete _[u]);
        for (const u of m.fields || []) {
          const h = (O = m.prefilled) == null ? void 0 : O[u.key];
          _[u.key] = K(h, u);
        }
        const w = (te = m.fields) == null ? void 0 : te[0], H = w == null ? void 0 : w.key, oe = H && ((Se = m.prefilled) == null ? void 0 : Se[H]) !== void 0 ? m.prefilled[H] : (pt = m.prefilled) == null ? void 0 : pt.value;
        if (m.component === "multi_select") {
          Array.isArray(oe) ? p.value = [...oe] : oe == null ? p.value = [] : p.value = [oe], v.value = null;
          return;
        }
        oe !== void 0 && (typeof oe == "string" || typeof oe == "number" || typeof oe == "boolean" ? v.value = oe : oe == null ? v.value = null : v.value = String(oe));
      },
      { immediate: !0, deep: !0 }
    );
    function P(m) {
      var w;
      return m.type === "select" || m.type === "multi_select" || !!((w = m.options) != null && w.length);
    }
    function V(m) {
      const w = _[m.key];
      return m.type === "multi_select" ? Array.isArray(w) ? w.map(String) : [] : typeof w == "string" || typeof w == "number" ? w : w == null ? void 0 : String(w);
    }
    function $(m, w) {
      const H = w.target;
      m.type === "multi_select" ? _[m.key] = Array.from(H.selectedOptions).map((oe) => oe.value) : _[m.key] = H.value;
    }
    const W = fe(() => {
      var H, oe;
      const m = (H = s.request.fields) == null ? void 0 : H[0];
      if ((oe = m == null ? void 0 : m.options) != null && oe.length) return m.options;
      const w = s.request.data;
      return Array.isArray(w) ? w.map((O, te) => {
        if (O && typeof O == "object") {
          const Se = O;
          return { value: Se.value ?? Se.id ?? te, label: String(Se.label ?? Se.name ?? Se.value ?? te) };
        }
        return { value: O, label: String(O) };
      }) : [];
    }), y = fe(() => {
      const m = s.request.data;
      return Array.isArray(m) ? m.map((w) => w && typeof w == "object" ? w : { value: w }) : m && typeof m == "object" ? [m] : s.request.summary ? [s.request.summary] : [];
    }), k = fe(() => {
      const m = z(s.request);
      if (m.length) return m;
      const w = y.value[0];
      return w ? Object.keys(w).map((H) => ({ key: H, label: H })) : [];
    });
    function z(m) {
      var H, oe;
      const w = [
        (H = m.schema) == null ? void 0 : H.columns,
        (oe = m.extension) == null ? void 0 : oe.columns,
        m.data && typeof m.data == "object" && !Array.isArray(m.data) ? m.data.columns : void 0
      ];
      for (const O of w)
        if (!(!Array.isArray(O) || !O.length))
          return O.map((te, Se) => {
            if (typeof te == "string") return { key: te, label: te };
            if (te && typeof te == "object") {
              const pt = te, u = String(pt.key ?? pt.field ?? pt.name ?? Se);
              return { key: u, label: String(pt.label ?? pt.title ?? u) };
            }
            return { key: String(Se), label: String(te) };
          });
      return [];
    }
    const U = fe(() => {
      const m = s.request.summary || s.request.data || {};
      return Array.isArray(m) ? m.map((w, H) => ({
        key: String(H),
        label: `#${H + 1}`,
        value: w
      })) : Object.entries(m || {}).map(([w, H]) => ({ key: w, label: w, value: H }));
    }), Q = fe(() => {
      var w;
      const m = (w = s.request.extension) == null ? void 0 : w.pageActionRequest;
      return m && typeof m == "object" ? m : s.request.data && typeof s.request.data == "object" ? s.request.data : {};
    }), xe = fe(
      () => String(Q.value.title || s.request.title || "页面动作")
    ), Ae = fe(
      () => {
        var m;
        return (m = s.request.extension) != null && m.rendererKey ? String(s.request.extension.rendererKey) : "";
      }
    ), j = fe(() => {
      const m = Ae.value;
      if (!m) return null;
      const w = yc(m);
      if (!w) return null;
      const H = w({
        request: s.request,
        state: i.value,
        disabled: o.value,
        onSubmit: (oe, O) => ge(oe, O),
        onCancel: () => le()
      });
      return H ? /* @__PURE__ */ ht({
        name: `ReachAiCustomInteraction_${m}`,
        setup() {
          return () => fl(H);
        }
      }) : null;
    });
    function T(m) {
      if (m == null) return "-";
      if (typeof m == "string") return m;
      try {
        return JSON.stringify(m);
      } catch {
        return String(m);
      }
    }
    function B(m) {
      return String(m.key || m.action || "submit");
    }
    function G(m) {
      return String(m.label || m.key || m.action || "提交");
    }
    function se(m) {
      return m.values && typeof m.values == "object" ? m.values : { ...m };
    }
    function re(m) {
      return m.type === "primary" || B(m) === "confirm" || B(m) === "submit";
    }
    function ge(m, w) {
      o.value && i.value !== "failed" || (M.value = { action: m, values: w }, n("submit", m, w), n("action", m, w));
    }
    function je(m) {
      for (const w of s.request.fields || [])
        if (w.required) {
          const H = _[w.key];
          if (H === "" || H == null || Array.isArray(H) && !H.length) {
            l.value = `请填写必填项：${w.label || w.key}`;
            return;
          }
        }
      l.value = "", ge(m, { ..._ });
    }
    function Ce() {
      var m, w;
      if (s.request.component === "multi_select") {
        if (!p.value.length && ((m = s.request.fields) != null && m.some((H) => H.required))) {
          l.value = "请至少选择一项";
          return;
        }
        l.value = "", ge("choose", { value: [...p.value] });
      } else {
        if ((v.value === null || v.value === "") && ((w = s.request.fields) != null && w.some((H) => H.required))) {
          l.value = "请选择一项";
          return;
        }
        l.value = "", ge("choose", { value: v.value });
      }
    }
    function le() {
      o.value || (n("cancel"), n("action", "cancel", {}));
    }
    function D() {
      M.value && (n("submit", M.value.action, M.value.values), n("action", M.value.action, M.value.values));
    }
    return (m, w) => {
      var H, oe;
      return A(), E("div", {
        class: Ye(["reachai-interaction", [
          `reachai-interaction--${r.value}`,
          `reachai-interaction--${i.value}`,
          { "is-disabled": o.value }
        ]]),
        role: "region",
        "aria-label": e.request.title || e.request.component || "interaction"
      }, [
        e.request.title || (H = e.request.missing) != null && H.length ? (A(), E("header", _c, [
          e.request.title ? (A(), E("strong", vc, ne(e.request.title), 1)) : ie("", !0),
          (oe = e.request.missing) != null && oe.length ? (A(), E("span", wc, "待补充 " + ne(e.request.missing.length) + " 项", 1)) : ie("", !0)
        ])) : ie("", !0),
        e.request.message && r.value !== "form" ? (A(), E("p", Sc, ne(e.request.message), 1)) : ie("", !0),
        g.value ? (A(), E("div", Ic, ne(g.value), 1)) : ie("", !0),
        j.value ? (A(), st(Aa(j.value), {
          key: 3,
          class: "reachai-interaction__custom-host"
        })) : r.value === "form" ? (A(), E("form", {
          key: 4,
          class: "reachai-interaction__form",
          onSubmit: w[0] || (w[0] = Zi((O) => je("submit"), ["prevent"]))
        }, [
          (A(!0), E(be, null, Ve(e.request.fields || [], (O) => (A(), E("label", {
            key: O.key,
            class: "reachai-interaction__field"
          }, [
            N("span", null, [
              us(ne(O.label), 1),
              O.required ? (A(), E("em", xc, "*")) : ie("", !0)
            ]),
            O.type === "boolean" ? Kt((A(), E("input", {
              key: 0,
              "onUpdate:modelValue": (te) => _[O.key] = te,
              type: "checkbox",
              disabled: o.value
            }, null, 8, Ac)), [
              [Or, _[O.key]]
            ]) : O.type === "number" || O.type === "integer" ? Kt((A(), E("input", {
              key: 1,
              "onUpdate:modelValue": (te) => _[O.key] = te,
              type: "number",
              disabled: o.value,
              placeholder: O.placeholder
            }, null, 8, Cc)), [
              [
                Sn,
                _[O.key],
                void 0,
                { number: !0 }
              ]
            ]) : P(O) ? (A(), E("select", {
              key: 2,
              value: V(O),
              multiple: O.type === "multi_select",
              disabled: o.value,
              onChange: (te) => $(O, te)
            }, [
              (A(!0), E(be, null, Ve(O.options || [], (te) => (A(), E("option", {
                key: String(te.value),
                value: te.value
              }, ne(te.label), 9, Ec))), 128))
            ], 40, kc)) : O.type === "date" ? Kt((A(), E("input", {
              key: 3,
              "onUpdate:modelValue": (te) => _[O.key] = te,
              type: "date",
              disabled: o.value
            }, null, 8, Tc)), [
              [Sn, _[O.key]]
            ]) : O.type === "textarea" || O.type === "object" || O.type === "array" ? (A(), E("textarea", {
              key: 4,
              value: String(_[O.key] ?? ""),
              rows: "3",
              disabled: o.value,
              placeholder: O.placeholder,
              onInput: (te) => _[O.key] = te.target.value
            }, null, 40, Pc)) : (A(), E("input", {
              key: 5,
              value: String(_[O.key] ?? ""),
              type: "text",
              disabled: o.value,
              placeholder: O.placeholder,
              onInput: (te) => _[O.key] = te.target.value
            }, null, 40, $c))
          ]))), 128)),
          d.value ? (A(), E("div", Rc, [
            N("button", {
              type: "button",
              disabled: o.value,
              onClick: le
            }, "取消", 8, Mc),
            N("button", {
              type: "submit",
              class: "is-primary",
              disabled: o.value
            }, "提交", 8, Oc)
          ])) : ie("", !0)
        ], 32)) : r.value === "confirm" ? (A(), E("div", qc, [
          N("p", null, ne(e.request.message || "请确认是否继续。"), 1),
          d.value ? (A(), E("div", jc, [
            N("button", {
              type: "button",
              disabled: o.value,
              onClick: le
            }, "取消", 8, Dc),
            N("button", {
              type: "button",
              disabled: o.value,
              onClick: w[1] || (w[1] = (O) => ge("reject", { confirm: !1 }))
            }, "拒绝", 8, Fc),
            N("button", {
              type: "button",
              class: "is-primary",
              disabled: o.value,
              onClick: w[2] || (w[2] = (O) => ge("confirm", { confirm: !0 }))
            }, "确认", 8, Nc)
          ])) : ie("", !0)
        ])) : r.value === "select" ? (A(), E("div", Kc, [
          (A(!0), E(be, null, Ve(W.value, (O) => (A(), E("label", {
            key: String(O.value),
            class: "reachai-interaction__option"
          }, [
            e.request.component === "multi_select" ? Kt((A(), E("input", {
              key: 0,
              "onUpdate:modelValue": w[3] || (w[3] = (te) => p.value = te),
              type: "checkbox",
              value: O.value,
              disabled: o.value
            }, null, 8, Lc)), [
              [Or, p.value]
            ]) : Kt((A(), E("input", {
              key: 1,
              "onUpdate:modelValue": w[4] || (w[4] = (te) => v.value = te),
              type: "radio",
              name: a.value,
              value: O.value,
              disabled: o.value
            }, null, 8, Uc)), [
              [jl, v.value]
            ]),
            N("span", null, ne(O.label), 1)
          ]))), 128)),
          d.value ? (A(), E("div", Vc, [
            N("button", {
              type: "button",
              disabled: o.value,
              onClick: le
            }, "取消", 8, Bc),
            N("button", {
              type: "button",
              class: "is-primary",
              disabled: o.value,
              onClick: Ce
            }, "选择", 8, Hc)
          ])) : ie("", !0)
        ])) : r.value === "table" ? (A(), E("div", Wc, [
          N("table", zc, [
            N("thead", null, [
              N("tr", null, [
                (A(!0), E(be, null, Ve(k.value, (O) => (A(), E("th", {
                  key: O.key
                }, ne(O.label), 1))), 128))
              ])
            ]),
            N("tbody", null, [
              (A(!0), E(be, null, Ve(y.value, (O, te) => (A(), E("tr", { key: te }, [
                (A(!0), E(be, null, Ve(k.value, (Se) => (A(), E("td", {
                  key: Se.key
                }, ne(T(O[Se.key])), 1))), 128))
              ]))), 128))
            ])
          ])
        ])) : r.value === "detail" || r.value === "summary_card" || r.value === "output_card" ? (A(), E("div", Jc, [
          N("dl", null, [
            (A(!0), E(be, null, Ve(U.value, (O) => (A(), E("div", {
              key: O.key
            }, [
              N("dt", null, ne(O.label), 1),
              N("dd", null, ne(T(O.value)), 1)
            ]))), 128))
          ]),
          d.value && f.value.length ? (A(), E("div", Gc, [
            (A(!0), E(be, null, Ve(f.value, (O) => (A(), E("button", {
              key: B(O),
              type: "button",
              class: Ye({ "is-primary": re(O) }),
              disabled: o.value,
              onClick: (te) => ge(B(O), se(O))
            }, ne(G(O)), 11, Yc))), 128))
          ])) : ie("", !0)
        ])) : r.value === "list_card" ? (A(), E("div", Xc, [
          (A(!0), E(be, null, Ve(y.value, (O, te) => (A(), E("article", {
            key: te,
            class: "reachai-interaction__list-item"
          }, [
            N("strong", null, ne(O.title || O.name || `#${te + 1}`), 1),
            N("span", null, ne(O.description || O.summary || T(O)), 1)
          ]))), 128))
        ])) : r.value === "page_action" ? (A(), E("div", Qc, [
          N("p", null, ne(xe.value), 1),
          N("dl", null, [
            N("div", null, [
              w[7] || (w[7] = N("dt", null, "actionKey", -1)),
              N("dd", null, ne(Q.value.actionKey || "-"), 1)
            ]),
            N("div", null, [
              w[8] || (w[8] = N("dt", null, "requestId", -1)),
              N("dd", null, ne(Q.value.requestId || e.request.interactionId || "-"), 1)
            ]),
            N("div", null, [
              w[9] || (w[9] = N("dt", null, "args", -1)),
              N("dd", null, ne(T(Q.value.args || {})), 1)
            ])
          ]),
          N("div", Zc, [
            Q.value.confirm ? (A(), E("button", {
              key: 0,
              type: "button",
              disabled: o.value,
              onClick: le
            }, "取消", 8, eu)) : ie("", !0),
            N("button", {
              type: "button",
              class: "is-primary",
              disabled: o.value,
              onClick: w[5] || (w[5] = (O) => ge("page_action_ack", { requestId: Q.value.requestId, actionKey: Q.value.actionKey }))
            }, " 已收到 ", 8, tu)
          ])
        ])) : (A(), E("div", su, [
          N("p", nu, ne(Ae.value ? `自定义渲染器未在宿主注册：${Ae.value}` : `未注册的交互组件：${e.request.component || "unknown"}`), 1),
          N("pre", null, ne(T(e.request.data ?? e.request.summary ?? {})), 1),
          N("div", ru, [
            N("button", {
              type: "button",
              disabled: o.value,
              onClick: le
            }, "取消", 8, iu),
            N("button", {
              type: "button",
              class: "is-primary",
              disabled: o.value,
              onClick: w[6] || (w[6] = (O) => ge("submit", {}))
            }, "按原始值提交", 8, ou)
          ])
        ])),
        l.value || e.errorMessage ? (A(), E("p", au, ne(l.value || e.errorMessage), 1)) : ie("", !0),
        i.value === "failed" ? (A(), E("div", lu, [
          N("button", {
            type: "button",
            class: "is-primary",
            onClick: D
          }, "重试")
        ])) : ie("", !0)
      ], 10, bc);
    };
  }
}), Dt = (e, t) => {
  const s = e.__vccOpts || e;
  for (const [n, r] of t)
    s[n] = r;
  return s;
}, uu = /* @__PURE__ */ Dt(cu, [["__scopeId", "data-v-3056692d"]]), fu = ["data-type"], du = {
  key: 0,
  class: "reachai-block__caret",
  "aria-hidden": "true"
}, hu = {
  key: 2,
  class: "reachai-block__page-action"
}, pu = { key: 0 }, gu = ["data-level"], mu = {
  key: 4,
  class: "reachai-block__error",
  role: "alert"
}, yu = /* @__PURE__ */ ht({
  __name: "ConversationBlockRenderer",
  props: {
    block: {}
  },
  emits: ["interaction-submit", "interaction-cancel", "retry"],
  setup(e, { emit: t }) {
    const s = t;
    function n(i, o, a) {
      i.type === "interaction" && s("interaction-submit", i.request.interactionId, o, a);
    }
    function r(i) {
      i.type === "interaction" && s("interaction-cancel", i.request.interactionId);
    }
    return (i, o) => (A(), E("div", {
      class: "reachai-block",
      "data-type": e.block.type
    }, [
      e.block.type === "text" ? (A(), E("div", {
        key: 0,
        class: Ye(["reachai-block__text", { "is-streaming": e.block.status === "streaming" }])
      }, [
        us(ne(e.block.text) + " ", 1),
        e.block.status === "streaming" ? (A(), E("span", du)) : ie("", !0)
      ], 2)) : e.block.type === "interaction" ? (A(), st(uu, {
        key: 1,
        request: e.block.request,
        state: e.block.state,
        "error-message": e.block.errorMessage,
        onSubmit: o[0] || (o[0] = (a, l) => n(e.block, a, l)),
        onCancel: o[1] || (o[1] = (a) => r(e.block))
      }, null, 8, ["request", "state", "error-message"])) : e.block.type === "page_action" ? (A(), E("div", hu, [
        N("strong", null, ne(e.block.title || e.block.actionKey), 1),
        N("span", null, ne(e.block.status), 1),
        e.block.message ? (A(), E("p", pu, ne(e.block.message), 1)) : ie("", !0)
      ])) : e.block.type === "notice" ? (A(), E("div", {
        key: 3,
        class: "reachai-block__notice",
        "data-level": e.block.level || "info"
      }, ne(e.block.text), 9, gu)) : e.block.type === "error" ? (A(), E("div", mu, [
        us(ne(e.block.text) + " ", 1),
        e.block.retryable ? (A(), E("button", {
          key: 0,
          type: "button",
          onClick: o[2] || (o[2] = (a) => i.$emit("retry"))
        }, "重试")) : ie("", !0)
      ])) : ie("", !0)
    ], 8, fu));
  }
}), Lr = /* @__PURE__ */ Dt(yu, [["__scopeId", "data-v-775b19fc"]]), bu = ["data-message-id", "data-role", "data-status"], _u = {
  key: 0,
  class: "reachai-message__user-row"
}, vu = { class: "reachai-message__user-bubble" }, wu = {
  key: 0,
  class: "reachai-message__user-avatar",
  "aria-hidden": "true"
}, Su = {
  key: 1,
  class: "reachai-message__assistant-row"
}, Iu = {
  key: 0,
  class: "reachai-message__prism-avatar",
  "aria-hidden": "true"
}, xu = {
  key: 0,
  class: "reachai-message__card-heading"
}, Au = {
  key: 0,
  class: "reachai-message__thinking-title"
}, Cu = {
  key: 1,
  class: "reachai-message__weak-label"
}, ku = {
  key: 2,
  class: "reachai-message__heading-spacer",
  "aria-hidden": "true"
}, Eu = ["data-tone"], Tu = {
  key: 1,
  class: "reachai-message__status-hint"
}, Pu = {
  key: 2,
  class: "reachai-message__thinking-details"
}, $u = ["aria-expanded"], Ru = {
  class: "reachai-message__thinking-chevron",
  "aria-hidden": "true"
}, Mu = {
  key: 0,
  class: "reachai-message__thinking-steps"
}, Ou = ["data-state"], qu = { class: "reachai-message__thinking-step-body" }, ju = { key: 0 }, Du = { class: "reachai-message__body" }, Fu = {
  key: 0,
  class: "reachai-message__loading"
}, Nu = {
  key: 3,
  class: "reachai-message__meta"
}, Ku = /* @__PURE__ */ ht({
  __name: "ConversationMessageItem",
  props: {
    message: {},
    assistantLabel: { default: "" },
    statusHint: { default: "" },
    thinkingPresentation: { default: null },
    showAvatars: { type: Boolean, default: !0 },
    surface: { default: "admin" }
  },
  emits: ["interaction-submit", "interaction-cancel", "retry"],
  setup(e) {
    const t = e, s = /* @__PURE__ */ Ne(!1), n = fe(
      () => t.message.role !== "user" && (t.message.status === "pending" || t.message.status === "streaming")
    ), r = fe(() => n.value), i = fe(() => {
      var d;
      return ((d = t.thinkingPresentation) == null ? void 0 : d.steps) || [];
    });
    qt(
      () => t.message.id,
      () => {
        s.value = !1;
      }
    ), qt(n, (d) => {
      d || (s.value = !1);
    });
    const o = fe(
      () => !n.value && !!t.assistantLabel && t.message.role === "assistant" && t.surface === "admin"
    ), a = fe(() => [
      `reachai-message--${t.message.role}`,
      `reachai-message--${t.message.status}`,
      {
        "reachai-message--thinking": n.value,
        "reachai-message--prism": t.message.role !== "user"
      }
    ]), l = fe(() => ({
      "reachai-message__card-shell--thinking": n.value,
      "reachai-message__card-shell--response": !n.value,
      "reachai-message__card-shell--failed": t.message.status === "failed",
      "reachai-message__card-shell--cancelled": t.message.status === "cancelled"
    })), f = fe(() => ({
      "reachai-message__card--thinking": n.value,
      "reachai-message__card--response": !n.value,
      [`reachai-message__card--${t.message.status}`]: !0
    })), c = fe(() => n.value ? null : t.message.status === "failed" ? { label: "失败", tone: "danger" } : t.message.status === "cancelled" ? { label: "已取消", tone: "warning" } : null);
    return (d, g) => {
      var _;
      return A(), E("article", {
        class: Ye(["reachai-message", a.value]),
        "data-message-id": e.message.id,
        "data-role": e.message.role,
        "data-status": e.message.status
      }, [
        e.message.role === "user" ? (A(), E("div", _u, [
          N("div", vu, [
            (A(!0), E(be, null, Ve(e.message.blocks, (v) => (A(), st(Lr, {
              key: v.id,
              block: v,
              onInteractionSubmit: g[0] || (g[0] = (...p) => d.$emit("interaction-submit", ...p)),
              onInteractionCancel: g[1] || (g[1] = (p) => d.$emit("interaction-cancel", p)),
              onRetry: g[2] || (g[2] = (p) => d.$emit("retry"))
            }, null, 8, ["block"]))), 128))
          ]),
          e.showAvatars ? (A(), E("div", wu, [...g[7] || (g[7] = [
            N("svg", {
              viewBox: "0 0 24 24",
              width: "18",
              height: "18",
              fill: "none",
              stroke: "currentColor",
              "stroke-width": "1.8"
            }, [
              N("circle", {
                cx: "12",
                cy: "8",
                r: "3.5"
              }),
              N("path", {
                d: "M5 19.5c1.2-3.2 3.6-4.8 7-4.8s5.8 1.6 7 4.8",
                "stroke-linecap": "round"
              })
            ], -1)
          ])])) : ie("", !0)
        ])) : (A(), E("div", Su, [
          e.showAvatars ? (A(), E("div", Iu, [...g[8] || (g[8] = [
            N("span", { class: "reachai-message__prism-avatar-img" }, null, -1)
          ])])) : ie("", !0),
          N("div", {
            class: Ye(["reachai-message__card-shell", l.value])
          }, [
            N("div", {
              class: Ye(["reachai-message__card", f.value])
            }, [
              r.value || o.value || c.value ? (A(), E("header", xu, [
                r.value ? (A(), E("div", Au, [...g[9] || (g[9] = [
                  N("span", {
                    class: "reachai-message__spark",
                    "aria-hidden": "true"
                  }, "✦", -1),
                  N("strong", null, "思考中…", -1),
                  N("span", {
                    class: "reachai-message__thinking-dots",
                    "aria-hidden": "true"
                  }, [
                    N("i"),
                    N("i"),
                    N("i")
                  ], -1)
                ])])) : o.value ? (A(), E("div", Cu, ne(e.assistantLabel), 1)) : (A(), E("span", ku)),
                c.value ? (A(), E("span", {
                  key: 3,
                  class: "reachai-message__status-capsule",
                  "data-tone": c.value.tone
                }, ne(c.value.label), 9, Eu)) : ie("", !0)
              ])) : ie("", !0),
              r.value && e.statusHint ? (A(), E("p", Tu, ne(e.statusHint), 1)) : ie("", !0),
              r.value && ((_ = e.thinkingPresentation) != null && _.label) ? (A(), E("div", Pu, [
                N("button", {
                  type: "button",
                  class: "reachai-message__thinking-toggle",
                  "aria-expanded": s.value,
                  onClick: g[3] || (g[3] = (v) => s.value = !s.value)
                }, [
                  N("span", null, ne(e.thinkingPresentation.label), 1),
                  N("span", Ru, ne(s.value ? "▴" : "▾"), 1)
                ], 8, $u),
                s.value && i.value.length ? (A(), E("ul", Mu, [
                  (A(!0), E(be, null, Ve(i.value, (v) => (A(), E("li", {
                    key: v.id,
                    class: "reachai-message__thinking-step",
                    "data-state": v.state
                  }, [
                    g[10] || (g[10] = N("span", {
                      class: "reachai-message__thinking-step-mark",
                      "aria-hidden": "true"
                    }, null, -1)),
                    N("div", qu, [
                      N("strong", null, ne(v.title), 1),
                      v.detail ? (A(), E("p", ju, ne(v.detail), 1)) : ie("", !0)
                    ])
                  ], 8, Ou))), 128))
                ])) : ie("", !0)
              ])) : ie("", !0),
              N("div", Du, [
                (A(!0), E(be, null, Ve(e.message.blocks, (v) => (A(), st(Lr, {
                  key: v.id,
                  block: v,
                  onInteractionSubmit: g[4] || (g[4] = (...p) => d.$emit("interaction-submit", ...p)),
                  onInteractionCancel: g[5] || (g[5] = (p) => d.$emit("interaction-cancel", p)),
                  onRetry: g[6] || (g[6] = (p) => d.$emit("retry"))
                }, null, 8, ["block"]))), 128)),
                !e.message.blocks.length && n.value && !e.statusHint ? (A(), E("div", Fu, " 正在处理 ")) : ie("", !0)
              ]),
              d.$slots.meta ? (A(), E("footer", Nu, [
                Et(d.$slots, "meta", { message: e.message }, void 0)
              ])) : ie("", !0)
            ], 2)
          ], 2)
        ]))
      ], 10, bu);
    };
  }
}), Lu = /* @__PURE__ */ Dt(Ku, [["__scopeId", "data-v-05a4c2be"]]), Uu = {
  key: 0,
  class: "reachai-message-list__empty"
}, Vu = /* @__PURE__ */ ht({
  __name: "ConversationMessageList",
  props: {
    messages: {},
    autoFollow: { type: Boolean, default: !0 },
    assistantLabel: { default: "" },
    resolveStatusHint: {},
    resolveThinkingPresentation: {},
    showAvatars: { type: Boolean, default: !0 },
    surface: { default: "admin" }
  },
  emits: ["interaction-submit", "interaction-cancel", "retry"],
  setup(e, { expose: t }) {
    const s = e, n = /* @__PURE__ */ Ne(null), r = /* @__PURE__ */ Ne(!0), i = /* @__PURE__ */ Ne(!1);
    function o(c) {
      var d;
      return ((d = s.resolveStatusHint) == null ? void 0 : d.call(s, c)) || "";
    }
    function a(c) {
      var d;
      return ((d = s.resolveThinkingPresentation) == null ? void 0 : d.call(s, c)) || null;
    }
    function l() {
      const c = n.value;
      if (!c) return;
      const d = c.scrollHeight - c.scrollTop - c.clientHeight;
      r.value = d < 48, i.value = !r.value;
    }
    function f(c = !1) {
      const d = n.value;
      d && (!c && !r.value || (d.scrollTop = d.scrollHeight, i.value = !1, r.value = !0));
    }
    return qt(
      () => s.messages,
      async () => {
        s.autoFollow !== !1 && (await Dn(), f());
      },
      { deep: !0 }
    ), Kn(() => f(!0)), t({ scrollToBottom: f }), (c, d) => (A(), E("div", {
      ref_key: "listEl",
      ref: n,
      class: "reachai-message-list",
      role: "log",
      "aria-live": "polite",
      onScroll: l
    }, [
      e.messages.length ? ie("", !0) : (A(), E("div", Uu, [
        Et(c.$slots, "empty", {}, () => [
          d[4] || (d[4] = us("开始对话吧", -1))
        ])
      ])),
      (A(!0), E(be, null, Ve(e.messages, (g) => (A(), st(Lu, {
        key: g.id,
        message: g,
        "assistant-label": e.assistantLabel,
        "status-hint": o(g),
        "thinking-presentation": a(g),
        "show-avatars": e.showAvatars,
        surface: e.surface,
        onInteractionSubmit: d[0] || (d[0] = (..._) => c.$emit("interaction-submit", ..._)),
        onInteractionCancel: d[1] || (d[1] = (_) => c.$emit("interaction-cancel", _)),
        onRetry: d[2] || (d[2] = (_) => c.$emit("retry"))
      }, Ai({ _: 2 }, [
        c.$slots["message-meta"] ? {
          name: "meta",
          fn: Ts((_) => [
            Et(c.$slots, "message-meta", zi({ ref_for: !0 }, _), void 0, !0)
          ]),
          key: "0"
        } : void 0
      ]), 1032, ["message", "assistant-label", "status-hint", "thinking-presentation", "show-avatars", "surface"]))), 128)),
      i.value ? (A(), E("button", {
        key: 1,
        type: "button",
        class: "reachai-message-list__jump",
        onClick: d[3] || (d[3] = (g) => f(!0))
      }, " 回到底部 ")) : ie("", !0)
    ], 544));
  }
}), Bu = /* @__PURE__ */ Dt(Vu, [["__scopeId", "data-v-3cddb8bb"]]), Hu = ["placeholder", "disabled", "aria-label"], Wu = { class: "reachai-composer__actions" }, zu = { class: "reachai-composer__buttons" }, Ju = ["disabled"], Gu = /* @__PURE__ */ ht({
  __name: "ConversationComposer",
  props: {
    placeholder: { default: "输入消息" },
    disabled: { type: Boolean, default: !1 },
    showStop: { type: Boolean, default: !1 }
  },
  emits: ["send", "stop"],
  setup(e, { expose: t, emit: s }) {
    const n = s, r = /* @__PURE__ */ Ne(""), i = /* @__PURE__ */ Ne(null);
    function o() {
      const l = r.value.trim();
      l && (n("send", l), r.value = "");
    }
    function a(l) {
      (l.ctrlKey || l.metaKey) && l.key === "Enter" && (l.preventDefault(), o());
    }
    return t({
      focus() {
        var l;
        (l = i.value) == null || l.focus();
      },
      setValue(l) {
        r.value = l;
      }
    }), (l, f) => (A(), E("form", {
      class: "reachai-composer",
      onSubmit: Zi(o, ["prevent"])
    }, [
      Kt(N("textarea", {
        ref_key: "inputEl",
        ref: i,
        "onUpdate:modelValue": f[0] || (f[0] = (c) => r.value = c),
        class: "reachai-composer__input",
        rows: "2",
        placeholder: e.placeholder,
        disabled: e.disabled,
        "aria-label": e.placeholder,
        onKeydown: a
      }, null, 40, Hu), [
        [Sn, r.value]
      ]),
      N("div", Wu, [
        f[2] || (f[2] = N("span", { class: "reachai-composer__hint" }, [
          N("kbd", null, "Ctrl"),
          N("b", null, "+"),
          N("kbd", null, "Enter"),
          N("em", null, "发送")
        ], -1)),
        N("div", zu, [
          e.showStop ? (A(), E("button", {
            key: 0,
            type: "button",
            class: "reachai-composer__stop",
            onClick: f[1] || (f[1] = (c) => l.$emit("stop"))
          }, " 停止 ")) : ie("", !0),
          N("button", {
            type: "submit",
            class: Ye(["reachai-composer__send", { "is-busy": e.showStop }]),
            disabled: e.disabled || !r.value.trim()
          }, ne(e.showStop ? "思考中" : "发送"), 11, Ju)
        ])
      ])
    ], 32));
  }
}), Yu = /* @__PURE__ */ Dt(Gu, [["__scopeId", "data-v-fe697210"]]);
function io(e) {
  return `./${e}`;
}
const Xu = io("agent-prism.webp"), Qu = io("conversation-atmosphere.webp"), Zu = ["data-surface"], ef = {
  key: 0,
  class: "reachai-conversation__header"
}, tf = {
  key: 1,
  class: "reachai-conversation__error",
  role: "alert"
}, sf = {
  key: 2,
  class: "reachai-conversation__footer"
}, nf = /* @__PURE__ */ ht({
  __name: "ConversationView",
  props: {
    snapshot: {},
    density: { default: "comfortable" },
    chrome: { default: "panel" },
    placeholder: {},
    hideComposer: { type: Boolean, default: !1 },
    autoFollow: { type: Boolean, default: !0 },
    disableSendWhileBusy: { type: Boolean, default: !0 },
    atmosphere: { type: Boolean, default: !0 },
    assistantLabel: { default: "" },
    showAvatars: { type: Boolean, default: !0 },
    surface: { default: "admin" },
    resolveStatusHint: {},
    resolveThinkingPresentation: {}
  },
  emits: ["send", "stop", "retry", "interaction-submit", "interaction-cancel"],
  setup(e, { emit: t }) {
    const s = e, n = t, r = fe(() => ({
      "--reachai-chat-atmosphere-image": `url("${Qu}")`,
      "--reachai-chat-prism-avatar": `url("${Xu}")`
    })), i = fe(
      () => s.snapshot.turnStatus === "sending" || s.snapshot.turnStatus === "streaming"
    ), o = fe(() => i.value), a = fe(
      () => s.disableSendWhileBusy && (i.value || s.snapshot.turnStatus === "waiting")
    );
    function l(d) {
      n("send", d);
    }
    function f(d, g, _) {
      n("interaction-submit", d, g, _);
    }
    function c(d) {
      n("interaction-cancel", d);
    }
    return (d, g) => (A(), E("div", {
      class: Ye(["reachai-conversation", [
        `reachai-conversation--${e.density}`,
        `reachai-conversation--${e.chrome}`,
        {
          "reachai-conversation--atmosphere": e.atmosphere,
          "is-busy": i.value
        }
      ]]),
      "data-surface": e.surface,
      style: hs(r.value)
    }, [
      d.$slots.header ? (A(), E("header", ef, [
        Et(d.$slots, "header", {}, void 0)
      ])) : ie("", !0),
      Oe(Bu, {
        messages: e.snapshot.messages,
        "auto-follow": e.autoFollow,
        "assistant-label": e.assistantLabel,
        "resolve-status-hint": e.resolveStatusHint,
        "resolve-thinking-presentation": e.resolveThinkingPresentation,
        "show-avatars": e.showAvatars,
        surface: e.surface,
        onInteractionSubmit: f,
        onInteractionCancel: c,
        onRetry: g[0] || (g[0] = (_) => d.$emit("retry"))
      }, Ai({ _: 2 }, [
        d.$slots.empty ? {
          name: "empty",
          fn: Ts(() => [
            Et(d.$slots, "empty", {}, void 0, !0)
          ]),
          key: "0"
        } : void 0,
        d.$slots["message-meta"] ? {
          name: "message-meta",
          fn: Ts((_) => [
            Et(d.$slots, "message-meta", xo(Wi(_)), void 0, !0)
          ]),
          key: "1"
        } : void 0
      ]), 1032, ["messages", "auto-follow", "assistant-label", "resolve-status-hint", "resolve-thinking-presentation", "show-avatars", "surface"]),
      e.snapshot.error ? (A(), E("div", tf, [
        N("span", null, ne(e.snapshot.error), 1),
        N("button", {
          type: "button",
          onClick: g[1] || (g[1] = (_) => d.$emit("retry"))
        }, "重试")
      ])) : ie("", !0),
      Et(d.$slots, "composer", {}, () => [
        e.hideComposer ? ie("", !0) : (A(), st(Yu, {
          key: 0,
          disabled: a.value,
          "show-stop": o.value,
          placeholder: e.placeholder,
          onSend: l,
          onStop: g[2] || (g[2] = (_) => d.$emit("stop"))
        }, null, 8, ["disabled", "show-stop", "placeholder"]))
      ]),
      d.$slots.footer ? (A(), E("footer", sf, [
        Et(d.$slots, "footer", {}, void 0)
      ])) : ie("", !0)
    ], 14, Zu));
  }
}), rf = /* @__PURE__ */ Dt(nf, [["__scopeId", "data-v-13c4a68e"]]), of = "1.0.0";
function af(e, t) {
  return {
    pageKey: t == null ? void 0 : t.pageKey,
    pageInstanceId: e.pageInstanceId,
    route: e.route || (typeof location < "u" ? location.pathname : "/"),
    bridgeActions: e.registeredActions,
    sdkVersion: of
  };
}
const lf = /* @__PURE__ */ ht({
  __name: "EmbedChatHost",
  props: {
    apiBase: {},
    tokenProvider: {},
    bridge: {},
    page: {},
    context: { default: () => ({}) },
    placeholder: { default: "输入消息" },
    preferStream: { type: Boolean, default: !0 },
    onEvent: {},
    onError: {},
    onUnauthorized: {}
  },
  setup(e, { expose: t }) {
    const s = e, n = /* @__PURE__ */ Ne(Wn());
    let r = "", i = { ...s.context }, o = "", a = !1, l = null;
    async function f() {
      const j = await s.tokenProvider();
      return o = String(j || ""), o;
    }
    f().catch(() => {
    });
    const c = hc({
      apiBase: s.apiBase,
      tokenProvider: () => o,
      getSessionId: () => r || void 0,
      setSessionId: (j) => {
        r = j || "";
      },
      getContext: () => i,
      createSessionPayload: () => ({
        ...af(s.bridge, s.page)
      }),
      preferStream: s.preferStream,
      onUnauthorized: async () => {
        var T;
        const j = await ((T = s.onUnauthorized) == null ? void 0 : T.call(s));
        return typeof j == "string" && j ? (o = j, j) : f();
      }
    }), d = c, g = oc({
      transport: c,
      onPublicEvent: _,
      onChange(j) {
        n.value = j, j.sessionId && (r = j.sessionId), p(j);
      }
    });
    function _(j) {
      var G, se, re, ge, je, Ce, le;
      const T = j.data, B = {
        sessionId: j.sessionId || r || void 0,
        turnId: j.turnId
      };
      switch (j.type) {
        case "message.delta":
          (G = s.onEvent) == null || G.call(s, { type: "message.delta", data: T, ...B });
          return;
        case "ui.requested":
          (se = s.onEvent) == null || se.call(s, { type: "ui.requested", data: T, ...B });
          return;
        case "page.action.requested":
          (re = s.onEvent) == null || re.call(s, { type: "page.action.requested", data: T, ...B });
          return;
        case "turn.completed":
        case "turn.waiting":
          (ge = s.onEvent) == null || ge.call(s, {
            type: "message.completed",
            data: v(j),
            ...B
          });
          return;
        case "turn.failed":
          (je = s.onEvent) == null || je.call(s, { type: "error", data: T, ...B });
          return;
        case "interaction.submitted":
          (Ce = s.onEvent) == null || Ce.call(s, { type: "interaction.submitted", data: T, ...B });
          return;
        case "interaction.cancelled":
          (le = s.onEvent) == null || le.call(s, { type: "interaction.cancelled", data: T, ...B });
          return;
        default:
          return;
      }
    }
    function v(j) {
      const T = j.data && typeof j.data == "object" ? j.data : {}, B = no(T) || (T.metadata && typeof T.metadata == "object" && !Array.isArray(T.metadata) ? { ...T.metadata } : void 0);
      return {
        answer: T.answer != null ? String(T.answer) : void 0,
        sessionId: j.sessionId || (T.sessionId != null ? String(T.sessionId) : r) || void 0,
        uiRequest: T.uiRequest,
        metadata: B,
        intentType: T.intentType,
        toolCalls: T.toolCalls,
        turnId: j.turnId
      };
    }
    function p(j) {
      if (!l) return;
      const T = j.turnStatus;
      if (T === "sending" || T === "streaming") {
        l.armed = !0;
        return;
      }
      if (!l.armed || T !== "completed" && T !== "waiting" && T !== "failed" && T !== "cancelled")
        return;
      const B = l;
      if (l = null, T === "failed") {
        B.reject(new Error(j.error || "Message failed"));
        return;
      }
      if (T === "cancelled") {
        B.reject(new DOMException("The operation was aborted.", "AbortError"));
        return;
      }
      B.resolve(M(j));
    }
    function M(j) {
      var ge, je;
      let T = "", B, G, se, re;
      for (let Ce = j.messages.length - 1; Ce >= 0; Ce -= 1) {
        const le = j.messages[Ce];
        if (le.role === "assistant") {
          T = Vl(le);
          for (const D of le.blocks)
            D.type === "interaction" && (D.state === "waiting" || D.state === "submitting") && (B = D.request);
          G = le.metadata ? { ...le.metadata } : void 0, G && "metadata" in G && typeof G.metadata == "object" && (G = { ...G.metadata }), se = (ge = le.completion) == null ? void 0 : ge.intentType, re = (je = le.completion) == null ? void 0 : je.toolCalls;
          break;
        }
      }
      return G && (delete G.result, delete G.answer, delete G.uiRequest, delete G.sessionId, delete G.intentType, delete G.toolCalls), {
        answer: T,
        sessionId: j.sessionId || r || void 0,
        uiRequest: B,
        metadata: G && Object.keys(G).length ? G : void 0,
        intentType: se,
        toolCalls: re,
        turnId: j.turnId
      };
    }
    async function K(j) {
      if (a)
        throw new DOMException("The operation was aborted.", "AbortError");
      const T = j.trim();
      if (!T) return {};
      if (l)
        throw new Error("Another message is still in flight");
      return await f(), new Promise((B, G) => {
        l = { resolve: B, reject: G, armed: !1 }, g.send(T).catch((se) => {
          l && (l = null, G(se));
        });
      });
    }
    function P(j) {
      i = { ...i, ...j };
    }
    function V() {
      return r || null;
    }
    function $() {
      return r || null;
    }
    async function W() {
      if (a) throw new DOMException("The operation was aborted.", "AbortError");
      if (await f(), r) return r;
      if (typeof d.ensureSession == "function")
        return d.ensureSession();
      throw new Error("Embed transport cannot ensure session");
    }
    function y(j) {
      return j.role !== "assistant" || j.status !== "pending" && j.status !== "streaming" ? void 0 : j.blocks.some((B) => B.type === "text" && B.text) ? "正在生成回答" : "正在处理";
    }
    function k(j) {
      K(j).catch(xe);
    }
    function z() {
      g.cancel().then(() => {
        if (l) {
          const j = l;
          l = null, j.reject(new DOMException("The operation was aborted.", "AbortError"));
        }
      });
    }
    function U(j, T, B) {
      g.submitInteraction(j, T, B).catch(xe);
    }
    function Q(j) {
      g.submitInteraction(j, "cancel", {}).catch(xe);
    }
    function xe(j) {
      var B;
      const T = { message: j instanceof Error ? j.message : String(j), cause: j };
      (B = s.onError) == null || B.call(s, T);
    }
    function Ae() {
      if (a = !0, l) {
        const j = l;
        l = null, j.reject(new DOMException("The operation was aborted.", "AbortError"));
      }
      g.dispose();
    }
    return Ln(() => {
      Ae();
    }), t({
      sendMessage: K,
      setContext: P,
      getSessionId: V,
      getExistingSessionId: $,
      ensureHostSession: W,
      disposeHost: Ae
    }), (j, T) => (A(), st(jn(rf), {
      class: "eaf-chat__conversation",
      chrome: "inline",
      density: "compact",
      surface: "embed",
      atmosphere: "",
      snapshot: n.value,
      placeholder: e.placeholder,
      "resolve-status-hint": y,
      onSend: k,
      onStop: z,
      onInteractionSubmit: U,
      onInteractionCancel: Q
    }, null, 8, ["snapshot", "placeholder"]));
  }
}), oo = /* @__PURE__ */ Dt(lf, [["__scopeId", "data-v-6d4ebfab"]]);
function xn(e) {
  var n;
  const t = (n = e.metadata) == null ? void 0 : n.pageActionQueue;
  if (!Array.isArray(t)) return [];
  const s = Yn(e.metadata);
  return t.map((r) => ao(r, s)).filter((r) => !!r);
}
function ao(e, t) {
  if (!e || typeof e != "object") return null;
  const s = e;
  if (s.type !== "page.action.requested" || typeof s.requestId != "string" || typeof s.actionKey != "string") return null;
  const n = s.metadata && typeof s.metadata == "object" ? { ...s.metadata } : {}, r = typeof s.pageKey == "string" ? s.pageKey : t;
  return r && !n.pageKey && (n.pageKey = r), {
    type: "page.action.requested",
    protocolVersion: typeof s.protocolVersion == "string" ? s.protocolVersion : void 0,
    requestId: s.requestId,
    actionKey: s.actionKey,
    title: typeof s.title == "string" ? s.title : void 0,
    args: s.args && typeof s.args == "object" ? s.args : void 0,
    target: s.target && typeof s.target == "object" ? s.target : void 0,
    confirm: s.confirm === !0,
    metadata: n
  };
}
async function Gn(e) {
  const t = ao(e.request, Yn(e.responseMetadata));
  if (!(t != null && t.requestId)) return;
  const s = t.requestId;
  if (e.handledPageActions.has(s)) return;
  const n = e.inFlightPageActions.get(s);
  if (n) {
    await n;
    return;
  }
  const r = (async () => {
    var i, o, a;
    if (!e.handledPageActions.has(s)) {
      e.handledPageActions.add(s), (i = e.onRequested) == null || i.call(e, t);
      try {
        const l = await cf(
          t,
          e.bridge,
          e.responseMetadata,
          /* @__PURE__ */ new Set()
          // 已认领，内部不再二次 gated
        );
        if (!l) return;
        (l.status === "FAILED" || l.status === "TIMEOUT") && ((o = e.onError) == null || o.call(e, new Error(l.error || `Page action ${l.status}: ${t.actionKey}`)));
        let f = e.token;
        try {
          await Ur(
            e.apiBase,
            e.sessionId,
            f,
            l,
            e.fetchImpl
          );
        } catch (c) {
          if (!co(c) || !e.refreshToken) throw c;
          f = await e.refreshToken(), await Ur(
            e.apiBase,
            e.sessionId,
            f,
            l,
            e.fetchImpl
          );
        }
      } catch (l) {
        (a = e.onError) == null || a.call(e, l);
      }
    }
  })();
  e.inFlightPageActions.set(s, r);
  try {
    await r;
  } finally {
    e.inFlightPageActions.delete(s);
  }
}
async function cf(e, t, s, n) {
  const r = await t.handleEvent(e);
  if (r && r.status !== "ACTION_NOT_FOUND")
    return n.add(e.requestId), r;
  const i = await ff(e, s);
  return i ? (i.status !== "ACTION_NOT_FOUND" && n.add(e.requestId), i) : (r && n.add(e.requestId), r);
}
async function uf(e) {
  const t = xn(e.response);
  for (const s of t)
    await Gn({
      request: s,
      bridge: e.bridge,
      sessionId: e.sessionId,
      apiBase: e.apiBase,
      token: e.token,
      handledPageActions: e.handledPageActions,
      inFlightPageActions: e.inFlightPageActions,
      responseMetadata: e.response.metadata,
      onRequested: e.onRequested,
      onError: e.onError,
      refreshToken: e.refreshToken,
      fetchImpl: e.fetchImpl
    });
}
async function ff(e, t) {
  const s = typeof window < "u" ? window.__REACHAI_PAGE_BRIDGE__ : void 0;
  if (!s || typeof s.execute != "function") return null;
  const n = df(e) || Yn(t);
  if (!n)
    return {
      protocolVersion: e.protocolVersion || "1.0",
      type: "page.action.result",
      requestId: e.requestId,
      actionKey: e.actionKey,
      status: "ACTION_NOT_FOUND",
      error: "Page action pageKey is missing for window.__REACHAI_PAGE_BRIDGE__ fallback"
    };
  try {
    const r = await s.execute(n, e.actionKey, e.args || {}, {
      confirmed: !0,
      requestId: e.requestId
    }), i = r && typeof r == "object" ? r : { data: r }, o = String(i.status || "SUCCESS").toUpperCase(), a = o === "SUCCESS", l = i.error && typeof i.error == "object" ? String(i.error.message || i.message || "") : String(i.message || "");
    return {
      protocolVersion: e.protocolVersion || "1.0",
      type: "page.action.result",
      requestId: e.requestId,
      actionKey: e.actionKey,
      status: a ? "SUCCESS" : "FAILED",
      data: i.data ?? r,
      error: a ? void 0 : l || `Page action returned ${o}`
    };
  } catch (r) {
    return {
      protocolVersion: e.protocolVersion || "1.0",
      type: "page.action.result",
      requestId: e.requestId,
      actionKey: e.actionKey,
      status: "FAILED",
      error: r instanceof Error ? r.message : String(r)
    };
  }
}
function df(e) {
  var s;
  const t = (s = e.metadata) == null ? void 0 : s.pageKey;
  return typeof t == "string" && t.trim() ? t.trim() : void 0;
}
function Yn(e) {
  const t = e == null ? void 0 : e.pageKey;
  return typeof t == "string" && t.trim() ? t.trim() : void 0;
}
async function Ur(e, t, s, n, r = fetch) {
  await pf(
    `${e}/chat/sessions/${encodeURIComponent(t)}/page-actions/${encodeURIComponent(n.requestId)}/result`,
    n,
    s,
    r
  );
}
async function hf(e) {
  const t = e.fetchImpl || fetch, s = e.inFlightPageActions || /* @__PURE__ */ new Map(), n = `${e.apiBase}/chat/sessions/${encodeURIComponent(e.sessionId)}/page-actions/pending?limit=10`;
  let r;
  try {
    r = await Vr(n, e.token, t);
  } catch (i) {
    if (!co(i) || !e.refreshToken) throw i;
    const o = await e.refreshToken();
    r = await Vr(n, o, t);
  }
  for (const i of r)
    i != null && i.requestId && await Gn({
      request: i,
      bridge: e.bridge,
      sessionId: e.sessionId,
      apiBase: e.apiBase,
      token: e.token,
      handledPageActions: e.handledPageActions,
      inFlightPageActions: s,
      responseMetadata: e.context,
      onRequested: (o) => {
        var a;
        return (a = e.onEvent) == null ? void 0 : a.call(e, { type: "page.action.requested", data: o });
      },
      onError: e.onError,
      refreshToken: e.refreshToken,
      fetchImpl: t
    });
}
async function pf(e, t, s, n) {
  const r = await n(e, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${s}`
    },
    body: JSON.stringify(t)
  }), i = await r.json().catch(() => ({}));
  if (!r.ok || i.code && i.code !== 200 && i.code !== 0)
    throw lo(i.message || `Request failed: ${r.status}`, r.status);
  return i.data ?? i;
}
async function Vr(e, t, s) {
  const n = await s(e, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${t}`
    }
  }), r = await n.json().catch(() => ({}));
  if (!n.ok || r.code && r.code !== 200 && r.code !== 0)
    throw lo(r.message || `Request failed: ${n.status}`, n.status);
  return r.data ?? r;
}
function lo(e, t) {
  const s = new Error(e);
  return s.status = t, s;
}
function co(e) {
  return !!(e && typeof e == "object" && e.status === 401);
}
const ws = {
  activeWindowMs: 5e3,
  activeIntervalMs: 1e3,
  idleIntervalMs: 1e4,
  /** 第 1..n 次连续失败后的等待间隔（ms），封顶取最后一项 */
  backoffMs: [5e3, 1e4, 2e4, 4e4, 6e4]
};
function gf(e) {
  var Q, xe, Ae, j;
  const t = {
    activeWindowMs: ((Q = e.timings) == null ? void 0 : Q.activeWindowMs) ?? ws.activeWindowMs,
    activeIntervalMs: ((xe = e.timings) == null ? void 0 : xe.activeIntervalMs) ?? ws.activeIntervalMs,
    idleIntervalMs: ((Ae = e.timings) == null ? void 0 : Ae.idleIntervalMs) ?? ws.idleIntervalMs,
    backoffMs: ((j = e.timings) == null ? void 0 : j.backoffMs) ?? ws.backoffMs
  }, s = e.now || (() => Date.now()), n = e.setTimeoutFn || ((T, B) => window.setTimeout(T, B)), r = e.clearTimeoutFn || ((T) => window.clearTimeout(T)), i = e.isDocumentHidden || (() => typeof document > "u" ? !1 : document.visibilityState === "hidden");
  let o = !1, a, l = !1, f = !1, c = !1, d = 0, g = 0, _ = 0, v = 0, p;
  function M() {
    return !(o || e.isDestroyed() || !e.getSessionId() || !e.hasRegisteredActions() || i());
  }
  function K() {
    a !== void 0 && (r(a), a = void 0);
  }
  function P() {
    if (_ <= 0) return 0;
    const T = Math.min(_ - 1, t.backoffMs.length - 1);
    return t.backoffMs[T];
  }
  function V(T) {
    if (v > T)
      return v - T;
    if (c) {
      if (g > 0) {
        const B = T - g;
        if (B < t.activeIntervalMs)
          return t.activeIntervalMs - B;
      }
      return 0;
    }
    if (T < d) {
      if (g > 0) {
        const B = T - g;
        if (B < t.activeIntervalMs)
          return t.activeIntervalMs - B;
      }
      return 0;
    }
    if (g > 0) {
      const B = T - g;
      if (B < t.idleIntervalMs)
        return t.idleIntervalMs - B;
    }
    return t.idleIntervalMs;
  }
  function $() {
    if (K(), o || e.isDestroyed() || !M()) return;
    if (l) {
      f = !0;
      return;
    }
    const T = s(), B = V(T);
    a = n(() => {
      a = void 0, W();
    }, Math.max(0, B));
  }
  async function W() {
    var T;
    if (!(o || e.isDestroyed()) && M()) {
      if (l) {
        f = !0;
        return;
      }
      l = !0, c = !1, g = s();
      try {
        await e.poll(), _ = 0, v = 0;
      } catch (B) {
        _ += 1;
        const G = P();
        v = s() + G, (T = e.onError) == null || T.call(e, B);
      } finally {
        l = !1, f && (f = !1, c = !0), $();
      }
    }
  }
  function y() {
    if (o || e.isDestroyed()) return;
    const T = s();
    if (d = Math.max(d, T + t.activeWindowMs), c = !0, l) {
      f = !0;
      return;
    }
    $();
  }
  function k(T, B) {
    if (!(o || e.isDestroyed())) {
      if (T <= 0 && B > 0) {
        e.getSessionId() && y();
        return;
      }
      T > 0 && B <= 0 && (K(), c = !1, f = !1);
    }
  }
  function z() {
    if (!(o || e.isDestroyed())) {
      if (i()) {
        K();
        return;
      }
      y();
    }
  }
  return p = (e.addVisibilityListener || ((T) => typeof document > "u" ? () => {
  } : (document.addEventListener("visibilitychange", T), () => document.removeEventListener("visibilitychange", T))))(z), {
    notifyActivity: y,
    notifyActionsChanged: k,
    destroy() {
      o = !0, K(), c = !1, f = !1, p == null || p(), p = void 0;
    },
    isInFlight() {
      return l;
    }
  };
}
function mf(e, t) {
  const s = String(t || "").trim();
  if (!s) return;
  e.style.setProperty("--reachai-chat-primary", s), e.style.setProperty("--reachai-chat-spectrum-anchor", s);
  const n = yf(s);
  n && e.style.setProperty("--reachai-chat-primary-rgb", `${n[0]} ${n[1]} ${n[2]}`);
}
function yf(e) {
  const t = e.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);
  if (t) {
    const n = t[1];
    return n.length === 3 ? [
      parseInt(n[0] + n[0], 16),
      parseInt(n[1] + n[1], 16),
      parseInt(n[2] + n[2], 16)
    ] : [
      parseInt(n.slice(0, 2), 16),
      parseInt(n.slice(2, 4), 16),
      parseInt(n.slice(4, 6), 16)
    ];
  }
  const s = e.match(/^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
  return s ? [Number(s[1]), Number(s[2]), Number(s[3])] : null;
}
async function Pf(e) {
  var je, Ce, le;
  if (!e.agentId) throw new Error("agentId is required");
  const t = typeof e.mount == "string" ? document.querySelector(e.mount) : e.mount;
  if (!t) throw new Error("mount element not found");
  const s = e.bridge || un({ route: location.pathname }), n = Cf(e.apiBase, e.embedPathPrefix), r = kf(e.apiBase);
  let i = await e.tokenProvider(), o = { ...e.context || {} };
  const a = /* @__PURE__ */ new Set(), l = /* @__PURE__ */ new Set(), f = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Set();
  let d, g = !1, _ = null, v = null, p = !1, M = s.registeredActions.length;
  function K(D, m = {}) {
    var oe;
    const H = String((D && typeof D == "object" ? D : {}).requestId || "");
    if (H) {
      if (c.has(H)) return !1;
      c.add(H);
    }
    return (oe = e.onEvent) == null || oe.call(e, {
      type: "page.action.requested",
      data: D,
      sessionId: m.sessionId,
      turnId: m.turnId
    }), !0;
  }
  function P(D, m, w) {
    if (!g) {
      if (!m) {
        y(new Error("Page action requires an active embed session; no sessionId available"));
        return;
      }
      Gn({
        request: D,
        bridge: s,
        sessionId: m,
        apiBase: n,
        token: i,
        handledPageActions: l,
        inFlightPageActions: f,
        responseMetadata: w,
        onRequested: (H) => K(H, { sessionId: m }),
        onError: y,
        refreshToken: async () => (await se(), i)
      }).catch(y);
    }
  }
  function V(D) {
    if (D.sessionId) return D.sessionId;
    const m = D.data && typeof D.data == "object" ? D.data : {};
    return m.sessionId != null && String(m.sessionId) ? String(m.sessionId) : (v == null ? void 0 : v.getExistingSessionId()) || (v == null ? void 0 : v.getSessionId()) || void 0;
  }
  function $(D) {
    var m, w;
    if (D.type === "page.action.requested") {
      const H = K(D.data, {
        sessionId: D.sessionId,
        turnId: D.turnId
      });
      P(
        D.data,
        V(D),
        D.data && typeof D.data == "object" ? D.data.metadata : void 0
      ), H && z.notifyActivity();
      return;
    }
    if (D.type === "message.completed") {
      const H = D.data;
      for (const oe of xn(H))
        K(oe, { sessionId: H.sessionId, turnId: H.turnId });
      (m = e.onEvent) == null || m.call(e, D), W(H).catch(y), z.notifyActivity();
      return;
    }
    (w = e.onEvent) == null || w.call(e, D);
  }
  async function W(D) {
    if (!D || g) return;
    const m = D.sessionId || (v == null ? void 0 : v.getExistingSessionId()) || (v == null ? void 0 : v.getSessionId()), w = xn(D);
    if (!m) {
      w.length > 0 && y(new Error("Page action requires an active embed session; no sessionId available"));
      return;
    }
    await uf({
      response: D,
      bridge: s,
      sessionId: m,
      apiBase: n,
      token: i,
      handledPageActions: l,
      inFlightPageActions: f,
      onRequested: (H) => K(H, { sessionId: m }),
      onError: y,
      refreshToken: async () => (await se(), i)
    });
  }
  function y(D) {
    var w;
    const m = { message: D instanceof Error ? D.message : String(D), cause: D };
    (w = e.onError) == null || w.call(e, m);
  }
  async function k() {
    if (g) return;
    const D = v == null ? void 0 : v.getExistingSessionId();
    D && await hf({
      apiBase: n,
      token: i,
      sessionId: D,
      bridge: s,
      handledPageActions: l,
      pendingPageActions: a,
      inFlightPageActions: f,
      context: o,
      // poll 自己已 dispatch；此处只 publish，禁止再走 emitPublicEvent→dispatch 递归
      onEvent: (m) => {
        m.type === "page.action.requested" && K(m.data, { sessionId: D });
      },
      onError: y,
      refreshToken: async () => (await se(), i)
    });
  }
  const z = gf({
    getSessionId: () => (v == null ? void 0 : v.getExistingSessionId()) || null,
    hasRegisteredActions: () => s.registeredActions.length > 0,
    isDestroyed: () => g,
    poll: k,
    onError: y
  }), U = document.createElement("div");
  U.className = "eaf-chat", e.position && e.position !== "inline" && U.classList.add(`eaf-chat--${e.position}`), e.initialOpen === !1 && U.classList.add("eaf-chat--closed"), (je = e.theme) != null && je.primaryColor && mf(U, e.theme.primaryColor), U.innerHTML = `
    <div class="eaf-chat__header">
      <div class="eaf-chat__brand">${Af(((Ce = e.theme) == null ? void 0 : Ce.brandName) || "ReachAI")}</div>
      <button class="eaf-chat__toggle" type="button" aria-expanded="${e.initialOpen === !1 ? "false" : "true"}">
        ${e.initialOpen === !1 ? "+" : "-"}
      </button>
    </div>
    <div class="eaf-chat__body"></div>
  `, t.appendChild(U);
  const Q = U.querySelector(".eaf-chat__toggle"), xe = U.querySelector(".eaf-chat__body");
  _ = In(oo, {
    apiBase: n,
    tokenProvider: () => i,
    bridge: s,
    page: e.page,
    context: o,
    placeholder: e.locale === "zh-CN" ? "输入消息" : "Type a message",
    preferStream: e.stream !== !1,
    onEvent: $,
    onError: (D) => y(D.cause ?? new Error(D.message)),
    onUnauthorized: async () => (i = await e.tokenProvider(), i)
  }), v = _.mount(xe);
  const Ae = s.onActionDefinitionsChange(() => {
    T();
    const D = s.registeredActions.length;
    z.notifyActionsChanged(M, D), M = D;
  });
  T(0);
  function j(D) {
    var w;
    const m = { message: D instanceof Error ? D.message : String(D), cause: D };
    (w = e.onError) == null || w.call(e, m);
  }
  function T(D = 250) {
    !e.pageRegistry || e.pageRegistry.registerOnStart === !1 || !e.page || (d && window.clearTimeout(d), d = window.setTimeout(() => {
      d = void 0, B().catch(j);
    }, D));
  }
  async function B() {
    g || await bf(r, e, s);
  }
  function G() {
    const D = !U.classList.contains("eaf-chat--closed");
    Q.textContent = D ? "-" : "+", Q.setAttribute("aria-expanded", D ? "true" : "false");
  }
  async function se() {
    i = await e.tokenProvider();
  }
  async function re(D) {
    const m = D.trim();
    if (!m || !v || g) return {};
    if (p) throw new Error("Another message is still in flight");
    p = !0, z.notifyActivity();
    try {
      const w = await v.sendMessage(m);
      return await W(w), z.notifyActivity(), w;
    } catch (w) {
      throw xf(w) && await se(), y(w), w;
    } finally {
      p = !1;
    }
  }
  Q.addEventListener("click", () => {
    const D = U.classList.contains("eaf-chat--closed");
    U.classList.toggle("eaf-chat--closed"), G(), D && !U.classList.contains("eaf-chat--closed") && z.notifyActivity();
  }), G();
  const ge = {
    bridge: s,
    get sessionId() {
      return (v == null ? void 0 : v.getSessionId()) || null;
    },
    open() {
      U.classList.remove("eaf-chat--closed"), G(), z.notifyActivity();
    },
    close() {
      U.classList.add("eaf-chat--closed"), G();
    },
    toggle() {
      const D = U.classList.contains("eaf-chat--closed");
      U.classList.toggle("eaf-chat--closed"), G(), D && !U.classList.contains("eaf-chat--closed") && z.notifyActivity();
    },
    send: re,
    registerPageCatalog: B,
    setContext(D) {
      o = { ...o, ...D || {} }, v == null || v.setContext(D || {});
    },
    destroy() {
      g = !0, z.destroy(), Ae(), d && window.clearTimeout(d), v == null || v.disposeHost(), _ == null || _.unmount(), _ = null, v = null, U.remove();
    }
  };
  return typeof process < "u" && ((le = process.env) != null && le.VITEST) && Object.assign(ge, {
    __emitPublicEventForTests: $
  }), ge;
}
async function bf(e, t, s) {
  const n = t.pageRegistry, r = t.page;
  !n || n.registerOnStart === !1 || !r || !n.projectCode || !n.appKey || !n.appSecret || await vf(
    `${e}/api/registry/projects/${encodeURIComponent(n.projectCode)}/pages/register`,
    {
      pageKey: r.pageKey,
      name: r.name || r.pageKey,
      routePattern: r.routePattern || s.route || location.pathname,
      origin: r.origin || location.origin,
      pageInstanceId: s.pageInstanceId,
      replaceActions: !0,
      actions: s.actionDefinitions.map(_f),
      metadata: r.metadata || {}
    },
    n
  );
}
function _f(e) {
  return {
    actionKey: e.actionKey,
    title: e.title || e.actionKey,
    description: e.description || "",
    confirmRequired: e.confirmRequired === !0,
    inputSchema: e.inputSchema || {},
    outputSchema: e.outputSchema || {},
    sampleArgs: e.sampleArgs || {},
    allowedAgentIds: e.allowedAgentIds || [],
    metadata: e.metadata || {}
  };
}
async function vf(e, t, s) {
  const n = String(Date.now()), r = Sf(), i = await wf(s.appSecret, `${s.projectCode}
${n}
${r}`), o = await fetch(e, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-ReachAI-App-Key": s.appKey,
      "X-ReachAI-Timestamp": n,
      "X-ReachAI-Nonce": r,
      "X-ReachAI-Signature": i
    },
    body: JSON.stringify(t)
  }), a = await o.json().catch(() => ({}));
  if (!o.ok || a.code && a.code !== 200 && a.code !== 0)
    throw If(a.message || `Page catalog registration failed: ${o.status}`, o.status);
  return a.data ?? a;
}
async function wf(e, t) {
  if (!(crypto != null && crypto.subtle))
    throw new Error("Web Crypto API is required for ReachAI page catalog registration");
  const s = new TextEncoder(), n = await crypto.subtle.importKey(
    "raw",
    s.encode(e),
    { name: "HMAC", hash: "SHA-256" },
    !1,
    ["sign"]
  ), r = await crypto.subtle.sign("HMAC", n, s.encode(t));
  return Array.from(new Uint8Array(r)).map((i) => i.toString(16).padStart(2, "0")).join("");
}
function Sf() {
  return typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}
function If(e, t) {
  const s = new Error(e);
  return s.status = t, s;
}
function xf(e) {
  return !!(e && typeof e == "object" && e.status === 401);
}
function Af(e) {
  return e.replace(/[<>&"']/g, (t) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", '"': "&quot;", "'": "&#39;" })[t] || t);
}
function Cf(e, t) {
  const s = ms((e || "").trim());
  if (t !== void 0) {
    const n = Xn(t || "/api/embed");
    return Br(Ef(s, n), n);
  }
  return uo(s) ? s : Br(s, "/api/embed");
}
function kf(e) {
  const t = ms((e || "").trim());
  return t ? uo(t) ? t.replace(/\/api\/(?:reachai\/)?embed$/i, "") : t : "";
}
function Br(e, t) {
  const s = ms(e), n = Xn(t);
  return s ? n ? `${s}${n}` : s : n || "";
}
function Ef(e, t) {
  const s = Xn(t);
  return !e || !s ? e : e.toLowerCase().endsWith(s.toLowerCase()) ? ms(e.slice(0, -s.length)) : e;
}
function Xn(e) {
  const t = ms((e || "").trim());
  return t ? t.startsWith("/") ? t : `/${t}` : "";
}
function uo(e) {
  return /\/api\/(?:reachai\/)?embed$/i.test(e);
}
function ms(e) {
  return e.endsWith("/") ? e.slice(0, -1) : e;
}
const Tf = /* @__PURE__ */ ht({
  __name: "ReachAiChatElement.ce",
  props: {
    apiBase: { default: "/api/embed", type: String },
    token: { default: "", type: String },
    pageKey: { type: String },
    route: { type: String },
    placeholder: { default: "输入消息", type: String }
  },
  setup(e) {
    const t = e, s = /* @__PURE__ */ Ne(!1), n = /* @__PURE__ */ Ne(un()), r = /* @__PURE__ */ Ne(void 0), i = /* @__PURE__ */ Ne({});
    function o() {
      return t.token;
    }
    async function a() {
      return t.token;
    }
    return Kn(() => {
      n.value = un({
        route: t.route || (typeof location < "u" ? location.pathname : "/")
      }), t.pageKey && (r.value = { pageKey: t.pageKey }), s.value = !0;
    }), (l, f) => s.value ? (A(), st(oo, {
      key: 0,
      "api-base": e.apiBase,
      "token-provider": o,
      bridge: n.value,
      page: r.value,
      context: i.value,
      placeholder: e.placeholder,
      "on-unauthorized": a
    }, null, 8, ["api-base", "bridge", "page", "context", "placeholder"])) : ie("", !0);
  }
});
let cn = !1;
function $f(e = "reachai-chat") {
  if (!(cn || typeof customElements > "u")) {
    if (customElements.get(e)) {
      cn = !0;
      return;
    }
    customElements.define(e, /* @__PURE__ */ Ml(Tf)), cn = !0;
  }
}
export {
  af as buildEafChatSessionPayload,
  Pf as createEafChat,
  un as createEafPageBridge,
  $f as defineReachAiChatElement,
  Cf as resolveEafChatEmbedApiRoot,
  kf as resolveEafChatPlatformBase
};
