function Ss(e = {}) {
  const t = e.pageInstanceId || Do(), n = Math.max(1e3, e.actionTimeoutMs || 15e3), s = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Set();
  function a() {
    return Array.from(s.keys()).map((u) => ({
      actionKey: u,
      ...r.get(u) || {}
    }));
  }
  function l(u) {
    i.forEach((h) => h(u));
  }
  function d() {
    const u = a();
    o.forEach((h) => h(u));
  }
  return {
    pageInstanceId: t,
    route: e.route,
    get registeredActions() {
      return Array.from(s.keys());
    },
    get actionDefinitions() {
      return a();
    },
    registerAction(u, h, v = {}) {
      return s.set(u, h), r.set(u, v), d(), () => {
        s.delete(u), r.delete(u), d();
      };
    },
    async handleEvent(u) {
      var M;
      if (!qo(u)) return null;
      const h = (M = u.target) == null ? void 0 : M.pageInstanceId;
      if (h && h !== t) return null;
      const v = s.get(u.actionKey);
      if (!v) {
        const I = Cn(u, "ACTION_NOT_FOUND", void 0, `Action is not registered: ${u.actionKey}`);
        return l(I), I;
      }
      if (!await No(u, e.confirmAction)) {
        const I = Cn(u, "CANCELLED", void 0, `Action was cancelled: ${u.actionKey}`);
        return l(I), I;
      }
      try {
        const I = await Lo(v(u.args || {}, u), n), x = Cn(u, "SUCCESS", I);
        return l(x), x;
      } catch (I) {
        const x = I instanceof Error ? I.message : String(I), N = Cn(u, x === "Page action timed out" ? "TIMEOUT" : "FAILED", void 0, x);
        return l(N), N;
      }
    },
    onResult(u) {
      return i.add(u), () => i.delete(u);
    },
    onActionDefinitionsChange(u) {
      return o.add(u), () => o.delete(u);
    }
  };
}
async function No(e, t) {
  return e.confirm ? t ? await t(e) : typeof window < "u" && typeof window.confirm == "function" ? window.confirm(e.title || `Run page action: ${e.actionKey}`) : !1 : !0;
}
function Cn(e, t, n, s) {
  return {
    protocolVersion: e.protocolVersion || "1.0",
    type: "page.action.result",
    requestId: e.requestId,
    actionKey: e.actionKey,
    status: t,
    data: n,
    error: s
  };
}
async function Lo(e, t) {
  let n;
  try {
    return await Promise.race([
      Promise.resolve(e),
      new Promise((s, r) => {
        n = setTimeout(() => r(new Error("Page action timed out")), t);
      })
    ]);
  } catch (s) {
    throw s instanceof Error && s.message === "Page action timed out", s;
  } finally {
    n && clearTimeout(n);
  }
}
function qo(e) {
  if (!e || typeof e != "object") return !1;
  const t = e;
  return t.type === "page.action.requested" && typeof t.requestId == "string" && typeof t.actionKey == "string";
}
function Do() {
  return typeof crypto < "u" && "randomUUID" in crypto ? `page-${crypto.randomUUID()}` : `page-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}
/**
* @vue/shared v3.5.31
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
// @__NO_SIDE_EFFECTS__
function qs(e) {
  const t = /* @__PURE__ */ Object.create(null);
  for (const n of e.split(",")) t[n] = 1;
  return (n) => n in t;
}
const pe = {}, Jt = [], ht = () => {
}, ci = () => !1, Wn = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && // uppercase letter
(e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97), zn = (e) => e.startsWith("onUpdate:"), ve = Object.assign, Ds = (e, t) => {
  const n = e.indexOf(t);
  n > -1 && e.splice(n, 1);
}, Fo = Object.prototype.hasOwnProperty, ce = (e, t) => Fo.call(e, t), G = Array.isArray, Gt = (e) => Sn(e) === "[object Map]", Jn = (e) => Sn(e) === "[object Set]", pr = (e) => Sn(e) === "[object Date]", ee = (e) => typeof e == "function", _e = (e) => typeof e == "string", st = (e) => typeof e == "symbol", fe = (e) => e !== null && typeof e == "object", ui = (e) => (fe(e) || ee(e)) && ee(e.then) && ee(e.catch), fi = Object.prototype.toString, Sn = (e) => fi.call(e), jo = (e) => Sn(e).slice(8, -1), Gn = (e) => Sn(e) === "[object Object]", Fs = (e) => _e(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e, ln = /* @__PURE__ */ qs(
  // the leading comma is intentional so empty string "" is also included
  ",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"
), Yn = (e) => {
  const t = /* @__PURE__ */ Object.create(null);
  return ((n) => t[n] || (t[n] = e(n)));
}, Ko = /-\w/g, xe = Yn(
  (e) => e.replace(Ko, (t) => t.slice(1).toUpperCase())
), Uo = /\B([A-Z])/g, Ze = Yn(
  (e) => e.replace(Uo, "-$1").toLowerCase()
), Xn = Yn((e) => e.charAt(0).toUpperCase() + e.slice(1)), ls = Yn(
  (e) => e ? `on${Xn(e)}` : ""
), dt = (e, t) => !Object.is(e, t), $n = (e, ...t) => {
  for (let n = 0; n < e.length; n++)
    e[n](...t);
}, di = (e, t, n, s = !1) => {
  Object.defineProperty(e, t, {
    configurable: !0,
    enumerable: !1,
    writable: s,
    value: n
  });
}, js = (e) => {
  const t = parseFloat(e);
  return isNaN(t) ? e : t;
}, gr = (e) => {
  const t = _e(e) ? Number(e) : NaN;
  return isNaN(t) ? e : t;
};
let mr;
const Qn = () => mr || (mr = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {});
function In(e) {
  if (G(e)) {
    const t = {};
    for (let n = 0; n < e.length; n++) {
      const s = e[n], r = _e(s) ? Wo(s) : In(s);
      if (r)
        for (const i in r)
          t[i] = r[i];
    }
    return t;
  } else if (_e(e) || fe(e))
    return e;
}
const Ho = /;(?![^(]*\))/g, Vo = /:([^]+)/, Bo = /\/\*[^]*?\*\//g;
function Wo(e) {
  const t = {};
  return e.replace(Bo, "").split(Ho).forEach((n) => {
    if (n) {
      const s = n.split(Vo);
      s.length > 1 && (t[s[0].trim()] = s[1].trim());
    }
  }), t;
}
function Oe(e) {
  let t = "";
  if (_e(e))
    t = e;
  else if (G(e))
    for (let n = 0; n < e.length; n++) {
      const s = Oe(e[n]);
      s && (t += s + " ");
    }
  else if (fe(e))
    for (const n in e)
      e[n] && (t += n + " ");
  return t.trim();
}
function zo(e) {
  if (!e) return null;
  let { class: t, style: n } = e;
  return t && !_e(t) && (e.class = Oe(t)), n && (e.style = In(n)), e;
}
const Jo = "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly", Go = /* @__PURE__ */ qs(Jo);
function hi(e) {
  return !!e || e === "";
}
function Yo(e, t) {
  if (e.length !== t.length) return !1;
  let n = !0;
  for (let s = 0; n && s < e.length; s++)
    n = Ut(e[s], t[s]);
  return n;
}
function Ut(e, t) {
  if (e === t) return !0;
  let n = pr(e), s = pr(t);
  if (n || s)
    return n && s ? e.getTime() === t.getTime() : !1;
  if (n = st(e), s = st(t), n || s)
    return e === t;
  if (n = G(e), s = G(t), n || s)
    return n && s ? Yo(e, t) : !1;
  if (n = fe(e), s = fe(t), n || s) {
    if (!n || !s)
      return !1;
    const r = Object.keys(e).length, i = Object.keys(t).length;
    if (r !== i)
      return !1;
    for (const o in e) {
      const a = e.hasOwnProperty(o), l = t.hasOwnProperty(o);
      if (a && !l || !a && l || !Ut(e[o], t[o]))
        return !1;
    }
  }
  return String(e) === String(t);
}
function pi(e, t) {
  return e.findIndex((n) => Ut(n, t));
}
const gi = (e) => !!(e && e.__v_isRef === !0), X = (e) => _e(e) ? e : e == null ? "" : G(e) || fe(e) && (e.toString === fi || !ee(e.toString)) ? gi(e) ? X(e.value) : JSON.stringify(e, mi, 2) : String(e), mi = (e, t) => gi(t) ? mi(e, t.value) : Gt(t) ? {
  [`Map(${t.size})`]: [...t.entries()].reduce(
    (n, [s, r], i) => (n[cs(s, i) + " =>"] = r, n),
    {}
  )
} : Jn(t) ? {
  [`Set(${t.size})`]: [...t.values()].map((n) => cs(n))
} : st(t) ? cs(t) : fe(t) && !G(t) && !Gn(t) ? String(t) : t, cs = (e, t = "") => {
  var n;
  return (
    // Symbol.description in es2019+ so we need to cast here to pass
    // the lib: es2016 check
    st(e) ? `Symbol(${(n = e.description) != null ? n : t})` : e
  );
};
/**
* @vue/reactivity v3.5.31
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
let Ue;
class Xo {
  // TODO isolatedDeclarations "__v_skip"
  constructor(t = !1) {
    this.detached = t, this._active = !0, this._on = 0, this.effects = [], this.cleanups = [], this._isPaused = !1, this.__v_skip = !0, this.parent = Ue, !t && Ue && (this.index = (Ue.scopes || (Ue.scopes = [])).push(
      this
    ) - 1);
  }
  get active() {
    return this._active;
  }
  pause() {
    if (this._active) {
      this._isPaused = !0;
      let t, n;
      if (this.scopes)
        for (t = 0, n = this.scopes.length; t < n; t++)
          this.scopes[t].pause();
      for (t = 0, n = this.effects.length; t < n; t++)
        this.effects[t].pause();
    }
  }
  /**
   * Resumes the effect scope, including all child scopes and effects.
   */
  resume() {
    if (this._active && this._isPaused) {
      this._isPaused = !1;
      let t, n;
      if (this.scopes)
        for (t = 0, n = this.scopes.length; t < n; t++)
          this.scopes[t].resume();
      for (t = 0, n = this.effects.length; t < n; t++)
        this.effects[t].resume();
    }
  }
  run(t) {
    if (this._active) {
      const n = Ue;
      try {
        return Ue = this, t();
      } finally {
        Ue = n;
      }
    }
  }
  /**
   * This should only be called on non-detached scopes
   * @internal
   */
  on() {
    ++this._on === 1 && (this.prevScope = Ue, Ue = this);
  }
  /**
   * This should only be called on non-detached scopes
   * @internal
   */
  off() {
    this._on > 0 && --this._on === 0 && (Ue = this.prevScope, this.prevScope = void 0);
  }
  stop(t) {
    if (this._active) {
      this._active = !1;
      let n, s;
      for (n = 0, s = this.effects.length; n < s; n++)
        this.effects[n].stop();
      for (this.effects.length = 0, n = 0, s = this.cleanups.length; n < s; n++)
        this.cleanups[n]();
      if (this.cleanups.length = 0, this.scopes) {
        for (n = 0, s = this.scopes.length; n < s; n++)
          this.scopes[n].stop(!0);
        this.scopes.length = 0;
      }
      if (!this.detached && this.parent && !t) {
        const r = this.parent.scopes.pop();
        r && r !== this && (this.parent.scopes[this.index] = r, r.index = this.index);
      }
      this.parent = void 0;
    }
  }
}
function Qo() {
  return Ue;
}
let me;
const us = /* @__PURE__ */ new WeakSet();
class yi {
  constructor(t) {
    this.fn = t, this.deps = void 0, this.depsTail = void 0, this.flags = 5, this.next = void 0, this.cleanup = void 0, this.scheduler = void 0, Ue && Ue.active && Ue.effects.push(this);
  }
  pause() {
    this.flags |= 64;
  }
  resume() {
    this.flags & 64 && (this.flags &= -65, us.has(this) && (us.delete(this), this.trigger()));
  }
  /**
   * @internal
   */
  notify() {
    this.flags & 2 && !(this.flags & 32) || this.flags & 8 || _i(this);
  }
  run() {
    if (!(this.flags & 1))
      return this.fn();
    this.flags |= 2, yr(this), vi(this);
    const t = me, n = nt;
    me = this, nt = !0;
    try {
      return this.fn();
    } finally {
      wi(this), me = t, nt = n, this.flags &= -3;
    }
  }
  stop() {
    if (this.flags & 1) {
      for (let t = this.deps; t; t = t.nextDep)
        Hs(t);
      this.deps = this.depsTail = void 0, yr(this), this.onStop && this.onStop(), this.flags &= -2;
    }
  }
  trigger() {
    this.flags & 64 ? us.add(this) : this.scheduler ? this.scheduler() : this.runIfDirty();
  }
  /**
   * @internal
   */
  runIfDirty() {
    Is(this) && this.run();
  }
  get dirty() {
    return Is(this);
  }
}
let bi = 0, cn, un;
function _i(e, t = !1) {
  if (e.flags |= 8, t) {
    e.next = un, un = e;
    return;
  }
  e.next = cn, cn = e;
}
function Ks() {
  bi++;
}
function Us() {
  if (--bi > 0)
    return;
  if (un) {
    let t = un;
    for (un = void 0; t; ) {
      const n = t.next;
      t.next = void 0, t.flags &= -9, t = n;
    }
  }
  let e;
  for (; cn; ) {
    let t = cn;
    for (cn = void 0; t; ) {
      const n = t.next;
      if (t.next = void 0, t.flags &= -9, t.flags & 1)
        try {
          t.trigger();
        } catch (s) {
          e || (e = s);
        }
      t = n;
    }
  }
  if (e) throw e;
}
function vi(e) {
  for (let t = e.deps; t; t = t.nextDep)
    t.version = -1, t.prevActiveLink = t.dep.activeLink, t.dep.activeLink = t;
}
function wi(e) {
  let t, n = e.depsTail, s = n;
  for (; s; ) {
    const r = s.prevDep;
    s.version === -1 ? (s === n && (n = r), Hs(s), Zo(s)) : t = s, s.dep.activeLink = s.prevActiveLink, s.prevActiveLink = void 0, s = r;
  }
  e.deps = t, e.depsTail = n;
}
function Is(e) {
  for (let t = e.deps; t; t = t.nextDep)
    if (t.dep.version !== t.version || t.dep.computed && (Si(t.dep.computed) || t.dep.version !== t.version))
      return !0;
  return !!e._dirty;
}
function Si(e) {
  if (e.flags & 4 && !(e.flags & 16) || (e.flags &= -17, e.globalVersion === gn) || (e.globalVersion = gn, !e.isSSR && e.flags & 128 && (!e.deps && !e._dirty || !Is(e))))
    return;
  e.flags |= 2;
  const t = e.dep, n = me, s = nt;
  me = e, nt = !0;
  try {
    vi(e);
    const r = e.fn(e._value);
    (t.version === 0 || dt(r, e._value)) && (e.flags |= 128, e._value = r, t.version++);
  } catch (r) {
    throw t.version++, r;
  } finally {
    me = n, nt = s, wi(e), e.flags &= -3;
  }
}
function Hs(e, t = !1) {
  const { dep: n, prevSub: s, nextSub: r } = e;
  if (s && (s.nextSub = r, e.prevSub = void 0), r && (r.prevSub = s, e.nextSub = void 0), n.subs === e && (n.subs = s, !s && n.computed)) {
    n.computed.flags &= -5;
    for (let i = n.computed.deps; i; i = i.nextDep)
      Hs(i, !0);
  }
  !t && !--n.sc && n.map && n.map.delete(n.key);
}
function Zo(e) {
  const { prevDep: t, nextDep: n } = e;
  t && (t.nextDep = n, e.prevDep = void 0), n && (n.prevDep = t, e.nextDep = void 0);
}
let nt = !0;
const Ii = [];
function xt() {
  Ii.push(nt), nt = !1;
}
function Et() {
  const e = Ii.pop();
  nt = e === void 0 ? !0 : e;
}
function yr(e) {
  const { cleanup: t } = e;
  if (e.cleanup = void 0, t) {
    const n = me;
    me = void 0;
    try {
      t();
    } finally {
      me = n;
    }
  }
}
let gn = 0;
class ea {
  constructor(t, n) {
    this.sub = t, this.dep = n, this.version = n.version, this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0;
  }
}
class Vs {
  // TODO isolatedDeclarations "__v_skip"
  constructor(t) {
    this.computed = t, this.version = 0, this.activeLink = void 0, this.subs = void 0, this.map = void 0, this.key = void 0, this.sc = 0, this.__v_skip = !0;
  }
  track(t) {
    if (!me || !nt || me === this.computed)
      return;
    let n = this.activeLink;
    if (n === void 0 || n.sub !== me)
      n = this.activeLink = new ea(me, this), me.deps ? (n.prevDep = me.depsTail, me.depsTail.nextDep = n, me.depsTail = n) : me.deps = me.depsTail = n, Ai(n);
    else if (n.version === -1 && (n.version = this.version, n.nextDep)) {
      const s = n.nextDep;
      s.prevDep = n.prevDep, n.prevDep && (n.prevDep.nextDep = s), n.prevDep = me.depsTail, n.nextDep = void 0, me.depsTail.nextDep = n, me.depsTail = n, me.deps === n && (me.deps = s);
    }
    return n;
  }
  trigger(t) {
    this.version++, gn++, this.notify(t);
  }
  notify(t) {
    Ks();
    try {
      for (let n = this.subs; n; n = n.prevSub)
        n.sub.notify() && n.sub.dep.notify();
    } finally {
      Us();
    }
  }
}
function Ai(e) {
  if (e.dep.sc++, e.sub.flags & 4) {
    const t = e.dep.computed;
    if (t && !e.dep.subs) {
      t.flags |= 20;
      for (let s = t.deps; s; s = s.nextDep)
        Ai(s);
    }
    const n = e.dep.subs;
    n !== e && (e.prevSub = n, n && (n.nextSub = e)), e.dep.subs = e;
  }
}
const As = /* @__PURE__ */ new WeakMap(), Ft = /* @__PURE__ */ Symbol(
  ""
), xs = /* @__PURE__ */ Symbol(
  ""
), mn = /* @__PURE__ */ Symbol(
  ""
);
function $e(e, t, n) {
  if (nt && me) {
    let s = As.get(e);
    s || As.set(e, s = /* @__PURE__ */ new Map());
    let r = s.get(n);
    r || (s.set(n, r = new Vs()), r.map = s, r.key = n), r.track();
  }
}
function wt(e, t, n, s, r, i) {
  const o = As.get(e);
  if (!o) {
    gn++;
    return;
  }
  const a = (l) => {
    l && l.trigger();
  };
  if (Ks(), t === "clear")
    o.forEach(a);
  else {
    const l = G(e), d = l && Fs(n);
    if (l && n === "length") {
      const u = Number(s);
      o.forEach((h, v) => {
        (v === "length" || v === mn || !st(v) && v >= u) && a(h);
      });
    } else
      switch ((n !== void 0 || o.has(void 0)) && a(o.get(n)), d && a(o.get(mn)), t) {
        case "add":
          l ? d && a(o.get("length")) : (a(o.get(Ft)), Gt(e) && a(o.get(xs)));
          break;
        case "delete":
          l || (a(o.get(Ft)), Gt(e) && a(o.get(xs)));
          break;
        case "set":
          Gt(e) && a(o.get(Ft));
          break;
      }
  }
  Us();
}
function Vt(e) {
  const t = /* @__PURE__ */ ue(e);
  return t === e ? t : ($e(t, "iterate", mn), /* @__PURE__ */ et(e) ? t : t.map(rt));
}
function Zn(e) {
  return $e(e = /* @__PURE__ */ ue(e), "iterate", mn), e;
}
function ut(e, t) {
  return /* @__PURE__ */ Ct(e) ? Zt(/* @__PURE__ */ jt(e) ? rt(t) : t) : rt(t);
}
const ta = {
  __proto__: null,
  [Symbol.iterator]() {
    return fs(this, Symbol.iterator, (e) => ut(this, e));
  },
  concat(...e) {
    return Vt(this).concat(
      ...e.map((t) => G(t) ? Vt(t) : t)
    );
  },
  entries() {
    return fs(this, "entries", (e) => (e[1] = ut(this, e[1]), e));
  },
  every(e, t) {
    return yt(this, "every", e, t, void 0, arguments);
  },
  filter(e, t) {
    return yt(
      this,
      "filter",
      e,
      t,
      (n) => n.map((s) => ut(this, s)),
      arguments
    );
  },
  find(e, t) {
    return yt(
      this,
      "find",
      e,
      t,
      (n) => ut(this, n),
      arguments
    );
  },
  findIndex(e, t) {
    return yt(this, "findIndex", e, t, void 0, arguments);
  },
  findLast(e, t) {
    return yt(
      this,
      "findLast",
      e,
      t,
      (n) => ut(this, n),
      arguments
    );
  },
  findLastIndex(e, t) {
    return yt(this, "findLastIndex", e, t, void 0, arguments);
  },
  // flat, flatMap could benefit from ARRAY_ITERATE but are not straight-forward to implement
  forEach(e, t) {
    return yt(this, "forEach", e, t, void 0, arguments);
  },
  includes(...e) {
    return ds(this, "includes", e);
  },
  indexOf(...e) {
    return ds(this, "indexOf", e);
  },
  join(e) {
    return Vt(this).join(e);
  },
  // keys() iterator only reads `length`, no optimization required
  lastIndexOf(...e) {
    return ds(this, "lastIndexOf", e);
  },
  map(e, t) {
    return yt(this, "map", e, t, void 0, arguments);
  },
  pop() {
    return sn(this, "pop");
  },
  push(...e) {
    return sn(this, "push", e);
  },
  reduce(e, ...t) {
    return br(this, "reduce", e, t);
  },
  reduceRight(e, ...t) {
    return br(this, "reduceRight", e, t);
  },
  shift() {
    return sn(this, "shift");
  },
  // slice could use ARRAY_ITERATE but also seems to beg for range tracking
  some(e, t) {
    return yt(this, "some", e, t, void 0, arguments);
  },
  splice(...e) {
    return sn(this, "splice", e);
  },
  toReversed() {
    return Vt(this).toReversed();
  },
  toSorted(e) {
    return Vt(this).toSorted(e);
  },
  toSpliced(...e) {
    return Vt(this).toSpliced(...e);
  },
  unshift(...e) {
    return sn(this, "unshift", e);
  },
  values() {
    return fs(this, "values", (e) => ut(this, e));
  }
};
function fs(e, t, n) {
  const s = Zn(e), r = s[t]();
  return s !== e && !/* @__PURE__ */ et(e) && (r._next = r.next, r.next = () => {
    const i = r._next();
    return i.done || (i.value = n(i.value)), i;
  }), r;
}
const na = Array.prototype;
function yt(e, t, n, s, r, i) {
  const o = Zn(e), a = o !== e && !/* @__PURE__ */ et(e), l = o[t];
  if (l !== na[t]) {
    const h = l.apply(e, i);
    return a ? rt(h) : h;
  }
  let d = n;
  o !== e && (a ? d = function(h, v) {
    return n.call(this, ut(e, h), v, e);
  } : n.length > 2 && (d = function(h, v) {
    return n.call(this, h, v, e);
  }));
  const u = l.call(o, d, s);
  return a && r ? r(u) : u;
}
function br(e, t, n, s) {
  const r = Zn(e), i = r !== e && !/* @__PURE__ */ et(e);
  let o = n, a = !1;
  r !== e && (i ? (a = s.length === 0, o = function(d, u, h) {
    return a && (a = !1, d = ut(e, d)), n.call(this, d, ut(e, u), h, e);
  }) : n.length > 3 && (o = function(d, u, h) {
    return n.call(this, d, u, h, e);
  }));
  const l = r[t](o, ...s);
  return a ? ut(e, l) : l;
}
function ds(e, t, n) {
  const s = /* @__PURE__ */ ue(e);
  $e(s, "iterate", mn);
  const r = s[t](...n);
  return (r === -1 || r === !1) && /* @__PURE__ */ zs(n[0]) ? (n[0] = /* @__PURE__ */ ue(n[0]), s[t](...n)) : r;
}
function sn(e, t, n = []) {
  xt(), Ks();
  const s = (/* @__PURE__ */ ue(e))[t].apply(e, n);
  return Us(), Et(), s;
}
const sa = /* @__PURE__ */ qs("__proto__,__v_isRef,__isVue"), xi = new Set(
  /* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((e) => e !== "arguments" && e !== "caller").map((e) => Symbol[e]).filter(st)
);
function ra(e) {
  st(e) || (e = String(e));
  const t = /* @__PURE__ */ ue(this);
  return $e(t, "has", e), t.hasOwnProperty(e);
}
class Ei {
  constructor(t = !1, n = !1) {
    this._isReadonly = t, this._isShallow = n;
  }
  get(t, n, s) {
    if (n === "__v_skip") return t.__v_skip;
    const r = this._isReadonly, i = this._isShallow;
    if (n === "__v_isReactive")
      return !r;
    if (n === "__v_isReadonly")
      return r;
    if (n === "__v_isShallow")
      return i;
    if (n === "__v_raw")
      return s === (r ? i ? pa : Ti : i ? Pi : ki).get(t) || // receiver is not the reactive proxy, but has the same prototype
      // this means the receiver is a user proxy of the reactive proxy
      Object.getPrototypeOf(t) === Object.getPrototypeOf(s) ? t : void 0;
    const o = G(t);
    if (!r) {
      let l;
      if (o && (l = ta[n]))
        return l;
      if (n === "hasOwnProperty")
        return ra;
    }
    const a = Reflect.get(
      t,
      n,
      // if this is a proxy wrapping a ref, return methods using the raw ref
      // as receiver so that we don't have to call `toRaw` on the ref in all
      // its class methods
      /* @__PURE__ */ Ne(t) ? t : s
    );
    if ((st(n) ? xi.has(n) : sa(n)) || (r || $e(t, "get", n), i))
      return a;
    if (/* @__PURE__ */ Ne(a)) {
      const l = o && Fs(n) ? a : a.value;
      return r && fe(l) ? /* @__PURE__ */ Cs(l) : l;
    }
    return fe(a) ? r ? /* @__PURE__ */ Cs(a) : /* @__PURE__ */ es(a) : a;
  }
}
class Ci extends Ei {
  constructor(t = !1) {
    super(!1, t);
  }
  set(t, n, s, r) {
    let i = t[n];
    const o = G(t) && Fs(n);
    if (!this._isShallow) {
      const d = /* @__PURE__ */ Ct(i);
      if (!/* @__PURE__ */ et(s) && !/* @__PURE__ */ Ct(s) && (i = /* @__PURE__ */ ue(i), s = /* @__PURE__ */ ue(s)), !o && /* @__PURE__ */ Ne(i) && !/* @__PURE__ */ Ne(s))
        return d || (i.value = s), !0;
    }
    const a = o ? Number(n) < t.length : ce(t, n), l = Reflect.set(
      t,
      n,
      s,
      /* @__PURE__ */ Ne(t) ? t : r
    );
    return t === /* @__PURE__ */ ue(r) && (a ? dt(s, i) && wt(t, "set", n, s) : wt(t, "add", n, s)), l;
  }
  deleteProperty(t, n) {
    const s = ce(t, n);
    t[n];
    const r = Reflect.deleteProperty(t, n);
    return r && s && wt(t, "delete", n, void 0), r;
  }
  has(t, n) {
    const s = Reflect.has(t, n);
    return (!st(n) || !xi.has(n)) && $e(t, "has", n), s;
  }
  ownKeys(t) {
    return $e(
      t,
      "iterate",
      G(t) ? "length" : Ft
    ), Reflect.ownKeys(t);
  }
}
class ia extends Ei {
  constructor(t = !1) {
    super(!0, t);
  }
  set(t, n) {
    return !0;
  }
  deleteProperty(t, n) {
    return !0;
  }
}
const oa = /* @__PURE__ */ new Ci(), aa = /* @__PURE__ */ new ia(), la = /* @__PURE__ */ new Ci(!0);
const Es = (e) => e, kn = (e) => Reflect.getPrototypeOf(e);
function ca(e, t, n) {
  return function(...s) {
    const r = this.__v_raw, i = /* @__PURE__ */ ue(r), o = Gt(i), a = e === "entries" || e === Symbol.iterator && o, l = e === "keys" && o, d = r[e](...s), u = n ? Es : t ? Zt : rt;
    return !t && $e(
      i,
      "iterate",
      l ? xs : Ft
    ), ve(
      // inheriting all iterator properties
      Object.create(d),
      {
        // iterator protocol
        next() {
          const { value: h, done: v } = d.next();
          return v ? { value: h, done: v } : {
            value: a ? [u(h[0]), u(h[1])] : u(h),
            done: v
          };
        }
      }
    );
  };
}
function Pn(e) {
  return function(...t) {
    return e === "delete" ? !1 : e === "clear" ? void 0 : this;
  };
}
function ua(e, t) {
  const n = {
    get(r) {
      const i = this.__v_raw, o = /* @__PURE__ */ ue(i), a = /* @__PURE__ */ ue(r);
      e || (dt(r, a) && $e(o, "get", r), $e(o, "get", a));
      const { has: l } = kn(o), d = t ? Es : e ? Zt : rt;
      if (l.call(o, r))
        return d(i.get(r));
      if (l.call(o, a))
        return d(i.get(a));
      i !== o && i.get(r);
    },
    get size() {
      const r = this.__v_raw;
      return !e && $e(/* @__PURE__ */ ue(r), "iterate", Ft), r.size;
    },
    has(r) {
      const i = this.__v_raw, o = /* @__PURE__ */ ue(i), a = /* @__PURE__ */ ue(r);
      return e || (dt(r, a) && $e(o, "has", r), $e(o, "has", a)), r === a ? i.has(r) : i.has(r) || i.has(a);
    },
    forEach(r, i) {
      const o = this, a = o.__v_raw, l = /* @__PURE__ */ ue(a), d = t ? Es : e ? Zt : rt;
      return !e && $e(l, "iterate", Ft), a.forEach((u, h) => r.call(i, d(u), d(h), o));
    }
  };
  return ve(
    n,
    e ? {
      add: Pn("add"),
      set: Pn("set"),
      delete: Pn("delete"),
      clear: Pn("clear")
    } : {
      add(r) {
        const i = /* @__PURE__ */ ue(this), o = kn(i), a = /* @__PURE__ */ ue(r), l = !t && !/* @__PURE__ */ et(r) && !/* @__PURE__ */ Ct(r) ? a : r;
        return o.has.call(i, l) || dt(r, l) && o.has.call(i, r) || dt(a, l) && o.has.call(i, a) || (i.add(l), wt(i, "add", l, l)), this;
      },
      set(r, i) {
        !t && !/* @__PURE__ */ et(i) && !/* @__PURE__ */ Ct(i) && (i = /* @__PURE__ */ ue(i));
        const o = /* @__PURE__ */ ue(this), { has: a, get: l } = kn(o);
        let d = a.call(o, r);
        d || (r = /* @__PURE__ */ ue(r), d = a.call(o, r));
        const u = l.call(o, r);
        return o.set(r, i), d ? dt(i, u) && wt(o, "set", r, i) : wt(o, "add", r, i), this;
      },
      delete(r) {
        const i = /* @__PURE__ */ ue(this), { has: o, get: a } = kn(i);
        let l = o.call(i, r);
        l || (r = /* @__PURE__ */ ue(r), l = o.call(i, r)), a && a.call(i, r);
        const d = i.delete(r);
        return l && wt(i, "delete", r, void 0), d;
      },
      clear() {
        const r = /* @__PURE__ */ ue(this), i = r.size !== 0, o = r.clear();
        return i && wt(
          r,
          "clear",
          void 0,
          void 0
        ), o;
      }
    }
  ), [
    "keys",
    "values",
    "entries",
    Symbol.iterator
  ].forEach((r) => {
    n[r] = ca(r, e, t);
  }), n;
}
function Bs(e, t) {
  const n = ua(e, t);
  return (s, r, i) => r === "__v_isReactive" ? !e : r === "__v_isReadonly" ? e : r === "__v_raw" ? s : Reflect.get(
    ce(n, r) && r in s ? n : s,
    r,
    i
  );
}
const fa = {
  get: /* @__PURE__ */ Bs(!1, !1)
}, da = {
  get: /* @__PURE__ */ Bs(!1, !0)
}, ha = {
  get: /* @__PURE__ */ Bs(!0, !1)
};
const ki = /* @__PURE__ */ new WeakMap(), Pi = /* @__PURE__ */ new WeakMap(), Ti = /* @__PURE__ */ new WeakMap(), pa = /* @__PURE__ */ new WeakMap();
function ga(e) {
  switch (e) {
    case "Object":
    case "Array":
      return 1;
    case "Map":
    case "Set":
    case "WeakMap":
    case "WeakSet":
      return 2;
    default:
      return 0;
  }
}
function ma(e) {
  return e.__v_skip || !Object.isExtensible(e) ? 0 : ga(jo(e));
}
// @__NO_SIDE_EFFECTS__
function es(e) {
  return /* @__PURE__ */ Ct(e) ? e : Ws(
    e,
    !1,
    oa,
    fa,
    ki
  );
}
// @__NO_SIDE_EFFECTS__
function ya(e) {
  return Ws(
    e,
    !1,
    la,
    da,
    Pi
  );
}
// @__NO_SIDE_EFFECTS__
function Cs(e) {
  return Ws(
    e,
    !0,
    aa,
    ha,
    Ti
  );
}
function Ws(e, t, n, s, r) {
  if (!fe(e) || e.__v_raw && !(t && e.__v_isReactive))
    return e;
  const i = ma(e);
  if (i === 0)
    return e;
  const o = r.get(e);
  if (o)
    return o;
  const a = new Proxy(
    e,
    i === 2 ? s : n
  );
  return r.set(e, a), a;
}
// @__NO_SIDE_EFFECTS__
function jt(e) {
  return /* @__PURE__ */ Ct(e) ? /* @__PURE__ */ jt(e.__v_raw) : !!(e && e.__v_isReactive);
}
// @__NO_SIDE_EFFECTS__
function Ct(e) {
  return !!(e && e.__v_isReadonly);
}
// @__NO_SIDE_EFFECTS__
function et(e) {
  return !!(e && e.__v_isShallow);
}
// @__NO_SIDE_EFFECTS__
function zs(e) {
  return e ? !!e.__v_raw : !1;
}
// @__NO_SIDE_EFFECTS__
function ue(e) {
  const t = e && e.__v_raw;
  return t ? /* @__PURE__ */ ue(t) : e;
}
function ba(e) {
  return !ce(e, "__v_skip") && Object.isExtensible(e) && di(e, "__v_skip", !0), e;
}
const rt = (e) => fe(e) ? /* @__PURE__ */ es(e) : e, Zt = (e) => fe(e) ? /* @__PURE__ */ Cs(e) : e;
// @__NO_SIDE_EFFECTS__
function Ne(e) {
  return e ? e.__v_isRef === !0 : !1;
}
// @__NO_SIDE_EFFECTS__
function Se(e) {
  return _a(e, !1);
}
function _a(e, t) {
  return /* @__PURE__ */ Ne(e) ? e : new va(e, t);
}
class va {
  constructor(t, n) {
    this.dep = new Vs(), this.__v_isRef = !0, this.__v_isShallow = !1, this._rawValue = n ? t : /* @__PURE__ */ ue(t), this._value = n ? t : rt(t), this.__v_isShallow = n;
  }
  get value() {
    return this.dep.track(), this._value;
  }
  set value(t) {
    const n = this._rawValue, s = this.__v_isShallow || /* @__PURE__ */ et(t) || /* @__PURE__ */ Ct(t);
    t = s ? t : /* @__PURE__ */ ue(t), dt(t, n) && (this._rawValue = t, this._value = s ? t : rt(t), this.dep.trigger());
  }
}
function Js(e) {
  return /* @__PURE__ */ Ne(e) ? e.value : e;
}
const wa = {
  get: (e, t, n) => t === "__v_raw" ? e : Js(Reflect.get(e, t, n)),
  set: (e, t, n, s) => {
    const r = e[t];
    return /* @__PURE__ */ Ne(r) && !/* @__PURE__ */ Ne(n) ? (r.value = n, !0) : Reflect.set(e, t, n, s);
  }
};
function Ri(e) {
  return /* @__PURE__ */ jt(e) ? e : new Proxy(e, wa);
}
class Sa {
  constructor(t, n, s) {
    this.fn = t, this.setter = n, this._value = void 0, this.dep = new Vs(this), this.__v_isRef = !0, this.deps = void 0, this.depsTail = void 0, this.flags = 16, this.globalVersion = gn - 1, this.next = void 0, this.effect = this, this.__v_isReadonly = !n, this.isSSR = s;
  }
  /**
   * @internal
   */
  notify() {
    if (this.flags |= 16, !(this.flags & 8) && // avoid infinite self recursion
    me !== this)
      return _i(this, !0), !0;
  }
  get value() {
    const t = this.dep.track();
    return Si(this), t && (t.version = this.dep.version), this._value;
  }
  set value(t) {
    this.setter && this.setter(t);
  }
}
// @__NO_SIDE_EFFECTS__
function Ia(e, t, n = !1) {
  let s, r;
  return ee(e) ? s = e : (s = e.get, r = e.set), new Sa(s, r, n);
}
const Tn = {}, Ln = /* @__PURE__ */ new WeakMap();
let Dt;
function Aa(e, t = !1, n = Dt) {
  if (n) {
    let s = Ln.get(n);
    s || Ln.set(n, s = []), s.push(e);
  }
}
function xa(e, t, n = pe) {
  const { immediate: s, deep: r, once: i, scheduler: o, augmentJob: a, call: l } = n, d = (T) => r ? T : /* @__PURE__ */ et(T) || r === !1 || r === 0 ? St(T, 1) : St(T);
  let u, h, v, M, I = !1, x = !1;
  if (/* @__PURE__ */ Ne(e) ? (h = () => e.value, I = /* @__PURE__ */ et(e)) : /* @__PURE__ */ jt(e) ? (h = () => d(e), I = !0) : G(e) ? (x = !0, I = e.some((T) => /* @__PURE__ */ jt(T) || /* @__PURE__ */ et(T)), h = () => e.map((T) => {
    if (/* @__PURE__ */ Ne(T))
      return T.value;
    if (/* @__PURE__ */ jt(T))
      return d(T);
    if (ee(T))
      return l ? l(T, 2) : T();
  })) : ee(e) ? t ? h = l ? () => l(e, 2) : e : h = () => {
    if (v) {
      xt();
      try {
        v();
      } finally {
        Et();
      }
    }
    const T = Dt;
    Dt = u;
    try {
      return l ? l(e, 3, [M]) : e(M);
    } finally {
      Dt = T;
    }
  } : h = ht, t && r) {
    const T = h, U = r === !0 ? 1 / 0 : r;
    h = () => St(T(), U);
  }
  const N = Qo(), K = () => {
    u.stop(), N && N.active && Ds(N.effects, u);
  };
  if (i && t) {
    const T = t;
    t = (...U) => {
      T(...U), K();
    };
  }
  let b = x ? new Array(e.length).fill(Tn) : Tn;
  const D = (T) => {
    if (!(!(u.flags & 1) || !u.dirty && !T))
      if (t) {
        const U = u.run();
        if (r || I || (x ? U.some((S, O) => dt(S, b[O])) : dt(U, b))) {
          v && v();
          const S = Dt;
          Dt = u;
          try {
            const O = [
              U,
              // pass undefined as the old value when it's changed for the first time
              b === Tn ? void 0 : x && b[0] === Tn ? [] : b,
              M
            ];
            b = U, l ? l(t, 3, O) : (
              // @ts-expect-error
              t(...O)
            );
          } finally {
            Dt = S;
          }
        }
      } else
        u.run();
  };
  return a && a(D), u = new yi(h), u.scheduler = o ? () => o(D, !1) : D, M = (T) => Aa(T, !1, u), v = u.onStop = () => {
    const T = Ln.get(u);
    if (T) {
      if (l)
        l(T, 4);
      else
        for (const U of T) U();
      Ln.delete(u);
    }
  }, t ? s ? D(!0) : b = u.run() : o ? o(D.bind(null, !0), !0) : u.run(), K.pause = u.pause.bind(u), K.resume = u.resume.bind(u), K.stop = K, K;
}
function St(e, t = 1 / 0, n) {
  if (t <= 0 || !fe(e) || e.__v_skip || (n = n || /* @__PURE__ */ new Map(), (n.get(e) || 0) >= t))
    return e;
  if (n.set(e, t), t--, /* @__PURE__ */ Ne(e))
    St(e.value, t, n);
  else if (G(e))
    for (let s = 0; s < e.length; s++)
      St(e[s], t, n);
  else if (Jn(e) || Gt(e))
    e.forEach((s) => {
      St(s, t, n);
    });
  else if (Gn(e)) {
    for (const s in e)
      St(e[s], t, n);
    for (const s of Object.getOwnPropertySymbols(e))
      Object.prototype.propertyIsEnumerable.call(e, s) && St(e[s], t, n);
  }
  return e;
}
/**
* @vue/runtime-core v3.5.31
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
function An(e, t, n, s) {
  try {
    return s ? e(...s) : e();
  } catch (r) {
    ts(r, t, n);
  }
}
function pt(e, t, n, s) {
  if (ee(e)) {
    const r = An(e, t, n, s);
    return r && ui(r) && r.catch((i) => {
      ts(i, t, n);
    }), r;
  }
  if (G(e)) {
    const r = [];
    for (let i = 0; i < e.length; i++)
      r.push(pt(e[i], t, n, s));
    return r;
  }
}
function ts(e, t, n, s = !0) {
  const r = t ? t.vnode : null, { errorHandler: i, throwUnhandledErrorInProduction: o } = t && t.appContext.config || pe;
  if (t) {
    let a = t.parent;
    const l = t.proxy, d = `https://vuejs.org/error-reference/#runtime-${n}`;
    for (; a; ) {
      const u = a.ec;
      if (u) {
        for (let h = 0; h < u.length; h++)
          if (u[h](e, l, d) === !1)
            return;
      }
      a = a.parent;
    }
    if (i) {
      xt(), An(i, null, 10, [
        e,
        l,
        d
      ]), Et();
      return;
    }
  }
  Ea(e, n, r, s, o);
}
function Ea(e, t, n, s = !0, r = !1) {
  if (r)
    throw e;
  console.error(e);
}
const qe = [];
let ct = -1;
const Yt = [];
let $t = null, Wt = 0;
const $i = /* @__PURE__ */ Promise.resolve();
let qn = null;
function Gs(e) {
  const t = qn || $i;
  return e ? t.then(this ? e.bind(this) : e) : t;
}
function Ca(e) {
  let t = ct + 1, n = qe.length;
  for (; t < n; ) {
    const s = t + n >>> 1, r = qe[s], i = yn(r);
    i < e || i === e && r.flags & 2 ? t = s + 1 : n = s;
  }
  return t;
}
function Ys(e) {
  if (!(e.flags & 1)) {
    const t = yn(e), n = qe[qe.length - 1];
    !n || // fast path when the job id is larger than the tail
    !(e.flags & 2) && t >= yn(n) ? qe.push(e) : qe.splice(Ca(t), 0, e), e.flags |= 1, Mi();
  }
}
function Mi() {
  qn || (qn = $i.then(Ni));
}
function ka(e) {
  G(e) ? Yt.push(...e) : $t && e.id === -1 ? $t.splice(Wt + 1, 0, e) : e.flags & 1 || (Yt.push(e), e.flags |= 1), Mi();
}
function _r(e, t, n = ct + 1) {
  for (; n < qe.length; n++) {
    const s = qe[n];
    if (s && s.flags & 2) {
      if (e && s.id !== e.uid)
        continue;
      qe.splice(n, 1), n--, s.flags & 4 && (s.flags &= -2), s(), s.flags & 4 || (s.flags &= -2);
    }
  }
}
function Oi(e) {
  if (Yt.length) {
    const t = [...new Set(Yt)].sort(
      (n, s) => yn(n) - yn(s)
    );
    if (Yt.length = 0, $t) {
      $t.push(...t);
      return;
    }
    for ($t = t, Wt = 0; Wt < $t.length; Wt++) {
      const n = $t[Wt];
      n.flags & 4 && (n.flags &= -2), n.flags & 8 || n(), n.flags &= -2;
    }
    $t = null, Wt = 0;
  }
}
const yn = (e) => e.id == null ? e.flags & 2 ? -1 : 1 / 0 : e.id;
function Ni(e) {
  try {
    for (ct = 0; ct < qe.length; ct++) {
      const t = qe[ct];
      t && !(t.flags & 8) && (t.flags & 4 && (t.flags &= -2), An(
        t,
        t.i,
        t.i ? 15 : 14
      ), t.flags & 4 || (t.flags &= -2));
    }
  } finally {
    for (; ct < qe.length; ct++) {
      const t = qe[ct];
      t && (t.flags &= -2);
    }
    ct = -1, qe.length = 0, Oi(), qn = null, (qe.length || Yt.length) && Ni();
  }
}
let ke = null, Li = null;
function Dn(e) {
  const t = ke;
  return ke = e, Li = e && e.type.__scopeId || null, t;
}
function Fn(e, t = ke, n) {
  if (!t || e._n)
    return e;
  const s = (...r) => {
    s._d && Un(-1);
    const i = Dn(t);
    let o;
    try {
      o = e(...r);
    } finally {
      Dn(i), s._d && Un(1);
    }
    return o;
  };
  return s._n = !0, s._c = !0, s._d = !0, s;
}
function zt(e, t) {
  if (ke === null)
    return e;
  const n = os(ke), s = e.dirs || (e.dirs = []);
  for (let r = 0; r < t.length; r++) {
    let [i, o, a, l = pe] = t[r];
    i && (ee(i) && (i = {
      mounted: i,
      updated: i
    }), i.deep && St(o), s.push({
      dir: i,
      instance: n,
      value: o,
      oldValue: void 0,
      arg: a,
      modifiers: l
    }));
  }
  return e;
}
function Lt(e, t, n, s) {
  const r = e.dirs, i = t && t.dirs;
  for (let o = 0; o < r.length; o++) {
    const a = r[o];
    i && (a.oldValue = i[o].value);
    let l = a.dir[s];
    l && (xt(), pt(l, n, 8, [
      e.el,
      a,
      e,
      t
    ]), Et());
  }
}
function Pa(e, t) {
  if (Me) {
    let n = Me.provides;
    const s = Me.parent && Me.parent.provides;
    s === n && (n = Me.provides = Object.create(s)), n[e] = t;
  }
}
function Mn(e, t, n = !1) {
  const s = El();
  if (s || Qt) {
    let r = Qt ? Qt._context.provides : s ? s.parent == null || s.ce ? s.vnode.appContext && s.vnode.appContext.provides : s.parent.provides : void 0;
    if (r && e in r)
      return r[e];
    if (arguments.length > 1)
      return n && ee(t) ? t.call(s && s.proxy) : t;
  }
}
const Ta = /* @__PURE__ */ Symbol.for("v-scx"), Ra = () => Mn(Ta);
function Kt(e, t, n) {
  return qi(e, t, n);
}
function qi(e, t, n = pe) {
  const { immediate: s, deep: r, flush: i, once: o } = n, a = ve({}, n), l = t && s || !t && i !== "post";
  let d;
  if (wn) {
    if (i === "sync") {
      const M = Ra();
      d = M.__watcherHandles || (M.__watcherHandles = []);
    } else if (!l) {
      const M = () => {
      };
      return M.stop = ht, M.resume = ht, M.pause = ht, M;
    }
  }
  const u = Me;
  a.call = (M, I, x) => pt(M, u, I, x);
  let h = !1;
  i === "post" ? a.scheduler = (M) => {
    Ke(M, u && u.suspense);
  } : i !== "sync" && (h = !0, a.scheduler = (M, I) => {
    I ? M() : Ys(M);
  }), a.augmentJob = (M) => {
    t && (M.flags |= 4), h && (M.flags |= 2, u && (M.id = u.uid, M.i = u));
  };
  const v = xa(e, t, a);
  return wn && (d ? d.push(v) : l && v()), v;
}
function $a(e, t, n) {
  const s = this.proxy, r = _e(e) ? e.includes(".") ? Di(s, e) : () => s[e] : e.bind(s, s);
  let i;
  ee(t) ? i = t : (i = t.handler, n = t);
  const o = xn(this), a = qi(r, i.bind(s), n);
  return o(), a;
}
function Di(e, t) {
  const n = t.split(".");
  return () => {
    let s = e;
    for (let r = 0; r < n.length && s; r++)
      s = s[n[r]];
    return s;
  };
}
const Ma = /* @__PURE__ */ Symbol("_vte"), Oa = (e) => e.__isTeleport, Na = /* @__PURE__ */ Symbol("_leaveCb");
function Xs(e, t) {
  e.shapeFlag & 6 && e.component ? (e.transition = t, Xs(e.component.subTree, t)) : e.shapeFlag & 128 ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t;
}
// @__NO_SIDE_EFFECTS__
function gt(e, t) {
  return ee(e) ? (
    // #8236: extend call and options.name access are considered side-effects
    // by Rollup, so we have to wrap it in a pure-annotated IIFE.
    ve({ name: e.name }, t, { setup: e })
  ) : e;
}
function Fi(e) {
  e.ids = [e.ids[0] + e.ids[2]++ + "-", 0, 0];
}
function vr(e, t) {
  let n;
  return !!((n = Object.getOwnPropertyDescriptor(e, t)) && !n.configurable);
}
const jn = /* @__PURE__ */ new WeakMap();
function fn(e, t, n, s, r = !1) {
  if (G(e)) {
    e.forEach(
      (x, N) => fn(
        x,
        t && (G(t) ? t[N] : t),
        n,
        s,
        r
      )
    );
    return;
  }
  if (Xt(s) && !r) {
    s.shapeFlag & 512 && s.type.__asyncResolved && s.component.subTree.component && fn(e, t, n, s.component.subTree);
    return;
  }
  const i = s.shapeFlag & 4 ? os(s.component) : s.el, o = r ? null : i, { i: a, r: l } = e, d = t && t.r, u = a.refs === pe ? a.refs = {} : a.refs, h = a.setupState, v = /* @__PURE__ */ ue(h), M = h === pe ? ci : (x) => vr(u, x) ? !1 : ce(v, x), I = (x, N) => !(N && vr(u, N));
  if (d != null && d !== l) {
    if (wr(t), _e(d))
      u[d] = null, M(d) && (h[d] = null);
    else if (/* @__PURE__ */ Ne(d)) {
      const x = t;
      I(d, x.k) && (d.value = null), x.k && (u[x.k] = null);
    }
  }
  if (ee(l))
    An(l, a, 12, [o, u]);
  else {
    const x = _e(l), N = /* @__PURE__ */ Ne(l);
    if (x || N) {
      const K = () => {
        if (e.f) {
          const b = x ? M(l) ? h[l] : u[l] : I() || !e.k ? l.value : u[e.k];
          if (r)
            G(b) && Ds(b, i);
          else if (G(b))
            b.includes(i) || b.push(i);
          else if (x)
            u[l] = [i], M(l) && (h[l] = u[l]);
          else {
            const D = [i];
            I(l, e.k) && (l.value = D), e.k && (u[e.k] = D);
          }
        } else x ? (u[l] = o, M(l) && (h[l] = o)) : N && (I(l, e.k) && (l.value = o), e.k && (u[e.k] = o));
      };
      if (o) {
        const b = () => {
          K(), jn.delete(e);
        };
        b.id = -1, jn.set(e, b), Ke(b, n);
      } else
        wr(e), K();
    }
  }
}
function wr(e) {
  const t = jn.get(e);
  t && (t.flags |= 8, jn.delete(e));
}
Qn().requestIdleCallback;
Qn().cancelIdleCallback;
const Xt = (e) => !!e.type.__asyncLoader, ji = (e) => e.type.__isKeepAlive;
function La(e, t) {
  Ki(e, "a", t);
}
function qa(e, t) {
  Ki(e, "da", t);
}
function Ki(e, t, n = Me) {
  const s = e.__wdc || (e.__wdc = () => {
    let r = n;
    for (; r; ) {
      if (r.isDeactivated)
        return;
      r = r.parent;
    }
    return e();
  });
  if (ns(t, s, n), n) {
    let r = n.parent;
    for (; r && r.parent; )
      ji(r.parent.vnode) && Da(s, t, n, r), r = r.parent;
  }
}
function Da(e, t, n, s) {
  const r = ns(
    t,
    e,
    s,
    !0
    /* prepend */
  );
  Qs(() => {
    Ds(s[t], r);
  }, n);
}
function ns(e, t, n = Me, s = !1) {
  if (n) {
    const r = n[e] || (n[e] = []), i = t.__weh || (t.__weh = (...o) => {
      xt();
      const a = xn(n), l = pt(t, n, e, o);
      return a(), Et(), l;
    });
    return s ? r.unshift(i) : r.push(i), i;
  }
}
const Pt = (e) => (t, n = Me) => {
  (!wn || e === "sp") && ns(e, (...s) => t(...s), n);
}, Fa = Pt("bm"), ss = Pt("m"), ja = Pt(
  "bu"
), Ka = Pt("u"), Ui = Pt(
  "bum"
), Qs = Pt("um"), Ua = Pt(
  "sp"
), Ha = Pt("rtg"), Va = Pt("rtc");
function Ba(e, t = Me) {
  ns("ec", e, t);
}
const Wa = "components", Hi = /* @__PURE__ */ Symbol.for("v-ndc");
function za(e) {
  return _e(e) ? Ja(Wa, e, !1) || e : e || Hi;
}
function Ja(e, t, n = !0, s = !1) {
  const r = ke || Me;
  if (r) {
    const i = r.type;
    {
      const a = Rl(
        i,
        !1
      );
      if (a && (a === t || a === xe(t) || a === Xn(xe(t))))
        return i;
    }
    const o = (
      // local registration
      // check instance[type] first which is resolved for options API
      Sr(r[e] || i[e], t) || // global registration
      Sr(r.appContext[e], t)
    );
    return !o && s ? i : o;
  }
}
function Sr(e, t) {
  return e && (e[t] || e[xe(t)] || e[Xn(xe(t))]);
}
function He(e, t, n, s) {
  let r;
  const i = n, o = G(e);
  if (o || _e(e)) {
    const a = o && /* @__PURE__ */ jt(e);
    let l = !1, d = !1;
    a && (l = !/* @__PURE__ */ et(e), d = /* @__PURE__ */ Ct(e), e = Zn(e)), r = new Array(e.length);
    for (let u = 0, h = e.length; u < h; u++)
      r[u] = t(
        l ? d ? Zt(rt(e[u])) : rt(e[u]) : e[u],
        u,
        void 0,
        i
      );
  } else if (typeof e == "number") {
    r = new Array(e);
    for (let a = 0; a < e; a++)
      r[a] = t(a + 1, a, void 0, i);
  } else if (fe(e))
    if (e[Symbol.iterator])
      r = Array.from(
        e,
        (a, l) => t(a, l, void 0, i)
      );
    else {
      const a = Object.keys(e);
      r = new Array(a.length);
      for (let l = 0, d = a.length; l < d; l++) {
        const u = a[l];
        r[l] = t(e[u], u, l, i);
      }
    }
  else
    r = [];
  return r;
}
function Vi(e, t) {
  for (let n = 0; n < t.length; n++) {
    const s = t[n];
    if (G(s))
      for (let r = 0; r < s.length; r++)
        e[s[r].name] = s[r].fn;
    else s && (e[s.name] = s.key ? (...r) => {
      const i = s.fn(...r);
      return i && (i.key = s.key), i;
    } : s.fn);
  }
  return e;
}
function Mt(e, t, n = {}, s, r) {
  if (ke.ce || ke.parent && Xt(ke.parent) && ke.parent.ce) {
    const d = Object.keys(n).length > 0;
    return t !== "default" && (n.name = t), $(), mt(
      ye,
      null,
      [Pe("slot", n, s && s())],
      d ? -2 : 64
    );
  }
  let i = e[t];
  i && i._c && (i._d = !1), $();
  const o = i && Bi(i(n)), a = n.key || // slot content array of a dynamic conditional slot may have a branch
  // key attached in the `createSlots` helper, respect that
  o && o.key, l = mt(
    ye,
    {
      key: (a && !st(a) ? a : `_${t}`) + // #7256 force differentiate fallback content from actual content
      (!o && s ? "_fb" : "")
    },
    o || (s ? s() : []),
    o && e._ === 1 ? 64 : -2
  );
  return i && i._c && (i._d = !0), l;
}
function Bi(e) {
  return e.some((t) => _n(t) ? !(t.type === kt || t.type === ye && !Bi(t.children)) : !0) ? e : null;
}
const ks = (e) => e ? po(e) ? os(e) : ks(e.parent) : null, dn = (
  // Move PURE marker to new line to workaround compiler discarding it
  // due to type annotation
  /* @__PURE__ */ ve(/* @__PURE__ */ Object.create(null), {
    $: (e) => e,
    $el: (e) => e.vnode.el,
    $data: (e) => e.data,
    $props: (e) => e.props,
    $attrs: (e) => e.attrs,
    $slots: (e) => e.slots,
    $refs: (e) => e.refs,
    $parent: (e) => ks(e.parent),
    $root: (e) => ks(e.root),
    $host: (e) => e.ce,
    $emit: (e) => e.emit,
    $options: (e) => zi(e),
    $forceUpdate: (e) => e.f || (e.f = () => {
      Ys(e.update);
    }),
    $nextTick: (e) => e.n || (e.n = Gs.bind(e.proxy)),
    $watch: (e) => $a.bind(e)
  })
), hs = (e, t) => e !== pe && !e.__isScriptSetup && ce(e, t), Ga = {
  get({ _: e }, t) {
    if (t === "__v_skip")
      return !0;
    const { ctx: n, setupState: s, data: r, props: i, accessCache: o, type: a, appContext: l } = e;
    if (t[0] !== "$") {
      const v = o[t];
      if (v !== void 0)
        switch (v) {
          case 1:
            return s[t];
          case 2:
            return r[t];
          case 4:
            return n[t];
          case 3:
            return i[t];
        }
      else {
        if (hs(s, t))
          return o[t] = 1, s[t];
        if (r !== pe && ce(r, t))
          return o[t] = 2, r[t];
        if (ce(i, t))
          return o[t] = 3, i[t];
        if (n !== pe && ce(n, t))
          return o[t] = 4, n[t];
        Ps && (o[t] = 0);
      }
    }
    const d = dn[t];
    let u, h;
    if (d)
      return t === "$attrs" && $e(e.attrs, "get", ""), d(e);
    if (
      // css module (injected by vue-loader)
      (u = a.__cssModules) && (u = u[t])
    )
      return u;
    if (n !== pe && ce(n, t))
      return o[t] = 4, n[t];
    if (
      // global properties
      h = l.config.globalProperties, ce(h, t)
    )
      return h[t];
  },
  set({ _: e }, t, n) {
    const { data: s, setupState: r, ctx: i } = e;
    return hs(r, t) ? (r[t] = n, !0) : s !== pe && ce(s, t) ? (s[t] = n, !0) : ce(e.props, t) || t[0] === "$" && t.slice(1) in e ? !1 : (i[t] = n, !0);
  },
  has({
    _: { data: e, setupState: t, accessCache: n, ctx: s, appContext: r, props: i, type: o }
  }, a) {
    let l;
    return !!(n[a] || e !== pe && a[0] !== "$" && ce(e, a) || hs(t, a) || ce(i, a) || ce(s, a) || ce(dn, a) || ce(r.config.globalProperties, a) || (l = o.__cssModules) && l[a]);
  },
  defineProperty(e, t, n) {
    return n.get != null ? e._.accessCache[t] = 0 : ce(n, "value") && this.set(e, t, n.value, null), Reflect.defineProperty(e, t, n);
  }
};
function Ir(e) {
  return G(e) ? e.reduce(
    (t, n) => (t[n] = null, t),
    {}
  ) : e;
}
let Ps = !0;
function Ya(e) {
  const t = zi(e), n = e.proxy, s = e.ctx;
  Ps = !1, t.beforeCreate && Ar(t.beforeCreate, e, "bc");
  const {
    // state
    data: r,
    computed: i,
    methods: o,
    watch: a,
    provide: l,
    inject: d,
    // lifecycle
    created: u,
    beforeMount: h,
    mounted: v,
    beforeUpdate: M,
    updated: I,
    activated: x,
    deactivated: N,
    beforeDestroy: K,
    beforeUnmount: b,
    destroyed: D,
    unmounted: T,
    render: U,
    renderTracked: S,
    renderTriggered: O,
    errorCaptured: j,
    serverPrefetch: H,
    // public API
    expose: B,
    inheritAttrs: se,
    // assets
    components: ne,
    directives: ae,
    filters: Y
  } = t;
  if (d && Xa(d, s, null), o)
    for (const re in o) {
      const te = o[re];
      ee(te) && (s[re] = te.bind(n));
    }
  if (r) {
    const re = r.call(n, n);
    fe(re) && (e.data = /* @__PURE__ */ es(re));
  }
  if (Ps = !0, i)
    for (const re in i) {
      const te = i[re], Ie = ee(te) ? te.bind(n, n) : ee(te.get) ? te.get.bind(n, n) : ht, Xe = !ee(te) && ee(te.set) ? te.set.bind(n) : ht, Ee = le({
        get: Ie,
        set: Xe
      });
      Object.defineProperty(s, re, {
        enumerable: !0,
        configurable: !0,
        get: () => Ee.value,
        set: (de) => Ee.value = de
      });
    }
  if (a)
    for (const re in a)
      Wi(a[re], s, n, re);
  if (l) {
    const re = ee(l) ? l.call(n) : l;
    Reflect.ownKeys(re).forEach((te) => {
      Pa(te, re[te]);
    });
  }
  u && Ar(u, e, "c");
  function oe(re, te) {
    G(te) ? te.forEach((Ie) => re(Ie.bind(n))) : te && re(te.bind(n));
  }
  if (oe(Fa, h), oe(ss, v), oe(ja, M), oe(Ka, I), oe(La, x), oe(qa, N), oe(Ba, j), oe(Va, S), oe(Ha, O), oe(Ui, b), oe(Qs, T), oe(Ua, H), G(B))
    if (B.length) {
      const re = e.exposed || (e.exposed = {});
      B.forEach((te) => {
        Object.defineProperty(re, te, {
          get: () => n[te],
          set: (Ie) => n[te] = Ie,
          enumerable: !0
        });
      });
    } else e.exposed || (e.exposed = {});
  U && e.render === ht && (e.render = U), se != null && (e.inheritAttrs = se), ne && (e.components = ne), ae && (e.directives = ae), H && Fi(e);
}
function Xa(e, t, n = ht) {
  G(e) && (e = Ts(e));
  for (const s in e) {
    const r = e[s];
    let i;
    fe(r) ? "default" in r ? i = Mn(
      r.from || s,
      r.default,
      !0
    ) : i = Mn(r.from || s) : i = Mn(r), /* @__PURE__ */ Ne(i) ? Object.defineProperty(t, s, {
      enumerable: !0,
      configurable: !0,
      get: () => i.value,
      set: (o) => i.value = o
    }) : t[s] = i;
  }
}
function Ar(e, t, n) {
  pt(
    G(e) ? e.map((s) => s.bind(t.proxy)) : e.bind(t.proxy),
    t,
    n
  );
}
function Wi(e, t, n, s) {
  let r = s.includes(".") ? Di(n, s) : () => n[s];
  if (_e(e)) {
    const i = t[e];
    ee(i) && Kt(r, i);
  } else if (ee(e))
    Kt(r, e.bind(n));
  else if (fe(e))
    if (G(e))
      e.forEach((i) => Wi(i, t, n, s));
    else {
      const i = ee(e.handler) ? e.handler.bind(n) : t[e.handler];
      ee(i) && Kt(r, i, e);
    }
}
function zi(e) {
  const t = e.type, { mixins: n, extends: s } = t, {
    mixins: r,
    optionsCache: i,
    config: { optionMergeStrategies: o }
  } = e.appContext, a = i.get(t);
  let l;
  return a ? l = a : !r.length && !n && !s ? l = t : (l = {}, r.length && r.forEach(
    (d) => Kn(l, d, o, !0)
  ), Kn(l, t, o)), fe(t) && i.set(t, l), l;
}
function Kn(e, t, n, s = !1) {
  const { mixins: r, extends: i } = t;
  i && Kn(e, i, n, !0), r && r.forEach(
    (o) => Kn(e, o, n, !0)
  );
  for (const o in t)
    if (!(s && o === "expose")) {
      const a = Qa[o] || n && n[o];
      e[o] = a ? a(e[o], t[o]) : t[o];
    }
  return e;
}
const Qa = {
  data: xr,
  props: Er,
  emits: Er,
  // objects
  methods: on,
  computed: on,
  // lifecycle
  beforeCreate: Le,
  created: Le,
  beforeMount: Le,
  mounted: Le,
  beforeUpdate: Le,
  updated: Le,
  beforeDestroy: Le,
  beforeUnmount: Le,
  destroyed: Le,
  unmounted: Le,
  activated: Le,
  deactivated: Le,
  errorCaptured: Le,
  serverPrefetch: Le,
  // assets
  components: on,
  directives: on,
  // watch
  watch: el,
  // provide / inject
  provide: xr,
  inject: Za
};
function xr(e, t) {
  return t ? e ? function() {
    return ve(
      ee(e) ? e.call(this, this) : e,
      ee(t) ? t.call(this, this) : t
    );
  } : t : e;
}
function Za(e, t) {
  return on(Ts(e), Ts(t));
}
function Ts(e) {
  if (G(e)) {
    const t = {};
    for (let n = 0; n < e.length; n++)
      t[e[n]] = e[n];
    return t;
  }
  return e;
}
function Le(e, t) {
  return e ? [...new Set([].concat(e, t))] : t;
}
function on(e, t) {
  return e ? ve(/* @__PURE__ */ Object.create(null), e, t) : t;
}
function Er(e, t) {
  return e ? G(e) && G(t) ? [.../* @__PURE__ */ new Set([...e, ...t])] : ve(
    /* @__PURE__ */ Object.create(null),
    Ir(e),
    Ir(t ?? {})
  ) : t;
}
function el(e, t) {
  if (!e) return t;
  if (!t) return e;
  const n = ve(/* @__PURE__ */ Object.create(null), e);
  for (const s in t)
    n[s] = Le(e[s], t[s]);
  return n;
}
function Ji() {
  return {
    app: null,
    config: {
      isNativeTag: ci,
      performance: !1,
      globalProperties: {},
      optionMergeStrategies: {},
      errorHandler: void 0,
      warnHandler: void 0,
      compilerOptions: {}
    },
    mixins: [],
    components: {},
    directives: {},
    provides: /* @__PURE__ */ Object.create(null),
    optionsCache: /* @__PURE__ */ new WeakMap(),
    propsCache: /* @__PURE__ */ new WeakMap(),
    emitsCache: /* @__PURE__ */ new WeakMap()
  };
}
let tl = 0;
function nl(e, t) {
  return function(s, r = null) {
    ee(s) || (s = ve({}, s)), r != null && !fe(r) && (r = null);
    const i = Ji(), o = /* @__PURE__ */ new WeakSet(), a = [];
    let l = !1;
    const d = i.app = {
      _uid: tl++,
      _component: s,
      _props: r,
      _container: null,
      _context: i,
      _instance: null,
      version: Ol,
      get config() {
        return i.config;
      },
      set config(u) {
      },
      use(u, ...h) {
        return o.has(u) || (u && ee(u.install) ? (o.add(u), u.install(d, ...h)) : ee(u) && (o.add(u), u(d, ...h))), d;
      },
      mixin(u) {
        return i.mixins.includes(u) || i.mixins.push(u), d;
      },
      component(u, h) {
        return h ? (i.components[u] = h, d) : i.components[u];
      },
      directive(u, h) {
        return h ? (i.directives[u] = h, d) : i.directives[u];
      },
      mount(u, h, v) {
        if (!l) {
          const M = d._ceVNode || Pe(s, r);
          return M.appContext = i, v === !0 ? v = "svg" : v === !1 && (v = void 0), e(M, u, v), l = !0, d._container = u, u.__vue_app__ = d, os(M.component);
        }
      },
      onUnmount(u) {
        a.push(u);
      },
      unmount() {
        l && (pt(
          a,
          d._instance,
          16
        ), e(null, d._container), delete d._container.__vue_app__);
      },
      provide(u, h) {
        return i.provides[u] = h, d;
      },
      runWithContext(u) {
        const h = Qt;
        Qt = d;
        try {
          return u();
        } finally {
          Qt = h;
        }
      }
    };
    return d;
  };
}
let Qt = null;
const sl = (e, t) => t === "modelValue" || t === "model-value" ? e.modelModifiers : e[`${t}Modifiers`] || e[`${xe(t)}Modifiers`] || e[`${Ze(t)}Modifiers`];
function rl(e, t, ...n) {
  if (e.isUnmounted) return;
  const s = e.vnode.props || pe;
  let r = n;
  const i = t.startsWith("update:"), o = i && sl(s, t.slice(7));
  o && (o.trim && (r = n.map((u) => _e(u) ? u.trim() : u)), o.number && (r = n.map(js)));
  let a, l = s[a = ls(t)] || // also try camelCase event handler (#2249)
  s[a = ls(xe(t))];
  !l && i && (l = s[a = ls(Ze(t))]), l && pt(
    l,
    e,
    6,
    r
  );
  const d = s[a + "Once"];
  if (d) {
    if (!e.emitted)
      e.emitted = {};
    else if (e.emitted[a])
      return;
    e.emitted[a] = !0, pt(
      d,
      e,
      6,
      r
    );
  }
}
const il = /* @__PURE__ */ new WeakMap();
function Gi(e, t, n = !1) {
  const s = n ? il : t.emitsCache, r = s.get(e);
  if (r !== void 0)
    return r;
  const i = e.emits;
  let o = {}, a = !1;
  if (!ee(e)) {
    const l = (d) => {
      const u = Gi(d, t, !0);
      u && (a = !0, ve(o, u));
    };
    !n && t.mixins.length && t.mixins.forEach(l), e.extends && l(e.extends), e.mixins && e.mixins.forEach(l);
  }
  return !i && !a ? (fe(e) && s.set(e, null), null) : (G(i) ? i.forEach((l) => o[l] = null) : ve(o, i), fe(e) && s.set(e, o), o);
}
function rs(e, t) {
  return !e || !Wn(t) ? !1 : (t = t.slice(2).replace(/Once$/, ""), ce(e, t[0].toLowerCase() + t.slice(1)) || ce(e, Ze(t)) || ce(e, t));
}
function Cr(e) {
  const {
    type: t,
    vnode: n,
    proxy: s,
    withProxy: r,
    propsOptions: [i],
    slots: o,
    attrs: a,
    emit: l,
    render: d,
    renderCache: u,
    props: h,
    data: v,
    setupState: M,
    ctx: I,
    inheritAttrs: x
  } = e, N = Dn(e);
  let K, b;
  try {
    if (n.shapeFlag & 4) {
      const T = r || s, U = T;
      K = ft(
        d.call(
          U,
          T,
          u,
          h,
          M,
          v,
          I
        )
      ), b = a;
    } else {
      const T = t;
      K = ft(
        T.length > 1 ? T(
          h,
          { attrs: a, slots: o, emit: l }
        ) : T(
          h,
          null
        )
      ), b = t.props ? a : ol(a);
    }
  } catch (T) {
    hn.length = 0, ts(T, e, 1), K = Pe(kt);
  }
  let D = K;
  if (b && x !== !1) {
    const T = Object.keys(b), { shapeFlag: U } = D;
    T.length && U & 7 && (i && T.some(zn) && (b = al(
      b,
      i
    )), D = en(D, b, !1, !0));
  }
  return n.dirs && (D = en(D, null, !1, !0), D.dirs = D.dirs ? D.dirs.concat(n.dirs) : n.dirs), n.transition && Xs(D, n.transition), K = D, Dn(N), K;
}
const ol = (e) => {
  let t;
  for (const n in e)
    (n === "class" || n === "style" || Wn(n)) && ((t || (t = {}))[n] = e[n]);
  return t;
}, al = (e, t) => {
  const n = {};
  for (const s in e)
    (!zn(s) || !(s.slice(9) in t)) && (n[s] = e[s]);
  return n;
};
function ll(e, t, n) {
  const { props: s, children: r, component: i } = e, { props: o, children: a, patchFlag: l } = t, d = i.emitsOptions;
  if (t.dirs || t.transition)
    return !0;
  if (n && l >= 0) {
    if (l & 1024)
      return !0;
    if (l & 16)
      return s ? kr(s, o, d) : !!o;
    if (l & 8) {
      const u = t.dynamicProps;
      for (let h = 0; h < u.length; h++) {
        const v = u[h];
        if (Yi(o, s, v) && !rs(d, v))
          return !0;
      }
    }
  } else
    return (r || a) && (!a || !a.$stable) ? !0 : s === o ? !1 : s ? o ? kr(s, o, d) : !0 : !!o;
  return !1;
}
function kr(e, t, n) {
  const s = Object.keys(t);
  if (s.length !== Object.keys(e).length)
    return !0;
  for (let r = 0; r < s.length; r++) {
    const i = s[r];
    if (Yi(t, e, i) && !rs(n, i))
      return !0;
  }
  return !1;
}
function Yi(e, t, n) {
  const s = e[n], r = t[n];
  return n === "style" && fe(s) && fe(r) ? !Ut(s, r) : s !== r;
}
function cl({ vnode: e, parent: t, suspense: n }, s) {
  for (; t; ) {
    const r = t.subTree;
    if (r.suspense && r.suspense.activeBranch === e && (r.suspense.vnode.el = r.el = s, e = r), r === e)
      (e = t.vnode).el = s, t = t.parent;
    else
      break;
  }
  n && n.activeBranch === e && (n.vnode.el = s);
}
const Xi = {}, Qi = () => Object.create(Xi), Zi = (e) => Object.getPrototypeOf(e) === Xi;
function ul(e, t, n, s = !1) {
  const r = {}, i = Qi();
  e.propsDefaults = /* @__PURE__ */ Object.create(null), eo(e, t, r, i);
  for (const o in e.propsOptions[0])
    o in r || (r[o] = void 0);
  n ? e.props = s ? r : /* @__PURE__ */ ya(r) : e.type.props ? e.props = r : e.props = i, e.attrs = i;
}
function fl(e, t, n, s) {
  const {
    props: r,
    attrs: i,
    vnode: { patchFlag: o }
  } = e, a = /* @__PURE__ */ ue(r), [l] = e.propsOptions;
  let d = !1;
  if (
    // always force full diff in dev
    // - #1942 if hmr is enabled with sfc component
    // - vite#872 non-sfc component used by sfc component
    (s || o > 0) && !(o & 16)
  ) {
    if (o & 8) {
      const u = e.vnode.dynamicProps;
      for (let h = 0; h < u.length; h++) {
        let v = u[h];
        if (rs(e.emitsOptions, v))
          continue;
        const M = t[v];
        if (l)
          if (ce(i, v))
            M !== i[v] && (i[v] = M, d = !0);
          else {
            const I = xe(v);
            r[I] = Rs(
              l,
              a,
              I,
              M,
              e,
              !1
            );
          }
        else
          M !== i[v] && (i[v] = M, d = !0);
      }
    }
  } else {
    eo(e, t, r, i) && (d = !0);
    let u;
    for (const h in a)
      (!t || // for camelCase
      !ce(t, h) && // it's possible the original props was passed in as kebab-case
      // and converted to camelCase (#955)
      ((u = Ze(h)) === h || !ce(t, u))) && (l ? n && // for camelCase
      (n[h] !== void 0 || // for kebab-case
      n[u] !== void 0) && (r[h] = Rs(
        l,
        a,
        h,
        void 0,
        e,
        !0
      )) : delete r[h]);
    if (i !== a)
      for (const h in i)
        (!t || !ce(t, h)) && (delete i[h], d = !0);
  }
  d && wt(e.attrs, "set", "");
}
function eo(e, t, n, s) {
  const [r, i] = e.propsOptions;
  let o = !1, a;
  if (t)
    for (let l in t) {
      if (ln(l))
        continue;
      const d = t[l];
      let u;
      r && ce(r, u = xe(l)) ? !i || !i.includes(u) ? n[u] = d : (a || (a = {}))[u] = d : rs(e.emitsOptions, l) || (!(l in s) || d !== s[l]) && (s[l] = d, o = !0);
    }
  if (i) {
    const l = /* @__PURE__ */ ue(n), d = a || pe;
    for (let u = 0; u < i.length; u++) {
      const h = i[u];
      n[h] = Rs(
        r,
        l,
        h,
        d[h],
        e,
        !ce(d, h)
      );
    }
  }
  return o;
}
function Rs(e, t, n, s, r, i) {
  const o = e[n];
  if (o != null) {
    const a = ce(o, "default");
    if (a && s === void 0) {
      const l = o.default;
      if (o.type !== Function && !o.skipFactory && ee(l)) {
        const { propsDefaults: d } = r;
        if (n in d)
          s = d[n];
        else {
          const u = xn(r);
          s = d[n] = l.call(
            null,
            t
          ), u();
        }
      } else
        s = l;
      r.ce && r.ce._setProp(n, s);
    }
    o[
      0
      /* shouldCast */
    ] && (i && !a ? s = !1 : o[
      1
      /* shouldCastTrue */
    ] && (s === "" || s === Ze(n)) && (s = !0));
  }
  return s;
}
const dl = /* @__PURE__ */ new WeakMap();
function to(e, t, n = !1) {
  const s = n ? dl : t.propsCache, r = s.get(e);
  if (r)
    return r;
  const i = e.props, o = {}, a = [];
  let l = !1;
  if (!ee(e)) {
    const u = (h) => {
      l = !0;
      const [v, M] = to(h, t, !0);
      ve(o, v), M && a.push(...M);
    };
    !n && t.mixins.length && t.mixins.forEach(u), e.extends && u(e.extends), e.mixins && e.mixins.forEach(u);
  }
  if (!i && !l)
    return fe(e) && s.set(e, Jt), Jt;
  if (G(i))
    for (let u = 0; u < i.length; u++) {
      const h = xe(i[u]);
      Pr(h) && (o[h] = pe);
    }
  else if (i)
    for (const u in i) {
      const h = xe(u);
      if (Pr(h)) {
        const v = i[u], M = o[h] = G(v) || ee(v) ? { type: v } : ve({}, v), I = M.type;
        let x = !1, N = !0;
        if (G(I))
          for (let K = 0; K < I.length; ++K) {
            const b = I[K], D = ee(b) && b.name;
            if (D === "Boolean") {
              x = !0;
              break;
            } else D === "String" && (N = !1);
          }
        else
          x = ee(I) && I.name === "Boolean";
        M[
          0
          /* shouldCast */
        ] = x, M[
          1
          /* shouldCastTrue */
        ] = N, (x || ce(M, "default")) && a.push(h);
      }
    }
  const d = [o, a];
  return fe(e) && s.set(e, d), d;
}
function Pr(e) {
  return e[0] !== "$" && !ln(e);
}
const Zs = (e) => e === "_" || e === "_ctx" || e === "$stable", er = (e) => G(e) ? e.map(ft) : [ft(e)], hl = (e, t, n) => {
  if (t._n)
    return t;
  const s = Fn((...r) => er(t(...r)), n);
  return s._c = !1, s;
}, no = (e, t, n) => {
  const s = e._ctx;
  for (const r in e) {
    if (Zs(r)) continue;
    const i = e[r];
    if (ee(i))
      t[r] = hl(r, i, s);
    else if (i != null) {
      const o = er(i);
      t[r] = () => o;
    }
  }
}, so = (e, t) => {
  const n = er(t);
  e.slots.default = () => n;
}, ro = (e, t, n) => {
  for (const s in t)
    (n || !Zs(s)) && (e[s] = t[s]);
}, pl = (e, t, n) => {
  const s = e.slots = Qi();
  if (e.vnode.shapeFlag & 32) {
    const r = t._;
    r ? (ro(s, t, n), n && di(s, "_", r, !0)) : no(t, s);
  } else t && so(e, t);
}, gl = (e, t, n) => {
  const { vnode: s, slots: r } = e;
  let i = !0, o = pe;
  if (s.shapeFlag & 32) {
    const a = t._;
    a ? n && a === 1 ? i = !1 : ro(r, t, n) : (i = !t.$stable, no(t, r)), o = t;
  } else t && (so(e, t), o = { default: 1 });
  if (i)
    for (const a in r)
      !Zs(a) && o[a] == null && delete r[a];
}, Ke = vl;
function ml(e) {
  return yl(e);
}
function yl(e, t) {
  const n = Qn();
  n.__VUE__ = !0;
  const {
    insert: s,
    remove: r,
    patchProp: i,
    createElement: o,
    createText: a,
    createComment: l,
    setText: d,
    setElementText: u,
    parentNode: h,
    nextSibling: v,
    setScopeId: M = ht,
    insertStaticContent: I
  } = e, x = (c, f, y, E = null, k = null, p = null, w = void 0, _ = null, P = !!f.dynamicChildren) => {
    if (c === f)
      return;
    c && !rn(c, f) && (E = R(c), de(c, k, p, !0), c = null), f.patchFlag === -2 && (P = !1, f.dynamicChildren = null);
    const { type: A, ref: z, shapeFlag: F } = f;
    switch (A) {
      case is:
        N(c, f, y, E);
        break;
      case kt:
        K(c, f, y, E);
        break;
      case gs:
        c == null && b(f, y, E, w);
        break;
      case ye:
        ne(
          c,
          f,
          y,
          E,
          k,
          p,
          w,
          _,
          P
        );
        break;
      default:
        F & 1 ? U(
          c,
          f,
          y,
          E,
          k,
          p,
          w,
          _,
          P
        ) : F & 6 ? ae(
          c,
          f,
          y,
          E,
          k,
          p,
          w,
          _,
          P
        ) : (F & 64 || F & 128) && A.process(
          c,
          f,
          y,
          E,
          k,
          p,
          w,
          _,
          P,
          m
        );
    }
    z != null && k ? fn(z, c && c.ref, p, f || c, !f) : z == null && c && c.ref != null && fn(c.ref, null, p, c, !0);
  }, N = (c, f, y, E) => {
    if (c == null)
      s(
        f.el = a(f.children),
        y,
        E
      );
    else {
      const k = f.el = c.el;
      f.children !== c.children && d(k, f.children);
    }
  }, K = (c, f, y, E) => {
    c == null ? s(
      f.el = l(f.children || ""),
      y,
      E
    ) : f.el = c.el;
  }, b = (c, f, y, E) => {
    [c.el, c.anchor] = I(
      c.children,
      f,
      y,
      E,
      c.el,
      c.anchor
    );
  }, D = ({ el: c, anchor: f }, y, E) => {
    let k;
    for (; c && c !== f; )
      k = v(c), s(c, y, E), c = k;
    s(f, y, E);
  }, T = ({ el: c, anchor: f }) => {
    let y;
    for (; c && c !== f; )
      y = v(c), r(c), c = y;
    r(f);
  }, U = (c, f, y, E, k, p, w, _, P) => {
    if (f.type === "svg" ? w = "svg" : f.type === "math" && (w = "mathml"), c == null)
      S(
        f,
        y,
        E,
        k,
        p,
        w,
        _,
        P
      );
    else {
      const A = c.el && c.el._isVueCE ? c.el : null;
      try {
        A && A._beginPatch(), H(
          c,
          f,
          k,
          p,
          w,
          _,
          P
        );
      } finally {
        A && A._endPatch();
      }
    }
  }, S = (c, f, y, E, k, p, w, _) => {
    let P, A;
    const { props: z, shapeFlag: F, transition: W, dirs: J } = c;
    if (P = c.el = o(
      c.type,
      p,
      z && z.is,
      z
    ), F & 8 ? u(P, c.children) : F & 16 && j(
      c.children,
      P,
      null,
      E,
      k,
      ps(c, p),
      w,
      _
    ), J && Lt(c, null, E, "created"), O(P, c, c.scopeId, w, E), z) {
      for (const he in z)
        he !== "value" && !ln(he) && i(P, he, null, z[he], p, E);
      "value" in z && i(P, "value", null, z.value, p), (A = z.onVnodeBeforeMount) && lt(A, E, c);
    }
    J && Lt(c, null, E, "beforeMount");
    const ie = bl(k, W);
    ie && W.beforeEnter(P), s(P, f, y), ((A = z && z.onVnodeMounted) || ie || J) && Ke(() => {
      try {
        A && lt(A, E, c), ie && W.enter(P), J && Lt(c, null, E, "mounted");
      } finally {
      }
    }, k);
  }, O = (c, f, y, E, k) => {
    if (y && M(c, y), E)
      for (let p = 0; p < E.length; p++)
        M(c, E[p]);
    if (k) {
      let p = k.subTree;
      if (f === p || lo(p.type) && (p.ssContent === f || p.ssFallback === f)) {
        const w = k.vnode;
        O(
          c,
          w,
          w.scopeId,
          w.slotScopeIds,
          k.parent
        );
      }
    }
  }, j = (c, f, y, E, k, p, w, _, P = 0) => {
    for (let A = P; A < c.length; A++) {
      const z = c[A] = _ ? vt(c[A]) : ft(c[A]);
      x(
        null,
        z,
        f,
        y,
        E,
        k,
        p,
        w,
        _
      );
    }
  }, H = (c, f, y, E, k, p, w) => {
    const _ = f.el = c.el;
    let { patchFlag: P, dynamicChildren: A, dirs: z } = f;
    P |= c.patchFlag & 16;
    const F = c.props || pe, W = f.props || pe;
    let J;
    if (y && qt(y, !1), (J = W.onVnodeBeforeUpdate) && lt(J, y, f, c), z && Lt(f, c, y, "beforeUpdate"), y && qt(y, !0), (F.innerHTML && W.innerHTML == null || F.textContent && W.textContent == null) && u(_, ""), A ? B(
      c.dynamicChildren,
      A,
      _,
      y,
      E,
      ps(f, k),
      p
    ) : w || te(
      c,
      f,
      _,
      null,
      y,
      E,
      ps(f, k),
      p,
      !1
    ), P > 0) {
      if (P & 16)
        se(_, F, W, y, k);
      else if (P & 2 && F.class !== W.class && i(_, "class", null, W.class, k), P & 4 && i(_, "style", F.style, W.style, k), P & 8) {
        const ie = f.dynamicProps;
        for (let he = 0; he < ie.length; he++) {
          const ge = ie[he], we = F[ge], Ce = W[ge];
          (Ce !== we || ge === "value") && i(_, ge, we, Ce, k, y);
        }
      }
      P & 1 && c.children !== f.children && u(_, f.children);
    } else !w && A == null && se(_, F, W, y, k);
    ((J = W.onVnodeUpdated) || z) && Ke(() => {
      J && lt(J, y, f, c), z && Lt(f, c, y, "updated");
    }, E);
  }, B = (c, f, y, E, k, p, w) => {
    for (let _ = 0; _ < f.length; _++) {
      const P = c[_], A = f[_], z = (
        // oldVNode may be an errored async setup() component inside Suspense
        // which will not have a mounted element
        P.el && // - In the case of a Fragment, we need to provide the actual parent
        // of the Fragment itself so it can move its children.
        (P.type === ye || // - In the case of different nodes, there is going to be a replacement
        // which also requires the correct parent container
        !rn(P, A) || // - In the case of a component, it could contain anything.
        P.shapeFlag & 198) ? h(P.el) : (
          // In other cases, the parent container is not actually used so we
          // just pass the block element here to avoid a DOM parentNode call.
          y
        )
      );
      x(
        P,
        A,
        z,
        null,
        E,
        k,
        p,
        w,
        !0
      );
    }
  }, se = (c, f, y, E, k) => {
    if (f !== y) {
      if (f !== pe)
        for (const p in f)
          !ln(p) && !(p in y) && i(
            c,
            p,
            f[p],
            null,
            k,
            E
          );
      for (const p in y) {
        if (ln(p)) continue;
        const w = y[p], _ = f[p];
        w !== _ && p !== "value" && i(c, p, _, w, k, E);
      }
      "value" in y && i(c, "value", f.value, y.value, k);
    }
  }, ne = (c, f, y, E, k, p, w, _, P) => {
    const A = f.el = c ? c.el : a(""), z = f.anchor = c ? c.anchor : a("");
    let { patchFlag: F, dynamicChildren: W, slotScopeIds: J } = f;
    J && (_ = _ ? _.concat(J) : J), c == null ? (s(A, y, E), s(z, y, E), j(
      // #10007
      // such fragment like `<></>` will be compiled into
      // a fragment which doesn't have a children.
      // In this case fallback to an empty array
      f.children || [],
      y,
      z,
      k,
      p,
      w,
      _,
      P
    )) : F > 0 && F & 64 && W && // #2715 the previous fragment could've been a BAILed one as a result
    // of renderSlot() with no valid children
    c.dynamicChildren && c.dynamicChildren.length === W.length ? (B(
      c.dynamicChildren,
      W,
      y,
      k,
      p,
      w,
      _
    ), // #2080 if the stable fragment has a key, it's a <template v-for> that may
    //  get moved around. Make sure all root level vnodes inherit el.
    // #2134 or if it's a component root, it may also get moved around
    // as the component is being moved.
    (f.key != null || k && f === k.subTree) && io(
      c,
      f,
      !0
      /* shallow */
    )) : te(
      c,
      f,
      y,
      z,
      k,
      p,
      w,
      _,
      P
    );
  }, ae = (c, f, y, E, k, p, w, _, P) => {
    f.slotScopeIds = _, c == null ? f.shapeFlag & 512 ? k.ctx.activate(
      f,
      y,
      E,
      w,
      P
    ) : Y(
      f,
      y,
      E,
      k,
      p,
      w,
      P
    ) : Q(c, f, P);
  }, Y = (c, f, y, E, k, p, w) => {
    const _ = c.component = xl(
      c,
      E,
      k
    );
    if (ji(c) && (_.ctx.renderer = m), Cl(_, !1, w), _.asyncDep) {
      if (k && k.registerDep(_, oe, w), !c.el) {
        const P = _.subTree = Pe(kt);
        K(null, P, f, y), c.placeholder = P.el;
      }
    } else
      oe(
        _,
        c,
        f,
        y,
        k,
        p,
        w
      );
  }, Q = (c, f, y) => {
    const E = f.component = c.component;
    if (ll(c, f, y))
      if (E.asyncDep && !E.asyncResolved) {
        re(E, f, y);
        return;
      } else
        E.next = f, E.update();
    else
      f.el = c.el, E.vnode = f;
  }, oe = (c, f, y, E, k, p, w) => {
    const _ = () => {
      if (c.isMounted) {
        let { next: F, bu: W, u: J, parent: ie, vnode: he } = c;
        {
          const ot = oo(c);
          if (ot) {
            F && (F.el = he.el, re(c, F, w)), ot.asyncDep.then(() => {
              Ke(() => {
                c.isUnmounted || A();
              }, k);
            });
            return;
          }
        }
        let ge = F, we;
        qt(c, !1), F ? (F.el = he.el, re(c, F, w)) : F = he, W && $n(W), (we = F.props && F.props.onVnodeBeforeUpdate) && lt(we, ie, F, he), qt(c, !0);
        const Ce = Cr(c), it = c.subTree;
        c.subTree = Ce, x(
          it,
          Ce,
          // parent may have changed if it's in a teleport
          h(it.el),
          // anchor may have changed if it's in a fragment
          R(it),
          c,
          k,
          p
        ), F.el = Ce.el, ge === null && cl(c, Ce.el), J && Ke(J, k), (we = F.props && F.props.onVnodeUpdated) && Ke(
          () => lt(we, ie, F, he),
          k
        );
      } else {
        let F;
        const { el: W, props: J } = f, { bm: ie, m: he, parent: ge, root: we, type: Ce } = c, it = Xt(f);
        qt(c, !1), ie && $n(ie), !it && (F = J && J.onVnodeBeforeMount) && lt(F, ge, f), qt(c, !0);
        {
          we.ce && we.ce._hasShadowRoot() && we.ce._injectChildStyle(
            Ce,
            c.parent ? c.parent.type : void 0
          );
          const ot = c.subTree = Cr(c);
          x(
            null,
            ot,
            y,
            E,
            c,
            k,
            p
          ), f.el = ot.el;
        }
        if (he && Ke(he, k), !it && (F = J && J.onVnodeMounted)) {
          const ot = f;
          Ke(
            () => lt(F, ge, ot),
            k
          );
        }
        (f.shapeFlag & 256 || ge && Xt(ge.vnode) && ge.vnode.shapeFlag & 256) && c.a && Ke(c.a, k), c.isMounted = !0, f = y = E = null;
      }
    };
    c.scope.on();
    const P = c.effect = new yi(_);
    c.scope.off();
    const A = c.update = P.run.bind(P), z = c.job = P.runIfDirty.bind(P);
    z.i = c, z.id = c.uid, P.scheduler = () => Ys(z), qt(c, !0), A();
  }, re = (c, f, y) => {
    f.component = c;
    const E = c.vnode.props;
    c.vnode = f, c.next = null, fl(c, f.props, E, y), gl(c, f.children, y), xt(), _r(c), Et();
  }, te = (c, f, y, E, k, p, w, _, P = !1) => {
    const A = c && c.children, z = c ? c.shapeFlag : 0, F = f.children, { patchFlag: W, shapeFlag: J } = f;
    if (W > 0) {
      if (W & 128) {
        Xe(
          A,
          F,
          y,
          E,
          k,
          p,
          w,
          _,
          P
        );
        return;
      } else if (W & 256) {
        Ie(
          A,
          F,
          y,
          E,
          k,
          p,
          w,
          _,
          P
        );
        return;
      }
    }
    J & 8 ? (z & 16 && Fe(A, k, p), F !== A && u(y, F)) : z & 16 ? J & 16 ? Xe(
      A,
      F,
      y,
      E,
      k,
      p,
      w,
      _,
      P
    ) : Fe(A, k, p, !0) : (z & 8 && u(y, ""), J & 16 && j(
      F,
      y,
      E,
      k,
      p,
      w,
      _,
      P
    ));
  }, Ie = (c, f, y, E, k, p, w, _, P) => {
    c = c || Jt, f = f || Jt;
    const A = c.length, z = f.length, F = Math.min(A, z);
    let W;
    for (W = 0; W < F; W++) {
      const J = f[W] = P ? vt(f[W]) : ft(f[W]);
      x(
        c[W],
        J,
        y,
        null,
        k,
        p,
        w,
        _,
        P
      );
    }
    A > z ? Fe(
      c,
      k,
      p,
      !0,
      !1,
      F
    ) : j(
      f,
      y,
      E,
      k,
      p,
      w,
      _,
      P,
      F
    );
  }, Xe = (c, f, y, E, k, p, w, _, P) => {
    let A = 0;
    const z = f.length;
    let F = c.length - 1, W = z - 1;
    for (; A <= F && A <= W; ) {
      const J = c[A], ie = f[A] = P ? vt(f[A]) : ft(f[A]);
      if (rn(J, ie))
        x(
          J,
          ie,
          y,
          null,
          k,
          p,
          w,
          _,
          P
        );
      else
        break;
      A++;
    }
    for (; A <= F && A <= W; ) {
      const J = c[F], ie = f[W] = P ? vt(f[W]) : ft(f[W]);
      if (rn(J, ie))
        x(
          J,
          ie,
          y,
          null,
          k,
          p,
          w,
          _,
          P
        );
      else
        break;
      F--, W--;
    }
    if (A > F) {
      if (A <= W) {
        const J = W + 1, ie = J < z ? f[J].el : E;
        for (; A <= W; )
          x(
            null,
            f[A] = P ? vt(f[A]) : ft(f[A]),
            y,
            ie,
            k,
            p,
            w,
            _,
            P
          ), A++;
      }
    } else if (A > W)
      for (; A <= F; )
        de(c[A], k, p, !0), A++;
    else {
      const J = A, ie = A, he = /* @__PURE__ */ new Map();
      for (A = ie; A <= W; A++) {
        const We = f[A] = P ? vt(f[A]) : ft(f[A]);
        We.key != null && he.set(We.key, A);
      }
      let ge, we = 0;
      const Ce = W - ie + 1;
      let it = !1, ot = 0;
      const nn = new Array(Ce);
      for (A = 0; A < Ce; A++) nn[A] = 0;
      for (A = J; A <= F; A++) {
        const We = c[A];
        if (we >= Ce) {
          de(We, k, p, !0);
          continue;
        }
        let at;
        if (We.key != null)
          at = he.get(We.key);
        else
          for (ge = ie; ge <= W; ge++)
            if (nn[ge - ie] === 0 && rn(We, f[ge])) {
              at = ge;
              break;
            }
        at === void 0 ? de(We, k, p, !0) : (nn[at - ie] = A + 1, at >= ot ? ot = at : it = !0, x(
          We,
          f[at],
          y,
          null,
          k,
          p,
          w,
          _,
          P
        ), we++);
      }
      const fr = it ? _l(nn) : Jt;
      for (ge = fr.length - 1, A = Ce - 1; A >= 0; A--) {
        const We = ie + A, at = f[We], dr = f[We + 1], hr = We + 1 < z ? (
          // #13559, #14173 fallback to el placeholder for unresolved async component
          dr.el || ao(dr)
        ) : E;
        nn[A] === 0 ? x(
          null,
          at,
          y,
          hr,
          k,
          p,
          w,
          _,
          P
        ) : it && (ge < 0 || A !== fr[ge] ? Ee(at, y, hr, 2) : ge--);
      }
    }
  }, Ee = (c, f, y, E, k = null) => {
    const { el: p, type: w, transition: _, children: P, shapeFlag: A } = c;
    if (A & 6) {
      Ee(c.component.subTree, f, y, E);
      return;
    }
    if (A & 128) {
      c.suspense.move(f, y, E);
      return;
    }
    if (A & 64) {
      w.move(c, f, y, m);
      return;
    }
    if (w === ye) {
      s(p, f, y);
      for (let F = 0; F < P.length; F++)
        Ee(P[F], f, y, E);
      s(c.anchor, f, y);
      return;
    }
    if (w === gs) {
      D(c, f, y);
      return;
    }
    if (E !== 2 && A & 1 && _)
      if (E === 0)
        _.beforeEnter(p), s(p, f, y), Ke(() => _.enter(p), k);
      else {
        const { leave: F, delayLeave: W, afterLeave: J } = _, ie = () => {
          c.ctx.isUnmounted ? r(p) : s(p, f, y);
        }, he = () => {
          p._isLeaving && p[Na](
            !0
            /* cancelled */
          ), F(p, () => {
            ie(), J && J();
          });
        };
        W ? W(p, ie, he) : he();
      }
    else
      s(p, f, y);
  }, de = (c, f, y, E = !1, k = !1) => {
    const {
      type: p,
      props: w,
      ref: _,
      children: P,
      dynamicChildren: A,
      shapeFlag: z,
      patchFlag: F,
      dirs: W,
      cacheIndex: J,
      memo: ie
    } = c;
    if (F === -2 && (k = !1), _ != null && (xt(), fn(_, null, y, c, !0), Et()), J != null && (f.renderCache[J] = void 0), z & 256) {
      f.ctx.deactivate(c);
      return;
    }
    const he = z & 1 && W, ge = !Xt(c);
    let we;
    if (ge && (we = w && w.onVnodeBeforeUnmount) && lt(we, f, c), z & 6)
      De(c.component, y, E);
    else {
      if (z & 128) {
        c.suspense.unmount(y, E);
        return;
      }
      he && Lt(c, null, f, "beforeUnmount"), z & 64 ? c.type.remove(
        c,
        f,
        y,
        m,
        E
      ) : A && // #5154
      // when v-once is used inside a block, setBlockTracking(-1) marks the
      // parent block with hasOnce: true
      // so that it doesn't take the fast path during unmount - otherwise
      // components nested in v-once are never unmounted.
      !A.hasOnce && // #1153: fast path should not be taken for non-stable (v-for) fragments
      (p !== ye || F > 0 && F & 64) ? Fe(
        A,
        f,
        y,
        !1,
        !0
      ) : (p === ye && F & 384 || !k && z & 16) && Fe(P, f, y), E && Te(c);
    }
    const Ce = ie != null && J == null;
    (ge && (we = w && w.onVnodeUnmounted) || he || Ce) && Ke(() => {
      we && lt(we, f, c), he && Lt(c, null, f, "unmounted"), Ce && (c.el = null);
    }, y);
  }, Te = (c) => {
    const { type: f, el: y, anchor: E, transition: k } = c;
    if (f === ye) {
      tt(y, E);
      return;
    }
    if (f === gs) {
      T(c);
      return;
    }
    const p = () => {
      r(y), k && !k.persisted && k.afterLeave && k.afterLeave();
    };
    if (c.shapeFlag & 1 && k && !k.persisted) {
      const { leave: w, delayLeave: _ } = k, P = () => w(y, p);
      _ ? _(c.el, p, P) : P();
    } else
      p();
  }, tt = (c, f) => {
    let y;
    for (; c !== f; )
      y = v(c), r(c), c = y;
    r(f);
  }, De = (c, f, y) => {
    const { bum: E, scope: k, job: p, subTree: w, um: _, m: P, a: A } = c;
    Tr(P), Tr(A), E && $n(E), k.stop(), p && (p.flags |= 8, de(w, c, f, y)), _ && Ke(_, f), Ke(() => {
      c.isUnmounted = !0;
    }, f);
  }, Fe = (c, f, y, E = !1, k = !1, p = 0) => {
    for (let w = p; w < c.length; w++)
      de(c[w], f, y, E, k);
  }, R = (c) => {
    if (c.shapeFlag & 6)
      return R(c.component.subTree);
    if (c.shapeFlag & 128)
      return c.suspense.next();
    const f = v(c.anchor || c.el), y = f && f[Ma];
    return y ? v(y) : f;
  };
  let L = !1;
  const C = (c, f, y) => {
    let E;
    c == null ? f._vnode && (de(f._vnode, null, null, !0), E = f._vnode.component) : x(
      f._vnode || null,
      c,
      f,
      null,
      null,
      null,
      y
    ), f._vnode = c, L || (L = !0, _r(E), Oi(), L = !1);
  }, m = {
    p: x,
    um: de,
    m: Ee,
    r: Te,
    mt: Y,
    mc: j,
    pc: te,
    pbc: B,
    n: R,
    o: e
  };
  return {
    render: C,
    hydrate: void 0,
    createApp: nl(C)
  };
}
function ps({ type: e, props: t }, n) {
  return n === "svg" && e === "foreignObject" || n === "mathml" && e === "annotation-xml" && t && t.encoding && t.encoding.includes("html") ? void 0 : n;
}
function qt({ effect: e, job: t }, n) {
  n ? (e.flags |= 32, t.flags |= 4) : (e.flags &= -33, t.flags &= -5);
}
function bl(e, t) {
  return (!e || e && !e.pendingBranch) && t && !t.persisted;
}
function io(e, t, n = !1) {
  const s = e.children, r = t.children;
  if (G(s) && G(r))
    for (let i = 0; i < s.length; i++) {
      const o = s[i];
      let a = r[i];
      a.shapeFlag & 1 && !a.dynamicChildren && ((a.patchFlag <= 0 || a.patchFlag === 32) && (a = r[i] = vt(r[i]), a.el = o.el), !n && a.patchFlag !== -2 && io(o, a)), a.type === is && (a.patchFlag === -1 && (a = r[i] = vt(a)), a.el = o.el), a.type === kt && !a.el && (a.el = o.el);
    }
}
function _l(e) {
  const t = e.slice(), n = [0];
  let s, r, i, o, a;
  const l = e.length;
  for (s = 0; s < l; s++) {
    const d = e[s];
    if (d !== 0) {
      if (r = n[n.length - 1], e[r] < d) {
        t[s] = r, n.push(s);
        continue;
      }
      for (i = 0, o = n.length - 1; i < o; )
        a = i + o >> 1, e[n[a]] < d ? i = a + 1 : o = a;
      d < e[n[i]] && (i > 0 && (t[s] = n[i - 1]), n[i] = s);
    }
  }
  for (i = n.length, o = n[i - 1]; i-- > 0; )
    n[i] = o, o = t[o];
  return n;
}
function oo(e) {
  const t = e.subTree.component;
  if (t)
    return t.asyncDep && !t.asyncResolved ? t : oo(t);
}
function Tr(e) {
  if (e)
    for (let t = 0; t < e.length; t++)
      e[t].flags |= 8;
}
function ao(e) {
  if (e.placeholder)
    return e.placeholder;
  const t = e.component;
  return t ? ao(t.subTree) : null;
}
const lo = (e) => e.__isSuspense;
function vl(e, t) {
  t && t.pendingBranch ? G(e) ? t.effects.push(...e) : t.effects.push(e) : ka(e);
}
const ye = /* @__PURE__ */ Symbol.for("v-fgt"), is = /* @__PURE__ */ Symbol.for("v-txt"), kt = /* @__PURE__ */ Symbol.for("v-cmt"), gs = /* @__PURE__ */ Symbol.for("v-stc"), hn = [];
let Ge = null;
function $(e = !1) {
  hn.push(Ge = e ? null : []);
}
function wl() {
  hn.pop(), Ge = hn[hn.length - 1] || null;
}
let bn = 1;
function Un(e, t = !1) {
  bn += e, e < 0 && Ge && t && (Ge.hasOnce = !0);
}
function co(e) {
  return e.dynamicChildren = bn > 0 ? Ge || Jt : null, wl(), bn > 0 && Ge && Ge.push(e), e;
}
function q(e, t, n, s, r, i) {
  return co(
    V(
      e,
      t,
      n,
      s,
      r,
      i,
      !0
    )
  );
}
function mt(e, t, n, s, r) {
  return co(
    Pe(
      e,
      t,
      n,
      s,
      r,
      !0
    )
  );
}
function _n(e) {
  return e ? e.__v_isVNode === !0 : !1;
}
function rn(e, t) {
  return e.type === t.type && e.key === t.key;
}
const uo = ({ key: e }) => e ?? null, On = ({
  ref: e,
  ref_key: t,
  ref_for: n
}) => (typeof e == "number" && (e = "" + e), e != null ? _e(e) || /* @__PURE__ */ Ne(e) || ee(e) ? { i: ke, r: e, k: t, f: !!n } : e : null);
function V(e, t = null, n = null, s = 0, r = null, i = e === ye ? 0 : 1, o = !1, a = !1) {
  const l = {
    __v_isVNode: !0,
    __v_skip: !0,
    type: e,
    props: t,
    key: t && uo(t),
    ref: t && On(t),
    scopeId: Li,
    slotScopeIds: null,
    children: n,
    component: null,
    suspense: null,
    ssContent: null,
    ssFallback: null,
    dirs: null,
    transition: null,
    el: null,
    anchor: null,
    target: null,
    targetStart: null,
    targetAnchor: null,
    staticCount: 0,
    shapeFlag: i,
    patchFlag: s,
    dynamicProps: r,
    dynamicChildren: null,
    appContext: null,
    ctx: ke
  };
  return a ? (tr(l, n), i & 128 && e.normalize(l)) : n && (l.shapeFlag |= _e(n) ? 8 : 16), bn > 0 && // avoid a block node from tracking itself
  !o && // has current parent block
  Ge && // presence of a patch flag indicates this node needs patching on updates.
  // component nodes also should always be patched, because even if the
  // component doesn't need to update, it needs to persist the instance on to
  // the next vnode so that it can be properly unmounted later.
  (l.patchFlag > 0 || i & 6) && // the EVENTS flag is only for hydration and if it is the only flag, the
  // vnode should not be considered dynamic due to handler caching.
  l.patchFlag !== 32 && Ge.push(l), l;
}
const Pe = Sl;
function Sl(e, t = null, n = null, s = 0, r = null, i = !1) {
  if ((!e || e === Hi) && (e = kt), _n(e)) {
    const a = en(
      e,
      t,
      !0
      /* mergeRef: true */
    );
    return n && tr(a, n), bn > 0 && !i && Ge && (a.shapeFlag & 6 ? Ge[Ge.indexOf(e)] = a : Ge.push(a)), a.patchFlag = -2, a;
  }
  if ($l(e) && (e = e.__vccOpts), t) {
    t = fo(t);
    let { class: a, style: l } = t;
    a && !_e(a) && (t.class = Oe(a)), fe(l) && (/* @__PURE__ */ zs(l) && !G(l) && (l = ve({}, l)), t.style = In(l));
  }
  const o = _e(e) ? 1 : lo(e) ? 128 : Oa(e) ? 64 : fe(e) ? 4 : ee(e) ? 2 : 0;
  return V(
    e,
    t,
    n,
    s,
    r,
    o,
    i,
    !0
  );
}
function fo(e) {
  return e ? /* @__PURE__ */ zs(e) || Zi(e) ? ve({}, e) : e : null;
}
function en(e, t, n = !1, s = !1) {
  const { props: r, ref: i, patchFlag: o, children: a, transition: l } = e, d = t ? ho(r || {}, t) : r, u = {
    __v_isVNode: !0,
    __v_skip: !0,
    type: e.type,
    props: d,
    key: d && uo(d),
    ref: t && t.ref ? (
      // #2078 in the case of <component :is="vnode" ref="extra"/>
      // if the vnode itself already has a ref, cloneVNode will need to merge
      // the refs so the single vnode can be set on multiple refs
      n && i ? G(i) ? i.concat(On(t)) : [i, On(t)] : On(t)
    ) : i,
    scopeId: e.scopeId,
    slotScopeIds: e.slotScopeIds,
    children: a,
    target: e.target,
    targetStart: e.targetStart,
    targetAnchor: e.targetAnchor,
    staticCount: e.staticCount,
    shapeFlag: e.shapeFlag,
    // if the vnode is cloned with extra props, we can no longer assume its
    // existing patch flag to be reliable and need to add the FULL_PROPS flag.
    // note: preserve flag for fragments since they use the flag for children
    // fast paths only.
    patchFlag: t && e.type !== ye ? o === -1 ? 16 : o | 16 : o,
    dynamicProps: e.dynamicProps,
    dynamicChildren: e.dynamicChildren,
    appContext: e.appContext,
    dirs: e.dirs,
    transition: l,
    // These should technically only be non-null on mounted VNodes. However,
    // they *should* be copied for kept-alive vnodes. So we just always copy
    // them since them being non-null during a mount doesn't affect the logic as
    // they will simply be overwritten.
    component: e.component,
    suspense: e.suspense,
    ssContent: e.ssContent && en(e.ssContent),
    ssFallback: e.ssFallback && en(e.ssFallback),
    placeholder: e.placeholder,
    el: e.el,
    anchor: e.anchor,
    ctx: e.ctx,
    ce: e.ce
  };
  return l && s && Xs(
    u,
    l.clone(u)
  ), u;
}
function vn(e = " ", t = 0) {
  return Pe(is, null, e, t);
}
function Z(e = "", t = !1) {
  return t ? ($(), mt(kt, null, e)) : Pe(kt, null, e);
}
function ft(e) {
  return e == null || typeof e == "boolean" ? Pe(kt) : G(e) ? Pe(
    ye,
    null,
    // #3666, avoid reference pollution when reusing vnode
    e.slice()
  ) : _n(e) ? vt(e) : Pe(is, null, String(e));
}
function vt(e) {
  return e.el === null && e.patchFlag !== -1 || e.memo ? e : en(e);
}
function tr(e, t) {
  let n = 0;
  const { shapeFlag: s } = e;
  if (t == null)
    t = null;
  else if (G(t))
    n = 16;
  else if (typeof t == "object")
    if (s & 65) {
      const r = t.default;
      r && (r._c && (r._d = !1), tr(e, r()), r._c && (r._d = !0));
      return;
    } else {
      n = 32;
      const r = t._;
      !r && !Zi(t) ? t._ctx = ke : r === 3 && ke && (ke.slots._ === 1 ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024));
    }
  else ee(t) ? (t = { default: t, _ctx: ke }, n = 32) : (t = String(t), s & 64 ? (n = 16, t = [vn(t)]) : n = 8);
  e.children = t, e.shapeFlag |= n;
}
function ho(...e) {
  const t = {};
  for (let n = 0; n < e.length; n++) {
    const s = e[n];
    for (const r in s)
      if (r === "class")
        t.class !== s.class && (t.class = Oe([t.class, s.class]));
      else if (r === "style")
        t.style = In([t.style, s.style]);
      else if (Wn(r)) {
        const i = t[r], o = s[r];
        o && i !== o && !(G(i) && i.includes(o)) ? t[r] = i ? [].concat(i, o) : o : o == null && i == null && // mergeProps({ 'onUpdate:modelValue': undefined }) should not retain
        // the model listener.
        !zn(r) && (t[r] = o);
      } else r !== "" && (t[r] = s[r]);
  }
  return t;
}
function lt(e, t, n, s = null) {
  pt(e, t, 7, [
    n,
    s
  ]);
}
const Il = Ji();
let Al = 0;
function xl(e, t, n) {
  const s = e.type, r = (t ? t.appContext : e.appContext) || Il, i = {
    uid: Al++,
    vnode: e,
    type: s,
    parent: t,
    appContext: r,
    root: null,
    // to be immediately set
    next: null,
    subTree: null,
    // will be set synchronously right after creation
    effect: null,
    update: null,
    // will be set synchronously right after creation
    job: null,
    scope: new Xo(
      !0
      /* detached */
    ),
    render: null,
    proxy: null,
    exposed: null,
    exposeProxy: null,
    withProxy: null,
    provides: t ? t.provides : Object.create(r.provides),
    ids: t ? t.ids : ["", 0, 0],
    accessCache: null,
    renderCache: [],
    // local resolved assets
    components: null,
    directives: null,
    // resolved props and emits options
    propsOptions: to(s, r),
    emitsOptions: Gi(s, r),
    // emit
    emit: null,
    // to be set immediately
    emitted: null,
    // props default value
    propsDefaults: pe,
    // inheritAttrs
    inheritAttrs: s.inheritAttrs,
    // state
    ctx: pe,
    data: pe,
    props: pe,
    attrs: pe,
    slots: pe,
    refs: pe,
    setupState: pe,
    setupContext: null,
    // suspense related
    suspense: n,
    suspenseId: n ? n.pendingId : 0,
    asyncDep: null,
    asyncResolved: !1,
    // lifecycle hooks
    // not using enums here because it results in computed properties
    isMounted: !1,
    isUnmounted: !1,
    isDeactivated: !1,
    bc: null,
    c: null,
    bm: null,
    m: null,
    bu: null,
    u: null,
    um: null,
    bum: null,
    da: null,
    a: null,
    rtg: null,
    rtc: null,
    ec: null,
    sp: null
  };
  return i.ctx = { _: i }, i.root = t ? t.root : i, i.emit = rl.bind(null, i), e.ce && e.ce(i), i;
}
let Me = null;
const El = () => Me || ke;
let Hn, $s;
{
  const e = Qn(), t = (n, s) => {
    let r;
    return (r = e[n]) || (r = e[n] = []), r.push(s), (i) => {
      r.length > 1 ? r.forEach((o) => o(i)) : r[0](i);
    };
  };
  Hn = t(
    "__VUE_INSTANCE_SETTERS__",
    (n) => Me = n
  ), $s = t(
    "__VUE_SSR_SETTERS__",
    (n) => wn = n
  );
}
const xn = (e) => {
  const t = Me;
  return Hn(e), e.scope.on(), () => {
    e.scope.off(), Hn(t);
  };
}, Rr = () => {
  Me && Me.scope.off(), Hn(null);
};
function po(e) {
  return e.vnode.shapeFlag & 4;
}
let wn = !1;
function Cl(e, t = !1, n = !1) {
  t && $s(t);
  const { props: s, children: r } = e.vnode, i = po(e);
  ul(e, s, i, t), pl(e, r, n || t);
  const o = i ? kl(e, t) : void 0;
  return t && $s(!1), o;
}
function kl(e, t) {
  const n = e.type;
  e.accessCache = /* @__PURE__ */ Object.create(null), e.proxy = new Proxy(e.ctx, Ga);
  const { setup: s } = n;
  if (s) {
    xt();
    const r = e.setupContext = s.length > 1 ? Tl(e) : null, i = xn(e), o = An(
      s,
      e,
      0,
      [
        e.props,
        r
      ]
    ), a = ui(o);
    if (Et(), i(), (a || e.sp) && !Xt(e) && Fi(e), a) {
      if (o.then(Rr, Rr), t)
        return o.then((l) => {
          $r(e, l);
        }).catch((l) => {
          ts(l, e, 0);
        });
      e.asyncDep = o;
    } else
      $r(e, o);
  } else
    go(e);
}
function $r(e, t, n) {
  ee(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : fe(t) && (e.setupState = Ri(t)), go(e);
}
function go(e, t, n) {
  const s = e.type;
  e.render || (e.render = s.render || ht);
  {
    const r = xn(e);
    xt();
    try {
      Ya(e);
    } finally {
      Et(), r();
    }
  }
}
const Pl = {
  get(e, t) {
    return $e(e, "get", ""), e[t];
  }
};
function Tl(e) {
  const t = (n) => {
    e.exposed = n || {};
  };
  return {
    attrs: new Proxy(e.attrs, Pl),
    slots: e.slots,
    emit: e.emit,
    expose: t
  };
}
function os(e) {
  return e.exposed ? e.exposeProxy || (e.exposeProxy = new Proxy(Ri(ba(e.exposed)), {
    get(t, n) {
      if (n in t)
        return t[n];
      if (n in dn)
        return dn[n](e);
    },
    has(t, n) {
      return n in t || n in dn;
    }
  })) : e.proxy;
}
function Rl(e, t = !0) {
  return ee(e) ? e.displayName || e.name : e.name || t && e.__name;
}
function $l(e) {
  return ee(e) && "__vccOpts" in e;
}
const le = (e, t) => /* @__PURE__ */ Ia(e, t, wn);
function Ml(e, t, n) {
  try {
    Un(-1);
    const s = arguments.length;
    return s === 2 ? fe(t) && !G(t) ? _n(t) ? Pe(e, null, [t]) : Pe(e, t) : Pe(e, null, t) : (s > 3 ? n = Array.prototype.slice.call(arguments, 2) : s === 3 && _n(n) && (n = [n]), Pe(e, t, n));
  } finally {
    Un(1);
  }
}
const Ol = "3.5.31";
/**
* @vue/runtime-dom v3.5.31
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
let Ms;
const Mr = typeof window < "u" && window.trustedTypes;
if (Mr)
  try {
    Ms = /* @__PURE__ */ Mr.createPolicy("vue", {
      createHTML: (e) => e
    });
  } catch {
  }
const mo = Ms ? (e) => Ms.createHTML(e) : (e) => e, Nl = "http://www.w3.org/2000/svg", Ll = "http://www.w3.org/1998/Math/MathML", _t = typeof document < "u" ? document : null, Or = _t && /* @__PURE__ */ _t.createElement("template"), ql = {
  insert: (e, t, n) => {
    t.insertBefore(e, n || null);
  },
  remove: (e) => {
    const t = e.parentNode;
    t && t.removeChild(e);
  },
  createElement: (e, t, n, s) => {
    const r = t === "svg" ? _t.createElementNS(Nl, e) : t === "mathml" ? _t.createElementNS(Ll, e) : n ? _t.createElement(e, { is: n }) : _t.createElement(e);
    return e === "select" && s && s.multiple != null && r.setAttribute("multiple", s.multiple), r;
  },
  createText: (e) => _t.createTextNode(e),
  createComment: (e) => _t.createComment(e),
  setText: (e, t) => {
    e.nodeValue = t;
  },
  setElementText: (e, t) => {
    e.textContent = t;
  },
  parentNode: (e) => e.parentNode,
  nextSibling: (e) => e.nextSibling,
  querySelector: (e) => _t.querySelector(e),
  setScopeId(e, t) {
    e.setAttribute(t, "");
  },
  // __UNSAFE__
  // Reason: innerHTML.
  // Static content here can only come from compiled templates.
  // As long as the user only uses trusted templates, this is safe.
  insertStaticContent(e, t, n, s, r, i) {
    const o = n ? n.previousSibling : t.lastChild;
    if (r && (r === i || r.nextSibling))
      for (; t.insertBefore(r.cloneNode(!0), n), !(r === i || !(r = r.nextSibling)); )
        ;
    else {
      Or.innerHTML = mo(
        s === "svg" ? `<svg>${e}</svg>` : s === "mathml" ? `<math>${e}</math>` : e
      );
      const a = Or.content;
      if (s === "svg" || s === "mathml") {
        const l = a.firstChild;
        for (; l.firstChild; )
          a.appendChild(l.firstChild);
        a.removeChild(l);
      }
      t.insertBefore(a, n);
    }
    return [
      // first
      o ? o.nextSibling : t.firstChild,
      // last
      n ? n.previousSibling : t.lastChild
    ];
  }
}, Dl = /* @__PURE__ */ Symbol("_vtc");
function Fl(e, t, n) {
  const s = e[Dl];
  s && (t = (t ? [t, ...s] : [...s]).join(" ")), t == null ? e.removeAttribute("class") : n ? e.setAttribute("class", t) : e.className = t;
}
const Nr = /* @__PURE__ */ Symbol("_vod"), jl = /* @__PURE__ */ Symbol("_vsh"), Kl = /* @__PURE__ */ Symbol(""), Ul = /(?:^|;)\s*display\s*:/;
function Hl(e, t, n) {
  const s = e.style, r = _e(n);
  let i = !1;
  if (n && !r) {
    if (t)
      if (_e(t))
        for (const o of t.split(";")) {
          const a = o.slice(0, o.indexOf(":")).trim();
          n[a] == null && Nn(s, a, "");
        }
      else
        for (const o in t)
          n[o] == null && Nn(s, o, "");
    for (const o in n)
      o === "display" && (i = !0), Nn(s, o, n[o]);
  } else if (r) {
    if (t !== n) {
      const o = s[Kl];
      o && (n += ";" + o), s.cssText = n, i = Ul.test(n);
    }
  } else t && e.removeAttribute("style");
  Nr in e && (e[Nr] = i ? s.display : "", e[jl] && (s.display = "none"));
}
const Lr = /\s*!important$/;
function Nn(e, t, n) {
  if (G(n))
    n.forEach((s) => Nn(e, t, s));
  else if (n == null && (n = ""), t.startsWith("--"))
    e.setProperty(t, n);
  else {
    const s = Vl(e, t);
    Lr.test(n) ? e.setProperty(
      Ze(s),
      n.replace(Lr, ""),
      "important"
    ) : e[s] = n;
  }
}
const qr = ["Webkit", "Moz", "ms"], ms = {};
function Vl(e, t) {
  const n = ms[t];
  if (n)
    return n;
  let s = xe(t);
  if (s !== "filter" && s in e)
    return ms[t] = s;
  s = Xn(s);
  for (let r = 0; r < qr.length; r++) {
    const i = qr[r] + s;
    if (i in e)
      return ms[t] = i;
  }
  return t;
}
const Dr = "http://www.w3.org/1999/xlink";
function Fr(e, t, n, s, r, i = Go(t)) {
  s && t.startsWith("xlink:") ? n == null ? e.removeAttributeNS(Dr, t.slice(6, t.length)) : e.setAttributeNS(Dr, t, n) : n == null || i && !hi(n) ? e.removeAttribute(t) : e.setAttribute(
    t,
    i ? "" : st(n) ? String(n) : n
  );
}
function jr(e, t, n, s, r) {
  if (t === "innerHTML" || t === "textContent") {
    n != null && (e[t] = t === "innerHTML" ? mo(n) : n);
    return;
  }
  const i = e.tagName;
  if (t === "value" && i !== "PROGRESS" && // custom elements may use _value internally
  !i.includes("-")) {
    const a = i === "OPTION" ? e.getAttribute("value") || "" : e.value, l = n == null ? (
      // #11647: value should be set as empty string for null and undefined,
      // but <input type="checkbox"> should be set as 'on'.
      e.type === "checkbox" ? "on" : ""
    ) : String(n);
    (a !== l || !("_value" in e)) && (e.value = l), n == null && e.removeAttribute(t), e._value = n;
    return;
  }
  let o = !1;
  if (n === "" || n == null) {
    const a = typeof e[t];
    a === "boolean" ? n = hi(n) : n == null && a === "string" ? (n = "", o = !0) : a === "number" && (n = 0, o = !0);
  }
  try {
    e[t] = n;
  } catch {
  }
  o && e.removeAttribute(r || t);
}
function Ot(e, t, n, s) {
  e.addEventListener(t, n, s);
}
function Bl(e, t, n, s) {
  e.removeEventListener(t, n, s);
}
const Kr = /* @__PURE__ */ Symbol("_vei");
function Wl(e, t, n, s, r = null) {
  const i = e[Kr] || (e[Kr] = {}), o = i[t];
  if (s && o)
    o.value = s;
  else {
    const [a, l] = zl(t);
    if (s) {
      const d = i[t] = Yl(
        s,
        r
      );
      Ot(e, a, d, l);
    } else o && (Bl(e, a, o, l), i[t] = void 0);
  }
}
const Ur = /(?:Once|Passive|Capture)$/;
function zl(e) {
  let t;
  if (Ur.test(e)) {
    t = {};
    let s;
    for (; s = e.match(Ur); )
      e = e.slice(0, e.length - s[0].length), t[s[0].toLowerCase()] = !0;
  }
  return [e[2] === ":" ? e.slice(3) : Ze(e.slice(2)), t];
}
let ys = 0;
const Jl = /* @__PURE__ */ Promise.resolve(), Gl = () => ys || (Jl.then(() => ys = 0), ys = Date.now());
function Yl(e, t) {
  const n = (s) => {
    if (!s._vts)
      s._vts = Date.now();
    else if (s._vts <= n.attached)
      return;
    pt(
      Xl(s, n.value),
      t,
      5,
      [s]
    );
  };
  return n.value = e, n.attached = Gl(), n;
}
function Xl(e, t) {
  if (G(t)) {
    const n = e.stopImmediatePropagation;
    return e.stopImmediatePropagation = () => {
      n.call(e), e._stopped = !0;
    }, t.map(
      (s) => (r) => !r._stopped && s && s(r)
    );
  } else
    return t;
}
const Hr = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && // lowercase letter
e.charCodeAt(2) > 96 && e.charCodeAt(2) < 123, Ql = (e, t, n, s, r, i) => {
  const o = r === "svg";
  t === "class" ? Fl(e, s, o) : t === "style" ? Hl(e, n, s) : Wn(t) ? zn(t) || Wl(e, t, n, s, i) : (t[0] === "." ? (t = t.slice(1), !0) : t[0] === "^" ? (t = t.slice(1), !1) : Zl(e, t, s, o)) ? (jr(e, t, s), !e.tagName.includes("-") && (t === "value" || t === "checked" || t === "selected") && Fr(e, t, s, o, i, t !== "value")) : /* #11081 force set props for possible async custom element */ e._isVueCE && // #12408 check if it's declared prop or it's async custom element
  (ec(e, t) || // @ts-expect-error _def is private
  e._def.__asyncLoader && (/[A-Z]/.test(t) || !_e(s))) ? jr(e, xe(t), s, i, t) : (t === "true-value" ? e._trueValue = s : t === "false-value" && (e._falseValue = s), Fr(e, t, s, o));
};
function Zl(e, t, n, s) {
  if (s)
    return !!(t === "innerHTML" || t === "textContent" || t in e && Hr(t) && ee(n));
  if (t === "spellcheck" || t === "draggable" || t === "translate" || t === "autocorrect" || t === "sandbox" && e.tagName === "IFRAME" || t === "form" || t === "list" && e.tagName === "INPUT" || t === "type" && e.tagName === "TEXTAREA")
    return !1;
  if (t === "width" || t === "height") {
    const r = e.tagName;
    if (r === "IMG" || r === "VIDEO" || r === "CANVAS" || r === "SOURCE")
      return !1;
  }
  return Hr(t) && _e(n) ? !1 : t in e;
}
function ec(e, t) {
  const n = (
    // @ts-expect-error _def is private
    e._def.props
  );
  if (!n)
    return !1;
  const s = xe(t);
  return Array.isArray(n) ? n.some((r) => xe(r) === s) : Object.keys(n).some((r) => xe(r) === s);
}
const Vr = {};
// @__NO_SIDE_EFFECTS__
function tc(e, t, n) {
  let s = /* @__PURE__ */ gt(e, t);
  Gn(s) && (s = ve({}, s, t));
  class r extends nr {
    constructor(o) {
      super(s, o, n);
    }
  }
  return r.def = s, r;
}
const nc = typeof HTMLElement < "u" ? HTMLElement : class {
};
class nr extends nc {
  constructor(t, n = {}, s = Ns) {
    super(), this._def = t, this._props = n, this._createApp = s, this._isVueCE = !0, this._instance = null, this._app = null, this._nonce = this._def.nonce, this._connected = !1, this._resolved = !1, this._patching = !1, this._dirty = !1, this._numberProps = null, this._styleChildren = /* @__PURE__ */ new WeakSet(), this._styleAnchors = /* @__PURE__ */ new WeakMap(), this._ob = null, this.shadowRoot && s !== Ns ? this._root = this.shadowRoot : t.shadowRoot !== !1 ? (this.attachShadow(
      ve({}, t.shadowRootOptions, {
        mode: "open"
      })
    ), this._root = this.shadowRoot) : this._root = this;
  }
  connectedCallback() {
    if (!this.isConnected) return;
    !this.shadowRoot && !this._resolved && this._parseSlots(), this._connected = !0;
    let t = this;
    for (; t = t && // #12479 should check assignedSlot first to get correct parent
    (t.assignedSlot || t.parentNode || t.host); )
      if (t instanceof nr) {
        this._parent = t;
        break;
      }
    this._instance || (this._resolved ? this._mount(this._def) : t && t._pendingResolve ? this._pendingResolve = t._pendingResolve.then(() => {
      this._pendingResolve = void 0, this._resolveDef();
    }) : this._resolveDef());
  }
  _setParent(t = this._parent) {
    t && (this._instance.parent = t._instance, this._inheritParentContext(t));
  }
  _inheritParentContext(t = this._parent) {
    t && this._app && Object.setPrototypeOf(
      this._app._context.provides,
      t._instance.provides
    );
  }
  disconnectedCallback() {
    this._connected = !1, Gs(() => {
      this._connected || (this._ob && (this._ob.disconnect(), this._ob = null), this._app && this._app.unmount(), this._instance && (this._instance.ce = void 0), this._app = this._instance = null, this._teleportTargets && (this._teleportTargets.clear(), this._teleportTargets = void 0));
    });
  }
  _processMutations(t) {
    for (const n of t)
      this._setAttr(n.attributeName);
  }
  /**
   * resolve inner component definition (handle possible async component)
   */
  _resolveDef() {
    if (this._pendingResolve)
      return;
    for (let s = 0; s < this.attributes.length; s++)
      this._setAttr(this.attributes[s].name);
    this._ob = new MutationObserver(this._processMutations.bind(this)), this._ob.observe(this, { attributes: !0 });
    const t = (s, r = !1) => {
      this._resolved = !0, this._pendingResolve = void 0;
      const { props: i, styles: o } = s;
      let a;
      if (i && !G(i))
        for (const l in i) {
          const d = i[l];
          (d === Number || d && d.type === Number) && (l in this._props && (this._props[l] = gr(this._props[l])), (a || (a = /* @__PURE__ */ Object.create(null)))[xe(l)] = !0);
        }
      this._numberProps = a, this._resolveProps(s), this.shadowRoot && this._applyStyles(o), this._mount(s);
    }, n = this._def.__asyncLoader;
    n ? this._pendingResolve = n().then((s) => {
      s.configureApp = this._def.configureApp, t(this._def = s, !0);
    }) : t(this._def);
  }
  _mount(t) {
    this._app = this._createApp(t), this._inheritParentContext(), t.configureApp && t.configureApp(this._app), this._app._ceVNode = this._createVNode(), this._app.mount(this._root);
    const n = this._instance && this._instance.exposed;
    if (n)
      for (const s in n)
        ce(this, s) || Object.defineProperty(this, s, {
          // unwrap ref to be consistent with public instance behavior
          get: () => Js(n[s])
        });
  }
  _resolveProps(t) {
    const { props: n } = t, s = G(n) ? n : Object.keys(n || {});
    for (const r of Object.keys(this))
      r[0] !== "_" && s.includes(r) && this._setProp(r, this[r]);
    for (const r of s.map(xe))
      Object.defineProperty(this, r, {
        get() {
          return this._getProp(r);
        },
        set(i) {
          this._setProp(r, i, !0, !this._patching);
        }
      });
  }
  _setAttr(t) {
    if (t.startsWith("data-v-")) return;
    const n = this.hasAttribute(t);
    let s = n ? this.getAttribute(t) : Vr;
    const r = xe(t);
    n && this._numberProps && this._numberProps[r] && (s = gr(s)), this._setProp(r, s, !1, !0);
  }
  /**
   * @internal
   */
  _getProp(t) {
    return this._props[t];
  }
  /**
   * @internal
   */
  _setProp(t, n, s = !0, r = !1) {
    if (n !== this._props[t] && (this._dirty = !0, n === Vr ? delete this._props[t] : (this._props[t] = n, t === "key" && this._app && (this._app._ceVNode.key = n)), r && this._instance && this._update(), s)) {
      const i = this._ob;
      i && (this._processMutations(i.takeRecords()), i.disconnect()), n === !0 ? this.setAttribute(Ze(t), "") : typeof n == "string" || typeof n == "number" ? this.setAttribute(Ze(t), n + "") : n || this.removeAttribute(Ze(t)), i && i.observe(this, { attributes: !0 });
    }
  }
  _update() {
    const t = this._createVNode();
    this._app && (t.appContext = this._app._context), lc(t, this._root);
  }
  _createVNode() {
    const t = {};
    this.shadowRoot || (t.onVnodeMounted = t.onVnodeUpdated = this._renderSlots.bind(this));
    const n = Pe(this._def, ve(t, this._props));
    return this._instance || (n.ce = (s) => {
      this._instance = s, s.ce = this, s.isCE = !0;
      const r = (i, o) => {
        this.dispatchEvent(
          new CustomEvent(
            i,
            Gn(o[0]) ? ve({ detail: o }, o[0]) : { detail: o }
          )
        );
      };
      s.emit = (i, ...o) => {
        r(i, o), Ze(i) !== i && r(Ze(i), o);
      }, this._setParent();
    }), n;
  }
  _applyStyles(t, n, s) {
    if (!t) return;
    if (n) {
      if (n === this._def || this._styleChildren.has(n))
        return;
      this._styleChildren.add(n);
    }
    const r = this._nonce, i = this.shadowRoot, o = s ? this._getStyleAnchor(s) || this._getStyleAnchor(this._def) : this._getRootStyleInsertionAnchor(i);
    let a = null;
    for (let l = t.length - 1; l >= 0; l--) {
      const d = document.createElement("style");
      r && d.setAttribute("nonce", r), d.textContent = t[l], i.insertBefore(d, a || o), a = d, l === 0 && (s || this._styleAnchors.set(this._def, d), n && this._styleAnchors.set(n, d));
    }
  }
  _getStyleAnchor(t) {
    if (!t)
      return null;
    const n = this._styleAnchors.get(t);
    return n && n.parentNode === this.shadowRoot ? n : (n && this._styleAnchors.delete(t), null);
  }
  _getRootStyleInsertionAnchor(t) {
    for (let n = 0; n < t.childNodes.length; n++) {
      const s = t.childNodes[n];
      if (!(s instanceof HTMLStyleElement))
        return s;
    }
    return null;
  }
  /**
   * Only called when shadowRoot is false
   */
  _parseSlots() {
    const t = this._slots = {};
    let n;
    for (; n = this.firstChild; ) {
      const s = n.nodeType === 1 && n.getAttribute("slot") || "default";
      (t[s] || (t[s] = [])).push(n), this.removeChild(n);
    }
  }
  /**
   * Only called when shadowRoot is false
   */
  _renderSlots() {
    const t = this._getSlots(), n = this._instance.type.__scopeId;
    for (let s = 0; s < t.length; s++) {
      const r = t[s], i = r.getAttribute("name") || "default", o = this._slots[i], a = r.parentNode;
      if (o)
        for (const l of o) {
          if (n && l.nodeType === 1) {
            const d = n + "-s", u = document.createTreeWalker(l, 1);
            l.setAttribute(d, "");
            let h;
            for (; h = u.nextNode(); )
              h.setAttribute(d, "");
          }
          a.insertBefore(l, r);
        }
      else
        for (; r.firstChild; ) a.insertBefore(r.firstChild, r);
      a.removeChild(r);
    }
  }
  /**
   * @internal
   */
  _getSlots() {
    const t = [this];
    this._teleportTargets && t.push(...this._teleportTargets);
    const n = /* @__PURE__ */ new Set();
    for (const s of t) {
      const r = s.querySelectorAll("slot");
      for (let i = 0; i < r.length; i++)
        n.add(r[i]);
    }
    return Array.from(n);
  }
  /**
   * @internal
   */
  _injectChildStyle(t, n) {
    this._applyStyles(t.styles, t, n);
  }
  /**
   * @internal
   */
  _beginPatch() {
    this._patching = !0, this._dirty = !1;
  }
  /**
   * @internal
   */
  _endPatch() {
    this._patching = !1, this._dirty && this._instance && this._update();
  }
  /**
   * @internal
   */
  _hasShadowRoot() {
    return this._def.shadowRoot !== !1;
  }
  /**
   * @internal
   */
  _removeChildStyle(t) {
  }
}
const tn = (e) => {
  const t = e.props["onUpdate:modelValue"] || !1;
  return G(t) ? (n) => $n(t, n) : t;
};
function sc(e) {
  e.target.composing = !0;
}
function Br(e) {
  const t = e.target;
  t.composing && (t.composing = !1, t.dispatchEvent(new Event("input")));
}
const It = /* @__PURE__ */ Symbol("_assign");
function Wr(e, t, n) {
  return t && (e = e.trim()), n && (e = js(e)), e;
}
const Os = {
  created(e, { modifiers: { lazy: t, trim: n, number: s } }, r) {
    e[It] = tn(r);
    const i = s || r.props && r.props.type === "number";
    Ot(e, t ? "change" : "input", (o) => {
      o.target.composing || e[It](Wr(e.value, n, i));
    }), (n || i) && Ot(e, "change", () => {
      e.value = Wr(e.value, n, i);
    }), t || (Ot(e, "compositionstart", sc), Ot(e, "compositionend", Br), Ot(e, "change", Br));
  },
  // set value on mounted so it's after min/max for type="range"
  mounted(e, { value: t }) {
    e.value = t ?? "";
  },
  beforeUpdate(e, { value: t, oldValue: n, modifiers: { lazy: s, trim: r, number: i } }, o) {
    if (e[It] = tn(o), e.composing) return;
    const a = (i || e.type === "number") && !/^0\d/.test(e.value) ? js(e.value) : e.value, l = t ?? "";
    if (a === l)
      return;
    const d = e.getRootNode();
    (d instanceof Document || d instanceof ShadowRoot) && d.activeElement === e && e.type !== "range" && (s && t === n || r && e.value.trim() === l) || (e.value = l);
  }
}, zr = {
  // #4096 array checkboxes need to be deep traversed
  deep: !0,
  created(e, t, n) {
    e[It] = tn(n), Ot(e, "change", () => {
      const s = e._modelValue, r = yo(e), i = e.checked, o = e[It];
      if (G(s)) {
        const a = pi(s, r), l = a !== -1;
        if (i && !l)
          o(s.concat(r));
        else if (!i && l) {
          const d = [...s];
          d.splice(a, 1), o(d);
        }
      } else if (Jn(s)) {
        const a = new Set(s);
        i ? a.add(r) : a.delete(r), o(a);
      } else
        o(bo(e, i));
    });
  },
  // set initial checked on mount to wait for true-value/false-value
  mounted: Jr,
  beforeUpdate(e, t, n) {
    e[It] = tn(n), Jr(e, t, n);
  }
};
function Jr(e, { value: t, oldValue: n }, s) {
  e._modelValue = t;
  let r;
  if (G(t))
    r = pi(t, s.props.value) > -1;
  else if (Jn(t))
    r = t.has(s.props.value);
  else {
    if (t === n) return;
    r = Ut(t, bo(e, !0));
  }
  e.checked !== r && (e.checked = r);
}
const rc = {
  created(e, { value: t }, n) {
    e.checked = Ut(t, n.props.value), e[It] = tn(n), Ot(e, "change", () => {
      e[It](yo(e));
    });
  },
  beforeUpdate(e, { value: t, oldValue: n }, s) {
    e[It] = tn(s), t !== n && (e.checked = Ut(t, s.props.value));
  }
};
function yo(e) {
  return "_value" in e ? e._value : e.value;
}
function bo(e, t) {
  const n = t ? "_trueValue" : "_falseValue";
  return n in e ? e[n] : t;
}
const ic = ["ctrl", "shift", "alt", "meta"], oc = {
  stop: (e) => e.stopPropagation(),
  prevent: (e) => e.preventDefault(),
  self: (e) => e.target !== e.currentTarget,
  ctrl: (e) => !e.ctrlKey,
  shift: (e) => !e.shiftKey,
  alt: (e) => !e.altKey,
  meta: (e) => !e.metaKey,
  left: (e) => "button" in e && e.button !== 0,
  middle: (e) => "button" in e && e.button !== 1,
  right: (e) => "button" in e && e.button !== 2,
  exact: (e, t) => ic.some((n) => e[`${n}Key`] && !t.includes(n))
}, _o = (e, t) => {
  if (!e) return e;
  const n = e._withMods || (e._withMods = {}), s = t.join(".");
  return n[s] || (n[s] = ((r, ...i) => {
    for (let o = 0; o < t.length; o++) {
      const a = oc[t[o]];
      if (a && a(r, t)) return;
    }
    return e(r, ...i);
  }));
}, ac = /* @__PURE__ */ ve({ patchProp: Ql }, ql);
let Gr;
function vo() {
  return Gr || (Gr = ml(ac));
}
const lc = ((...e) => {
  vo().render(...e);
}), Ns = ((...e) => {
  const t = vo().createApp(...e), { mount: n } = t;
  return t.mount = (s) => {
    const r = uc(s);
    if (!r) return;
    const i = t._component;
    !ee(i) && !i.render && !i.template && (i.template = r.innerHTML), r.nodeType === 1 && (r.textContent = "");
    const o = n(r, !1, cc(r));
    return r instanceof Element && (r.removeAttribute("v-cloak"), r.setAttribute("data-v-app", "")), o;
  }, t;
});
function cc(e) {
  if (e instanceof SVGElement)
    return "svg";
  if (typeof MathMLElement == "function" && e instanceof MathMLElement)
    return "mathml";
}
function uc(e) {
  return _e(e) ? document.querySelector(e) : e;
}
let Yr = 0;
function ze(e = "c") {
  Yr += 1;
  const t = Math.random().toString(36).slice(2, 8);
  return `${e}_${Date.now().toString(36)}_${Yr}_${t}`;
}
function Je() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
function sr(e) {
  return {
    sessionId: e,
    turnStatus: "idle",
    messages: [],
    error: null
  };
}
function fc(e) {
  return e.blocks.filter((t) => t.type === "text").map((t) => t.text).join("");
}
function dc(e) {
  return e.startsWith("debug.");
}
function be(e, t, n = {}) {
  return {
    protocolVersion: "1.0",
    type: e,
    timestamp: Je(),
    data: t,
    ...n
  };
}
const hc = {
  form: "form",
  text_question: "text_question",
  textquestion: "text_question",
  select: "select",
  choice: "choice",
  multi_select: "multi_select",
  multiselect: "multi_select",
  confirm: "confirm",
  table: "table",
  detail: "detail",
  card: "card",
  report: "report",
  summary_card: "summary_card",
  summarycard: "summary_card",
  list_card: "list_card",
  listcard: "list_card",
  output_card: "output_card",
  outputcard: "output_card",
  page_action: "page_action",
  pageaction: "page_action",
  custom: "custom"
}, wo = /* @__PURE__ */ new Set([
  "table",
  "detail",
  "card",
  "report",
  "summary_card",
  "list_card",
  "output_card"
]), pc = /* @__PURE__ */ new Set([
  "card_only",
  "text_and_card",
  "text_only"
]);
function Ve(e) {
  return !e || typeof e != "object" || Array.isArray(e) ? null : e;
}
function Be(e) {
  if (e == null) return;
  const t = String(e).trim();
  return t || void 0;
}
function So(e) {
  var n;
  const t = ((n = Be(e)) == null ? void 0 : n.toLowerCase().replace(/[\s-]+/g, "_")) || "custom";
  return hc[t] || t;
}
function gc(e) {
  if (!Array.isArray(e)) return;
  const t = [];
  for (const n of e) {
    const s = Ve(n);
    if (!s) continue;
    const r = Be(s.key) || Be(s.name) || Be(s.id);
    if (!r) continue;
    const i = Array.isArray(s.options) ? s.options.map((o) => {
      const a = Ve(o);
      return a ? {
        value: a.value ?? a.id ?? "",
        label: String(a.label ?? a.name ?? a.value ?? "")
      } : null;
    }).filter((o) => !!o) : void 0;
    t.push({
      key: r,
      name: Be(s.name),
      label: String(s.label ?? s.name ?? r),
      type: String(s.type ?? "string"),
      required: s.required === !0,
      targetPath: Be(s.targetPath),
      options: i,
      placeholder: Be(s.placeholder),
      source: Ve(s.source) || void 0
    });
  }
  return t.length ? t : void 0;
}
function mc(e) {
  if (!Array.isArray(e)) return;
  const t = [];
  for (const n of e) {
    const s = Ve(n);
    s && t.push({ ...s });
  }
  return t.length ? t : void 0;
}
function yc(e) {
  var s;
  const t = Ve(e);
  if (!t) return;
  const n = (s = Be(t.mode)) == null ? void 0 : s.toLowerCase().replace(/[\s-]+/g, "_");
  if (!(!n || !pc.has(n)))
    return { ...t, mode: n };
}
function bc(e, t, n) {
  const s = `${e}|${t || ""}|${n || ""}`.slice(0, 80);
  let r = 0;
  for (let i = 0; i < s.length; i += 1)
    r = (r << 5) - r + s.charCodeAt(i) | 0;
  return `local:readonly:${e}:${Math.abs(r).toString(36)}`;
}
function rr(e) {
  const t = Ve(e);
  if (!t) return null;
  const n = So(t.component ?? t.type), s = Be(t.title), r = Be(t.message);
  let i = Be(t.interactionId);
  i || (wo.has(n) ? i = bc(n, s, r) : i = ze("interaction"));
  const o = Ve(t.extension) || void 0, a = Ve(t.schema) || Ve(t.renderSchema) || Ve(o == null ? void 0 : o.renderSchema) || void 0;
  return {
    schemaVersion: "1.0",
    interactionId: i,
    traceId: Be(t.traceId),
    type: Be(t.type),
    component: n,
    title: s,
    message: r,
    ttlSeconds: typeof t.ttlSeconds == "number" ? t.ttlSeconds : void 0,
    expiresAt: Be(t.expiresAt),
    fields: gc(t.fields),
    prefilled: Ve(t.prefilled) || void 0,
    missing: Array.isArray(t.missing) ? t.missing.map(String) : void 0,
    summary: Ve(t.summary) || void 0,
    data: t.data,
    schema: a,
    actions: mc(t.actions),
    presentation: yc(t.presentation ?? (o == null ? void 0 : o.presentation)),
    datasources: Ve(t.datasources) || void 0,
    behavior: Ve(t.behavior) || void 0,
    extension: o
  };
}
function _c(e) {
  return wo.has(So(e));
}
function Io(e) {
  var t, n;
  return ((n = (t = rr(e)) == null ? void 0 : t.presentation) == null ? void 0 : n.mode) || "text_and_card";
}
function ir(e) {
  return Io(e) === "card_only";
}
function vc(e) {
  return Io(e) === "text_only";
}
function as(e) {
  var s;
  const t = rr(e);
  if (!t) return !1;
  const n = (s = t.behavior) == null ? void 0 : s.blocking;
  return typeof n == "boolean" ? n : !_c(t.component);
}
function Re(e) {
  return {
    ...e,
    messages: e.messages.map((t) => ({
      ...t,
      blocks: t.blocks.map((n) => ({ ...n })),
      metadata: t.metadata ? { ...t.metadata } : void 0,
      completion: t.completion ? { ...t.completion } : void 0
    })),
    metadata: e.metadata ? { ...e.metadata } : void 0
  };
}
function wc(e, t) {
  return e.id === t || e.transportMessageId === t;
}
function or(e) {
  for (let t = e.messages.length - 1; t >= 0; t -= 1) {
    const n = e.messages[t];
    if (n.role === "assistant" && (n.status === "streaming" || n.status === "pending"))
      return n;
  }
}
function Xr(e, t) {
  return or(e);
}
function Sc(e) {
  for (let t = e.messages.length - 1; t >= 0; t -= 1)
    if (e.messages[t].role === "assistant") return e.messages[t];
}
function Tt(e, t, n, s = {}) {
  if (t) {
    const o = e.messages.find((a) => wc(a, t));
    if (o && (o.status === "pending" || o.status === "streaming" || s.reuseCompleted))
      return n && (o.metadata = { ...o.metadata || {}, ...n }), o;
  }
  const r = or(e);
  if (r)
    return t && r.transportMessageId !== t && (r.transportMessageId = t), n && (r.metadata = { ...r.metadata || {}, ...n }), r;
  if (s.reuseCompleted) {
    const o = Sc(e);
    if (o)
      return n && (o.metadata = { ...o.metadata || {}, ...n }), o;
  }
  const i = {
    id: ze("msg"),
    role: "assistant",
    status: "streaming",
    blocks: [],
    createdAt: Je(),
    metadata: n,
    transportMessageId: t
  };
  return e.messages.push(i), i;
}
function Ao(e, t) {
  return e.blocks.find(
    (n) => n.type === "interaction" && n.request.interactionId === t
  );
}
function Qr(e, t) {
  if (!t || e.blocks.some((s) => s.type === "interaction" && ir(s.request))) return;
  const n = e.blocks[e.blocks.length - 1];
  if (n && n.type === "text" && n.status !== "completed")
    n.text += t, n.status = "streaming";
  else {
    const s = {
      id: ze("blk"),
      type: "text",
      text: t,
      status: "streaming"
    };
    e.blocks.push(s);
  }
  e.status = "streaming", e.updatedAt = Je();
}
function Zr(e, t, n = "waiting") {
  const s = rr(t);
  if (!s) return;
  if (vc(s)) {
    e.blocks = e.blocks.filter(
      (i) => i.type !== "interaction" || i.request.interactionId !== s.interactionId
    ), e.updatedAt = Je();
    return;
  }
  ir(s) && (e.blocks = e.blocks.filter((i) => i.type !== "text"));
  const r = Ao(e, s.interactionId);
  if (r) {
    r.request = s, (r.state === "waiting" || r.state === "failed") && (r.state = n), e.updatedAt = Je();
    return;
  }
  e.blocks.push({
    id: ze("blk"),
    type: "interaction",
    request: s,
    state: n
  }), e.updatedAt = Je();
}
function bs(e) {
  for (const t of e.blocks)
    t.type === "text" && t.status === "streaming" && (t.status = "completed");
}
function Qe(e, t) {
  switch (t.type) {
    case "reset":
      return sr(t.sessionId);
    case "restore":
      return Re(t.snapshot);
    case "set_session": {
      const n = Re(e);
      return n.sessionId = t.sessionId, n;
    }
    case "set_error": {
      const n = Re(e);
      return n.error = t.error, n;
    }
    case "append_user_message": {
      const n = Re(e);
      return n.messages.push({
        id: t.id || ze("msg"),
        role: "user",
        status: "completed",
        blocks: [{ id: ze("blk"), type: "text", text: t.text, status: "completed" }],
        createdAt: Je(),
        metadata: t.metadata
      }), n.error = null, n;
    }
    case "begin_assistant_placeholder": {
      const n = Re(e), s = or(n);
      return s && (!t.turnId || !s.turnId || s.turnId === t.turnId) ? (t.turnId && (s.turnId = t.turnId, n.turnId = t.turnId), n) : (n.messages.push({
        id: ze("msg"),
        role: "assistant",
        status: "pending",
        blocks: [],
        createdAt: Je(),
        turnId: t.turnId,
        localPlaceholder: !0
      }), t.turnId && (n.turnId = t.turnId), n.error = null, n);
    }
    case "start_assistant_message": {
      const n = Re(e), s = Tt(n, t.id, t.metadata);
      return s.status === "pending" && (s.status = "streaming"), s.updatedAt = Je(), n.turnStatus = n.turnStatus === "waiting" ? "waiting" : "streaming", n.error = null, n;
    }
    case "append_text_delta": {
      const n = Re(e), s = Tt(n, t.messageId);
      return Qr(s, t.text), (n.turnStatus === "idle" || n.turnStatus === "sending") && (n.turnStatus = "streaming"), n;
    }
    case "add_interaction": {
      const n = Re(e), s = Tt(n, t.messageId);
      return Zr(s, t.request, t.state || "waiting"), (n.turnStatus === "idle" || n.turnStatus === "sending") && (n.turnStatus = "streaming"), n;
    }
    case "update_interaction_state": {
      const n = Re(e);
      for (const s of n.messages) {
        const r = Ao(s, t.interactionId);
        if (r) {
          r.state = t.state, t.result && (r.result = t.result), t.errorMessage !== void 0 && (r.errorMessage = t.errorMessage), s.updatedAt = Je();
          break;
        }
      }
      return n;
    }
    case "add_notice": {
      const n = Re(e);
      return Tt(n, t.messageId).blocks.push({
        id: ze("blk"),
        type: "notice",
        level: t.level || "info",
        text: t.text
      }), n;
    }
    case "add_error_block": {
      const n = Re(e), s = Tt(n, t.messageId);
      return s.blocks.push({
        id: ze("blk"),
        type: "error",
        text: t.text,
        retryable: t.retryable
      }), s.status = "failed", n;
    }
    case "add_page_action": {
      const n = Re(e), s = Tt(n, t.messageId);
      return s.blocks.some(
        (i) => i.type === "page_action" && i.requestId === t.requestId
      ) || !t.requestId || s.blocks.push({
        id: ze("blk"),
        type: "page_action",
        requestId: t.requestId,
        actionKey: t.actionKey,
        title: t.title,
        args: t.args,
        status: "pending"
      }), n;
    }
    case "set_turn_status": {
      const n = Re(e);
      return n.turnStatus = t.status, n;
    }
    case "complete_turn": {
      const n = Re(e);
      t.sessionId && (n.sessionId = t.sessionId);
      const s = Tt(n, void 0, void 0, { reuseCompleted: !0 });
      t.answer && (s.blocks.some((o) => o.type === "text" && o.text) || Qr(s, t.answer)), t.uiRequest && Zr(s, t.uiRequest, as(t.uiRequest) ? "waiting" : "resolved"), bs(s);
      const r = s.blocks.some(
        (i) => i.type === "interaction" && i.state === "waiting"
      );
      return s.status = "completed", s.updatedAt = Je(), t.metadata && (s.metadata = { ...s.metadata || {}, ...t.metadata }, n.metadata = { ...n.metadata || {}, ...t.metadata }), t.completion && (s.completion = {
        ...s.completion || {},
        ...t.completion
      }), n.turnStatus = r ? "waiting" : "completed", n.error = null, n;
    }
    case "fail_turn": {
      const n = Re(e), s = Xr(n) || Tt(n);
      return bs(s), s.status = "failed", s.blocks.push({
        id: ze("blk"),
        type: "error",
        text: t.message,
        retryable: !0
      }), t.metadata && (s.metadata = { ...s.metadata || {}, ...t.metadata }, n.metadata = { ...n.metadata || {}, ...t.metadata }), s.updatedAt = Je(), n.turnStatus = "failed", n.error = t.message, n;
    }
    case "cancel_turn": {
      const n = Re(e), s = Xr(n);
      return s && (bs(s), s.status = "cancelled", s.updatedAt = Je()), n.turnStatus = "cancelled", n.error = null, n;
    }
    case "apply_event":
      return Ic(e, t.event);
    default:
      return e;
  }
}
function Ic(e, t) {
  const n = t.type, s = t.data && typeof t.data == "object" ? t.data : {}, r = t.turnId && e.turnId !== t.turnId ? { ...e, turnId: t.turnId } : e;
  switch (n) {
    case "session.created":
    case "session.restored":
      return n === "session.restored" && t.data && typeof t.data == "object" && "messages" in t.data ? Qe(r, { type: "restore", snapshot: t.data }) : Qe(r, { type: "set_session", sessionId: t.sessionId || Ae(s.sessionId) });
    case "turn.started":
      return Qe(r, { type: "set_turn_status", status: "sending" });
    case "message.started":
      return Qe(r, {
        type: "start_assistant_message",
        id: Ae(s.messageId)
      });
    case "message.delta": {
      const i = typeof s.text == "string" ? s.text : typeof t.data == "string" ? t.data : "";
      return Qe(r, {
        type: "append_text_delta",
        text: i,
        messageId: Ae(s.messageId)
      });
    }
    case "ui.requested":
      return Qe(r, {
        type: "add_interaction",
        request: s.uiRequest ?? t.data,
        state: as(s.uiRequest ?? t.data) ? "waiting" : "resolved",
        messageId: Ae(s.messageId)
      });
    case "page.action.requested":
      return Qe(r, {
        type: "add_page_action",
        requestId: String(s.requestId || ""),
        actionKey: String(s.actionKey || ""),
        title: Ae(s.title),
        args: s.args || void 0,
        messageId: Ae(s.messageId)
      });
    case "turn.waiting":
      return Qe(r, {
        type: "complete_turn",
        answer: Ae(s.answer),
        uiRequest: s.uiRequest,
        sessionId: t.sessionId || Ae(s.sessionId),
        metadata: _s(s.metadata, s.result),
        completion: {
          intentType: s.intentType,
          toolCalls: s.toolCalls,
          result: s.result
        }
      });
    case "turn.completed":
      return Qe(r, {
        type: "complete_turn",
        answer: Ae(s.answer),
        uiRequest: s.uiRequest,
        sessionId: t.sessionId || Ae(s.sessionId),
        metadata: {
          ..._s(s.metadata, s.result),
          ...t.traceId ? { traceId: t.traceId } : {},
          ...s.traceId ? { traceId: s.traceId } : {}
        },
        completion: {
          intentType: s.intentType,
          toolCalls: s.toolCalls,
          result: s.result
        }
      });
    case "turn.cancelled":
      return Qe(r, { type: "cancel_turn" });
    case "turn.failed": {
      const i = _s(s.metadata, s.result), o = t.traceId || Ae(s.traceId) || Ae(i.traceId), a = Ae(s.code) || Ae(i.code);
      return Qe(r, {
        type: "fail_turn",
        message: Ae(s.message) || Ae(s.error) || "对话失败",
        metadata: {
          ...i,
          success: !1,
          ...a ? { code: a } : {},
          ...o ? { traceId: o } : {},
          ...t.sessionId || Ae(s.sessionId) ? { sessionId: t.sessionId || Ae(s.sessionId) } : {}
        }
      });
    }
    default:
      return r;
  }
}
function Ae(e) {
  if (e == null) return;
  const t = String(e);
  return t || void 0;
}
function _s(e, t) {
  if (e && typeof e == "object" && !Array.isArray(e)) {
    const n = e;
    if (n.metadata && typeof n.metadata == "object" && !Array.isArray(n.metadata) && ("answer" in n || "uiRequest" in n || "sessionId" in n)) {
      const r = { ...n.metadata };
      return "success" in n && (r.success = n.success), n.code != null && (r.code = n.code), n.traceId != null && (r.traceId = n.traceId), r;
    }
    if (!("answer" in n) && !("uiRequest" in n))
      return { ...n };
    const s = {};
    if ("success" in n && (s.success = n.success), n.code != null && (s.code = n.code), n.traceId != null && (s.traceId = n.traceId), t && typeof t == "object" && !Array.isArray(t)) {
      const r = t.metadata;
      if (r && typeof r == "object" && !Array.isArray(r))
        return { ...r, ...s };
    }
    return s;
  }
  if (t && typeof t == "object" && !Array.isArray(t)) {
    const n = t, s = n.metadata, r = {};
    return "success" in n && (r.success = n.success), s && typeof s == "object" && !Array.isArray(s) ? { ...s, ...r } : r;
  }
  return {};
}
function Ac(e) {
  return sr(e);
}
function xc(e) {
  const t = e.trim();
  if (!t) return "";
  try {
    return JSON.parse(t);
  } catch {
    return e;
  }
}
function xo(e) {
  const n = e.replace(/\r\n/g, `
`).replace(/\r/g, `
`).split(`
`);
  let s = "message", r;
  const i = [];
  for (const a of n)
    if (!(!a || a.startsWith(":"))) {
      if (a.startsWith("event:")) {
        s = a.slice(6).trim();
        continue;
      }
      if (a.startsWith("id:")) {
        r = a.slice(3).trim();
        continue;
      }
      a.startsWith("data:") && i.push(a.slice(5).replace(/^ /, ""));
    }
  if (!i.length && s === "message") return null;
  const o = i.join(`
`);
  return {
    event: s,
    rawData: o,
    data: xc(o),
    id: r
  };
}
function Ec(e) {
  const t = [];
  let n = e.replace(/\r\n/g, `
`).replace(/\r/g, `
`), s = n.indexOf(`

`);
  for (; s >= 0; ) {
    const r = n.slice(0, s);
    n = n.slice(s + 2);
    const i = xo(r);
    i && t.push(i), s = n.indexOf(`

`);
  }
  return { frames: t, rest: n };
}
async function* Cc(e, t = {}) {
  const n = e.getReader(), s = new TextDecoder();
  let r = "";
  const i = t.signal, o = () => {
    if (i != null && i.aborted)
      throw new DOMException("The operation was aborted.", "AbortError");
  };
  try {
    for (; ; ) {
      o();
      const { done: a, value: l } = await n.read();
      if (a) break;
      o(), r += s.decode(l, { stream: !0 });
      const d = Ec(r);
      r = d.rest;
      for (const u of d.frames)
        yield u;
    }
    if (r += s.decode(), r.trim()) {
      const a = xo(r.trim());
      a && (yield a);
    }
  } finally {
    try {
      n.releaseLock();
    } catch {
    }
  }
}
function Vn(e) {
  return !e || typeof e != "object" ? !1 : e.name === "AbortError";
}
const kc = /* @__PURE__ */ new Set([
  "message.delta",
  "ui.requested",
  "page.action.requested",
  "turn.started",
  "turn.waiting",
  "turn.completed",
  "turn.failed",
  "turn.cancelled",
  "interaction.submitted",
  "interaction.cancelled"
]);
function Pc(e) {
  const { transport: t, onDebugEvent: n, onPublicEvent: s } = e;
  let r = Ac(e.initialSessionId);
  const i = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Set();
  let a = !1, l = null, d = 0, u;
  const h = /* @__PURE__ */ new Set(), v = /* @__PURE__ */ new Set(), M = /* @__PURE__ */ new Set();
  function I() {
    var S;
    (S = e.onChange) == null || S.call(e, r);
    for (const O of i) O(r);
  }
  function x(S) {
    r = Qe(r, S), I();
  }
  function N(S) {
    return S.turnId || !u ? S : { ...S, turnId: u };
  }
  function K(S) {
    if (!kc.has(S.type)) return !1;
    const O = S.data && typeof S.data == "object" ? S.data : {}, j = S.turnId || u || "";
    if (S.type === "message.delta")
      return !0;
    if (S.type === "page.action.requested") {
      const H = String(O.requestId || "");
      if (!H) return !0;
      const B = `page.action.requested:${H}`;
      return M.has(B) ? !1 : (M.add(B), !0);
    }
    if (S.type === "ui.requested") {
      const H = O.uiRequest, B = `ui.requested:${j}:${(H == null ? void 0 : H.interactionId) || JSON.stringify(O.uiRequest || "")}`;
      return v.has(B) ? !1 : (v.add(B), !0);
    }
    if (S.type === "turn.completed" || S.type === "turn.waiting" || S.type === "turn.failed" || S.type === "turn.cancelled") {
      const H = S.sessionId || (O.sessionId != null ? String(O.sessionId) : "") || r.sessionId || "", B = `${S.type}:${H}:${j}`;
      return h.has(B) ? !1 : (h.add(B), !0);
    }
    if (S.type === "interaction.submitted" || S.type === "interaction.cancelled") {
      const H = `${S.type}:${j}:${String(O.interactionId || "")}:${String(O.action || "")}`;
      return h.has(H) ? !1 : (h.add(H), !0);
    }
    return !0;
  }
  function b(S) {
    const O = N(S);
    K(O) && (s == null || s(O));
  }
  function D(S) {
    const O = N(S);
    if (dc(O.type)) {
      n == null || n(O);
      return;
    }
    if (O.type === "page.action.requested") {
      const j = O.data && typeof O.data == "object" ? O.data : {}, H = String(j.requestId || "");
      if (H) {
        const B = `page.action.requested:${H}`;
        if (M.has(B))
          return;
      }
    }
    b(O), x({ type: "apply_event", event: O });
  }
  async function T(S, O) {
    for await (const j of S) {
      if (a || O !== d) break;
      D(j);
    }
  }
  async function U(S, O) {
    var se, ne, ae, Y;
    if (a) return;
    const j = ++d;
    u = ze("turn"), O === "start" || ((se = S.uiSubmit) == null ? void 0 : se.action) !== "cancel" ? (l == null || l.abort(), l = new AbortController()) : (!l || l.signal.aborted) && (l = new AbortController());
    const H = l.signal;
    x({ type: "set_turn_status", status: "sending" }), x({ type: "set_error", error: null }), O === "start" && S.message && x({ type: "append_user_message", text: S.message }), (O === "start" || ((ne = S.uiSubmit) == null ? void 0 : ne.action) !== "cancel") && x({ type: "begin_assistant_placeholder", turnId: u });
    try {
      const Q = O === "resume" && t.resumeInteraction && S.interactionId ? t.resumeInteraction(
        S.interactionId,
        ((ae = S.uiSubmit) == null ? void 0 : ae.action) || "submit",
        ((Y = S.uiSubmit) == null ? void 0 : Y.values) || S.values || {},
        H
      ) : t.startTurn(S, H);
      if (await T(Q, j), j !== d) return;
      (r.turnStatus === "sending" || r.turnStatus === "streaming") && x({ type: "set_turn_status", status: "completed" });
    } catch (Q) {
      if (j !== d) return;
      if (Vn(Q) || H.aborted) {
        x({ type: "cancel_turn" }), b(be("turn.cancelled", {}, { sessionId: r.sessionId, turnId: u }));
        return;
      }
      const oe = Q instanceof Error ? Q.message : String(Q);
      x({ type: "fail_turn", message: oe }), b(be("turn.failed", { message: oe, error: oe }, {
        sessionId: r.sessionId,
        turnId: u
      }));
    }
  }
  return {
    getState() {
      return r;
    },
    subscribe(S) {
      return i.add(S), S(r), () => i.delete(S);
    },
    async send(S) {
      const O = typeof S == "string" ? { message: S } : S;
      !O.message && !O.values && !O.uiSubmit || await U(O, "start");
    },
    async submitInteraction(S, O, j = {}) {
      if (!S || o.has(S)) return;
      o.add(S);
      const H = O === "cancel";
      x({
        type: "update_interaction_state",
        interactionId: S,
        state: "submitting",
        result: { action: O, values: j }
      });
      try {
        await U(
          {
            interactionId: S,
            uiSubmit: { action: O, values: j },
            values: j,
            message: void 0
          },
          "resume"
        ), H && r.turnStatus === "cancelled" ? (x({
          type: "update_interaction_state",
          interactionId: S,
          state: "cancelled",
          result: { action: O, values: j }
        }), b(be(
          "interaction.cancelled",
          { interactionId: S, action: O, values: j },
          { sessionId: r.sessionId, turnId: u }
        ))) : r.turnStatus === "failed" ? x({
          type: "update_interaction_state",
          interactionId: S,
          state: "failed",
          errorMessage: r.error || "提交失败"
        }) : H ? (x({
          type: "update_interaction_state",
          interactionId: S,
          state: "cancelled",
          result: { action: O, values: j }
        }), b(be(
          "interaction.cancelled",
          { interactionId: S, action: O, values: j },
          { sessionId: r.sessionId, turnId: u }
        ))) : r.turnStatus === "cancelled" ? x({
          type: "update_interaction_state",
          interactionId: S,
          state: "cancelled",
          result: { action: O, values: j }
        }) : (x({
          type: "update_interaction_state",
          interactionId: S,
          state: "resolved",
          result: { action: O, values: j }
        }), b(be(
          "interaction.submitted",
          { interactionId: S, action: O, values: j },
          { sessionId: r.sessionId, turnId: u }
        )));
      } catch (B) {
        Vn(B) || r.turnStatus === "cancelled" ? x({
          type: "update_interaction_state",
          interactionId: S,
          state: "failed",
          errorMessage: "交互提交被中断"
        }) : x({
          type: "update_interaction_state",
          interactionId: S,
          state: "failed",
          errorMessage: B instanceof Error ? B.message : String(B)
        });
      } finally {
        o.delete(S);
      }
    },
    async cancel() {
      var S;
      d += 1, u = ze("turn"), l == null || l.abort(), l = null;
      try {
        await ((S = t.cancelTurn) == null ? void 0 : S.call(t));
      } catch {
      }
      x({ type: "cancel_turn" }), b(be("turn.cancelled", {}, { sessionId: r.sessionId, turnId: u }));
    },
    async clearSession() {
      var S;
      d += 1, u = void 0, l == null || l.abort(), l = null, await ((S = t.clearSession) == null ? void 0 : S.call(t)), h.clear(), v.clear(), M.clear(), x({ type: "reset", sessionId: void 0 });
    },
    async restore() {
      var O;
      const S = await ((O = t.restoreSession) == null ? void 0 : O.call(t));
      return S ? (x({ type: "restore", snapshot: S }), S) : null;
    },
    dispose() {
      a = !0, d += 1, u = void 0, l == null || l.abort(), l = null, i.clear(), h.clear(), v.clear(), M.clear(), t.dispose();
    }
  };
}
function ar(e) {
  return !e || typeof e != "object" || Array.isArray(e) ? null : e;
}
function Tc(e) {
  const t = ar(e);
  return t && "text" in t ? String(t.text ?? "") : typeof e == "string" ? e : "";
}
function Eo(e) {
  if (!e) return;
  const t = ar(e.metadata);
  if (t) return { ...t };
  if (!("answer" in e) && !("uiRequest" in e) && !("sessionId" in e) && !("toolCalls" in e))
    return { ...e };
}
function Rc(e, t, n, s) {
  const r = Eo(e || void 0);
  return {
    answer: s,
    sessionId: n,
    result: t,
    metadata: r,
    intentType: e == null ? void 0 : e.intentType,
    toolCalls: e == null ? void 0 : e.toolCalls,
    uiRequest: e == null ? void 0 : e.uiRequest
  };
}
function Co(e, t, n = {}) {
  const s = ar(t), r = n.sessionId || (s != null && s.sessionId ? String(s.sessionId) : void 0);
  switch (e) {
    case "message.delta": {
      const i = Tc(t);
      return i ? be("message.delta", { text: i }, { sessionId: r }) : null;
    }
    case "ui.requested":
      return be("ui.requested", {
        uiRequest: (s == null ? void 0 : s.uiRequest) ?? t
      }, { sessionId: r });
    case "page.action.requested":
      return be("page.action.requested", t, { sessionId: r });
    case "message.completed": {
      const i = (s == null ? void 0 : s.answer) != null ? String(s.answer) : void 0, o = s == null ? void 0 : s.uiRequest, a = Rc(s, t, r, i);
      return o ? [
        be("ui.requested", { uiRequest: o }, { sessionId: r }),
        be(as(o) ? "turn.waiting" : "turn.completed", a, { sessionId: r })
      ] : be("turn.completed", a, { sessionId: r });
    }
    case "error":
    case "execution.error": {
      const i = (s == null ? void 0 : s.message) != null ? String(s.message) : typeof t == "string" ? t : "Embed 对话失败";
      return be("turn.failed", { message: i, error: i }, { sessionId: r });
    }
    case "execution.started":
      return be("turn.started", s || {}, { sessionId: r });
    case "execution.completed":
      return Co("message.completed", t, n);
    case "supervisor.step":
    case "reasoning.delta":
      return null;
    default:
      return null;
  }
}
function* $c(e) {
  if (e) {
    if (Array.isArray(e)) {
      for (const t of e) yield t;
      return;
    }
    yield e;
  }
}
function Mc(e, t) {
  const n = typeof crypto < "u" && typeof crypto.randomUUID == "function" ? crypto.randomUUID().replace(/-/g, "") : `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`;
  return `${e}-${t}-${n}`;
}
function Oc(e) {
  return e === 404 || e === 405 || e === 415 || e === 501;
}
function Nc(e) {
  return !e || typeof e != "object" ? !1 : e.name === "AbortError";
}
function vs(e) {
  return e.aborted || Nc(e.error) || e.bytesOrEventsConsumed || e.status == null ? !1 : Oc(e.status);
}
function Lc(e) {
  const t = e.fetchImpl || fetch, n = e.preferStream !== !1;
  let s = !1;
  const r = /* @__PURE__ */ new Set();
  let i = null;
  function o(b) {
    const D = e.apiBase.replace(/\/$/, "");
    return b.startsWith("http") ? b : `${D}${b.startsWith("/") ? b : `/${b}`}`;
  }
  async function a(b, D, T) {
    const U = {
      "Content-Type": "application/json",
      ...D.headers
    }, S = e.tokenProvider();
    S && (U.Authorization = `Bearer ${S}`);
    let O = await t(b, { ...D, headers: U, signal: T });
    if (O.status === 401 && e.onUnauthorized) {
      const j = await e.onUnauthorized();
      if (typeof j == "string" && j)
        U.Authorization = `Bearer ${j}`;
      else {
        const H = e.tokenProvider();
        H && (U.Authorization = `Bearer ${H}`);
      }
      O = await t(b, { ...D, headers: U, signal: T });
    }
    return O;
  }
  function l(b, D) {
    const T = new Error(`${b}: HTTP ${D}`);
    return T.status = D, T;
  }
  async function d(b) {
    if (s) throw new Error("Embed transport disposed");
    const D = e.getSessionId();
    return D || (i || (i = (async () => {
      var H, B;
      const T = e.sessionsPath || "/chat/sessions", U = await a(o(T), {
        method: "POST",
        body: JSON.stringify(((H = e.createSessionPayload) == null ? void 0 : H.call(e)) || { context: (B = e.getContext) == null ? void 0 : B.call(e) })
      }, b);
      if (!U.ok)
        throw l("Embed session create failed", U.status);
      const S = await U.json().catch(() => ({})), O = S.data && typeof S.data == "object" ? S.data : S, j = O.sessionId ? String(O.sessionId) : O.id ? String(O.id) : void 0;
      if (!j) throw new Error("Embed session create returned no sessionId");
      return e.setSessionId(j), j;
    })().finally(() => {
      i = null;
    })), i);
  }
  async function u(b) {
    return e.setSessionId(void 0), d(b);
  }
  async function* h(b, D, T) {
    if (!b.body) throw new Error("Embed stream has no body");
    for await (const U of Cc(b.body, { signal: T })) {
      const S = Co(U.event, U.data, { sessionId: D });
      for (const O of $c(S))
        yield O;
    }
  }
  function* v(b, D) {
    yield be("turn.started", {}, { sessionId: D }), b.answer && !ir(b.uiRequest) && (yield be("message.delta", { text: String(b.answer) }, { sessionId: D }));
    const T = b.metadata && typeof b.metadata == "object" && !Array.isArray(b.metadata) ? { ...b.metadata } : void 0;
    b.uiRequest ? (yield be("ui.requested", { uiRequest: b.uiRequest }, { sessionId: D }), yield be(as(b.uiRequest) ? "turn.waiting" : "turn.completed", {
      answer: b.answer,
      uiRequest: b.uiRequest,
      sessionId: D,
      result: b,
      metadata: T,
      intentType: b.intentType,
      toolCalls: b.toolCalls
    }, { sessionId: D })) : yield be("turn.completed", {
      answer: b.answer,
      sessionId: D,
      result: b,
      metadata: T,
      intentType: b.intentType,
      toolCalls: b.toolCalls
    }, { sessionId: D });
  }
  async function* M(b, D, T, U = !0) {
    var B, se;
    const S = ((B = e.messagesJsonPath) == null ? void 0 : B.call(e, b)) || `/chat/sessions/${encodeURIComponent(b)}/messages`, O = await a(o(S), {
      method: "POST",
      body: JSON.stringify({
        message: D.message,
        context: (se = e.getContext) == null ? void 0 : se.call(e),
        interactionId: D.interactionId,
        uiSubmit: D.uiSubmit
      })
    }, T);
    if (O.status === 401 && U) {
      const ne = await u(T);
      yield* M(ne, D, T, !1);
      return;
    }
    if (!O.ok)
      throw l("Embed message failed", O.status);
    const j = await O.json().catch(() => ({})), H = j.data && typeof j.data == "object" ? j.data : j;
    yield* v(H, b);
  }
  async function* I(b, D, T, U = !0) {
    var H, B;
    const S = ((H = e.messagesPath) == null ? void 0 : H.call(e, b)) || `/chat/sessions/${encodeURIComponent(b)}/messages/stream`, O = await a(o(S), {
      method: "POST",
      headers: { Accept: "text/event-stream" },
      body: JSON.stringify({
        message: D.message,
        context: (B = e.getContext) == null ? void 0 : B.call(e),
        interactionId: D.interactionId,
        uiSubmit: D.uiSubmit
      })
    }, T);
    if (O.status === 401 && U) {
      const se = await u(T);
      yield* I(se, D, T, !1);
      return;
    }
    const j = O.headers.get("content-type") || "";
    if (!O.ok || !O.body || !j.includes("text/event-stream")) {
      if (vs({
        status: O.status,
        bytesOrEventsConsumed: !1,
        aborted: T == null ? void 0 : T.aborted
      })) {
        yield* M(b, D, T, U);
        return;
      }
      throw l("Embed stream failed", O.status);
    }
    yield be("turn.started", {}, { sessionId: b }), yield* h(O, b, T);
  }
  async function* x(b, D) {
    if (s) return;
    const T = new AbortController();
    r.add(T);
    const U = () => T.abort();
    D == null || D.addEventListener("abort", U);
    try {
      const S = await d(T.signal);
      if (!n) {
        yield* M(S, b, T.signal);
        return;
      }
      yield* I(S, b, T.signal);
    } catch (S) {
      if (Vn(S) || T.signal.aborted) {
        yield be("turn.cancelled", {}, { sessionId: e.getSessionId() });
        return;
      }
      throw S;
    } finally {
      D == null || D.removeEventListener("abort", U), r.delete(T);
    }
  }
  async function* N(b, D, T, U, S, O) {
    var ne, ae;
    const j = ((ne = e.interactionSubmitPath) == null ? void 0 : ne.call(e, b, D)) || `/chat/sessions/${encodeURIComponent(b)}/interactions/${encodeURIComponent(D)}/submit`, H = await a(o(j), {
      method: "POST",
      body: JSON.stringify({
        action: T,
        values: U,
        idempotencyKey: S,
        context: (ae = e.getContext) == null ? void 0 : ae.call(e)
      })
    }, O);
    if (!H.ok)
      throw l("Embed interaction submit failed", H.status);
    const B = await H.json().catch(() => ({})), se = B.data && typeof B.data == "object" ? B.data : B;
    yield* v(se, b);
  }
  async function* K(b, D, T, U) {
    var B, se;
    if (s) return;
    const S = e.getSessionId();
    if (!S) throw new Error("No embed session");
    const O = Mc("embed", b);
    if (!n) {
      yield* N(S, b, D, T, O, U);
      return;
    }
    const j = ((B = e.interactionSubmitStreamPath) == null ? void 0 : B.call(e, S, b)) || `/chat/sessions/${encodeURIComponent(S)}/interactions/${encodeURIComponent(b)}/submit/stream`;
    let H = !1;
    try {
      const ne = await a(o(j), {
        method: "POST",
        headers: { Accept: "text/event-stream" },
        body: JSON.stringify({
          action: D,
          values: T,
          idempotencyKey: O,
          context: (se = e.getContext) == null ? void 0 : se.call(e)
        })
      }, U), ae = ne.headers.get("content-type") || "";
      if (ne.ok && ne.body && ae.includes("text/event-stream")) {
        yield be("turn.started", {}, { sessionId: S }), H = !0, yield* h(ne, S, U);
        return;
      }
      if (vs({
        status: ne.status,
        bytesOrEventsConsumed: !1,
        aborted: U == null ? void 0 : U.aborted
      })) {
        yield* N(S, b, D, T, O, U);
        return;
      }
      throw l("Embed interaction stream failed", ne.status);
    } catch (ne) {
      if (Vn(ne) || U != null && U.aborted) {
        yield be("turn.cancelled", {}, { sessionId: S });
        return;
      }
      if (vs({
        status: ne == null ? void 0 : ne.status,
        bytesOrEventsConsumed: H,
        aborted: U == null ? void 0 : U.aborted,
        error: ne
      })) {
        yield* N(S, b, D, T, O, U);
        return;
      }
      throw ne;
    }
  }
  return {
    kind: "embed",
    capabilities: {
      eventStreaming: n,
      tokenStreaming: !0,
      abort: !0,
      restore: !1,
      structuredInitialInput: !1,
      pageActions: !0
    },
    startTurn: x,
    resumeInteraction: K,
    /** 供 facade / 测试显式预热会话（带去重） */
    ensureSession: d,
    async cancelTurn() {
      for (const b of r) b.abort();
      r.clear();
    },
    dispose() {
      s = !0, i = null;
      for (const b of r) b.abort();
      r.clear();
    }
  };
}
const qc = /* @__PURE__ */ new Map(), Dc = {
  form: "form",
  text_question: "form",
  select: "select",
  choice: "select",
  multi_select: "select",
  confirm: "confirm",
  table: "table",
  detail: "detail",
  card: "output_card",
  report: "output_card",
  summary_card: "summary_card",
  list_card: "list_card",
  output_card: "output_card",
  page_action: "page_action",
  custom: "custom"
};
function Fc(e) {
  const t = String(e || "custom").toLowerCase();
  return Dc[t] || "custom";
}
function jc(e) {
  if (e)
    return qc.get(e);
}
const Kc = /* @__PURE__ */ new Set(["__proto__", "prototype", "constructor"]), Uc = /* @__PURE__ */ new Set(["neutral", "success", "warning", "danger", "info"]);
function Nt(e) {
  return !e || typeof e != "object" || Array.isArray(e) ? null : e;
}
function Ye(e) {
  return e == null ? void 0 : String(e).trim() || void 0;
}
function ko(e, t, n, s) {
  const r = typeof e == "number" ? e : Number(e);
  return Number.isFinite(r) ? Math.min(s, Math.max(n, Math.floor(r))) : t;
}
function Hc(e) {
  const t = e.trim().replace(/^\$\.?/, "").replace(/\[\s*["']?([^\]"']+)["']?\s*\]/g, ".$1").replace(/^\./, "");
  if (!t) return [];
  const n = t.split(".").filter(Boolean);
  return n.some((s) => Kc.has(s)) ? [] : n;
}
function At(e, t) {
  if (!(t != null && t.trim())) return e;
  const n = Hc(t);
  if (!n.length) return;
  let s = e;
  for (const r of n) {
    if (Array.isArray(s)) {
      const o = Number(r);
      if (!Number.isInteger(o) || o < 0 || o >= s.length) return;
      s = s[o];
      continue;
    }
    const i = Nt(s);
    if (!i || !Object.prototype.hasOwnProperty.call(i, r)) return;
    s = i[r];
  }
  return s;
}
function Vc(e) {
  var n;
  const t = Nt(e.schema);
  return t || Nt((n = e.extension) == null ? void 0 : n.renderSchema) || {};
}
function Bc(e, t) {
  const n = Ye(t.itemsPath ?? t.dataPath), s = n ? At(e, n) : void 0, r = Array.isArray(s) ? s : Array.isArray(e) ? e : [
    "records",
    "items",
    "rows",
    "list",
    "data.records",
    "data.items",
    "data.rows",
    "data.list",
    "data"
  ].map((o) => At(e, o)).find(Array.isArray);
  if (Array.isArray(r))
    return r.map((o) => Nt(o) || { value: o });
  const i = Nt(e);
  return i ? [i] : [];
}
function Wc(e, t, n) {
  const s = Ye(t.totalPath ?? t.totalField), r = s ? [At(e, s)] : ["total", "totalCount", "data.total", "data.totalCount", "pagination.total"].map((i) => At(e, i));
  for (const i of r) {
    const o = Number(i);
    if (Number.isFinite(o) && o >= 0) return Math.floor(o);
  }
  return n;
}
function lr(e) {
  const t = Nt(e);
  return t ? Object.fromEntries(
    Object.entries(t).filter(([, n]) => n != null).map(([n, s]) => [n, String(s)])
  ) : {};
}
function zc(e) {
  const t = lr(e);
  return Object.fromEntries(
    Object.entries(t).map(([n, s]) => [n, s.toLowerCase()]).filter((n) => Uc.has(n[1]))
  );
}
function Jc(e) {
  return Array.isArray(e.fields) ? e.fields.flatMap((t) => {
    if (typeof t == "string" && t.trim())
      return [{
        key: t.trim(),
        label: t.trim(),
        valueMap: {},
        separator: "、",
        hideWhenEmpty: !1
      }];
    const n = Nt(t), s = Ye((n == null ? void 0 : n.key) ?? (n == null ? void 0 : n.field) ?? (n == null ? void 0 : n.name));
    return !n || !s || n.hidden === !0 ? [] : [{
      key: s,
      label: Ye(n.label ?? n.title) || s,
      valueMap: lr(n.valueMap ?? n.labels),
      maxItems: n.maxItems == null ? void 0 : ko(n.maxItems, 3, 1, 20),
      separator: Ye(n.separator) || "、",
      hideWhenEmpty: n.hideWhenEmpty === !0
    }];
  }) : [];
}
function Gc(e) {
  const t = Nt(e.status) || {}, n = Ye(t.field ?? e.statusField ?? e.badgeField);
  return n ? {
    field: n,
    valueMap: lr(t.valueMap ?? t.labels ?? e.statusMap),
    toneMap: zc(t.toneMap ?? t.tones ?? e.statusToneMap)
  } : null;
}
function Po(e, t) {
  const n = String(e);
  return t[n] ?? t[n.toLowerCase()];
}
function pn(e, t) {
  if (e == null || e === "") return "-";
  const n = Po(e, (t == null ? void 0 : t.valueMap) || {});
  if (n != null) return n;
  if (Array.isArray(e)) {
    const s = (t == null ? void 0 : t.maxItems) ?? e.length, r = e.slice(0, s).map((o) => pn(o)), i = e.length - r.length;
    return `${r.join((t == null ? void 0 : t.separator) || "、")}${i > 0 ? `… +${i}` : ""}`;
  }
  if (typeof e == "object")
    try {
      return JSON.stringify(e);
    } catch {
      return String(e);
    }
  return String(e);
}
function Yc(e) {
  for (const n of ["title", "name", "displayName", "label"])
    if (Ye(e[n])) return n;
  const t = Object.keys(e).find((n) => /(?:name|title|label)$/i.test(n) && Ye(e[n]));
  return t || Object.keys(e).find((n) => typeof e[n] == "string" && Ye(e[n]));
}
function Xc(e, t) {
  return Object.keys(e).filter((n) => !t.has(n)).slice(0, 4).map((n) => ({
    key: n,
    label: n,
    valueMap: {},
    separator: "、",
    hideWhenEmpty: !1
  }));
}
function Qc(e, t, n) {
  const s = t ? At(e, t) : e.id ?? e.key ?? e.code;
  return s == null || s === "" ? `list-item-${n}` : String(s);
}
function Zc(e, t) {
  if (!t) return;
  const n = At(e, t.field);
  if (!(n == null || n === ""))
    return {
      label: Po(n, t.valueMap) || pn(n),
      tone: t.toneMap[String(n)] ?? t.toneMap[String(n).toLowerCase()] ?? "neutral"
    };
}
function eu(e) {
  const t = Vc(e), n = Bc(e.data, t), s = Jc(t), r = Gc(t), i = Ye(t.titleField), o = Ye(t.subtitleField), a = Ye(t.itemKey ?? t.rowKey), l = n.map((d, u) => {
    const h = i || Yc(d), v = new Set(
      [h, o, r == null ? void 0 : r.field, a].filter((I) => !!I)
    ), M = s.length ? s : Xc(d, v);
    return {
      key: Qc(d, a, u),
      title: h ? pn(At(d, h)) : `#${u + 1}`,
      subtitle: o ? pn(At(d, o)) : void 0,
      status: Zc(d, r),
      fields: M.flatMap((I) => {
        const x = At(d, I.key);
        return I.hideWhenEmpty && (x == null || x === "") ? [] : [{ key: I.key, label: I.label, value: pn(x, I) }];
      })
    };
  });
  return {
    items: l,
    total: Wc(e.data, t, l.length),
    initialVisibleCount: ko(t.initialVisibleCount, 5, 1, 50),
    showCount: t.showCount !== !1,
    emptyText: Ye(t.emptyText) || "暂无数据"
  };
}
const tu = ["aria-label"], nu = {
  key: 0,
  class: "reachai-interaction__header"
}, su = { key: 0 }, ru = {
  key: 1,
  class: "reachai-interaction__badge"
}, iu = {
  key: 1,
  class: "reachai-interaction__message"
}, ou = {
  key: 2,
  class: "reachai-interaction__state",
  "aria-live": "polite"
}, au = { key: 0 }, lu = ["onUpdate:modelValue", "disabled"], cu = ["onUpdate:modelValue", "disabled", "placeholder"], uu = ["value", "multiple", "disabled", "onChange"], fu = ["value"], du = ["onUpdate:modelValue", "disabled"], hu = ["value", "disabled", "placeholder", "onInput"], pu = ["value", "disabled", "placeholder", "onInput"], gu = {
  key: 0,
  class: "reachai-interaction__actions"
}, mu = ["disabled"], yu = ["disabled"], bu = {
  key: 5,
  class: "reachai-interaction__confirm"
}, _u = {
  key: 0,
  class: "reachai-interaction__actions"
}, vu = ["disabled"], wu = ["disabled"], Su = ["disabled"], Iu = {
  key: 6,
  class: "reachai-interaction__choice"
}, Au = ["value", "disabled"], xu = ["name", "value", "disabled"], Eu = {
  key: 0,
  class: "reachai-interaction__actions"
}, Cu = ["disabled"], ku = ["disabled"], Pu = {
  key: 7,
  class: "reachai-interaction__table-wrap"
}, Tu = { class: "reachai-interaction__table" }, Ru = {
  key: 8,
  class: "reachai-interaction__detail"
}, $u = {
  key: 0,
  class: "reachai-interaction__actions"
}, Mu = ["disabled", "onClick"], Ou = {
  key: 9,
  class: "reachai-interaction__list"
}, Nu = {
  key: 0,
  class: "reachai-interaction__list-summary"
}, Lu = {
  key: 1,
  class: "reachai-interaction__empty"
}, qu = { class: "reachai-interaction__list-item-header" }, Du = { class: "reachai-interaction__list-title" }, Fu = { key: 0 }, ju = {
  key: 0,
  class: "reachai-interaction__list-fields"
}, Ku = ["aria-expanded"], Uu = {
  key: 10,
  class: "reachai-interaction__page-action"
}, Hu = { class: "reachai-interaction__actions" }, Vu = ["disabled"], Bu = ["disabled"], Wu = {
  key: 11,
  class: "reachai-interaction__custom"
}, zu = { class: "reachai-interaction__warn" }, Ju = { class: "reachai-interaction__actions" }, Gu = ["disabled"], Yu = ["disabled"], Xu = {
  key: 12,
  class: "reachai-interaction__error",
  role: "alert"
}, Qu = {
  key: 13,
  class: "reachai-interaction__actions"
}, Zu = /* @__PURE__ */ gt({
  __name: "UnifiedInteractionRenderer",
  props: {
    request: {},
    state: {},
    errorMessage: {},
    disabled: { type: Boolean }
  },
  emits: ["submit", "cancel", "action"],
  setup(e, { emit: t }) {
    const n = e, s = t, r = le(() => Fc(n.request.component)), i = le(() => n.state || "waiting"), o = le(
      () => n.disabled || i.value === "submitting" || i.value === "resolved" || i.value === "expired" || i.value === "cancelled"
    ), a = le(() => `reachai-choice-${n.request.interactionId || "default"}`), l = /* @__PURE__ */ Se(""), d = /* @__PURE__ */ Se(!1), u = le(() => n.request.actions || []), h = le(() => {
      var L;
      return ((L = n.request.behavior) == null ? void 0 : L.readonly) === !0 ? !0 : (/* @__PURE__ */ new Set(["table", "detail", "summary_card", "list_card", "output_card", "card", "report"])).has(r.value) && !u.value.length;
    }), v = le(() => !h.value), M = le(() => {
      switch (i.value) {
        case "submitting":
          return "提交中…";
        case "resolved":
          return "已提交";
        case "failed":
          return "提交失败";
        case "expired":
          return "已过期";
        case "cancelled":
          return "已取消";
        default:
          return "";
      }
    }), I = /* @__PURE__ */ es({}), x = /* @__PURE__ */ Se(null), N = /* @__PURE__ */ Se([]), K = /* @__PURE__ */ Se(null);
    function b(R, L) {
      return R == null ? L.type === "boolean" ? !1 : L.type === "multi_select" ? [] : "" : typeof R == "string" || typeof R == "number" || typeof R == "boolean" ? R : Array.isArray(R) ? R.map(String) : String(R);
    }
    Kt(
      () => n.request,
      (R) => {
        var g, c, f, y;
        l.value = "", d.value = !1, Object.keys(I).forEach((E) => delete I[E]);
        for (const E of R.fields || []) {
          const k = (g = R.prefilled) == null ? void 0 : g[E.key];
          I[E.key] = b(k, E);
        }
        const L = (c = R.fields) == null ? void 0 : c[0], C = L == null ? void 0 : L.key, m = C && ((f = R.prefilled) == null ? void 0 : f[C]) !== void 0 ? R.prefilled[C] : (y = R.prefilled) == null ? void 0 : y.value;
        if (R.component === "multi_select") {
          Array.isArray(m) ? N.value = [...m] : m == null ? N.value = [] : N.value = [m], x.value = null;
          return;
        }
        m !== void 0 && (typeof m == "string" || typeof m == "number" || typeof m == "boolean" ? x.value = m : m == null ? x.value = null : x.value = String(m));
      },
      { immediate: !0, deep: !0 }
    );
    function D(R) {
      var L;
      return R.type === "select" || R.type === "multi_select" || !!((L = R.options) != null && L.length);
    }
    function T(R) {
      const L = I[R.key];
      return R.type === "multi_select" ? Array.isArray(L) ? L.map(String) : [] : typeof L == "string" || typeof L == "number" ? L : L == null ? void 0 : String(L);
    }
    function U(R, L) {
      const C = L.target;
      R.type === "multi_select" ? I[R.key] = Array.from(C.selectedOptions).map((m) => m.value) : I[R.key] = C.value;
    }
    const S = le(() => {
      var C, m;
      const R = (C = n.request.fields) == null ? void 0 : C[0];
      if ((m = R == null ? void 0 : R.options) != null && m.length) return R.options;
      const L = n.request.data;
      return Array.isArray(L) ? L.map((g, c) => {
        if (g && typeof g == "object") {
          const f = g;
          return { value: f.value ?? f.id ?? c, label: String(f.label ?? f.name ?? f.value ?? c) };
        }
        return { value: g, label: String(g) };
      }) : [];
    }), O = le(() => {
      const R = n.request.data;
      return Array.isArray(R) ? R.map((L) => L && typeof L == "object" ? L : { value: L }) : R && typeof R == "object" ? [R] : n.request.summary ? [n.request.summary] : [];
    }), j = le(() => {
      const R = se(n.request);
      if (R.length) return R;
      const L = O.value[0];
      return L ? Object.keys(L).map((C) => ({ key: C, label: C })) : [];
    }), H = le(() => eu(n.request)), B = le(() => d.value ? H.value.items : H.value.items.slice(0, H.value.initialVisibleCount));
    function se(R) {
      var C, m;
      const L = [
        (C = R.schema) == null ? void 0 : C.columns,
        (m = R.extension) == null ? void 0 : m.columns,
        R.data && typeof R.data == "object" && !Array.isArray(R.data) ? R.data.columns : void 0
      ];
      for (const g of L)
        if (!(!Array.isArray(g) || !g.length))
          return g.map((c, f) => {
            if (typeof c == "string") return { key: c, label: c };
            if (c && typeof c == "object") {
              const y = c, E = String(y.key ?? y.field ?? y.name ?? f);
              return { key: E, label: String(y.label ?? y.title ?? E) };
            }
            return { key: String(f), label: String(c) };
          });
      return [];
    }
    const ne = le(() => {
      const R = n.request.summary || n.request.data || {};
      return Array.isArray(R) ? R.map((L, C) => ({
        key: String(C),
        label: `#${C + 1}`,
        value: L
      })) : Object.entries(R || {}).map(([L, C]) => ({ key: L, label: L, value: C }));
    }), ae = le(() => {
      var L;
      const R = (L = n.request.extension) == null ? void 0 : L.pageActionRequest;
      return R && typeof R == "object" ? R : n.request.data && typeof n.request.data == "object" ? n.request.data : {};
    }), Y = le(
      () => String(ae.value.title || n.request.title || "页面动作")
    ), Q = le(
      () => {
        var R;
        return (R = n.request.extension) != null && R.rendererKey ? String(n.request.extension.rendererKey) : "";
      }
    ), oe = le(() => {
      const R = Q.value;
      if (!R) return null;
      const L = jc(R);
      if (!L) return null;
      const C = L({
        request: n.request,
        state: i.value,
        disabled: o.value,
        onSubmit: (m, g) => de(m, g),
        onCancel: () => De()
      });
      return C ? /* @__PURE__ */ gt({
        name: `ReachAiCustomInteraction_${R}`,
        setup() {
          return () => Ml(C);
        }
      }) : null;
    });
    function re(R) {
      if (R == null) return "-";
      if (typeof R == "string") return R;
      try {
        return JSON.stringify(R);
      } catch {
        return String(R);
      }
    }
    function te(R) {
      return String(R.key || R.action || "submit");
    }
    function Ie(R) {
      return String(R.label || R.key || R.action || "提交");
    }
    function Xe(R) {
      return R.values && typeof R.values == "object" ? R.values : { ...R };
    }
    function Ee(R) {
      return R.type === "primary" || te(R) === "confirm" || te(R) === "submit";
    }
    function de(R, L) {
      o.value && i.value !== "failed" || (K.value = { action: R, values: L }, s("submit", R, L), s("action", R, L));
    }
    function Te(R) {
      for (const L of n.request.fields || [])
        if (L.required) {
          const C = I[L.key];
          if (C === "" || C == null || Array.isArray(C) && !C.length) {
            l.value = `请填写必填项：${L.label || L.key}`;
            return;
          }
        }
      l.value = "", de(R, { ...I });
    }
    function tt() {
      var R, L;
      if (n.request.component === "multi_select") {
        if (!N.value.length && ((R = n.request.fields) != null && R.some((C) => C.required))) {
          l.value = "请至少选择一项";
          return;
        }
        l.value = "", de("choose", { value: [...N.value] });
      } else {
        if ((x.value === null || x.value === "") && ((L = n.request.fields) != null && L.some((C) => C.required))) {
          l.value = "请选择一项";
          return;
        }
        l.value = "", de("choose", { value: x.value });
      }
    }
    function De() {
      o.value || (s("cancel"), s("action", "cancel", {}));
    }
    function Fe() {
      K.value && (s("submit", K.value.action, K.value.values), s("action", K.value.action, K.value.values));
    }
    return (R, L) => {
      var C, m;
      return $(), q("div", {
        class: Oe(["reachai-interaction", [
          `reachai-interaction--${r.value}`,
          `reachai-interaction--${i.value}`,
          { "is-disabled": o.value }
        ]]),
        role: "region",
        "aria-label": e.request.title || e.request.component || "interaction"
      }, [
        e.request.title || (C = e.request.missing) != null && C.length ? ($(), q("header", nu, [
          e.request.title ? ($(), q("strong", su, X(e.request.title), 1)) : Z("", !0),
          (m = e.request.missing) != null && m.length ? ($(), q("span", ru, "待补充 " + X(e.request.missing.length) + " 项", 1)) : Z("", !0)
        ])) : Z("", !0),
        e.request.message && r.value !== "form" ? ($(), q("p", iu, X(e.request.message), 1)) : Z("", !0),
        M.value ? ($(), q("div", ou, X(M.value), 1)) : Z("", !0),
        oe.value ? ($(), mt(za(oe.value), {
          key: 3,
          class: "reachai-interaction__custom-host"
        })) : r.value === "form" ? ($(), q("form", {
          key: 4,
          class: "reachai-interaction__form",
          onSubmit: L[0] || (L[0] = _o((g) => Te("submit"), ["prevent"]))
        }, [
          ($(!0), q(ye, null, He(e.request.fields || [], (g) => ($(), q("label", {
            key: g.key,
            class: "reachai-interaction__field"
          }, [
            V("span", null, [
              vn(X(g.label), 1),
              g.required ? ($(), q("em", au, "*")) : Z("", !0)
            ]),
            g.type === "boolean" ? zt(($(), q("input", {
              key: 0,
              "onUpdate:modelValue": (c) => I[g.key] = c,
              type: "checkbox",
              disabled: o.value
            }, null, 8, lu)), [
              [zr, I[g.key]]
            ]) : g.type === "number" || g.type === "integer" ? zt(($(), q("input", {
              key: 1,
              "onUpdate:modelValue": (c) => I[g.key] = c,
              type: "number",
              disabled: o.value,
              placeholder: g.placeholder
            }, null, 8, cu)), [
              [
                Os,
                I[g.key],
                void 0,
                { number: !0 }
              ]
            ]) : D(g) ? ($(), q("select", {
              key: 2,
              value: T(g),
              multiple: g.type === "multi_select",
              disabled: o.value,
              onChange: (c) => U(g, c)
            }, [
              ($(!0), q(ye, null, He(g.options || [], (c) => ($(), q("option", {
                key: String(c.value),
                value: c.value
              }, X(c.label), 9, fu))), 128))
            ], 40, uu)) : g.type === "date" ? zt(($(), q("input", {
              key: 3,
              "onUpdate:modelValue": (c) => I[g.key] = c,
              type: "date",
              disabled: o.value
            }, null, 8, du)), [
              [Os, I[g.key]]
            ]) : g.type === "textarea" || g.type === "object" || g.type === "array" ? ($(), q("textarea", {
              key: 4,
              value: String(I[g.key] ?? ""),
              rows: "3",
              disabled: o.value,
              placeholder: g.placeholder,
              onInput: (c) => I[g.key] = c.target.value
            }, null, 40, hu)) : ($(), q("input", {
              key: 5,
              value: String(I[g.key] ?? ""),
              type: "text",
              disabled: o.value,
              placeholder: g.placeholder,
              onInput: (c) => I[g.key] = c.target.value
            }, null, 40, pu))
          ]))), 128)),
          v.value ? ($(), q("div", gu, [
            V("button", {
              type: "button",
              disabled: o.value,
              onClick: De
            }, "取消", 8, mu),
            V("button", {
              type: "submit",
              class: "is-primary",
              disabled: o.value
            }, "提交", 8, yu)
          ])) : Z("", !0)
        ], 32)) : r.value === "confirm" ? ($(), q("div", bu, [
          V("p", null, X(e.request.message || "请确认是否继续。"), 1),
          v.value ? ($(), q("div", _u, [
            V("button", {
              type: "button",
              disabled: o.value,
              onClick: De
            }, "取消", 8, vu),
            V("button", {
              type: "button",
              disabled: o.value,
              onClick: L[1] || (L[1] = (g) => de("reject", { confirm: !1 }))
            }, "拒绝", 8, wu),
            V("button", {
              type: "button",
              class: "is-primary",
              disabled: o.value,
              onClick: L[2] || (L[2] = (g) => de("confirm", { confirm: !0 }))
            }, "确认", 8, Su)
          ])) : Z("", !0)
        ])) : r.value === "select" ? ($(), q("div", Iu, [
          ($(!0), q(ye, null, He(S.value, (g) => ($(), q("label", {
            key: String(g.value),
            class: "reachai-interaction__option"
          }, [
            e.request.component === "multi_select" ? zt(($(), q("input", {
              key: 0,
              "onUpdate:modelValue": L[3] || (L[3] = (c) => N.value = c),
              type: "checkbox",
              value: g.value,
              disabled: o.value
            }, null, 8, Au)), [
              [zr, N.value]
            ]) : zt(($(), q("input", {
              key: 1,
              "onUpdate:modelValue": L[4] || (L[4] = (c) => x.value = c),
              type: "radio",
              name: a.value,
              value: g.value,
              disabled: o.value
            }, null, 8, xu)), [
              [rc, x.value]
            ]),
            V("span", null, X(g.label), 1)
          ]))), 128)),
          v.value ? ($(), q("div", Eu, [
            V("button", {
              type: "button",
              disabled: o.value,
              onClick: De
            }, "取消", 8, Cu),
            V("button", {
              type: "button",
              class: "is-primary",
              disabled: o.value,
              onClick: tt
            }, "选择", 8, ku)
          ])) : Z("", !0)
        ])) : r.value === "table" ? ($(), q("div", Pu, [
          V("table", Tu, [
            V("thead", null, [
              V("tr", null, [
                ($(!0), q(ye, null, He(j.value, (g) => ($(), q("th", {
                  key: g.key
                }, X(g.label), 1))), 128))
              ])
            ]),
            V("tbody", null, [
              ($(!0), q(ye, null, He(O.value, (g, c) => ($(), q("tr", { key: c }, [
                ($(!0), q(ye, null, He(j.value, (f) => ($(), q("td", {
                  key: f.key
                }, X(re(g[f.key])), 1))), 128))
              ]))), 128))
            ])
          ])
        ])) : r.value === "detail" || r.value === "summary_card" || r.value === "output_card" ? ($(), q("div", Ru, [
          V("dl", null, [
            ($(!0), q(ye, null, He(ne.value, (g) => ($(), q("div", {
              key: g.key
            }, [
              V("dt", null, X(g.label), 1),
              V("dd", null, X(re(g.value)), 1)
            ]))), 128))
          ]),
          v.value && u.value.length ? ($(), q("div", $u, [
            ($(!0), q(ye, null, He(u.value, (g) => ($(), q("button", {
              key: te(g),
              type: "button",
              class: Oe({ "is-primary": Ee(g) }),
              disabled: o.value,
              onClick: (c) => de(te(g), Xe(g))
            }, X(Ie(g)), 11, Mu))), 128))
          ])) : Z("", !0)
        ])) : r.value === "list_card" ? ($(), q("div", Ou, [
          H.value.showCount ? ($(), q("div", Nu, " 共 " + X(H.value.total) + " 条 ", 1)) : Z("", !0),
          H.value.items.length ? Z("", !0) : ($(), q("p", Lu, X(H.value.emptyText), 1)),
          ($(!0), q(ye, null, He(B.value, (g) => ($(), q("article", {
            key: g.key,
            class: "reachai-interaction__list-item"
          }, [
            V("header", qu, [
              V("div", Du, [
                V("strong", null, X(g.title), 1),
                g.subtitle ? ($(), q("span", Fu, X(g.subtitle), 1)) : Z("", !0)
              ]),
              g.status ? ($(), q("span", {
                key: 0,
                class: Oe(["reachai-interaction__status-chip", `is-${g.status.tone}`])
              }, X(g.status.label), 3)) : Z("", !0)
            ]),
            g.fields.length ? ($(), q("dl", ju, [
              ($(!0), q(ye, null, He(g.fields, (c) => ($(), q("div", {
                key: c.key
              }, [
                V("dt", null, X(c.label), 1),
                V("dd", null, X(c.value), 1)
              ]))), 128))
            ])) : Z("", !0)
          ]))), 128)),
          H.value.items.length > H.value.initialVisibleCount ? ($(), q("button", {
            key: 2,
            type: "button",
            class: "reachai-interaction__list-toggle",
            "aria-expanded": d.value,
            onClick: L[5] || (L[5] = (g) => d.value = !d.value)
          }, X(d.value ? "收起" : `展开剩余 ${H.value.items.length - H.value.initialVisibleCount} 条`), 9, Ku)) : Z("", !0)
        ])) : r.value === "page_action" ? ($(), q("div", Uu, [
          V("p", null, X(Y.value), 1),
          V("dl", null, [
            V("div", null, [
              L[8] || (L[8] = V("dt", null, "actionKey", -1)),
              V("dd", null, X(ae.value.actionKey || "-"), 1)
            ]),
            V("div", null, [
              L[9] || (L[9] = V("dt", null, "requestId", -1)),
              V("dd", null, X(ae.value.requestId || e.request.interactionId || "-"), 1)
            ]),
            V("div", null, [
              L[10] || (L[10] = V("dt", null, "args", -1)),
              V("dd", null, X(re(ae.value.args || {})), 1)
            ])
          ]),
          V("div", Hu, [
            ae.value.confirm ? ($(), q("button", {
              key: 0,
              type: "button",
              disabled: o.value,
              onClick: De
            }, "取消", 8, Vu)) : Z("", !0),
            V("button", {
              type: "button",
              class: "is-primary",
              disabled: o.value,
              onClick: L[6] || (L[6] = (g) => de("page_action_ack", { requestId: ae.value.requestId, actionKey: ae.value.actionKey }))
            }, " 已收到 ", 8, Bu)
          ])
        ])) : ($(), q("div", Wu, [
          V("p", zu, X(Q.value ? `自定义渲染器未在宿主注册：${Q.value}` : `未注册的交互组件：${e.request.component || "unknown"}`), 1),
          V("pre", null, X(re(e.request.data ?? e.request.summary ?? {})), 1),
          V("div", Ju, [
            V("button", {
              type: "button",
              disabled: o.value,
              onClick: De
            }, "取消", 8, Gu),
            V("button", {
              type: "button",
              class: "is-primary",
              disabled: o.value,
              onClick: L[7] || (L[7] = (g) => de("submit", {}))
            }, "按原始值提交", 8, Yu)
          ])
        ])),
        l.value || e.errorMessage ? ($(), q("p", Xu, X(l.value || e.errorMessage), 1)) : Z("", !0),
        i.value === "failed" ? ($(), q("div", Qu, [
          V("button", {
            type: "button",
            class: "is-primary",
            onClick: Fe
          }, "重试")
        ])) : Z("", !0)
      ], 10, tu);
    };
  }
}), Ht = (e, t) => {
  const n = e.__vccOpts || e;
  for (const [s, r] of t)
    n[s] = r;
  return n;
}, ef = /* @__PURE__ */ Ht(Zu, [["__scopeId", "data-v-2a5d0f29"]]), tf = ["data-type"], nf = {
  key: 0,
  class: "reachai-block__caret",
  "aria-hidden": "true"
}, sf = {
  key: 2,
  class: "reachai-block__page-action"
}, rf = { key: 0 }, of = ["data-level"], af = {
  key: 4,
  class: "reachai-block__error",
  role: "alert"
}, lf = /* @__PURE__ */ gt({
  __name: "ConversationBlockRenderer",
  props: {
    block: {}
  },
  emits: ["interaction-submit", "interaction-cancel", "retry"],
  setup(e, { emit: t }) {
    const n = t;
    function s(i, o, a) {
      i.type === "interaction" && n("interaction-submit", i.request.interactionId, o, a);
    }
    function r(i) {
      i.type === "interaction" && n("interaction-cancel", i.request.interactionId);
    }
    return (i, o) => ($(), q("div", {
      class: "reachai-block",
      "data-type": e.block.type
    }, [
      e.block.type === "text" ? ($(), q("div", {
        key: 0,
        class: Oe(["reachai-block__text", { "is-streaming": e.block.status === "streaming" }])
      }, [
        vn(X(e.block.text) + " ", 1),
        e.block.status === "streaming" ? ($(), q("span", nf)) : Z("", !0)
      ], 2)) : e.block.type === "interaction" ? ($(), mt(ef, {
        key: 1,
        request: e.block.request,
        state: e.block.state,
        "error-message": e.block.errorMessage,
        onSubmit: o[0] || (o[0] = (a, l) => s(e.block, a, l)),
        onCancel: o[1] || (o[1] = (a) => r(e.block))
      }, null, 8, ["request", "state", "error-message"])) : e.block.type === "page_action" ? ($(), q("div", sf, [
        V("strong", null, X(e.block.title || e.block.actionKey), 1),
        V("span", null, X(e.block.status), 1),
        e.block.message ? ($(), q("p", rf, X(e.block.message), 1)) : Z("", !0)
      ])) : e.block.type === "notice" ? ($(), q("div", {
        key: 3,
        class: "reachai-block__notice",
        "data-level": e.block.level || "info"
      }, X(e.block.text), 9, of)) : e.block.type === "error" ? ($(), q("div", af, [
        vn(X(e.block.text) + " ", 1),
        e.block.retryable ? ($(), q("button", {
          key: 0,
          type: "button",
          onClick: o[2] || (o[2] = (a) => i.$emit("retry"))
        }, "重试")) : Z("", !0)
      ])) : Z("", !0)
    ], 8, tf));
  }
}), ei = /* @__PURE__ */ Ht(lf, [["__scopeId", "data-v-775b19fc"]]), cf = ["data-message-id", "data-role", "data-status"], uf = {
  key: 0,
  class: "reachai-message__user-row"
}, ff = { class: "reachai-message__user-bubble" }, df = {
  key: 0,
  class: "reachai-message__user-avatar",
  "aria-hidden": "true"
}, hf = {
  key: 0,
  class: "reachai-message__prism-avatar",
  "aria-hidden": "true"
}, pf = {
  key: 0,
  class: "reachai-message__card-heading"
}, gf = {
  key: 0,
  class: "reachai-message__thinking-title"
}, mf = {
  key: 1,
  class: "reachai-message__weak-label"
}, yf = {
  key: 2,
  class: "reachai-message__heading-spacer",
  "aria-hidden": "true"
}, bf = ["data-tone"], _f = {
  key: 1,
  class: "reachai-message__status-hint"
}, vf = {
  key: 2,
  class: "reachai-message__thinking-details"
}, wf = ["aria-expanded"], Sf = {
  class: "reachai-message__thinking-chevron",
  "aria-hidden": "true"
}, If = {
  key: 0,
  class: "reachai-message__thinking-steps"
}, Af = ["data-state"], xf = { class: "reachai-message__thinking-step-body" }, Ef = { key: 0 }, Cf = { class: "reachai-message__body" }, kf = {
  key: 0,
  class: "reachai-message__loading"
}, Pf = {
  key: 3,
  class: "reachai-message__meta"
}, Tf = /* @__PURE__ */ gt({
  __name: "ConversationMessageItem",
  props: {
    message: {},
    assistantLabel: { default: "" },
    statusHint: { default: "" },
    thinkingPresentation: { default: null },
    showAvatars: { type: Boolean, default: !0 },
    surface: { default: "admin" }
  },
  emits: ["interaction-submit", "interaction-cancel", "retry"],
  setup(e) {
    const t = e, n = /* @__PURE__ */ Se(!1), s = le(
      () => t.message.role !== "user" && (t.message.status === "pending" || t.message.status === "streaming")
    ), r = le(() => s.value), i = le(() => {
      var h;
      return ((h = t.thinkingPresentation) == null ? void 0 : h.steps) || [];
    });
    Kt(
      () => t.message.id,
      () => {
        n.value = !1;
      }
    ), Kt(s, (h) => {
      h || (n.value = !1);
    });
    const o = le(
      () => !s.value && !!t.assistantLabel && t.message.role === "assistant" && t.surface === "admin"
    ), a = le(() => [
      `reachai-message--${t.message.role}`,
      `reachai-message--${t.message.status}`,
      {
        "reachai-message--thinking": s.value,
        "reachai-message--prism": t.message.role !== "user"
      }
    ]), l = le(() => ({
      "reachai-message__card-shell--thinking": s.value,
      "reachai-message__card-shell--response": !s.value,
      "reachai-message__card-shell--failed": t.message.status === "failed",
      "reachai-message__card-shell--cancelled": t.message.status === "cancelled"
    })), d = le(() => ({
      "reachai-message__card--thinking": s.value,
      "reachai-message__card--response": !s.value,
      [`reachai-message__card--${t.message.status}`]: !0
    })), u = le(() => s.value ? null : t.message.status === "failed" ? { label: "失败", tone: "danger" } : t.message.status === "cancelled" ? { label: "已取消", tone: "warning" } : null);
    return (h, v) => {
      var M;
      return $(), q("article", {
        class: Oe(["reachai-message", a.value]),
        "data-message-id": e.message.id,
        "data-role": e.message.role,
        "data-status": e.message.status
      }, [
        e.message.role === "user" ? ($(), q("div", uf, [
          V("div", ff, [
            ($(!0), q(ye, null, He(e.message.blocks, (I) => ($(), mt(ei, {
              key: I.id,
              block: I,
              onInteractionSubmit: v[0] || (v[0] = (...x) => h.$emit("interaction-submit", ...x)),
              onInteractionCancel: v[1] || (v[1] = (x) => h.$emit("interaction-cancel", x)),
              onRetry: v[2] || (v[2] = (x) => h.$emit("retry"))
            }, null, 8, ["block"]))), 128))
          ]),
          e.showAvatars ? ($(), q("div", df, [...v[7] || (v[7] = [
            V("svg", {
              viewBox: "0 0 24 24",
              width: "18",
              height: "18",
              fill: "none",
              stroke: "currentColor",
              "stroke-width": "1.8"
            }, [
              V("circle", {
                cx: "12",
                cy: "8",
                r: "3.5"
              }),
              V("path", {
                d: "M5 19.5c1.2-3.2 3.6-4.8 7-4.8s5.8 1.6 7 4.8",
                "stroke-linecap": "round"
              })
            ], -1)
          ])])) : Z("", !0)
        ])) : ($(), q("div", {
          key: 1,
          class: Oe(["reachai-message__assistant-row", { "reachai-message__assistant-row--without-avatar": !e.showAvatars }])
        }, [
          e.showAvatars ? ($(), q("div", hf, [...v[8] || (v[8] = [
            V("span", { class: "reachai-message__prism-avatar-img" }, null, -1)
          ])])) : Z("", !0),
          V("div", {
            class: Oe(["reachai-message__card-shell", l.value])
          }, [
            V("div", {
              class: Oe(["reachai-message__card", d.value])
            }, [
              r.value || o.value || u.value ? ($(), q("header", pf, [
                r.value ? ($(), q("div", gf, [...v[9] || (v[9] = [
                  V("span", {
                    class: "reachai-message__spark",
                    "aria-hidden": "true"
                  }, "✦", -1),
                  V("strong", null, "思考中…", -1),
                  V("span", {
                    class: "reachai-message__thinking-dots",
                    "aria-hidden": "true"
                  }, [
                    V("i"),
                    V("i"),
                    V("i")
                  ], -1)
                ])])) : o.value ? ($(), q("div", mf, X(e.assistantLabel), 1)) : ($(), q("span", yf)),
                u.value ? ($(), q("span", {
                  key: 3,
                  class: "reachai-message__status-capsule",
                  "data-tone": u.value.tone
                }, X(u.value.label), 9, bf)) : Z("", !0)
              ])) : Z("", !0),
              r.value && e.statusHint ? ($(), q("p", _f, X(e.statusHint), 1)) : Z("", !0),
              r.value && ((M = e.thinkingPresentation) != null && M.label) ? ($(), q("div", vf, [
                V("button", {
                  type: "button",
                  class: "reachai-message__thinking-toggle",
                  "aria-expanded": n.value,
                  onClick: v[3] || (v[3] = (I) => n.value = !n.value)
                }, [
                  V("span", null, X(e.thinkingPresentation.label), 1),
                  V("span", Sf, X(n.value ? "▴" : "▾"), 1)
                ], 8, wf),
                n.value && i.value.length ? ($(), q("ul", If, [
                  ($(!0), q(ye, null, He(i.value, (I) => ($(), q("li", {
                    key: I.id,
                    class: "reachai-message__thinking-step",
                    "data-state": I.state
                  }, [
                    v[10] || (v[10] = V("span", {
                      class: "reachai-message__thinking-step-mark",
                      "aria-hidden": "true"
                    }, null, -1)),
                    V("div", xf, [
                      V("strong", null, X(I.title), 1),
                      I.detail ? ($(), q("p", Ef, X(I.detail), 1)) : Z("", !0)
                    ])
                  ], 8, Af))), 128))
                ])) : Z("", !0)
              ])) : Z("", !0),
              V("div", Cf, [
                ($(!0), q(ye, null, He(e.message.blocks, (I) => ($(), mt(ei, {
                  key: I.id,
                  block: I,
                  onInteractionSubmit: v[4] || (v[4] = (...x) => h.$emit("interaction-submit", ...x)),
                  onInteractionCancel: v[5] || (v[5] = (x) => h.$emit("interaction-cancel", x)),
                  onRetry: v[6] || (v[6] = (x) => h.$emit("retry"))
                }, null, 8, ["block"]))), 128)),
                !e.message.blocks.length && s.value && !e.statusHint ? ($(), q("div", kf, " 正在处理 ")) : Z("", !0)
              ]),
              h.$slots.meta ? ($(), q("footer", Pf, [
                Mt(h.$slots, "meta", { message: e.message }, void 0)
              ])) : Z("", !0)
            ], 2)
          ], 2)
        ], 2))
      ], 10, cf);
    };
  }
}), Rf = /* @__PURE__ */ Ht(Tf, [["__scopeId", "data-v-7d8eb006"]]), $f = {
  key: 0,
  class: "reachai-message-list__empty"
}, Mf = /* @__PURE__ */ gt({
  __name: "ConversationMessageList",
  props: {
    messages: {},
    autoFollow: { type: Boolean, default: !0 },
    assistantLabel: { default: "" },
    resolveStatusHint: {},
    resolveThinkingPresentation: {},
    showAvatars: { type: Boolean, default: !0 },
    surface: { default: "admin" }
  },
  emits: ["interaction-submit", "interaction-cancel", "retry"],
  setup(e, { expose: t }) {
    const n = e, s = /* @__PURE__ */ Se(null), r = /* @__PURE__ */ Se(!0), i = /* @__PURE__ */ Se(!1);
    function o(u) {
      var h;
      return ((h = n.resolveStatusHint) == null ? void 0 : h.call(n, u)) || "";
    }
    function a(u) {
      var h;
      return ((h = n.resolveThinkingPresentation) == null ? void 0 : h.call(n, u)) || null;
    }
    function l() {
      const u = s.value;
      if (!u) return;
      const h = u.scrollHeight - u.scrollTop - u.clientHeight;
      r.value = h < 48, i.value = !r.value;
    }
    function d(u = !1) {
      const h = s.value;
      h && (!u && !r.value || (h.scrollTop = h.scrollHeight, i.value = !1, r.value = !0));
    }
    return Kt(
      () => n.messages,
      async () => {
        n.autoFollow !== !1 && (await Gs(), d());
      },
      { deep: !0 }
    ), ss(() => d(!0)), t({ scrollToBottom: d }), (u, h) => ($(), q("div", {
      ref_key: "listEl",
      ref: s,
      class: "reachai-message-list",
      role: "log",
      "aria-live": "polite",
      onScroll: l
    }, [
      e.messages.length ? Z("", !0) : ($(), q("div", $f, [
        Mt(u.$slots, "empty", {}, () => [
          h[4] || (h[4] = vn("开始对话吧", -1))
        ])
      ])),
      ($(!0), q(ye, null, He(e.messages, (v) => ($(), mt(Rf, {
        key: v.id,
        message: v,
        "assistant-label": e.assistantLabel,
        "status-hint": o(v),
        "thinking-presentation": a(v),
        "show-avatars": e.showAvatars,
        surface: e.surface,
        onInteractionSubmit: h[0] || (h[0] = (...M) => u.$emit("interaction-submit", ...M)),
        onInteractionCancel: h[1] || (h[1] = (M) => u.$emit("interaction-cancel", M)),
        onRetry: h[2] || (h[2] = (M) => u.$emit("retry"))
      }, Vi({ _: 2 }, [
        u.$slots["message-meta"] ? {
          name: "meta",
          fn: Fn((M) => [
            Mt(u.$slots, "message-meta", ho({ ref_for: !0 }, M), void 0, !0)
          ]),
          key: "0"
        } : void 0
      ]), 1032, ["message", "assistant-label", "status-hint", "thinking-presentation", "show-avatars", "surface"]))), 128)),
      i.value ? ($(), q("button", {
        key: 1,
        type: "button",
        class: "reachai-message-list__jump",
        onClick: h[3] || (h[3] = (v) => d(!0))
      }, " 回到底部 ")) : Z("", !0)
    ], 544));
  }
}), Of = /* @__PURE__ */ Ht(Mf, [["__scopeId", "data-v-3cddb8bb"]]), Nf = ["placeholder", "disabled", "aria-label"], Lf = { class: "reachai-composer__actions" }, qf = { class: "reachai-composer__buttons" }, Df = ["disabled"], Ff = /* @__PURE__ */ gt({
  __name: "ConversationComposer",
  props: {
    placeholder: { default: "输入消息" },
    disabled: { type: Boolean, default: !1 },
    showStop: { type: Boolean, default: !1 }
  },
  emits: ["send", "stop"],
  setup(e, { expose: t, emit: n }) {
    const s = n, r = /* @__PURE__ */ Se(""), i = /* @__PURE__ */ Se(null);
    function o() {
      const l = r.value.trim();
      l && (s("send", l), r.value = "");
    }
    function a(l) {
      (l.ctrlKey || l.metaKey) && l.key === "Enter" && (l.preventDefault(), o());
    }
    return t({
      focus() {
        var l;
        (l = i.value) == null || l.focus();
      },
      setValue(l) {
        r.value = l;
      }
    }), (l, d) => ($(), q("form", {
      class: Oe(["reachai-composer", { "is-disabled": e.disabled }]),
      onSubmit: _o(o, ["prevent"])
    }, [
      zt(V("textarea", {
        ref_key: "inputEl",
        ref: i,
        "onUpdate:modelValue": d[0] || (d[0] = (u) => r.value = u),
        class: "reachai-composer__input",
        rows: "2",
        placeholder: e.placeholder,
        disabled: e.disabled,
        "aria-label": e.placeholder,
        onKeydown: a
      }, null, 40, Nf), [
        [Os, r.value]
      ]),
      V("div", Lf, [
        d[2] || (d[2] = V("span", { class: "reachai-composer__hint" }, [
          V("kbd", null, "Ctrl"),
          V("b", null, "+"),
          V("kbd", null, "Enter"),
          V("em", null, "发送")
        ], -1)),
        V("div", qf, [
          e.showStop ? ($(), q("button", {
            key: 0,
            type: "button",
            class: "reachai-composer__stop",
            onClick: d[1] || (d[1] = (u) => l.$emit("stop"))
          }, " 停止 ")) : Z("", !0),
          V("button", {
            type: "submit",
            class: Oe(["reachai-composer__send", { "is-busy": e.showStop }]),
            disabled: e.disabled || !r.value.trim()
          }, X(e.showStop ? "思考中" : "发送"), 11, Df)
        ])
      ])
    ], 34));
  }
}), jf = /* @__PURE__ */ Ht(Ff, [["__scopeId", "data-v-2a661fcc"]]), Kf = ["data-surface"], Uf = {
  key: 0,
  class: "reachai-conversation__header"
}, Hf = {
  key: 1,
  class: "reachai-conversation__error",
  role: "alert"
}, Vf = {
  key: 2,
  class: "reachai-conversation__footer"
}, Bf = 480, Wf = /* @__PURE__ */ gt({
  __name: "ConversationView",
  props: {
    snapshot: {},
    density: { default: "comfortable" },
    chrome: { default: "panel" },
    placeholder: {},
    hideComposer: { type: Boolean, default: !1 },
    autoFollow: { type: Boolean, default: !0 },
    disableSendWhileBusy: { type: Boolean, default: !0 },
    forceComposerDisabled: { type: Boolean, default: !1 },
    atmosphere: { type: Boolean, default: !0 },
    assistantLabel: { default: "" },
    showAvatars: { type: Boolean, default: !0 },
    surface: { default: "admin" },
    resolveStatusHint: {},
    resolveThinkingPresentation: {}
  },
  emits: ["send", "stop", "retry", "interaction-submit", "interaction-cancel"],
  setup(e, { emit: t }) {
    const n = e, s = t, r = /* @__PURE__ */ Se(null), i = /* @__PURE__ */ Se(!1);
    let o = null;
    const a = le(() => ({})), l = le(
      () => n.snapshot.turnStatus === "sending" || n.snapshot.turnStatus === "streaming"
    ), d = le(() => l.value), u = le(() => n.showAvatars && !i.value), h = le(
      () => n.forceComposerDisabled || n.disableSendWhileBusy && (l.value || n.snapshot.turnStatus === "waiting")
    );
    function v(K) {
      s("send", K);
    }
    function M(K, b, D) {
      s("interaction-submit", K, b, D);
    }
    function I(K) {
      s("interaction-cancel", K);
    }
    function x(K) {
      K > 0 && (i.value = K <= Bf);
    }
    function N() {
      var b;
      const K = ((b = r.value) == null ? void 0 : b.getBoundingClientRect().width) || 0;
      x(K);
    }
    return ss(() => {
      if (N(), typeof ResizeObserver > "u") {
        window.addEventListener("resize", N);
        return;
      }
      o = new ResizeObserver((K) => {
        const b = K[0];
        b && x(b.contentRect.width);
      }), r.value && o.observe(r.value);
    }), Ui(() => {
      o == null || o.disconnect(), o = null, window.removeEventListener("resize", N);
    }), (K, b) => ($(), q("div", {
      ref_key: "conversationEl",
      ref: r,
      class: Oe(["reachai-conversation", [
        `reachai-conversation--${e.density}`,
        `reachai-conversation--${e.chrome}`,
        {
          "reachai-conversation--atmosphere": e.atmosphere,
          "reachai-conversation--narrow": i.value,
          "is-busy": l.value
        }
      ]]),
      "data-surface": e.surface,
      style: In(a.value)
    }, [
      K.$slots.header ? ($(), q("header", Uf, [
        Mt(K.$slots, "header", {}, void 0)
      ])) : Z("", !0),
      Pe(Of, {
        messages: e.snapshot.messages,
        "auto-follow": e.autoFollow,
        "assistant-label": e.assistantLabel,
        "resolve-status-hint": e.resolveStatusHint,
        "resolve-thinking-presentation": e.resolveThinkingPresentation,
        "show-avatars": u.value,
        surface: e.surface,
        onInteractionSubmit: M,
        onInteractionCancel: I,
        onRetry: b[0] || (b[0] = (D) => K.$emit("retry"))
      }, Vi({ _: 2 }, [
        K.$slots.empty ? {
          name: "empty",
          fn: Fn(() => [
            Mt(K.$slots, "empty", {}, void 0, !0)
          ]),
          key: "0"
        } : void 0,
        K.$slots["message-meta"] ? {
          name: "message-meta",
          fn: Fn((D) => [
            Mt(K.$slots, "message-meta", zo(fo(D)), void 0, !0)
          ]),
          key: "1"
        } : void 0
      ]), 1032, ["messages", "auto-follow", "assistant-label", "resolve-status-hint", "resolve-thinking-presentation", "show-avatars", "surface"]),
      e.snapshot.error ? ($(), q("div", Hf, [
        V("span", null, X(e.snapshot.error), 1),
        V("button", {
          type: "button",
          onClick: b[1] || (b[1] = (D) => K.$emit("retry"))
        }, "重试")
      ])) : Z("", !0),
      Mt(K.$slots, "composer", {}, () => [
        e.hideComposer ? Z("", !0) : ($(), mt(jf, {
          key: 0,
          disabled: h.value,
          "show-stop": d.value,
          placeholder: e.placeholder,
          onSend: v,
          onStop: b[2] || (b[2] = (D) => K.$emit("stop"))
        }, null, 8, ["disabled", "show-stop", "placeholder"]))
      ]),
      K.$slots.footer ? ($(), q("footer", Vf, [
        Mt(K.$slots, "footer", {}, void 0)
      ])) : Z("", !0)
    ], 14, Kf));
  }
}), zf = /* @__PURE__ */ Ht(Wf, [["__scopeId", "data-v-9f74d6d6"]]), Jf = "1.0.0-SNAPSHOT";
function ti(e, t) {
  return {
    pageKey: t == null ? void 0 : t.pageKey,
    pageInstanceId: e.pageInstanceId,
    route: e.route || (typeof location < "u" ? location.pathname : "/"),
    bridgeActions: e.registeredActions,
    sdkVersion: Jf
  };
}
const Gf = { class: "eaf-chat-host" }, Yf = ["role"], Xf = /* @__PURE__ */ gt({
  __name: "EmbedChatHost",
  props: {
    apiBase: {},
    tokenProvider: {},
    tokenTimeoutMs: { default: 1e4 },
    bridge: {},
    page: {},
    context: { default: () => ({}) },
    placeholder: { default: "输入消息" },
    locale: { default: "zh-CN" },
    preferStream: { type: Boolean, default: !0 },
    onEvent: {},
    onError: {},
    onAuthStateChange: {},
    onTokenChanged: {},
    onSessionChanged: {},
    onUnauthorized: {}
  },
  setup(e, { expose: t }) {
    const n = e, s = /* @__PURE__ */ Se(sr()), r = /* @__PURE__ */ Se({
      phase: "token",
      status: "loading",
      reason: "initial",
      attempt: 0,
      message: n.locale === "en-US" ? "Connecting to ReachAI…" : "正在连接 ReachAI…"
    });
    let i = "", o = { ...n.context }, a = "", l = 0, d = !1, u = 0, h = null, v = null, M = "", I = null;
    function x(m) {
      var g;
      r.value = m, (g = n.onAuthStateChange) == null || g.call(n, m);
    }
    function N(m) {
      const g = typeof m == "string" ? m : m == null ? void 0 : m.token, c = typeof m == "object" && m ? Number(m.expiresAt || 0) : 0, f = typeof m == "object" && m ? Number(m.expiresIn || 0) : 0;
      return {
        token: String(g || "").trim(),
        expiresAt: c > 0 ? c : f > 0 ? Date.now() + f * 1e3 : 0
      };
    }
    function K(m) {
      if (!m || typeof m != "object") return;
      const g = m.httpStatus ?? m.status, c = Number(g);
      return Number.isFinite(c) && c > 0 ? c : void 0;
    }
    function b(m, g, c, f) {
      const y = new Error(g);
      return y.name = "EafChatTokenError", y.code = m, y.phase = "token", y.retryable = f !== 403, y.httpStatus = f, y.cause = c, y;
    }
    function D(m) {
      if (m && typeof m == "object" && m.code)
        return m;
      const g = K(m);
      return g === 401 ? b(
        "TOKEN_PROVIDER_UNAUTHORIZED",
        n.locale === "en-US" ? "Authentication expired. Sign in again and retry." : "身份认证已失效，请重新登录后重试",
        m,
        g
      ) : g != null && g >= 500 ? b(
        "TOKEN_PROVIDER_UNAVAILABLE",
        n.locale === "en-US" ? "ReachAI is temporarily unavailable. Retry later." : "ReachAI 暂时不可用，请稍后重试",
        m,
        g
      ) : m instanceof TypeError ? b(
        "TOKEN_PROVIDER_NETWORK_ERROR",
        n.locale === "en-US" ? "Network connection failed. Check your network and retry." : "网络连接失败，请检查网络后重试",
        m,
        g
      ) : b(
        "TOKEN_PROVIDER_FAILED",
        n.locale === "en-US" ? "Unable to connect to ReachAI. Retry later." : "暂时无法连接 ReachAI，请稍后重试",
        m,
        g
      );
    }
    function T(m) {
      return {
        message: m.message,
        code: m.code,
        phase: m.phase,
        httpStatus: m.httpStatus,
        retryable: m.retryable
      };
    }
    async function U(m, g = !1) {
      var z;
      if (d) throw new DOMException("The operation was aborted.", "AbortError");
      const c = l > 0 && Date.now() + 3e4 >= l;
      if (a && !g && !c) return a;
      if (h) return h;
      const f = c && m === "send" ? "expiring" : m, y = ++u, E = new AbortController();
      v = E, x({
        phase: "token",
        status: "loading",
        reason: f,
        attempt: y,
        message: n.locale === "en-US" ? "Connecting to ReachAI…" : "正在连接 ReachAI…"
      });
      let k;
      const p = Number.isFinite(n.tokenTimeoutMs) && n.tokenTimeoutMs > 0 ? n.tokenTimeoutMs : 1e4, w = ti(n.bridge, n.page), _ = {
        reason: f,
        signal: E.signal,
        attempt: y,
        sessionId: i || void 0,
        pageKey: w.pageKey,
        pageInstanceId: w.pageInstanceId,
        route: w.route,
        origin: ((z = n.page) == null ? void 0 : z.origin) || (typeof location < "u" ? location.origin : "")
      }, P = Promise.resolve().then(async () => {
        if (m === "unauthorized" && n.onUnauthorized) {
          const F = await n.onUnauthorized();
          if (F) return F;
        }
        return n.tokenProvider(_);
      }), A = new Promise((F, W) => {
        k = setTimeout(() => {
          E.abort(), W(b(
            "TOKEN_PROVIDER_TIMEOUT",
            n.locale === "en-US" ? "Connection timed out. Retry." : "连接超时，请重试"
          ));
        }, p);
      });
      return h = Promise.race([P, A]).then((F) => {
        var J;
        if (d) throw new DOMException("The operation was aborted.", "AbortError");
        const W = N(F);
        if (!W.token)
          throw b(
            "TOKEN_PROVIDER_EMPTY",
            n.locale === "en-US" ? "Authentication token is unavailable. Retry." : "登录凭证不可用，请重试"
          );
        return a = W.token, l = W.expiresAt, (J = n.onTokenChanged) == null || J.call(n, W.token), x({
          phase: "token",
          status: "ready",
          reason: f,
          attempt: y
        }), W.token;
      }).catch((F) => {
        var J;
        if (F instanceof DOMException && F.name === "AbortError" && d) throw F;
        const W = D(F);
        throw a = "", l = 0, (J = n.onTokenChanged) == null || J.call(n, ""), x({
          phase: "token",
          status: "error",
          reason: f,
          attempt: y,
          message: W.message,
          error: T(W)
        }), W;
      }).finally(() => {
        k !== void 0 && clearTimeout(k), v === E && (v = null), h = null;
      }), h;
    }
    async function S(m = "unauthorized") {
      var g;
      return a = "", l = 0, (g = n.onTokenChanged) == null || g.call(n, ""), U(m, !0);
    }
    function O() {
      return S("retry");
    }
    function j(m) {
      var f;
      const g = String(m || ""), c = g !== i;
      i = g, c && g && ((f = n.onSessionChanged) == null || f.call(n, g));
    }
    const H = Lc({
      apiBase: n.apiBase,
      tokenProvider: () => a,
      getSessionId: () => i || void 0,
      setSessionId: j,
      getContext: () => o,
      createSessionPayload: () => ({
        ...ti(n.bridge, n.page)
      }),
      preferStream: n.preferStream,
      onUnauthorized: () => S("unauthorized")
    }), B = H, se = Pc({
      transport: H,
      onPublicEvent: ne,
      onChange(m) {
        s.value = m, m.sessionId && j(m.sessionId), Y(m);
      }
    });
    U("initial").catch((m) => {
      d || L(m);
    });
    function ne(m) {
      var f, y, E, k, p, w, _;
      const g = m.data, c = {
        sessionId: m.sessionId || i || void 0,
        turnId: m.turnId
      };
      switch (m.type) {
        case "message.delta":
          (f = n.onEvent) == null || f.call(n, { type: "message.delta", data: g, ...c });
          return;
        case "ui.requested":
          (y = n.onEvent) == null || y.call(n, { type: "ui.requested", data: g, ...c });
          return;
        case "page.action.requested":
          (E = n.onEvent) == null || E.call(n, { type: "page.action.requested", data: g, ...c });
          return;
        case "turn.completed":
        case "turn.waiting":
          (k = n.onEvent) == null || k.call(n, {
            type: "message.completed",
            data: ae(m),
            ...c
          });
          return;
        case "turn.failed":
          (p = n.onEvent) == null || p.call(n, { type: "error", data: g, ...c });
          return;
        case "interaction.submitted":
          (w = n.onEvent) == null || w.call(n, { type: "interaction.submitted", data: g, ...c });
          return;
        case "interaction.cancelled":
          (_ = n.onEvent) == null || _.call(n, { type: "interaction.cancelled", data: g, ...c });
          return;
        default:
          return;
      }
    }
    function ae(m) {
      const g = m.data && typeof m.data == "object" ? m.data : {}, c = Eo(g) || (g.metadata && typeof g.metadata == "object" && !Array.isArray(g.metadata) ? { ...g.metadata } : void 0);
      return {
        answer: g.answer != null ? String(g.answer) : void 0,
        sessionId: m.sessionId || (g.sessionId != null ? String(g.sessionId) : i) || void 0,
        uiRequest: g.uiRequest,
        metadata: c,
        intentType: g.intentType,
        toolCalls: g.toolCalls,
        turnId: m.turnId
      };
    }
    function Y(m) {
      if (!I) return;
      const g = m.turnStatus;
      if (g === "sending" || g === "streaming") {
        I.armed = !0;
        return;
      }
      if (!I.armed || g !== "completed" && g !== "waiting" && g !== "failed" && g !== "cancelled")
        return;
      const c = I;
      if (I = null, g === "failed") {
        c.reject(new Error(m.error || "Message failed"));
        return;
      }
      if (g === "cancelled") {
        c.reject(new DOMException("The operation was aborted.", "AbortError"));
        return;
      }
      c.resolve(Q(m));
    }
    function Q(m) {
      var k, p;
      let g = "", c, f, y, E;
      for (let w = m.messages.length - 1; w >= 0; w -= 1) {
        const _ = m.messages[w];
        if (_.role === "assistant") {
          g = fc(_);
          for (const P of _.blocks)
            P.type === "interaction" && (P.state === "waiting" || P.state === "submitting") && (c = P.request);
          f = _.metadata ? { ..._.metadata } : void 0, f && "metadata" in f && typeof f.metadata == "object" && (f = { ...f.metadata }), y = (k = _.completion) == null ? void 0 : k.intentType, E = (p = _.completion) == null ? void 0 : p.toolCalls;
          break;
        }
      }
      return f && (delete f.result, delete f.answer, delete f.uiRequest, delete f.sessionId, delete f.intentType, delete f.toolCalls), {
        answer: g,
        sessionId: m.sessionId || i || void 0,
        uiRequest: c,
        metadata: f && Object.keys(f).length ? f : void 0,
        intentType: y,
        toolCalls: E,
        turnId: m.turnId
      };
    }
    async function oe(m) {
      if (d)
        throw new DOMException("The operation was aborted.", "AbortError");
      const g = m.trim();
      if (!g) return {};
      if (I)
        throw new Error("Another message is still in flight");
      return M = g, await U("send"), new Promise((c, f) => {
        I = { resolve: c, reject: f, armed: !1 }, se.send(g).catch((y) => {
          I && (I = null, f(y));
        });
      });
    }
    function re(m) {
      o = { ...o, ...m };
    }
    function te() {
      return i || null;
    }
    function Ie() {
      return i || null;
    }
    async function Xe() {
      if (d) throw new DOMException("The operation was aborted.", "AbortError");
      if (await U("send"), i) return i;
      if (typeof B.ensureSession == "function")
        return B.ensureSession();
      throw new Error("Embed transport cannot ensure session");
    }
    function Ee(m) {
      return m.role !== "assistant" || m.status !== "pending" && m.status !== "streaming" ? void 0 : m.blocks.some((c) => c.type === "text" && c.text) ? "正在生成回答" : "正在处理";
    }
    function de(m) {
      oe(m).catch(L);
    }
    function Te() {
      O().catch(L);
    }
    function tt() {
      if (r.value.status === "error") {
        Te();
        return;
      }
      !M || I || oe(M).catch(L);
    }
    function De() {
      se.cancel().then(() => {
        if (I) {
          const m = I;
          I = null, m.reject(new DOMException("The operation was aborted.", "AbortError"));
        }
      });
    }
    function Fe(m, g, c) {
      se.submitInteraction(m, g, c).catch(L);
    }
    function R(m) {
      se.submitInteraction(m, "cancel", {}).catch(L);
    }
    function L(m) {
      var f;
      const g = m && typeof m == "object" ? m : void 0, c = {
        message: (g == null ? void 0 : g.message) || (m instanceof Error ? m.message : String(m)),
        cause: (g == null ? void 0 : g.cause) ?? m,
        code: g == null ? void 0 : g.code,
        phase: g == null ? void 0 : g.phase,
        httpStatus: (g == null ? void 0 : g.httpStatus) ?? K(m),
        retryable: g == null ? void 0 : g.retryable
      };
      try {
        (f = n.onError) == null || f.call(n, c);
      } catch {
      }
    }
    function C() {
      if (d = !0, v == null || v.abort(), v = null, I) {
        const m = I;
        I = null, m.reject(new DOMException("The operation was aborted.", "AbortError"));
      }
      se.dispose();
    }
    return Qs(() => {
      C();
    }), t({
      sendMessage: oe,
      retryAuthentication: O,
      refreshToken: S,
      setContext: re,
      getSessionId: te,
      getExistingSessionId: Ie,
      ensureHostSession: Xe,
      disposeHost: C
    }), (m, g) => ($(), q("div", Gf, [
      r.value.status !== "ready" ? ($(), q("div", {
        key: 0,
        class: Oe(["eaf-chat-auth", `is-${r.value.status}`]),
        role: r.value.status === "error" ? "alert" : "status",
        "aria-live": "polite"
      }, [
        V("span", null, X(r.value.message), 1),
        r.value.status === "error" ? ($(), q("button", {
          key: 0,
          type: "button",
          onClick: Te
        }, X(e.locale === "en-US" ? "Retry" : "重试"), 1)) : Z("", !0)
      ], 10, Yf)) : Z("", !0),
      Pe(Js(zf), {
        class: "eaf-chat__conversation",
        chrome: "inline",
        density: "compact",
        surface: "embed",
        atmosphere: "",
        snapshot: s.value,
        placeholder: e.placeholder,
        "force-composer-disabled": r.value.status !== "ready",
        "resolve-status-hint": Ee,
        onSend: de,
        onStop: De,
        onRetry: tt,
        onInteractionSubmit: Fe,
        onInteractionCancel: R
      }, null, 8, ["snapshot", "placeholder", "force-composer-disabled"])
    ]));
  }
}), To = /* @__PURE__ */ Ht(Xf, [["__scopeId", "data-v-0d217671"]]);
function Ls(e) {
  var s;
  const t = (s = e.metadata) == null ? void 0 : s.pageActionQueue;
  if (!Array.isArray(t)) return [];
  const n = cr(e.metadata);
  return t.map((r) => Ro(r, n)).filter((r) => !!r);
}
function Ro(e, t) {
  if (!e || typeof e != "object") return null;
  const n = e;
  if (n.type !== "page.action.requested" || typeof n.requestId != "string" || typeof n.actionKey != "string") return null;
  const s = n.metadata && typeof n.metadata == "object" ? { ...n.metadata } : {}, r = typeof n.pageKey == "string" ? n.pageKey : t;
  return r && !s.pageKey && (s.pageKey = r), {
    type: "page.action.requested",
    protocolVersion: typeof n.protocolVersion == "string" ? n.protocolVersion : void 0,
    requestId: n.requestId,
    actionKey: n.actionKey,
    title: typeof n.title == "string" ? n.title : void 0,
    args: n.args && typeof n.args == "object" ? n.args : void 0,
    target: n.target && typeof n.target == "object" ? n.target : void 0,
    confirm: n.confirm === !0,
    metadata: s
  };
}
async function Bn(e) {
  var i;
  const t = Ro(e.request, cr(e.responseMetadata));
  if (!(t != null && t.requestId)) return;
  const n = t.requestId;
  if (e.handledPageActions.has(n) && !((i = e.pendingPageActionResults) != null && i.has(n))) return;
  const s = e.inFlightPageActions.get(n);
  if (s) {
    await s;
    return;
  }
  const r = (async () => {
    var a, l, d, u, h, v, M;
    const o = (a = e.pendingPageActionResults) == null ? void 0 : a.get(n);
    if (e.handledPageActions.has(n)) {
      if (!o) return;
      await ni(e, o), (l = e.pendingPageActionResults) == null || l.delete(n);
      return;
    }
    e.handledPageActions.add(n), (d = e.onRequested) == null || d.call(e, t);
    try {
      const I = await Qf(
        t,
        e.bridge,
        e.responseMetadata,
        /* @__PURE__ */ new Set()
        // 已认领，内部不再二次 gated
      );
      if (!I) return;
      (I.status === "FAILED" || I.status === "TIMEOUT") && ((u = e.onError) == null || u.call(e, new Error(I.error || `Page action ${I.status}: ${t.actionKey}`))), (h = e.pendingPageActionResults) == null || h.set(n, I), await ni(e, I), (v = e.pendingPageActionResults) == null || v.delete(n);
    } catch (I) {
      (M = e.onError) == null || M.call(e, I);
    }
  })();
  e.inFlightPageActions.set(n, r);
  try {
    await r;
  } finally {
    e.inFlightPageActions.delete(n);
  }
}
async function ni(e, t) {
  let n = e.token;
  try {
    await si(
      e.apiBase,
      e.sessionId,
      n,
      t,
      e.fetchImpl
    );
  } catch (s) {
    if (!Mo(s) || !e.refreshToken) throw s;
    n = await e.refreshToken(), await si(
      e.apiBase,
      e.sessionId,
      n,
      t,
      e.fetchImpl
    );
  }
}
async function Qf(e, t, n, s) {
  const r = await t.handleEvent(e);
  if (r && r.status !== "ACTION_NOT_FOUND")
    return s.add(e.requestId), r;
  const i = await ed(e, n);
  return i ? (i.status !== "ACTION_NOT_FOUND" && s.add(e.requestId), i) : (r && s.add(e.requestId), r);
}
async function Zf(e) {
  const t = Ls(e.response);
  for (const n of t)
    await Bn({
      request: n,
      bridge: e.bridge,
      sessionId: e.sessionId,
      apiBase: e.apiBase,
      token: e.token,
      handledPageActions: e.handledPageActions,
      inFlightPageActions: e.inFlightPageActions,
      pendingPageActionResults: e.pendingPageActionResults,
      responseMetadata: e.response.metadata,
      onRequested: e.onRequested,
      onError: e.onError,
      refreshToken: e.refreshToken,
      fetchImpl: e.fetchImpl
    });
}
async function ed(e, t) {
  const n = typeof window < "u" ? window.__REACHAI_PAGE_BRIDGE__ : void 0;
  if (!n || typeof n.execute != "function") return null;
  const s = td(e) || cr(t);
  if (!s)
    return {
      protocolVersion: e.protocolVersion || "1.0",
      type: "page.action.result",
      requestId: e.requestId,
      actionKey: e.actionKey,
      status: "ACTION_NOT_FOUND",
      error: "Page action pageKey is missing for window.__REACHAI_PAGE_BRIDGE__ fallback"
    };
  try {
    const r = await n.execute(s, e.actionKey, e.args || {}, {
      confirmed: !0,
      requestId: e.requestId
    }), i = r && typeof r == "object" ? r : { data: r }, o = String(i.status || "SUCCESS").toUpperCase(), a = o === "SUCCESS", l = i.error && typeof i.error == "object" ? String(i.error.message || i.message || "") : String(i.message || "");
    return {
      protocolVersion: e.protocolVersion || "1.0",
      type: "page.action.result",
      requestId: e.requestId,
      actionKey: e.actionKey,
      status: a ? "SUCCESS" : "FAILED",
      data: i.data ?? r,
      error: a ? void 0 : l || `Page action returned ${o}`
    };
  } catch (r) {
    return {
      protocolVersion: e.protocolVersion || "1.0",
      type: "page.action.result",
      requestId: e.requestId,
      actionKey: e.actionKey,
      status: "FAILED",
      error: r instanceof Error ? r.message : String(r)
    };
  }
}
function td(e) {
  var n;
  const t = (n = e.metadata) == null ? void 0 : n.pageKey;
  return typeof t == "string" && t.trim() ? t.trim() : void 0;
}
function cr(e) {
  const t = e == null ? void 0 : e.pageKey;
  return typeof t == "string" && t.trim() ? t.trim() : void 0;
}
async function si(e, t, n, s, r = fetch) {
  await sd(
    `${e}/chat/sessions/${encodeURIComponent(t)}/page-actions/${encodeURIComponent(s.requestId)}/result`,
    s,
    n,
    r
  );
}
async function nd(e) {
  var l;
  const t = e.fetchImpl || fetch, n = e.inFlightPageActions || /* @__PURE__ */ new Map(), s = `${e.apiBase}/chat/sessions/${encodeURIComponent(e.sessionId)}/page-actions/pending?limit=10`;
  let r = e.token;
  const i = e.refreshToken ? async () => (r = await e.refreshToken(), r) : void 0;
  let o;
  try {
    o = await ri(s, r, t);
  } catch (d) {
    if (!Mo(d) || !i) throw d;
    await i(), o = await ri(s, r, t);
  }
  const a = /* @__PURE__ */ new Set();
  for (const d of o)
    d != null && d.requestId && (a.add(d.requestId), await Bn({
      request: d,
      bridge: e.bridge,
      sessionId: e.sessionId,
      apiBase: e.apiBase,
      token: r,
      handledPageActions: e.handledPageActions,
      inFlightPageActions: n,
      pendingPageActionResults: e.pendingPageActionResults,
      responseMetadata: e.context,
      onRequested: (u) => {
        var h;
        return (h = e.onEvent) == null ? void 0 : h.call(e, { type: "page.action.requested", data: u });
      },
      onError: e.onError,
      refreshToken: i,
      fetchImpl: t
    }));
  for (const [d, u] of [
    ...((l = e.pendingPageActionResults) == null ? void 0 : l.entries()) || []
  ])
    a.has(d) || (e.handledPageActions.add(d), await Bn({
      request: {
        type: "page.action.requested",
        requestId: d,
        actionKey: u.actionKey
      },
      bridge: e.bridge,
      sessionId: e.sessionId,
      apiBase: e.apiBase,
      token: r,
      handledPageActions: e.handledPageActions,
      inFlightPageActions: n,
      pendingPageActionResults: e.pendingPageActionResults,
      responseMetadata: e.context,
      onError: e.onError,
      refreshToken: i,
      fetchImpl: t
    }));
}
async function sd(e, t, n, s) {
  const r = await s(e, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${n}`
    },
    body: JSON.stringify(t)
  }), i = await r.json().catch(() => ({}));
  if (!r.ok || i.code && i.code !== 200 && i.code !== 0)
    throw $o(i.message || `Request failed: ${r.status}`, r.status);
  return i.data ?? i;
}
async function ri(e, t, n) {
  const s = await n(e, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${t}`
    }
  }), r = await s.json().catch(() => ({}));
  if (!s.ok || r.code && r.code !== 200 && r.code !== 0)
    throw $o(r.message || `Request failed: ${s.status}`, s.status);
  return r.data ?? r;
}
function $o(e, t) {
  const n = new Error(e);
  return n.status = t, n;
}
function Mo(e) {
  return !!(e && typeof e == "object" && e.status === 401);
}
const Rn = {
  activeWindowMs: 5e3,
  activeIntervalMs: 1e3,
  idleIntervalMs: 1e4,
  /** 第 1..n 次连续失败后的等待间隔（ms），封顶取最后一项 */
  backoffMs: [5e3, 1e4, 2e4, 4e4, 6e4]
};
function rd(e) {
  var B, se, ne, ae;
  const t = {
    activeWindowMs: ((B = e.timings) == null ? void 0 : B.activeWindowMs) ?? Rn.activeWindowMs,
    activeIntervalMs: ((se = e.timings) == null ? void 0 : se.activeIntervalMs) ?? Rn.activeIntervalMs,
    idleIntervalMs: ((ne = e.timings) == null ? void 0 : ne.idleIntervalMs) ?? Rn.idleIntervalMs,
    backoffMs: ((ae = e.timings) == null ? void 0 : ae.backoffMs) ?? Rn.backoffMs
  }, n = e.now || (() => Date.now()), s = e.setTimeoutFn || ((Y, Q) => window.setTimeout(Y, Q)), r = e.clearTimeoutFn || ((Y) => window.clearTimeout(Y)), i = e.isDocumentHidden || (() => typeof document > "u" ? !1 : document.visibilityState === "hidden");
  let o = !1, a, l = !1, d = !1, u = !1, h = 0, v = 0, M = 0, I = 0, x;
  function N() {
    return !(o || e.isDestroyed() || !e.getSessionId() || !e.hasRegisteredActions() || i());
  }
  function K() {
    a !== void 0 && (r(a), a = void 0);
  }
  function b() {
    if (M <= 0) return 0;
    const Y = Math.min(M - 1, t.backoffMs.length - 1);
    return t.backoffMs[Y];
  }
  function D(Y) {
    if (I > Y)
      return I - Y;
    if (u) {
      if (v > 0) {
        const Q = Y - v;
        if (Q < t.activeIntervalMs)
          return t.activeIntervalMs - Q;
      }
      return 0;
    }
    if (Y < h) {
      if (v > 0) {
        const Q = Y - v;
        if (Q < t.activeIntervalMs)
          return t.activeIntervalMs - Q;
      }
      return 0;
    }
    if (v > 0) {
      const Q = Y - v;
      if (Q < t.idleIntervalMs)
        return t.idleIntervalMs - Q;
    }
    return t.idleIntervalMs;
  }
  function T() {
    if (K(), o || e.isDestroyed() || !N()) return;
    if (l) {
      d = !0;
      return;
    }
    const Y = n(), Q = D(Y);
    a = s(() => {
      a = void 0, U();
    }, Math.max(0, Q));
  }
  async function U() {
    var Y;
    if (!(o || e.isDestroyed()) && N()) {
      if (l) {
        d = !0;
        return;
      }
      l = !0, u = !1, v = n();
      try {
        await e.poll(), M = 0, I = 0;
      } catch (Q) {
        M += 1;
        const oe = b();
        I = n() + oe, (Y = e.onError) == null || Y.call(e, Q);
      } finally {
        l = !1, d && (d = !1, u = !0), T();
      }
    }
  }
  function S() {
    if (o || e.isDestroyed()) return;
    const Y = n();
    if (h = Math.max(h, Y + t.activeWindowMs), u = !0, l) {
      d = !0;
      return;
    }
    T();
  }
  function O(Y, Q) {
    if (!(o || e.isDestroyed())) {
      if (Y <= 0 && Q > 0) {
        e.getSessionId() && S();
        return;
      }
      Y > 0 && Q <= 0 && (K(), u = !1, d = !1);
    }
  }
  function j() {
    if (!(o || e.isDestroyed())) {
      if (i()) {
        K();
        return;
      }
      S();
    }
  }
  return x = (e.addVisibilityListener || ((Y) => typeof document > "u" ? () => {
  } : (document.addEventListener("visibilitychange", Y), () => document.removeEventListener("visibilitychange", Y))))(j), {
    notifyActivity: S,
    notifyActionsChanged: O,
    destroy() {
      o = !0, K(), u = !1, d = !1, x == null || x(), x = void 0;
    },
    isInFlight() {
      return l;
    }
  };
}
const id = 380, od = 560, ad = 320, ld = 360, je = 12, ii = 18;
let cd = 0;
function ud(e) {
  const t = e.position || "inline", n = t !== "inline", s = e.resizable !== !1, r = n && e.launcherDraggable !== !1, i = e.locale === "en-US", o = `reachai-chat-panel-${++cd}`, a = document.createElement("div");
  a.className = "eaf-chat", a.dataset.launcherState = "thinking", a.dataset.position = t, n && a.classList.add(`eaf-chat--${t}`), s || a.classList.add("eaf-chat--resize-disabled");
  const l = i ? `Open ${e.brandName}` : `打开${e.brandName}`, d = i ? `Minimize ${e.brandName}` : `最小化${e.brandName}`, u = i ? "Resize conversation" : "调整对话框大小";
  a.innerHTML = `
    <section id="${o}" class="eaf-chat__panel" aria-label="${Rt(e.brandName)}">
      <div class="eaf-chat__header">
        <div class="eaf-chat__brand">${Rt(e.brandName)}</div>
        <div class="eaf-chat__header-actions">
          <span class="eaf-chat__connection-status" role="status" aria-live="polite">${i ? "Connecting" : "正在连接"}</span>
          <button
            class="eaf-chat__toggle eaf-chat__minimize"
            type="button"
            aria-label="${Rt(d)}"
            title="${Rt(d)}"
            aria-controls="${o}"
            aria-expanded="true"
          ><span aria-hidden="true"></span></button>
        </div>
      </div>
      <div class="eaf-chat__body"></div>
      <button
        class="eaf-chat__resize-handle"
        type="button"
        aria-label="${Rt(u)}"
        title="${Rt(u)}"
      ><span aria-hidden="true"></span></button>
    </section>
    <div class="eaf-chat__launcher-wrap">
      <span class="eaf-chat__launcher-label">${Rt(e.brandName)}</span>
      <button
        class="eaf-chat__launcher"
        type="button"
        aria-label="${Rt(l)}"
        aria-controls="${o}"
        aria-expanded="false"
      >
        <span class="eaf-chat__launcher-orbit eaf-chat__launcher-orbit--back" aria-hidden="true"></span>
        <span class="eaf-chat__launcher-prism" aria-hidden="true"></span>
        <span class="eaf-chat__launcher-glass" aria-hidden="true"></span>
        <span class="eaf-chat__launcher-orbit" aria-hidden="true"></span>
        <span class="eaf-chat__launcher-particle" aria-hidden="true"></span>
        <span class="eaf-chat__launcher-badge" aria-hidden="true">1</span>
        <span class="eaf-chat__launcher-error" aria-hidden="true">!</span>
      </button>
    </div>
  `, e.mount.appendChild(a);
  const h = bt(a, ".eaf-chat__panel"), v = bt(a, ".eaf-chat__header"), M = bt(a, ".eaf-chat__body"), I = bt(a, ".eaf-chat__connection-status"), x = bt(a, ".eaf-chat__minimize"), N = bt(a, ".eaf-chat__resize-handle"), K = bt(a, ".eaf-chat__launcher-wrap"), b = bt(a, ".eaf-chat__launcher"), D = bt(a, ".eaf-chat__launcher-label");
  let T = t === "bottom-left" ? "north-east" : t === "bottom-right" ? "north-west" : "south-east";
  N.dataset.resizeAnchor = T, N.hidden = !s, b.classList.toggle("eaf-chat__launcher--draggable", r), a.classList.toggle("eaf-chat--panel-draggable", n);
  let U = e.initialOpen !== !1, S = !1, O = "thinking", j = null, H = null, B = null, se = !1, ne = "", ae = "";
  function Y() {
    a.classList.toggle("eaf-chat--closed", !U), a.dataset.open = U ? "true" : "false", h.hidden = !U, h.setAttribute("aria-hidden", U ? "false" : "true"), K.hidden = U, b.setAttribute("aria-expanded", U ? "true" : "false"), x.setAttribute("aria-expanded", U ? "true" : "false");
  }
  function Q(p, w = !0) {
    var _;
    S || U === p || (U = p, Y(), U && w && ((_ = e.onOpen) == null || _.call(e)));
  }
  function oe(p) {
    O = p, a.dataset.launcherState = p;
    const w = p === "thinking" ? i ? "connecting" : "正在连接" : p === "unread" ? i ? "new message" : "有新消息" : p === "error" ? i ? "connection error" : "连接异常" : "", _ = w ? i ? `${l} (${w})` : `${l}（${w}）` : l;
    b.setAttribute("aria-label", _), b.title = _, D.textContent = p === "error" ? i ? `${e.brandName} · Connection error` : `${e.brandName} · 连接异常` : p === "unread" ? i ? `${e.brandName} · New message` : `${e.brandName} · 有新消息` : e.brandName;
  }
  function re() {
    const p = h.getBoundingClientRect(), w = p.width || oi(a, "--reachai-chat-user-width") || id, _ = p.height || oi(a, "--reachai-chat-user-height") || od;
    return { width: w, height: _ };
  }
  function te() {
    return n && Number.isFinite(Number.parseFloat(h.style.left)) && Number.isFinite(Number.parseFloat(h.style.top));
  }
  function Ie(p, w) {
    if (!n) return;
    const _ = h.getBoundingClientRect(), P = re(), A = _.width || P.width, z = _.height || P.height, F = Math.max(je, window.innerWidth - A - je), W = Math.max(je, window.innerHeight - z - je), J = Bt(p, je, F), ie = Bt(w, je, W);
    h.style.right = "auto", h.style.bottom = "auto", h.style.left = `${Math.round(J)}px`, h.style.top = `${Math.round(ie)}px`, a.classList.add("eaf-chat--user-positioned");
  }
  function Xe() {
    const p = e.mount.getBoundingClientRect(), w = n ? window.innerWidth - je * 2 : p.width || window.innerWidth, _ = n ? window.innerHeight - je * 2 : p.height || window.innerHeight, P = Math.max(240, w), A = Math.max(260, _);
    return {
      minWidth: Math.min(ad, P),
      minHeight: Math.min(ld, A),
      maxWidth: P,
      maxHeight: A
    };
  }
  function Ee(p, w) {
    const _ = Xe(), P = Math.round(Bt(p, _.minWidth, _.maxWidth)), A = Math.round(Bt(w, _.minHeight, _.maxHeight));
    return a.style.setProperty("--reachai-chat-user-width", `${P}px`), a.style.setProperty("--reachai-chat-user-height", `${A}px`), a.classList.add("eaf-chat--user-sized"), N.setAttribute(
      "aria-label",
      i ? `${u}, current ${P} by ${A}` : `${u}，当前 ${P} × ${A}`
    ), { width: P, height: A };
  }
  function de(p) {
    if (!j || p.pointerId !== j.pointerId) return;
    const w = p.clientX - j.startX, _ = p.clientY - j.startY, P = j.width + (T.includes("west") ? -w : w), A = j.height + (T.includes("north") ? -_ : _), z = Ee(P, A);
    if (j.customPosition) {
      const F = j.left + (T.includes("west") ? j.width - z.width : 0), W = j.top + (T.includes("north") ? j.height - z.height : 0);
      Ie(F, W);
    }
    p.preventDefault();
  }
  function Te(p) {
    var _;
    if (!j || p && p.pointerId !== j.pointerId) return;
    const w = j.pointerId;
    j = null, a.classList.remove("eaf-chat--resizing"), document.body.style.userSelect = ne;
    try {
      (_ = N.hasPointerCapture) != null && _.call(N, w) && N.releasePointerCapture(w);
    } catch {
    }
  }
  function tt(p) {
    var P;
    if (!s || p.button !== 0 || B) return;
    const w = re(), _ = h.getBoundingClientRect();
    j = {
      pointerId: p.pointerId,
      startX: p.clientX,
      startY: p.clientY,
      width: w.width,
      height: w.height,
      left: _.left,
      top: _.top,
      customPosition: te()
    }, ne = document.body.style.userSelect, document.body.style.userSelect = "none", a.classList.add("eaf-chat--resizing"), N.focus({ preventScroll: !0 }), (P = N.setPointerCapture) == null || P.call(N, p.pointerId), p.preventDefault(), p.stopPropagation();
  }
  function De(p) {
    if (!s || !["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(p.key)) return;
    const w = p.shiftKey ? 40 : 16, _ = re();
    let P = _.width, A = _.height;
    const z = h.getBoundingClientRect(), F = te();
    p.key === "ArrowLeft" && (P += T.includes("west") ? w : -w), p.key === "ArrowRight" && (P += T.includes("west") ? -w : w), p.key === "ArrowUp" && (A += T.includes("north") ? w : -w), p.key === "ArrowDown" && (A += T.includes("north") ? -w : w);
    const W = Ee(P, A);
    if (F) {
      const J = z.left + (T.includes("west") ? _.width - W.width : 0), ie = z.top + (T.includes("north") ? _.height - W.height : 0);
      Ie(J, ie);
    }
    p.preventDefault();
  }
  function Fe(p) {
    return p instanceof Element && !!p.closest('button, a, input, textarea, select, [role="button"], [contenteditable="true"]');
  }
  function R(p) {
    var _;
    if (!n || !U || p.button !== 0 || p.isPrimary === !1 || j || Fe(p.target)) return;
    const w = h.getBoundingClientRect();
    B = {
      pointerId: p.pointerId,
      startX: p.clientX,
      startY: p.clientY,
      left: w.left,
      top: w.top,
      moved: !1
    }, ae = document.body.style.userSelect, document.body.style.userSelect = "none", a.classList.add("eaf-chat--panel-dragging"), (_ = v.setPointerCapture) == null || _.call(v, p.pointerId), p.preventDefault();
  }
  function L(p) {
    if (!B || p.pointerId !== B.pointerId) return;
    const w = p.clientX - B.startX, _ = p.clientY - B.startY;
    !B.moved && Math.hypot(w, _) > 3 && (B.moved = !0), B.moved && (Ie(B.left + w, B.top + _), p.preventDefault());
  }
  function C(p) {
    var _;
    if (!B || p && p.pointerId !== B.pointerId) return;
    const w = B.pointerId;
    B = null, a.classList.remove("eaf-chat--panel-dragging"), document.body.style.userSelect = ae;
    try {
      (_ = v.hasPointerCapture) != null && _.call(v, w) && v.releasePointerCapture(w);
    } catch {
    }
  }
  function m(p, w) {
    const _ = K.offsetWidth || 64, P = K.offsetHeight || 64, A = Math.max(je, window.innerWidth - _ - je), z = Math.max(je, window.innerHeight - P - je), F = Bt(p, je, A), W = Bt(w, je, z);
    K.style.right = "auto", K.style.bottom = "auto", K.style.left = `${Math.round(F)}px`, K.style.top = `${Math.round(W)}px`;
    const J = F + _ / 2 < window.innerWidth / 2;
    a.dataset.launcherDock = J ? "left" : "right", n && !te() && (T = J ? "north-east" : "north-west", N.dataset.resizeAnchor = T);
  }
  function g() {
    const p = K.getBoundingClientRect(), w = p.left + p.width / 2 < window.innerWidth / 2;
    m(
      w ? ii : window.innerWidth - p.width - ii,
      p.top
    );
  }
  function c(p) {
    var _;
    if (!r || p.button !== 0) return;
    const w = K.getBoundingClientRect();
    H = {
      pointerId: p.pointerId,
      startX: p.clientX,
      startY: p.clientY,
      left: w.left,
      top: w.top,
      moved: !1
    }, (_ = b.setPointerCapture) == null || _.call(b, p.pointerId), a.classList.add("eaf-chat--launcher-dragging");
  }
  function f(p) {
    if (!H || p.pointerId !== H.pointerId) return;
    const w = p.clientX - H.startX, _ = p.clientY - H.startY;
    !H.moved && Math.hypot(w, _) > 4 && (H.moved = !0), H.moved && (m(H.left + w, H.top + _), p.preventDefault());
  }
  function y(p) {
    var _;
    if (!H || p.pointerId !== H.pointerId) return;
    const w = H.moved;
    H = null, a.classList.remove("eaf-chat--launcher-dragging");
    try {
      (_ = b.hasPointerCapture) != null && _.call(b, p.pointerId) && b.releasePointerCapture(p.pointerId);
    } catch {
    }
    w && (g(), se = !0, window.setTimeout(() => {
      se = !1;
    }, 0));
  }
  function E() {
    if (se) {
      se = !1;
      return;
    }
    Q(!0);
  }
  function k() {
    const p = Number.parseFloat(K.style.left), w = Number.parseFloat(K.style.top);
    if (Number.isFinite(p) && Number.isFinite(w) && m(p, w), a.classList.contains("eaf-chat--user-sized")) {
      const A = re();
      Ee(A.width, A.height);
    }
    const _ = Number.parseFloat(h.style.left), P = Number.parseFloat(h.style.top);
    Number.isFinite(_) && Number.isFinite(P) && Ie(_, P);
  }
  return x.addEventListener("click", () => Q(!1)), v.addEventListener("pointerdown", R), b.addEventListener("click", E), b.addEventListener("pointerdown", c), b.addEventListener("pointermove", f), b.addEventListener("pointerup", y), b.addEventListener("pointercancel", y), N.addEventListener("pointerdown", tt), N.addEventListener("keydown", De), window.addEventListener("pointermove", de), window.addEventListener("pointermove", L), window.addEventListener("pointerup", Te), window.addEventListener("pointerup", C), window.addEventListener("pointercancel", Te), window.addEventListener("pointercancel", C), window.addEventListener("resize", k), Y(), oe(O), {
    root: a,
    panel: h,
    body: M,
    connectionStatus: I,
    minimizeButton: x,
    launcher: b,
    isOpen: () => U,
    open: () => Q(!0),
    close: () => Q(!1),
    toggle: () => Q(!U),
    setLauncherState: oe,
    destroy() {
      S || (S = !0, Te(), C(), window.removeEventListener("pointermove", de), window.removeEventListener("pointermove", L), window.removeEventListener("pointerup", Te), window.removeEventListener("pointerup", C), window.removeEventListener("pointercancel", Te), window.removeEventListener("pointercancel", C), window.removeEventListener("resize", k), a.remove());
    }
  };
}
function bt(e, t) {
  const n = e.querySelector(t);
  if (!n) throw new Error(`ReachAI embed shell element missing: ${t}`);
  return n;
}
function oi(e, t) {
  const n = Number.parseFloat(e.style.getPropertyValue(t));
  return Number.isFinite(n) ? n : 0;
}
function Bt(e, t, n) {
  return Math.min(Math.max(e, t), n);
}
function Rt(e) {
  return e.replace(/[<>&"']/g, (t) => ({
    "<": "&lt;",
    ">": "&gt;",
    "&": "&amp;",
    '"': "&quot;",
    "'": "&#39;"
  })[t] || t);
}
const an = {
  "tech-purple": { primary: "#6366f1", rgb: "99 102 241" },
  "metro-green": { primary: "#0b7a59", rgb: "11 122 89" },
  "aurora-cyan": { primary: "#0891b2", rgb: "8 145 178" },
  "nebula-violet": { primary: "#7c3aed", rgb: "124 58 237" },
  "coral-rose": { primary: "#db2777", rgb: "219 39 119" },
  "solar-gold": { primary: "#b45309", rgb: "180 83 9" },
  "deep-ocean": { primary: "#1d4ed8", rgb: "29 78 216" }
}, ai = "tech-purple";
function fd(e) {
  const t = String((e == null ? void 0 : e.primaryColor) || "").trim();
  if (t)
    return {
      primary: t,
      rgb: dd(t) || an[ai].rgb,
      source: "primaryColor"
    };
  const n = String((e == null ? void 0 : e.preset) || "").trim();
  if (n && n in an) {
    const r = an[n];
    return { primary: r.primary, rgb: r.rgb, source: "preset" };
  }
  const s = an[ai];
  return { primary: s.primary, rgb: s.rgb, source: "default" };
}
function dd(e) {
  const t = e.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);
  if (t) {
    const s = t[1];
    return s.length === 3 ? [
      parseInt(s[0] + s[0], 16),
      parseInt(s[1] + s[1], 16),
      parseInt(s[2] + s[2], 16)
    ].join(" ") : [
      parseInt(s.slice(0, 2), 16),
      parseInt(s.slice(2, 4), 16),
      parseInt(s.slice(4, 6), 16)
    ].join(" ");
  }
  const n = e.match(/^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
  return n ? `${Number(n[1])} ${Number(n[2])} ${Number(n[3])}` : null;
}
function hd(e, t) {
  const n = fd({
    preset: t == null ? void 0 : t.preset,
    primaryColor: t == null ? void 0 : t.primaryColor
  });
  e.style.setProperty("--reachai-chat-primary", n.primary), e.style.setProperty("--reachai-chat-spectrum-anchor", n.primary), e.style.setProperty("--reachai-chat-primary-rgb", n.rgb), t != null && t.preset && t.preset in an ? e.dataset.chatPreset = t.preset : n.source === "default" ? e.dataset.chatPreset = "tech-purple" : delete e.dataset.chatPreset;
}
async function Ad(e) {
  var R, L;
  if (!e.agentId) throw new Error("agentId is required");
  const t = typeof e.mount == "string" ? document.querySelector(e.mount) : e.mount;
  if (!t) throw new Error("mount element not found");
  const n = e.bridge || Ss({ route: location.pathname }), s = vd(e.apiBase, e.embedPathPrefix), r = wd(e.apiBase), i = e.locale || "zh-CN";
  let o = "", a = { ...e.context || {} };
  const l = /* @__PURE__ */ new Set(), d = /* @__PURE__ */ new Set(), u = /* @__PURE__ */ new Map(), h = /* @__PURE__ */ new Map(), v = /* @__PURE__ */ new Set();
  let M, I = !1, x = null, N = null, K = !1, b = n.registeredActions.length;
  function D(C, m = {}) {
    var f;
    const c = String((C && typeof C == "object" ? C : {}).requestId || "");
    if (c) {
      if (v.has(c)) return !1;
      v.add(c);
    }
    return (f = e.onEvent) == null || f.call(e, {
      type: "page.action.requested",
      data: C,
      sessionId: m.sessionId,
      turnId: m.turnId
    }), !0;
  }
  function T(C, m, g) {
    if (!I) {
      if (!m) {
        j(new Error("Page action requires an active embed session; no sessionId available"));
        return;
      }
      Bn({
        request: C,
        bridge: n,
        sessionId: m,
        apiBase: s,
        token: o,
        handledPageActions: d,
        inFlightPageActions: u,
        pendingPageActionResults: h,
        responseMetadata: g,
        onRequested: (c) => D(c, { sessionId: m }),
        onError: j,
        refreshToken: async () => (await tt(), o)
      }).catch(j);
    }
  }
  function U(C) {
    if (C.sessionId) return C.sessionId;
    const m = C.data && typeof C.data == "object" ? C.data : {};
    return m.sessionId != null && String(m.sessionId) ? String(m.sessionId) : (N == null ? void 0 : N.getExistingSessionId()) || (N == null ? void 0 : N.getSessionId()) || void 0;
  }
  function S(C) {
    var m, g;
    if (C.type === "page.action.requested") {
      const c = D(C.data, {
        sessionId: C.sessionId,
        turnId: C.turnId
      });
      T(
        C.data,
        U(C),
        C.data && typeof C.data == "object" ? C.data.metadata : void 0
      ), c && B.notifyActivity();
      return;
    }
    if (C.type === "message.completed") {
      const c = C.data;
      Y && !Y.isOpen() && (ae = !0, Q());
      for (const f of Ls(c))
        D(f, { sessionId: c.sessionId, turnId: c.turnId });
      (m = e.onEvent) == null || m.call(e, C), O(c).catch(j), B.notifyActivity();
      return;
    }
    (g = e.onEvent) == null || g.call(e, C);
  }
  async function O(C) {
    if (!C || I) return;
    const m = C.sessionId || (N == null ? void 0 : N.getExistingSessionId()) || (N == null ? void 0 : N.getSessionId()), g = Ls(C);
    if (!m) {
      g.length > 0 && j(new Error("Page action requires an active embed session; no sessionId available"));
      return;
    }
    await Zf({
      response: C,
      bridge: n,
      sessionId: m,
      apiBase: s,
      token: o,
      handledPageActions: d,
      inFlightPageActions: u,
      pendingPageActionResults: h,
      onRequested: (c) => D(c, { sessionId: m }),
      onError: j,
      refreshToken: async () => (await tt(), o)
    });
  }
  function j(C) {
    var g;
    const m = { message: C instanceof Error ? C.message : String(C), cause: C };
    (g = e.onError) == null || g.call(e, m);
  }
  async function H() {
    if (I) return;
    const C = N == null ? void 0 : N.getExistingSessionId();
    C && await nd({
      apiBase: s,
      token: o,
      sessionId: C,
      bridge: n,
      handledPageActions: d,
      pendingPageActions: l,
      inFlightPageActions: u,
      pendingPageActionResults: h,
      context: a,
      // poll 自己已 dispatch；此处只 publish，禁止再走 emitPublicEvent→dispatch 递归
      onEvent: (m) => {
        m.type === "page.action.requested" && D(m.data, { sessionId: C });
      },
      onError: j,
      refreshToken: async () => (await tt(), o)
    });
  }
  const B = rd({
    getSessionId: () => (N == null ? void 0 : N.getExistingSessionId()) || null,
    hasRegisteredActions: () => n.registeredActions.length > 0,
    isDestroyed: () => I,
    poll: H,
    onError: j
  });
  let se = "loading", ne = !1, ae = !1, Y;
  function Q() {
    Y && Y.setLauncherState(
      se === "error" ? "error" : se === "loading" || ne ? "thinking" : ae ? "unread" : "idle"
    );
  }
  Y = ud({
    mount: t,
    position: e.position,
    initialOpen: e.initialOpen,
    brandName: ((R = e.theme) == null ? void 0 : R.brandName) || "ReachAI",
    locale: i,
    resizable: e.resizable,
    launcherDraggable: e.launcherDraggable,
    onOpen: () => {
      ae = !1, Q(), B.notifyActivity();
    }
  });
  const { root: oe, body: re, connectionStatus: te } = Y;
  hd(oe, e.theme);
  function Ie(C) {
    var m, g;
    se = C.status, oe.dataset.authState = C.status, te.hidden = C.status === "ready", te.classList.toggle("is-error", C.status === "error"), te.textContent = C.status === "loading" ? i === "en-US" ? "Connecting" : "正在连接" : C.status === "error" ? i === "en-US" ? "Connection failed" : "连接失败" : "", Q();
    try {
      (m = e.onStateChange) == null || m.call(e, C);
    } catch (c) {
      try {
        (g = e.onError) == null || g.call(e, {
          message: "ReachAI state callback failed",
          cause: c,
          code: "STATE_CALLBACK_FAILED",
          phase: "token",
          retryable: !1
        });
      } catch {
      }
    }
  }
  x = Ns(To, {
    apiBase: s,
    tokenProvider: e.tokenProvider,
    tokenTimeoutMs: e.tokenTimeoutMs,
    bridge: n,
    page: e.page,
    context: a,
    locale: i,
    placeholder: i === "zh-CN" ? "输入消息" : "Type a message",
    preferStream: e.stream !== !1,
    onEvent: S,
    onError: (C) => {
      var m;
      return (m = e.onError) == null ? void 0 : m.call(e, C);
    },
    onAuthStateChange: Ie,
    onTokenChanged: (C) => {
      o = C;
    },
    onSessionChanged: () => {
      B.notifyActivity();
    }
  }), N = x.mount(re);
  const Xe = n.onActionDefinitionsChange(() => {
    de();
    const C = n.registeredActions.length;
    B.notifyActionsChanged(b, C), b = C;
  });
  de(0);
  function Ee(C) {
    var g;
    const m = { message: C instanceof Error ? C.message : String(C), cause: C };
    (g = e.onError) == null || g.call(e, m);
  }
  function de(C = 250) {
    !e.pageRegistry || e.pageRegistry.registerOnStart === !1 || !e.page || (M && window.clearTimeout(M), M = window.setTimeout(() => {
      M = void 0, Te().catch(Ee);
    }, C));
  }
  async function Te() {
    I || await pd(r, e, n);
  }
  async function tt() {
    if (!N) throw new Error("Embed chat host is not ready");
    o = await N.refreshToken("page-action");
  }
  async function De(C) {
    const m = C.trim();
    if (!m || !N || I) return {};
    if (K) throw new Error("Another message is still in flight");
    K = !0, ne = !0, Q(), B.notifyActivity();
    try {
      const g = await N.sendMessage(m);
      return await O(g), B.notifyActivity(), g;
    } catch (g) {
      throw j(g), g;
    } finally {
      K = !1, ne = !1, Q();
    }
  }
  const Fe = {
    bridge: n,
    get sessionId() {
      return (N == null ? void 0 : N.getSessionId()) || null;
    },
    open() {
      Y.open();
    },
    close() {
      Y.close();
    },
    toggle() {
      Y.toggle();
    },
    send: De,
    async retry() {
      !N || I || (o = await N.retryAuthentication());
    },
    registerPageCatalog: Te,
    setContext(C) {
      a = { ...a, ...C || {} }, N == null || N.setContext(C || {});
    },
    destroy() {
      I = !0, B.destroy(), Xe(), M && window.clearTimeout(M), N == null || N.disposeHost(), x == null || x.unmount(), x = null, N = null, Y.destroy();
    }
  };
  return typeof process < "u" && ((L = process.env) != null && L.VITEST) && Object.assign(Fe, {
    __emitPublicEventForTests: S
  }), Fe;
}
async function pd(e, t, n) {
  const s = t.pageRegistry, r = t.page;
  !s || s.registerOnStart === !1 || !r || !s.projectCode || !s.appKey || !s.appSecret || await md(
    `${e}/api/registry/projects/${encodeURIComponent(s.projectCode)}/pages/register`,
    {
      pageKey: r.pageKey,
      name: r.name || r.pageKey,
      routePattern: r.routePattern || n.route || location.pathname,
      origin: r.origin || location.origin,
      pageInstanceId: n.pageInstanceId,
      replaceActions: !0,
      actions: n.actionDefinitions.map(gd),
      metadata: r.metadata || {}
    },
    s
  );
}
function gd(e) {
  return {
    actionKey: e.actionKey,
    title: e.title || e.actionKey,
    description: e.description || "",
    confirmRequired: e.confirmRequired === !0,
    inputSchema: e.inputSchema || {},
    outputSchema: e.outputSchema || {},
    sampleArgs: e.sampleArgs || {},
    allowedAgentIds: e.allowedAgentIds || [],
    metadata: e.metadata || {}
  };
}
async function md(e, t, n) {
  const s = String(Date.now()), r = bd(), i = await yd(n.appSecret, `${n.projectCode}
${s}
${r}`), o = await fetch(e, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-ReachAI-App-Key": n.appKey,
      "X-ReachAI-Timestamp": s,
      "X-ReachAI-Nonce": r,
      "X-ReachAI-Signature": i
    },
    body: JSON.stringify(t)
  }), a = await o.json().catch(() => ({}));
  if (!o.ok || a.code && a.code !== 200 && a.code !== 0)
    throw _d(a.message || `Page catalog registration failed: ${o.status}`, o.status);
  return a.data ?? a;
}
async function yd(e, t) {
  if (!(crypto != null && crypto.subtle))
    throw new Error("Web Crypto API is required for ReachAI page catalog registration");
  const n = new TextEncoder(), s = await crypto.subtle.importKey(
    "raw",
    n.encode(e),
    { name: "HMAC", hash: "SHA-256" },
    !1,
    ["sign"]
  ), r = await crypto.subtle.sign("HMAC", s, n.encode(t));
  return Array.from(new Uint8Array(r)).map((i) => i.toString(16).padStart(2, "0")).join("");
}
function bd() {
  return typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}
function _d(e, t) {
  const n = new Error(e);
  return n.status = t, n;
}
function vd(e, t) {
  const n = En((e || "").trim());
  if (t !== void 0) {
    const s = ur(t || "/api/embed");
    return li(Sd(n, s), s);
  }
  return Oo(n) ? n : li(n, "/api/embed");
}
function wd(e) {
  const t = En((e || "").trim());
  return t ? Oo(t) ? t.replace(/\/api\/(?:reachai\/)?embed$/i, "") : t : "";
}
function li(e, t) {
  const n = En(e), s = ur(t);
  return n ? s ? `${n}${s}` : n : s || "";
}
function Sd(e, t) {
  const n = ur(t);
  return !e || !n ? e : e.toLowerCase().endsWith(n.toLowerCase()) ? En(e.slice(0, -n.length)) : e;
}
function ur(e) {
  const t = En((e || "").trim());
  return t ? t.startsWith("/") ? t : `/${t}` : "";
}
function Oo(e) {
  return /\/api\/(?:reachai\/)?embed$/i.test(e);
}
function En(e) {
  return e.endsWith("/") ? e.slice(0, -1) : e;
}
const Id = /* @__PURE__ */ gt({
  __name: "ReachAiChatElement.ce",
  props: {
    apiBase: { default: "/api/embed", type: String },
    token: { default: "", type: String },
    pageKey: { type: String },
    route: { type: String },
    placeholder: { default: "输入消息", type: String }
  },
  setup(e) {
    const t = e, n = /* @__PURE__ */ Se(!1), s = /* @__PURE__ */ Se(Ss()), r = /* @__PURE__ */ Se(void 0), i = /* @__PURE__ */ Se({});
    function o() {
      return t.token;
    }
    async function a() {
      return t.token;
    }
    return ss(() => {
      s.value = Ss({
        route: t.route || (typeof location < "u" ? location.pathname : "/")
      }), t.pageKey && (r.value = { pageKey: t.pageKey }), n.value = !0;
    }), (l, d) => n.value ? ($(), mt(To, {
      key: 0,
      "api-base": e.apiBase,
      "token-provider": o,
      bridge: s.value,
      page: r.value,
      context: i.value,
      placeholder: e.placeholder,
      "on-unauthorized": a
    }, null, 8, ["api-base", "bridge", "page", "context", "placeholder"])) : Z("", !0);
  }
});
let ws = !1;
function xd(e = "reachai-chat") {
  if (!(ws || typeof customElements > "u")) {
    if (customElements.get(e)) {
      ws = !0;
      return;
    }
    customElements.define(e, /* @__PURE__ */ tc(Id)), ws = !0;
  }
}
export {
  an as EAF_CHAT_THEME_PRESETS,
  ti as buildEafChatSessionPayload,
  Ad as createEafChat,
  Ss as createEafPageBridge,
  xd as defineReachAiChatElement,
  vd as resolveEafChatEmbedApiRoot,
  wd as resolveEafChatPlatformBase,
  fd as resolveEafChatThemePrimary
};
